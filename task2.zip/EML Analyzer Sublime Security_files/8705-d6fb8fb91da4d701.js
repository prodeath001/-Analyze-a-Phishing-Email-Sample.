"use strict";(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[8705],{8705:(A,e,t)=>{t.r(e),t.d(e,{__N_SSP:()=>e4,default:()=>e5});var a=t(37876),i=t(68268),s=t(7766),n=t.n(s),o=t(89099),d=t(8710),r=t(14232),f=t(75625),l=t(90746),c=t(66937),g=t(23158),p=t(49092);function b(A){let e,{isOpen:t,onClose:i,selectedRule:s,ruleId:n,initialType:o,isLoading:d,onSubmit:r}=A,{watch:l}=(0,f.xW)(),b=l("type"),m=!!n&&!!s;return e=(0,g.e)(b)?`${m?"Save":"Create"} Automation`:`${m?"Save":"Create"} Rule`,(0,a.jsx)(c.a,{"data-testid":n?"edit-rule-modal":"create-rule-modal",size:"2xl",isOpen:t,onClose:i,header:e,isLoading:d,actions:(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(c.a.CloseAction,{children:"Cancel"}),(0,a.jsx)(c.a.Action,{isLoading:d,onClick:r,children:e})]}),children:(0,a.jsx)(p.n4,{editing:!!(s&&n),selectedRuleType:s?.type??o})})}var m=t(48720),u=t(10841),D=t.n(u),h=t(53556),B=t(84030),x=t(66726),C=t(76327),I=t(14038),Q=t(20438);function E(A){let{canCopyToClipboard:e,isBuildModalOpen:t,onCloseBuildModal:i,onCopyAsCurl:s,onUploadNewEml:n,onOpenBuildModal:o,selectedFileName:d}=A;return(0,a.jsxs)("div",{className:"w-full @container",children:[(0,a.jsxs)("div",{className:"flex w-full flex-col flex-nowrap items-start justify-between gap-2 @sm:flex-row",id:"eml-filename",children:[(0,a.jsxs)("div",{className:"flex grow gap-3",children:[(0,a.jsx)("div",{className:"flex size-9 shrink-0 items-center justify-center rounded-full bg-gray-200",children:(0,a.jsx)(h.GlS,{color:"functional.icon.default",fontSize:"20px"})}),(0,a.jsxs)("div",{className:"flex grow flex-col",children:[(0,a.jsx)(x.EY,{variant:"bodySmall",color:"functional.text.weak",textTransform:"uppercase",children:"File Name"}),(0,a.jsx)("div",{className:"grow",children:(0,a.jsx)(I.G,{lines:1,"data-record":"false",wordBreak:"break-word",children:d})})]})]}),(0,a.jsxs)("div",{className:"flex flex-wrap justify-end gap-2",children:[(0,a.jsx)(C.m,{disabled:e,content:"Copy as cURL is only supported over HTTPS connections due to browser limitations.",children:(0,a.jsx)("div",{className:"flex",children:(0,a.jsx)(B.$n,{variant:"secondary",onClick:s,isDisabled:!e,children:"Copy as cURL"})})}),(0,a.jsx)(B.$n,{variant:"secondary",onClick:n,children:"Upload different .EML file"}),(0,a.jsx)(B.$n,{variant:"secondary",onClick:o,rightIcon:(0,a.jsx)(h.N1U,{}),children:"Build new EML"})]})]}),(0,a.jsx)(Q.Yx,{isOpen:t,onClose:i})]})}let y=()=>(0,a.jsxs)("div",{className:"mb-1 flex flex-row items-center gap-2",children:[(0,a.jsx)("div",{className:"mb-0.5 flex size-5 items-center",children:(0,a.jsx)(h.KFi,{})}),(0,a.jsx)(x.EY,{className:"text-left text-fn-text-weak",children:"Click “View Contents” to show all insights and matching rules."})]});var w=t(85673);function v(A){return A.loading?(0,a.jsxs)("div",{className:"flex items-center gap-2","data-testid":"loading-spinner",children:[(0,a.jsx)(w.y,{size:"xs"})," ",(0,a.jsx)("div",{className:"text-fn-bodySmall",children:"Loading queries..."})]}):null}var k=t(42602),j=t(57219),F=t(53580),S=t(18349),M=t(42166),R=t(78651),T=t(96742),N=t(24316);function P(A){let{mdm:e}=A,{error:t,refetch:i,data:s,isFetching:n}=(0,j.E)({mdm:e});if(t&&!(0,N.TR)())return(0,a.jsx)("div",{className:"w-full",children:(0,a.jsx)(T.J,{justifyContent:"left",width:"full",error:s?.error,name:"Attack Score",height:"100%",refetch:i})});let o=!n&&(s?.top_signals??[]).length>0;return(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)("div",{className:"flex items-center gap-1",children:[(0,a.jsx)("div",{className:"text-fn-h5",children:"Attack Score Verdict"}),(0,a.jsx)(F.q,{trigger:(0,a.jsx)("button",{children:(0,a.jsx)(h.Rtb,{})})})]}),(0,M.R)()?(0,a.jsx)(x.EY,{className:"italic",variant:"bodySmall",children:R.K6}):n?(0,a.jsx)("div",{className:"mt-1",children:(0,a.jsx)(v,{loading:n})}):(0,a.jsx)("div",{className:"mt-1",children:(0,a.jsx)(S.H,{verdict:s?.verdict})}),!!o&&(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)("div",{className:"text-fn-h5",children:"Attack Score Signals"}),(0,a.jsx)("div",{className:"pr-1",children:(0,a.jsx)(k.fh,{className:"flex flex-col gap-4",children:s?.top_signals?.slice(0,R.tf).map(A=>(0,a.jsx)(U,{...A},A.description))})})]})]})}function U(A){let{description:e,category:t}=A;return(0,a.jsxs)("div",{className:"shrink",children:[(0,a.jsx)(x.EY,{fontSize:"sm",color:"base.gray.700",fontWeight:600,flexShrink:0,children:t}),(0,a.jsx)(x.EY,{fontSize:"sm",padding:0,whiteSpace:"pre-line",children:e})]},e)}var V=t(99312),X=t(10853),H=t(84577),G=t(94814),J=t(56264),z=t(4430),L=t(79238);let O=A=>{let{item:e,isSandbox:t}=A,{feed:i,name:s,active:n=!1,isNewRule:o,link:d,source:r,description:f,severity:l}=e,{isOpen:c,onToggle:g}=(0,z.j1)({defaultIsOpen:!1}),p=(0,L.Qi)({active:n,isNewRule:o}),{mdm:b,justifyNeeded:m,requiresJustificationMsg:u,justificationId:D}=(0,Q.mt)(),B=t?(0,a.jsx)("div",{}):(0,a.jsx)(V.W,{testId:"feed-rule-item-status",active:n,tooltip:t?"":p,className:(0,z.cn)(o&&"bg-gray-600")});return t||!d||0===d.length?(0,a.jsxs)("div",{className:"flex items-center gap-1.5","data-testid":"feed-rule-item",children:[B,(0,a.jsx)("div",{children:(0,a.jsx)(X.r,{hideIfNull:!0,iconProps:{display:"flex"},severity:l,showTooltip:!0})}),(0,a.jsx)(C.m,{content:f,side:"top",children:(0,a.jsx)("div",{className:"truncate text-fn-bodyMedium",children:s})})]}):(0,a.jsx)("div",{className:"flex flex-col gap-2",children:(0,a.jsxs)(H.S.Root,{open:c,children:[(0,a.jsxs)("div",{className:"inline-flex items-center gap-1.5","data-testid":"feed-rule-item",children:[(0,a.jsx)(H.S.Trigger,{asChild:!0,children:(0,a.jsx)("button",{onClick:g,className:"flex size-4 shrink-0 items-center justify-center rounded-full border border-fn-layout-borderWeak text-[9px] text-fn-icon-default",children:c?(0,a.jsx)(h.h5v,{}):(0,a.jsx)(h.nLb,{})})}),B,(0,a.jsx)("div",{children:(0,a.jsx)(X.r,{hideIfNull:!0,iconProps:{display:"flex"},severity:l,showTooltip:!0})}),(0,a.jsx)(G.N,{"data-testid":"feed-rule-item-name",target:"_blank",href:d,variant:"unstyled",className:"group/link flex py-0.5 text-fn-bodyMedium text-fn-text-link",children:(0,a.jsxs)("div",{className:"flex items-center gap-2",children:[(0,a.jsx)("span",{className:"shrink-0 text-fn-bodyMedium group-hover/link:underline",children:s}),(0,a.jsx)(J.C,{feed:i})]})})]}),(0,a.jsx)(H.S.Content,{animateOpacity:!0,children:(0,a.jsx)("div",{className:"min-h-16 pl-6",children:(0,a.jsx)(Q.K1,{isVisible:c,mdm:b,ruleSource:r,justificationId:D,requiresJustificationExplanation:u,justificationNeeded:m})})})]})})};var Z=t(82851),W=t.n(Z),Y=t(6207),q=t(68627),K=t(8413),_=t(67989),$=t(65744);let AA=()=>(0,a.jsxs)("div",{className:"flex items-center gap-1","data-testid":"loading-spinner",children:[(0,a.jsx)(w.y,{size:"xs"})," ",(0,a.jsx)("div",{className:"text-fn-bodySmall",children:"Loading history..."})]}),Ae=A=>{let{loading:e,historyInfo:t}=A,{messageGroup:i}=(0,Q.mt)(),{canSearch:s}=(0,K.V)(),n=(0,r.useMemo)(()=>W().keyBy(i?.dataModel?.attachments,"sha256"),[i?.dataModel?.attachments]),o=(0,r.useMemo)(()=>t?.attachments?t.attachments.map(A=>{let e=n[A.sha256]?.file_name??"<no name>";return{...A,name:e}}):[],[t,n]),d=t?.sender_email?.matching_message_groups??0,f=t?.sender_email?.first_seen_at,l=t?.subject?.matching_message_groups??0,c=t?.subject?.first_seen_at,g=i?.subject??"",p=i?.sender?.email??"",b=i?.firstCreatedAt,m=0===d||!s,u=0===l||!s;return(0,a.jsxs)("div",{className:"flex flex-col gap-2",children:[(0,a.jsx)("div",{className:"text-fn-h5",children:"Related History"}),(0,a.jsxs)("div",{className:"flex flex-col gap-1",children:[!e&&(0,a.jsxs)("div",{className:"text-fn-bodyMedium",children:["Messages from this sender:"," ",(0,a.jsx)(G.N,{variant:"unstyled",href:(0,Y.j)(p,b),target:"_blank",disabled:m,className:(0,z.cn)(!m&&"text-fn-text-link"),children:d})," ",!!f&&(0,a.jsxs)("span",{className:"text-fn-text-weak",children:["(first seen ",(0,$.Yq)(f),")"]})]}),!e&&(0,a.jsxs)("div",{className:"text-fn-bodyMedium",children:["Messages with this subject:"," ",(0,a.jsx)(G.N,{variant:"unstyled",href:(0,Y.UK)(g,b),target:"_blank",disabled:u,className:(0,z.cn)(!u&&"text-fn-text-link"),children:d})," ",!!c&&(0,a.jsxs)("span",{className:"text-fn-text-weak",children:["(first seen ",(0,$.Yq)(c),")"]})]}),(0,a.jsx)(At,{firstCreatedAt:b,canSearch:s,attachments:o}),!!e&&(0,a.jsx)(AA,{})]})]})},At=A=>{let{attachments:e=[],canSearch:t=!1,firstCreatedAt:i}=A,[s,n]=(0,r.useState)(!0);return(0,a.jsxs)(a.Fragment,{children:[W().take(e,s?3:e.length).map(A=>(0,a.jsx)(q.i,{canSearch:t,firstCreatedAt:i,attachment:A},A.sha256)),e.length>3&&(0,a.jsx)("button",{className:"text-start text-fn-bodyMedium text-fn-text-link",onClick:()=>{n(A=>!A)},children:s?`see ${e.length-3} more...`:"see less"})]})},Aa=()=>{let{messageId:A}=(0,Q.mt)(),e=(0,N.YF)(),{data:t,isLoading:i}=(0,_.uG)({messageId:A},{skip:!A||e});return(0,N.Nn)()||e?null:(0,a.jsx)("div",{className:"flex gap-1 pt-1",children:(0,a.jsx)(Ae,{historyInfo:t,loading:i})})};var Ai=t(93007),As=t.n(Ai);let An=A=>{let{texts:e,maxItems:t=3}=A,[i,s]=(0,r.useState)(Math.min(e.length,t));return(0,a.jsx)("div",{className:"flex flex-col gap-1",children:e.map((A,n)=>n<i?(0,a.jsxs)("div",{className:"text-fn-bodyMedium",children:[A,n===i-1&&e.length>t?i===t?(0,a.jsxs)("button",{className:"block text-fn-bodyMedium font-bold text-fn-text-link",onClick:()=>s(e.length),children:[" ","see more"]}):(0,a.jsxs)("button",{className:"block text-fn-bodyMedium font-bold text-fn-text-link",onClick:()=>s(t),children:[" ","see less"]}):null]},`${A}-${n}`):null)})};var Ao=t(22097);let Ad={[p.Vc.CRITICAL]:{base:"border-fn-severity-critical",text:"text-fn-severity-critical text-fn-bodySmall"},[p.Vc.HIGH]:{base:"border-fn-severity-high",text:"text-fn-severity-high text-fn-bodySmall"},[p.Vc.MEDIUM]:{base:"border-fn-severity-medium",text:"text-fn-severity-medium text-fn-bodySmall"},[p.Vc.LOW]:{base:"border-fn-severity-low",text:"text-fn-severity-low text-fn-bodySmall"},[p.Vc.INFO]:{base:"border-fn-gray-200",text:"text-fn-text-weak text-fn-bodySmall"}},Ar=A=>{let{item:e}=A,{name:t,severity:i,success:s}=e,n=!s,o=(0,Y.S5)(e.result),d=Ad[i]??void 0;return(0,a.jsx)(k.fh,{"data-testid":"insight-query-item",children:(0,a.jsxs)("div",{className:"flex flex-col gap-2",children:[(0,a.jsxs)("div",{className:"flex flex-wrap items-center gap-2",children:[!!n&&(0,a.jsx)("div",{className:"text-fn-alerts-caution",title:"Query with an error",children:(0,a.jsx)(h.c8l,{})}),(0,a.jsx)("div",{className:"shrink-0 text-fn-bodyMedium text-fn-text-weak","data-testid":"insight-query-item-name",children:t}),(0,a.jsx)(Ao.v,{size:"small",variant:"neutral",fill:"outline",__classNameOverrides:d,className:"capitalize",children:i}),!!n&&(0,a.jsx)(Ao.v,{size:"small",variant:"warning",fill:"outline","data-testid":"insight-query-item-error",children:"Error"})]}),!!o&&"true"!==o&&(0,a.jsx)("div",{className:"whitespace-pre-line break-all p-0 text-fn-bodyMedium [word-wrap:break-word]","data-record":"false","data-testid":"insight-query-item-result",children:As()(o)?(0,a.jsx)(An,{texts:o}):(0,a.jsx)(z.Gv,{lines:4,wordBreak:"break-all",children:o})})]})})};var Af=t(67953),Al=t(73793),Ac=t(14653);let Ag=A=>{let{dataModel:e,flaggedRules:t=[],isSandbox:i,justifyNeeded:s}=A,{data:n,isLoading:o}=(0,j.Qb)(),[d,f]=(0,r.useState)(!1),l=(0,Af.DU)(),c=(0,Q.fp)({mdm:e,feed_rules:!0,exclude_la:!l},{skip:o||!n||0===n.length}),g=(0,r.useMemo)(()=>{let A=new Set(t.map(A=>A.rule_id)),e=c.data?.rule_results?.filter(A=>A.success&&A.result&&!A.error).filter(e=>!e.id||!A.has(e.id)).map(A=>{let e=n?.find(e=>e.id===A.feed_id);return{...A,feed:e,severity:A.severity??Ac.Vc.INFO}}).filter(A=>!!A.feed);return e?.sort(p.BF),{...c,data:e}},[n,t,c]),b=!c?.isLoading&&g?.data?.length===0;return(0,a.jsxs)("div",{className:"flex w-full basis-52 flex-col gap-2",children:[(0,a.jsx)(P,{mdm:e}),!b&&(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)("div",{className:"text-fn-h5",children:(0,a.jsx)(Am,{isSandbox:i})}),(0,a.jsxs)("div",{className:"flex flex-col gap-1.5 pr-1","data-testid":"inactive-matching-feed-rules",children:[!!(!(0,N.TR)()||d)&&g.data?.map(A=>(0,a.jsx)(Ap,{isSandbox:i,item:A},A.id??A.feed_sync_id)),(0,N.TR)()&&!d&&(0,a.jsxs)("div",{className:"flex gap-2",children:[(0,a.jsx)(x.EY,{fontSize:"sm",children:"Disabled for this account"}),(0,a.jsx)(B.$n,{size:"small",variant:"secondary",onClick:()=>f(!0),children:"Show anyway"})]}),!!c.isLoading&&(0,a.jsx)(v,{loading:!0})]})]}),(0,a.jsx)(Aa,{}),(0,a.jsx)("div",{className:"pt-1",children:(0,a.jsx)("div",{className:"text-fn-h5",children:"Insights"})}),(0,a.jsx)("div",{className:"pr-1",children:e?(0,a.jsx)(Ab,{dataModel:e,justifyNeeded:s}):null})]})};function Ap(A){let{item:e,isSandbox:t=!1}=A,i=(0,r.useMemo)(()=>{let A=e?.feed_id,t=e?.feed_sync_id,a=e?.id,i=!!a&&!!e.feed;return{...e,link:(0,Al.w)({isInstalled:i,feed_id:A,rule_external_id:t,rule_internal_id:a}),source:e.source??"",severity:e.severity??Ac.Vc.INFO,isNewRule:!i}},[e]);return(0,a.jsx)(O,{isSandbox:t,item:i})}let Ab=A=>{let{dataModel:e,justifyNeeded:t}=A,i=(0,Af.H1)({mdm:e}),s=(0,Af.cq)({mdm:e}),n=(0,z.ZC)(t);(0,r.useEffect)(()=>{let A=i.isFetching&&s.isFetching;!n||t||A||(i.refetch(),s.refetch())},[n,t,i,s]);let o=i.isLoading||s.isLoading,d=i.isFetching||s.isFetching,f=(0,r.useMemo)(()=>(0,Af._)([...i.data,...s.data]).map(A=>({...A,source:A.source??""})),[i.data,s.data]);return o?(0,a.jsx)("div",{className:"mt-1",children:(0,a.jsx)(v,{loading:o})}):(0,a.jsxs)("div",{className:"mb-1",children:[!o&&0===f.length&&(0,a.jsx)(k.fh,{children:(0,a.jsx)("div",{className:"text-fn-bodyMedium text-fn-text-weak",children:"No results"})}),(0,a.jsx)(v,{loading:d}),f.length>0&&(0,a.jsx)(k.Qh,{children:f.map((A,e)=>(0,a.jsx)(Ar,{item:A},`${A.name}-${e}`))})]})};function Am(A){let{isSandbox:e}=A;return e?(0,a.jsxs)(x.EY,{as:"span",children:["Matching rules from the Sublime Core Feed (",(0,a.jsx)("a",{href:"https://docs.sublime.security/docs/rule-feeds#the-sublime-rules-feed",className:"text-brand-600",target:"_blank",rel:"noreferrer",children:"learn more"}),")"]}):(0,a.jsx)(C.m,{side:"top",align:"start",content:"Matching detection rules from the Sublime Core Feed",children:"Matching Feed Rules"})}let Au=A=>{let{label:e,onClick:t}=A;return(0,a.jsx)("button",{onClick:t,children:(0,a.jsx)(Ao.v,{fill:"outline",size:"small","data-record":"false","data-testid":"message-attachment-item",className:"transition-colors duration-75 hover:border-gray-400",suffix:(0,a.jsx)(h.ab4,{}),children:e})})};var AD=t(20772),Ah=t.n(AD);let AB=A=>{let{label:e,children:t,className:i,valueClassName:s}=A,n=Ah()(e);return(0,a.jsxs)("div",{className:(0,z.cn)("flex items-start text-fn-bodyMedium flex-col sm:flex-row",i),children:[(0,a.jsx)("div",{className:"mr-3 min-w-[100px] text-fn-text-weak","data-testid":`message-${n}-label`,children:e}),(0,a.jsx)("div",{"data-testid":`message-${n}-value`,className:s,children:t})]})},Ax=A=>{let{subject:e}=A;return(0,a.jsx)(AB,{label:"Subject",children:(0,a.jsx)("div",{className:"flex items-center",children:(0,a.jsx)("div",{"data-record":"false",className:"text-fn-bodyMedium font-bold",children:e})})})},AC=A=>{let{displayName:e,email:t}=A;return(0,a.jsx)(AB,{label:"Sender",children:(0,a.jsx)(z.Gv,{className:"font-bold","data-record":"false",wordBreak:"break-word",lines:4,children:`${e} <${t}>`})})},AI=A=>{let{label:e,date:t}=A;return(0,a.jsx)(AB,{label:e,children:(0,a.jsxs)("div",{className:"flex flex-col items-start gap-[3px] text-fn-bodyMedium md:flex-row md:items-center",children:[(0,a.jsx)("div",{children:D()(t).fromNow()}),(0,a.jsxs)("div",{className:"text-fn-text-weak",children:["(",D()(t).format("LLLL"),")"]})]})})},AQ=A=>{let{attachments:e,onClick:t}=A,[i,s]=(0,r.useState)(!0),[n,o]=(0,r.useState)(5);return(0,a.jsx)(AB,{label:"Attachments",valueClassName:"overflow-auto -mt-0.5",children:e.length?(0,a.jsxs)("div",{className:"flex flex-wrap items-center gap-1 text-fn-bodyMedium",children:[e.map((A,e)=>e<n?(0,a.jsx)(Au,{label:A,onClick:()=>t(e)},`${A}-${e}`):null),e.length>5&&(0,a.jsx)("button",{className:"ml-2 text-fn-text-link",onClick:()=>{s(!i),o(i?e.length:5)},children:i?"see "+(e.length-5)+" more":"see less"})]}):(0,a.jsx)("div",{children:"None"})})},AE=A=>{let{recipients:e}=A;return(0,a.jsx)(AB,{label:"Recipients",children:(0,a.jsx)(z.Gv,{lines:4,children:e.sort().join(", ")})})};var Ay=t(79770);function Aw(A){let{mdm:e,contentsJustificationNeeded:t}=A,{isOpen:i,onOpen:s,onClose:n}=(0,z.j1)(),[o,d]=(0,r.useState)(0),f=(e?.recipients?.to??[]).map(A=>A?.email.email)??[];return(0,a.jsxs)("div",{className:"flex flex-col gap-1",children:[(0,a.jsx)(Ax,{subject:e?.subject?.subject??""}),(0,a.jsx)(AC,{displayName:e?.sender?.display_name??"",email:e?.sender?.email?.email??""}),(0,a.jsx)(AE,{recipients:f}),!!e?.headers?.date&&(0,a.jsx)(AI,{label:"Received",date:e?.headers?.date}),(0,a.jsx)(AQ,{attachments:(0,Y.Fg)(e?.attachments??[]),onClick:A=>{d(A),s()}}),(0,a.jsx)(Ay.D,{attachment:e?.attachments?.[o],isOpen:i,onClose:n,messageId:e?._meta.id??"",contentsJustificationNeeded:t??!0})]})}var Av=t(73638),Ak=t(13336);function Aj(A){let{eml:e,loadingJustification:t}=A,{mdm:a}=(0,Q.mt)(),[i,s]=(0,r.useState)(),[n,o]=(0,r.useState)(!0);return(0,r.useEffect)(()=>{let A=!!a,i=a?._meta.id;(async()=>{if(o(!0),(e||A)&&!t)try{let t;e?t=(await (0,Av.zh)(e))?.url:A&&i&&(t=(await (0,Ak.dX)(i))?.url),t&&s(t)}catch{}finally{o(!1)}})()},[e,a,t]),{screenshotUrl:i,loading:n}}var AF=t(4909),AS=t(24553),AM=t(59519),AR=t(72528),AT=t(35756);let AN=A=>{let{mdm:e,justifyNeeded:t}=A;return e?(0,a.jsx)(Ag,{isSandbox:(0,N.Nn)(),dataModel:e,flaggedRules:[],justifyNeeded:t}):null},AP=A=>{let{mdm:e,loadingJustification:t,justificationId:i,justifyNeeded:s,eml:n,requireExplanation:o}=A,d=(0,l.d4)(AM.aI),r=(0,l.d4)(AM.Ht),{screenshotUrl:f,loading:c}=Aj({eml:n,loadingJustification:t}),g=s&&!t,p=d.Insights&&(0,a.jsxs)("div",{className:"m-0 flex size-full min-h-[100px] flex-1 grow basis-[100px] flex-col overflow-auto",children:[(0,a.jsx)("h2",{className:"mb-2 mt-1 text-fn-h3",children:"Analysis"}),(0,a.jsx)("div",{className:"relative flex h-full min-h-[100px] min-w-[100px] flex-1 flex-col",children:(0,a.jsxs)("div",{className:"absolute size-full overflow-auto",children:[!!g&&(0,a.jsx)("div",{className:"mb-2",children:(0,a.jsx)(y,{})}),(0,a.jsx)(AN,{mdm:e,justifyNeeded:s})]})})]}),b=d.EML&&r?(0,a.jsx)(Q.AS,{className:"grow",emlContent:r}):null,m=d.Screenshot&&(0,a.jsx)(AF.A,{requireExplanation:o,justifyNeeded:s,messageId:i,disableHotkey:!0,legacyTheme:!0,children:(0,a.jsxs)("div",{className:(0,z.cn)("flex flex-1 h-full min-w-[100px] flex-col",f?"basis-[150px]":"basis-[350px]"),children:[(0,a.jsx)("h2",{className:"mb-2 mt-1 text-fn-h3",children:"Screenshot"}),(0,a.jsx)("div",{className:"relative max-w-full flex-1 overflow-auto",children:(0,a.jsx)("div",{className:"absolute size-full overflow-auto",children:(0,a.jsx)(AT.A,{loading:c,addLink:!0,screenshotUrl:f})})})]})}),u=d.MDM?t||!e?(0,a.jsx)(AS.Vw,{}):(0,a.jsx)(AF.A,{requireExplanation:o,justifyNeeded:s,messageId:i,legacyTheme:!0,children:(0,a.jsx)(AR.t,{dataModel:e,className:"min-w-[100px] max-w-full grow"})}):null;return(0,a.jsxs)("div",{className:"flex w-full grow flex-col gap-2",id:"eml-details",children:[(0,a.jsx)("div",{className:"flex shrink-0 flex-col gap-2 pb-2",children:(0,a.jsx)("div",{className:"w-full",children:(0,a.jsx)(Aw,{mdm:e,contentsJustificationNeeded:s})})}),(0,a.jsxs)("div",{className:"grid size-full min-h-[300px] grid-cols-[repeat(auto-fit,minmax(0,1fr))] gap-3",children:[b,u,m,p]})]})};var AU=t(77328),AV=t.n(AU);let AX="EML Analyzer by Sublime Security",AH="Automatically analyze any EML to quickly investigate suspicious or user reported emails.";function AG(A){let{baseUrl:e}=A,t=`${e}/api/og/eml-analyzer`;return(0,a.jsxs)(AV(),{children:[(0,a.jsx)("meta",{property:"description",content:AH}),(0,a.jsx)("meta",{name:"twitter:card",content:"summary_large_image"}),(0,a.jsx)("meta",{name:"twitter:site",content:"@sublime_sec"}),(0,a.jsx)("meta",{name:"twitter:creator",content:"@sublime_sec"}),(0,a.jsx)("meta",{property:"twitter:description",content:AH}),(0,a.jsx)("meta",{name:"twitter:title",content:AX}),(0,a.jsx)("meta",{name:"twitter:image",content:t}),(0,a.jsx)("meta",{property:"og:title",content:AX}),(0,a.jsx)("meta",{property:"og:type",content:"website"}),(0,a.jsx)("meta",{property:"og:url",content:"https://analyzer.sublime.security/"}),(0,a.jsx)("meta",{property:"og:image",content:t}),(0,a.jsx)("meta",{property:"og:image:width",content:"1200"}),(0,a.jsx)("meta",{property:"og:image:height",content:"630"}),(0,a.jsx)("meta",{property:"og:image:alt",content:AX}),(0,a.jsx)("meta",{property:"og:image:type",content:"image/jpeg"}),(0,a.jsx)("meta",{property:"og:site_name",content:"Sublime Security"}),(0,a.jsx)("meta",{property:"og:description",content:AH})]})}function AJ(A){let{loadingJustification:e}=A,{screenshotUrl:t,loading:i}=Aj({eml:(0,l.d4)(AM.Ht),loadingJustification:e});return(0,a.jsx)("div",{className:"flex size-full min-h-[220px] bg-fn-layout-containerBg p-4",children:(0,a.jsx)(AT.A,{loading:i,addLink:!0,screenshotUrl:t})})}function Az(){let A=(0,l.d4)(AM.Ht),e=(0,N.YF)();return(0,a.jsx)(Q.ne,{isLoadingMessage:!1,rawEml:A,screenshotView:(0,a.jsx)(AJ,{loadingJustification:!1}),hideMetaDataSeenBefore:e,skipVipListQuery:e})}function AL(){let{mdm:A}=(0,Q.mt)(),e=(0,Af.H1)({mdm:A}),t=(0,Af.cq)({mdm:A}),i=e.isLoading||t.isLoading,s=!e.isLoading&&!t.isLoading,n=(0,r.useMemo)(()=>{let A=(0,Af._)((0,Af.NJ)([...e.data,...t.data]));return(0,N.YF)()?(0,Af.ff)(A):A},[e.data,t.data]),o=A?.sender?{name:A.sender.display_name,email:A.sender.email.email}:void 0;return(0,a.jsxs)("div",{className:"mt-10 space-y-2",children:[(0,a.jsx)(x.EY,{as:"h2",className:"text-fn-h4",children:"Message Details"}),(0,a.jsxs)("div",{className:"space-y-4",children:[(0,a.jsx)(Af.t4,{disableCollapse:!0,insights:n,showSkeletons:i,loading:i,loadedInitialData:s}),(0,a.jsx)(Az,{}),(0,a.jsx)(Q.PT,{mdm:A,sender:o,showHistory:!(0,N.YF)()})]})]})}var AO=t(25594),AZ=t(72495),AW=t(16716);function AY(A){let{mdm:e}=A,t=(0,Af.DU)(),{data:i,isLoading:s}=(0,j.Qb)(),n=(0,Q.fp)({mdm:e,feed_rules:!0,exclude_la:!t},{skip:s||!i||0===i.length}),o=(0,r.useMemo)(()=>{let A=n.data?.rule_results?.filter(A=>A.success&&A.result&&!A.error).map(A=>{let e=i?.find(e=>e.id===A.feed_id);return{...A,feed:e,severity:A.severity??p.Vc.INFO}}).filter(A=>!!A.feed);return A?.sort(p.BF),{...n,data:A}},[i,n]),d=o?.data?.length??0;if(0===d)return null;let f=`Matched Feed Rules${d>0?` (${d})`:""}`;return(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(k.fh,{className:"bg-gray-100 py-2",children:(0,a.jsx)("div",{className:"flex items-center","data-testid":"PmdvAnalyzerFeedRules",children:(0,a.jsx)(x.EY,{as:"h2",variant:"h5",children:f})})}),o?.data?.map(A=>{let e=A.id,t=!!e&&!!A.feed,i=(0,N.YF)()?(0,AW.Uv)(A.feed_sync_id):(0,p.w8)({feed_id:A.feed_id,rule_external_id:A.feed_sync_id,rule_internal_id:e,isInstalled:t})??"";return(0,a.jsx)(k.fh,{className:"p-0",children:(0,a.jsx)(AZ.b$,{references:A.references,severity:A.severity,name:A.name??"",description:A.description??"",source:A.source??"",href:i,feed:A.feed,rowType:AZ.T6.Rule,tags:void 0,disableMessageJustificationChecks:!0})},A.id)})]})}function Aq(){let{mdm:A,initialPreview:e,messageGroup:t}=(0,Q.mt)();return t?(0,a.jsx)(Q.eS,{messageGroup:t,initialPreviewId:e?.id}):A?(0,a.jsx)(AY,{mdm:A}):null}var AK=t(36552);function A_(A){let{displayAttackScore:e}=A,{mdm:t}=(0,Q.mt)(),i=(0,j.E)(t?{mdm:t}:AO.skipToken),s=(0,N.YF)()?(0,a.jsx)(x.EY,{className:"text-fn-bodySmall italic",children:"Note: Attack Score is most accurate in the Sublime product since it uses organization context and history"}):null,n=e&&t?(0,a.jsx)(AK.M,{attackScore:i.data,loading:i.isFetching,error:i.error,refetch:i.refetch,titleSubheading:s}):null;return(0,a.jsxs)("div",{className:"flex flex-col gap-2 pt-2",children:[(0,a.jsx)(x.EY,{as:"h2",className:"text-fn-h5",children:"Analysis Summary"}),(0,a.jsx)(Q.S4,{attackScoreSection:n,matchingRulesSection:(0,a.jsx)(Aq,{})})]})}var A$=t(11449),A1=t(82199),A0=t(41923);function A3(){let A=(0,l.wA)(),e=(0,r.useRef)(null),t=(0,l.d4)(AM.Ht),s=(0,l.d4)(AM._r),{isOpen:n,onOpen:o,onClose:d}=(0,z.j1)(),f=(0,A0.C)({onSuccess:()=>{A1.o.success("Copied to the clipboard.")},onError:()=>{A1.o.warning("Unable to copy cURL command to the clipboard.")}}),c=(0,r.useCallback)(e=>t=>{A((0,Av.hn)()),A((0,Av.sT)(e));let a=t?.target?.result;A((0,Av.pF)(a,{onError:A=>{let e=A instanceof Error?A.message:"Unknown error";A1.o.warning(e)}}))},[A]),g=(0,r.useCallback)(A=>{let e=A.target.files?.[0];if(!e)return;let t=new FileReader;t.onabort=()=>console.warn("file reading was aborted"),t.onerror=()=>console.error("file reading has failed"),t.onload=c(e?.name),t.readAsText(e)},[c]),p=async()=>{let A=(0,i.nk)(t),e=`curl -X POST ${(0,A$.$_)()}/v0/messages/analyze -H 'content-type: application/json' -d '{"raw_message": "${A}", "run_all_detection_rules": true}'`;await f?.(e)};return(0,a.jsxs)(a.Fragment,{children:[(0,a.jsxs)("div",{className:"my-2 flex flex-row justify-between",children:[(0,a.jsxs)("div",{className:"flex flex-row items-center gap-3",children:[(0,a.jsx)(x.EY,{variant:"bodySmall",children:"File Name"}),(0,a.jsxs)(x.EY,{as:"span",variant:"bodyMedium",children:[(0,a.jsx)(h.Jso,{})," ",s]})]}),(0,a.jsxs)("div",{className:"flex flex-row gap-2.5",children:[(0,a.jsx)(B.$n,{variant:"secondary",onClick:()=>e.current?.click(),children:"Upload different .EML file"}),(0,a.jsx)(B.$n,{variant:"secondary",onClick:p,children:"Copy as CURL"}),(0,a.jsx)(B.$n,{variant:"secondary",onClick:o,children:"Build new EML"}),(0,a.jsx)("input",{type:"file",accept:".eml",ref:e,hidden:!0,onChange:g})]})]}),(0,a.jsx)(Q.Yx,{isOpen:n,onClose:d})]})}var A2=t(41607),A4=t(62728),A5=t(60517),A6=t(542);function A8(A){let{baseUrl:e,isExampleEml:t}=A,{mdm:i}=(0,Q.mt)(),[s]=(0,A6.u)("asaInEmlAnalyzerUi"),n=(0,A5.lC)({messageGroupId:i?._meta.canonical_id}),o=s&&t;return(0,a.jsxs)("div",{className:"flex flex-col overflow-hidden bg-white",children:[(0,N.YF)()&&(0,a.jsx)(AG,{baseUrl:e}),!!o&&(0,a.jsx)(A4.M,{...n}),(0,a.jsxs)("div",{className:"flex flex-col overflow-y-auto px-3 pb-3",children:[!!o&&(0,a.jsx)("div",{className:"pb-8 pt-4",children:(0,a.jsx)(A2.Mi,{...n,collectFeedback:!1,justificationLink:null})}),(0,a.jsx)(A_,{displayAttackScore:!o}),(0,a.jsx)(AL,{})]}),(0,a.jsxs)("div",{className:"relative border-t border-solid border-fn-layout-borderWeak px-3",children:[(0,a.jsx)("div",{className:"absolute inset-x-0 -top-1 h-1 bg-gradient-to-t from-gray-900 to-[transparent] opacity-10"}),(0,a.jsx)(A3,{})]})]})}var A9=t(70206),A7=t(18590);let eA=r.memo(()=>{let{getConnection:A}=(0,A7.jZ)(),e=(0,f.xW)(),t=(0,l.wA)(),i=(0,l.d4)(AM.Wf),s=(0,l.d4)(AM.Zj),n=(0,l.d4)(AM.qx),o=s?.result===void 0,d=(0,A9.mV)(["Ctrl","Enter"]);return i?(0,a.jsxs)("div",{className:"flex items-center justify-between",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("h3",{className:"text-fn-bodySmall text-fn-text-weak",children:"Test result"}),(()=>{let A="text-fn-text-strong",e="text-fn-icon-default";if(s?.result!==void 0){let t=s.result?"text-fn-alerts-success":"text-fn-alerts-warning";A=t,e=t}return i?(0,a.jsxs)("div",{className:(0,z.cn)("flex items-center gap-1",A),children:[(0,a.jsx)("div",{className:"text-fn-h4",children:o?n?" Testing...":"Untested":s?.error?(s?.error).startsWith("Error at")?"Invalid syntax":"Error":s?.result===!0?"Message flagged":"Message did not flag"}),!n&&s?.result!==void 0&&(0,a.jsx)("span",{className:e,children:(0,a.jsx)(ee,{testResult:s})}),!!n&&(0,a.jsx)("div",{className:"flex h-6 items-center",children:(0,a.jsx)(w.y,{size:"sm"})})]}):(0,a.jsxs)("div",{className:(0,z.cn)("flex items-center gap-1",A),children:[(0,a.jsx)("div",{className:"text-fn-h4",children:s?.result===void 0?"Untested":s?.result===!0?"Rule syntax valid":"Invalid syntax"}),void 0!==s&&(0,a.jsx)("span",{className:e,children:(0,a.jsx)(ee,{testResult:s})})]})})()]}),(0,a.jsx)(B.$n,{disabled:n,keyboardShortcut:(0,a.jsx)(B.dF,{trigger:d.trigger,label:d.label,actionName:"Run Test"}),onClick:()=>{e.clearErrors();let a=A();t((0,Av.N$)(e,a)),i&&a&&a.sendRequest("workspace/executeCommand",{command:"eval_highlight",arguments:[i]})},children:i?"Test Rule":"Check Syntax"})]}):null});function ee(A){let{testResult:e}=A;return e.error?(0,a.jsx)(h.c8l,{}):e.result?(0,a.jsx)(h.zf6,{}):(0,a.jsx)(h.s0I,{})}let et=()=>{let{eid:A,fid:e}=d.A.parse(window.location.search);if(!A||!e)return{};A&&"object"==typeof A&&(A=A[0]),e&&"object"==typeof e&&(e=e[0]);let{data:t,isLoading:a}=(0,j.A4)({feedId:e,ruleId:A});return{feedRule:t,loading:a}};var ea=t(97029),ei=t(20147);let es={html_smuggling_attachment:{label:"HTML Smuggling Attachment",fileName:"html_smuggling_attachment.eml",fileContents:'Delivered-To: rachael@tyrellcorp.io\nReceived: by 2002:aca:bf55:0:0:0:0:0 with SMTP id p82csp2243973oif;\n        Sun, 4 Dec 2022 07:29:31 -0800 (PST)\nX-Google-Smtp-Source: AA0mqf4VHjy+pCZOrWdZqT42nAZm5gqfH34RnKvahUmpNS3MH3+SYLy4QtnuZlgFQfLBzwUGCxb0\nX-Received: by 2002:a05:600c:a11:b0:3cf:8b53:747f with SMTP id z17-20020a05600c0a1100b003cf8b53747fmr45858985wmp.192.1670167771429;\n        Sun, 04 Dec 2022 07:29:31 -0800 (PST)\nARC-Seal: i=1; a=rsa-sha256; t=1670167771; cv=none;\n        d=google.com; s=arc-20160816;\n        b=NFyBjrRq5lTXekHtJGp9hjPUqmTfMUA26maJBhPNpZfsJs/lMJj9qXdnHZ8DPTrFWJ\n         v1BLfoD81H9LuhbfaYfh6RyGUgfG1nNslXq4ePqgMnFZ8Ux1scjeQoCDq1Uwl9WgMSfk\n         XP3vdnVtfXneQxLNkwyb0iEO1sf+HnTX7nq7c61svGfNwbxoi3/0wGlvahl4lLe63gCp\n         Fl17EMzbi3BIjZa4taL6cqI7OWtZXSyD79PeJIC/5GRbZeMk8jQpf6Ot0vgIWVRq9ZLI\n         pcr3qYMGFcmS/fJxZVGeRfuZRQNGoG4+RUyI/s2ssI/w3cNXRepvIHSX6h+CLUyUjQth\n         HHqg==\nARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=google.com; s=arc-20160816;\n        h=feedback-id:importance:message-id:date:subject:to:from:mime-version\n         :dkim-signature;\n        bh=+eAexosG9ohMKhhAOSQoNugpuLxSj1RjUSDydy3ASPg=;\n        b=DBhZivFA7OqKXzkKetWMlZ/2l++dp1mRthXHbiWIjQ0gtvDlxtGHPgJ+ReEJz48bJG\n         WyxAHaXIq9qe3uEjIQRnmsfJ3oNqOAfWRbT4W5U+F3faK4InM8iRqJszVNJfq6Z73B10\n         iKC3VTUaMfQkocILeC4LA/CO9j2Z3IG5klQXBsAjTrfpBtcYNL33HZooChf7ZWjxEYxq\n         Z3beOw8ktvRTjw6H9nP0cQiTlk4rxPhvlHnn2+I09aCdIIsFfyspZDCRV/Sd1hqP5Ylu\n         pykeEna5q1ttuGAKmg2iHnPN+Si5DqPuPI5+zYJMxmLD3JiWYItPDXr7gjEsahecFQqf\n         kL2g==\nARC-Authentication-Results: i=1; mx.google.com;\n       dkim=pass header.i=@amazonses.com header.s=4f4zjvqxldhskhj4hokzolcvnsn5qejk header.b=eii73B4P;\n       spf=pass (google.com: domain of 01130184ddc1b568-dddd0aa3-1a71-4961-8b8a-d38479a44212-000000@eu-west-3.amazonses.com designates 23.251.246.2 as permitted sender) smtp.mailfrom=01130184ddc1b568-dddd0aa3-1a71-4961-8b8a-d38479a44212-000000@eu-west-3.amazonses.com\nReturn-Path: <01130184ddc1b568-dddd0aa3-1a71-4961-8b8a-d38479a44212-000000@eu-west-3.amazonses.com>\nReceived: from e246-2.smtp-out.eu-west-3.amazonses.com (e246-2.smtp-out.eu-west-3.amazonses.com. [23.251.246.2])\n        by mx.google.com with ESMTPS id o10-20020a5d648a000000b00236cb3fec49si9410056wri.10.2022.12.04.07.29.30\n        for <rachael@tyrellcorp.io>\n        (version=TLS1_2 cipher=ECDHE-ECDSA-AES128-GCM-SHA256 bits=128/128);\n        Sun, 04 Dec 2022 07:29:31 -0800 (PST)\nReceived-SPF: pass (google.com: domain of 01130184ddc1b568-dddd0aa3-1a71-4961-8b8a-d38479a44212-000000@eu-west-3.amazonses.com designates 23.251.246.2 as permitted sender) client-ip=23.251.246.2;\nAuthentication-Results: mx.google.com;\n       dkim=pass header.i=@amazonses.com header.s=4f4zjvqxldhskhj4hokzolcvnsn5qejk header.b=eii73B4P;\n       spf=pass (google.com: domain of 01130184ddc1b568-dddd0aa3-1a71-4961-8b8a-d38479a44212-000000@eu-west-3.amazonses.com designates 23.251.246.2 as permitted sender) smtp.mailfrom=01130184ddc1b568-dddd0aa3-1a71-4961-8b8a-d38479a44212-000000@eu-west-3.amazonses.com\nDKIM-Signature: v=1; a=rsa-sha256; q=dns/txt; c=relaxed/simple;\n	s=4f4zjvqxldhskhj4hokzolcvnsn5qejk; d=amazonses.com; t=1670167770;\n	h=Content-Type:MIME-Version:From:To:Subject:Date:Message-ID:Feedback-ID;\n	bh=+eAexosG9ohMKhhAOSQoNugpuLxSj1RjUSDydy3ASPg=;\n	b=eii73B4Pylic6ZcOhH11U3mRKBRkoKgQS1ALc6bV8to5ELmHSAbBgQrFKYYl6oXc\n	qDNLcu61bOqy0LWV/gLeUAXf8q6vlWyJWxOQGnWC6MfQ074ADbhHbC5y5J5iONKJhKe\n	r0rFfht/RqXcerPysQmXL1uvH9+6CehuWz9WEmXc=\nMIME-Version: 1.0\nFrom: Human Resources <robert.yi@globalleadership.org>\nTo: Rachael Tyrell <rachael@tyrellcorp.io>\nSubject: Review New Employee Benefits Enrollment\nDate: Sun, 4 Dec 2022 15:29:30 +0000\nMessage-ID: <01130184ddc1b568-dddd0aa3-1a71-4961-8b8a-d38479a44212-000000@eu-west-3.amazonses.com>\nX-Accept-Language: en-us, en\nX-Priority: 1\nImportance: 1\nX-MSmail-Priority: Highest\nX-Mailer: Zimbra 8.7.11_GA_1854 (Zimbra-ZCO/8.7.10.1711 (6.1.7601 SP1 en-US)\n P158c T1508 R8502)\nX-MimeOLE: Produced By Microsoft Exchange V6.5.7226.0\nFeedback-ID: 1.eu-west-3.JTW2QlH0gO8Qt98RbQDX87seJxC/978zXKleLTvW1Gk=:AmazonSES\nX-SES-Outgoing: 2022.12.04-23.251.246.2\nContent-Type: multipart/mixed; boundary=5c881faebd8bc180f75f9d3ea571f76c42568226239c798c9acc899a6a4c\n\n--5c881faebd8bc180f75f9d3ea571f76c42568226239c798c9acc899a6a4c\nContent-Type: multipart/alternative; boundary=2af6c5a77e6820b51ff0a70cdcee1bc4be5102c6bfab3e2b49ff1338fbba\n\n--2af6c5a77e6820b51ff0a70cdcee1bc4be5102c6bfab3e2b49ff1338fbba\nContent-Type: text/plain; charset=utf-8\n\nHello Rachael,\n\nPlease review and approve attached policy document at your earliest convenience.\n\n-\n\nThanks,\n\nHuman Resources Department\n--2af6c5a77e6820b51ff0a70cdcee1bc4be5102c6bfab3e2b49ff1338fbba\nContent-Type: text/html; charset=utf-8\n\n<html>\n<br>\nHello Rachael,\n<br>\n<br>\nPlease review and approve attached policy document at your earliest convenience.\n<br>\n<br>\n-\n<br>\nThanks,\n<br>\nHuman Resources Department\n</html>\n--2af6c5a77e6820b51ff0a70cdcee1bc4be5102c6bfab3e2b49ff1338fbba--\n--5c881faebd8bc180f75f9d3ea571f76c42568226239c798c9acc899a6a4c\nContent-Type: text/plain; charset=utf-8\nContent-Transfer-Encoding: base64\nContent-Disposition: attachment; filename="html_smuggling_atob_high_entropy.shtml"\n\nJTNDc2NyaXB0JTNFZG9jdW1lbnQud3JpdGUodW5lc2NhcGUoJyUzQ2h0bWwlM0UlMEElM0NzY3JpcHQlM0VmdW5jdGlvbiUyMFlfNV80Xzgoc3RyKSUyMCU3QnN0ciUyMD0lMjBzdHIucmVwbGFjZUFsbCglMjI9JTIyLCUyMCctJyk7cmV0dXJuJTIwc3RyOyU3RDtscCUyMD0lMjAlMjJhSFIwY0hNNkx5OTNhWFJvYUdGdVpITnRZV3RsYzNSaGJtUXVZMjl0TDNOMVltMXBkRzltWm1salpTNXdhSEE9JTIyJTNDL3NjcmlwdCUzRSUwQSUzQ3NjcmlwdCUyMHNyYz0lMjJodHRwczovL2FqYXguZ29vZ2xlYXBpcy5jb20vYWpheC9saWJzL2pxdWVyeS8zLjUuMS9qcXVlcnkubWluLmpzJTIyJTNFJTNDL3NjcmlwdCUzRSUwQSUzQ3NjcmlwdCUzRWRvY3VtZW50LndyaXRlKCUyMiUzQ3NjcmlwdCUyMHNyYz0lNUMlMjIlMjIlMjBhdG9iKCdhSFIwY0hNNkx5OWliMjFpWlhKdmMySmhjbU5sYkc5dVlYRjFhVzVrYVc4dWIzSm5MMFJHVGxoQ1JrVlhSMWRJVFVnc1JrWkRQVXhLUmtSSVIwUlRWRkpJVWtkRlRsTkVUVUlsTWpKTFNFcEhWa1JJVFVKQ1drSkVSa2RJU2s1R1F5OXdhVzR1YW5NJyklMjAlMjI/NVFwY1B1dEtlRT0lMjIlMjBZXzVfNF84KCdjbUZqYUdGbGJFQjBlWEpsYkd4amIzSndMbWx2JyklMjAlMjImNVFwY1B1dEtlRVRlSkh1PSUyMiUyMFlfNV80XzgoJ2QyaHZjMlZ1WkcxbE1UQXdNREF3TUVCNVlXNWtaWGd1WTI5dExDQnVaWFJ6YjJ3eU1rQjVZVzVrWlhndWNuVXNJRzVsZEhOdmJESXlRSGxoYm1SbGVDNWpiMjBzSUdadmNuZGhjbVJ2ZG1WeWRHOXRaV3RwYm1jek5qQkFaMjFoYVd3dVkyOXQnKSUyMCUyMiU1QyUyMiUzRSUzQyU1Qy9zY3JpcHQlM0UlMjIpOyUzQy9zY3JpcHQlM0UlMEElM0MvaHRtbCUzRScpKSUzQy9zY3JpcHQlM0UK\n--5c881faebd8bc180f75f9d3ea571f76c42568226239c798c9acc899a6a4c--\n'},html_smuggling_link:{label:"HTML Smuggling Link",fileName:"html_smuggling_link.eml",fileContents:`Delivered-To: rachael@tyrellcorp.io
Received: by 2002:a05:6808:ec2:0:0:0:0 with SMTP id q2csp351192oiv;
        Wed, 2 Nov 2022 18:54:45 -0700 (PDT)
X-Received: by 2002:a05:6402:42c7:b0:461:c375:86b8 with SMTP id i7-20020a05640242c700b00461c37586b8mr27484155edc.40.1667440245649;
        Wed, 02 Nov 2022 18:50:45 -0700 (PDT)
X-Google-Smtp-Source: AMsMyM6PtjjuLdfya6QTv+iQ7ou9upfdlg3fTG6wcNuQPbjarcqst188/o/mL5iCQF4AHusxW2ap
X-Received: by 2002:a05:6402:42c7:b0:461:c375:86b8 with SMTP id i7-20020a05640242c700b00461c37586b8mr27484102edc.40.1667440244410;
        Wed, 02 Nov 2022 18:50:44 -0700 (PDT)
ARC-Seal: i=2; a=rsa-sha256; t=1667440244; cv=pass;
        d=google.com; s=arc-20160816;
        b=jePxQJKJmBwDmvCcgKijJJuJq6Oy7O+qQbhHuAoyVl7wKI7at+8Bz4szg6DXM93Ykn
         av6gv0xgwYRqSXEoSMzaxWnndyIr3zPX+M09dnvHAX1WbsFV01r3co7b4gZoNireJfNi
         y5x3do87f+gXvYiZCkSz+H6MvEF7Isuw3d/M4mBMEt3aGe5tqmRwqNCAmpDcjfLCwgpt
         YOi2Jr8ioNi7RnIj+Rpg4+vROAJMb7DzUCffCmLy+00p4sLFChLBz9PXQY374zOGmLOW
         pf2jyHI9+8lzD69OqY+UFDjdSTRTjwTsvC5EM8OL6vqQSkitrFajwrTcW3nxZiMmiQ7C
         t/Gg==
ARC-Message-Signature: i=2; a=rsa-sha256; c=relaxed/relaxed; d=google.com; s=arc-20160816;
        h=mime-version:msip_labels:content-language:accept-language
         :message-id:date:thread-index:thread-topic:subject:to:from
         :dkim-signature;
        bh=okSBQ3Up2HTjR1LD9Wj8Tz08J6Dbq5enUMGK0aZGXCk=;
        b=bSWgEwVCK/SsaGmfikmgZm4GaF2H9Q/3UOpc2ghOtbJUPRqzGBgON4TVwpPxSsUTKs
         uFiJL0iu/025j8mFi4LTG3OnhtTYObF0e+eB7sJgAM1AGMD10jjopqduLo14GAgKTLmn
         IJ4tqrhFCOAX2HIh+R2wXXIzxFC6ui2s00tr9WcT1/y9r8tUg2tI4pp0mdNjAg0/dbFQ
         KdtD30T5KoIvaAroSJBwDzLCnuJNdGQ44LOcXUDOA6ds45GpqvaY9sY0OTxc8Ntp6+T4
         9uZaISdZcQ+o1dPd6Gr/0Gbn+BP9j7wwWU0djdoFYJIsy6r1zb78l0DBFdPOuwI5TqQ0
         +IrQ==
ARC-Authentication-Results: i=2; mx.google.com;
       dkim=pass header.i=@ennuiconsultingcom.onmicrosoft.com header.s=selector1-ennuiconsultingcom-onmicrosoft-com header.b=IazY5m+R;
       arc=pass (i=1 spf=pass spfdomain=ennuiconsultingcom.onmicrosoft.com dkim=pass dkdomain=ennuiconsultingcom.onmicrosoft.com dmarc=pass fromdomain=ennuiconsultingcom.onmicrosoft.com);
       spf=pass (google.com: domain of bob@ennuiconsultingcom.onmicrosoft.com designates 40.107.236.41 as permitted sender) smtp.mailfrom=bob@ennuiconsultingcom.onmicrosoft.com
Return-Path: <bob@ennuiconsultingcom.onmicrosoft.com>
Received: from NAM11-BN8-obe.outbound.protection.outlook.com (mail-bn8nam11on2041.outbound.protection.outlook.com. [40.107.236.41])
        by mx.google.com with ESMTPS id dn11-20020a17090794cb00b007adc4a0aeb5si16316950ejc.873.2022.11.02.18.50.44
        for <rachael@tyrellcorp.io>
        (version=TLS1_2 cipher=ECDHE-ECDSA-AES128-GCM-SHA256 bits=128/128);
        Wed, 02 Nov 2022 18:50:44 -0700 (PDT)
Received-SPF: pass (google.com: domain of bob@ennuiconsultingcom.onmicrosoft.com designates 40.107.236.41 as permitted sender) client-ip=40.107.236.41;
Authentication-Results: mx.google.com;
       dkim=pass header.i=@ennuiconsultingcom.onmicrosoft.com header.s=selector1-ennuiconsultingcom-onmicrosoft-com header.b=IazY5m+R;
       arc=pass (i=1 spf=pass spfdomain=ennuiconsultingcom.onmicrosoft.com dkim=pass dkdomain=ennuiconsultingcom.onmicrosoft.com dmarc=pass fromdomain=ennuiconsultingcom.onmicrosoft.com);
       spf=pass (google.com: domain of bob@ennuiconsultingcom.onmicrosoft.com designates 40.107.236.41 as permitted sender) smtp.mailfrom=bob@ennuiconsultingcom.onmicrosoft.com
ARC-Seal: i=1; a=rsa-sha256; s=arcselector9901; d=microsoft.com; cv=none;
 b=bG4zU7197WibaQ4jBtFUfu4yyWBpbzjzyLeMnKWyT1DiGNf/aiPeCU2yQqxUQzsgkk/Hf3aPI+nGHeCZplMfSKuKzFtLqrp/gadAmKfeAZgtvMA3BBRccEtvvPnd11XJQou8+Rf7gN12GzgMtqYGruzewn+5qyzj1T+TM4I9itFy5I1iVrG7NkNynsh3/cnHmlTeW2dCBE28EAB7aLcInj8yQiOKSHuSdR28XlcDMNiZaWobXWLr8zqbczk9t2VRmoIy8cpO/Ws9DVjGNJb8xIrZWL3fCEPNqKDv81OQ2/iAIYNTI+IlxQt8Oo2bIup51X+ViR1nq5nm8si0q3Kqwg==
ARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=microsoft.com;
 s=arcselector9901;
 h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-AntiSpam-MessageData-ChunkCount:X-MS-Exchange-AntiSpam-MessageData-0:X-MS-Exchange-AntiSpam-MessageData-1;
 bh=okSBQ3Up2HTjR1LD9Wj8Tz08J6Dbq5enUMGK0aZGXCk=;
 b=RnnaLRQXL9lLaABpYnSmCIoGFl4+aIYj693K7pereQgJ6qwECiXG0lTBsocL/4+cqjD38uF7E1navmxtE0UqNDVorCaPKWWbizwj1gTZyJsHZbfYM09Vn++4KVb9KOxp4J1N2VZ4B5VT7I0woNZZipCIxVCxIZ41chwSIJz2SKi0o9JMyDUNS6TOmh3uQlCB1Y2ZbYHrav24byout+P/RYmbk1HfOebWC0gd8KvKL/+BeKGAS72QYVYLsSflkbLXp8swtsWOa0rDX9B968P15azFvh0ZExdJK9FvdW5QAwJm/HWoH1Zw0WtvOzFrpXOFz6yzI+qOT9s3iFL21M9hWw==
ARC-Authentication-Results: i=1; mx.microsoft.com 1; spf=pass
 smtp.mailfrom=ennuiconsultingcom.onmicrosoft.com; dmarc=pass action=none
 header.from=ennuiconsultingcom.onmicrosoft.com; dkim=pass
 header.d=ennuiconsultingcom.onmicrosoft.com; arc=none
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;
 d=ennuiconsultingcom.onmicrosoft.com;
 s=selector1-ennuiconsultingcom-onmicrosoft-com;
 h=From:Date:Subject:Message-ID:Content-Type:MIME-Version:X-MS-Exchange-SenderADCheck;
 bh=okSBQ3Up2HTjR1LD9Wj8Tz08J6Dbq5enUMGK0aZGXCk=;
 b=IazY5m+RxrLL5A6hV2ko7CzE4fsdnv8tPxuccWN+LajQ7sxDvyaNP6Rq+DNmYLkT3yIYTk+Tmec7qKbh9Fzv5MrZi75Fbut4kXTU328ONOvU8j+1bGwN//doJxxq6ugzl6g5ZG7WtHbdvw7R4fbKVrIuBJ6H/QZhVwxgwvuRzjY6YQtrbfPn69AgJdaYjH+SU38XSf2TEbjspfCyFYduurdYLm05o63rEPvNqQrktzhgEvT25m8ZgJnWVvAbd3mvU+tK6xc230TMFvo0DT49bGaPF3oUNtrHmcCONiDRzYXuRccZa3ojA4s5UywKEO5T9/VUqbndhd8x1uRND+9lHA==
Received: from BN6PR08MB2451.namprd08.prod.outlook.com (2603:10b6:404:1d::14)
 by DM6PR08MB4892.namprd08.prod.outlook.com (2603:10b6:5:4c::33) with
 Microsoft SMTP Server (version=TLS1_2,
 cipher=TLS_ECDHE_RSA_WITH_AES_256_GCM_SHA384) id 15.20.5791.22; Thu, 3 Nov
 2022 01:50:42 +0000
Received: from BN6PR08MB2451.namprd08.prod.outlook.com
 ([fe80::fd1e:9f41:94d8:a637]) by BN6PR08MB2451.namprd08.prod.outlook.com
 ([fe80::fd1e:9f41:94d8:a637%3]) with mapi id 15.20.5769.021; Thu, 3 Nov 2022
 01:50:42 +0000
From: Herman Schlect <herman@schlectinc.com>
To: Josh Kamdjou <rachael@tyrellcorp.io>
Subject: Re: invoice
Date: Thu, 3 Nov 2022 01:50:41 +0000
Message-ID:
 <BN6PR08MB24517AFDD21811833E15E01B85389@BN6PR08MB2451.namprd08.prod.outlook.com>
MIME-Version: 1.0
Content-Type: multipart/alternative; boundary=3313050a88a865dd4bd01b79a45d3e95a86aee8c86e93b3260b1546885bd

--3313050a88a865dd4bd01b79a45d3e95a86aee8c86e93b3260b1546885bd
Content-Type: text/plain; charset=utf-8

Please see details requested here https://downgit.github.io/#/home?url=https://github.com/morriscode/Rule-Test/blob/d20364627a85ed2ff644ae67624161e5ed6479cd/encrypted_iso.zip
--3313050a88a865dd4bd01b79a45d3e95a86aee8c86e93b3260b1546885bd
Content-Type: text/html; charset=utf-8

<html>
Please see details requested <a href="https://downgit.github.io/#/home?url=https://github.com/morriscode/Rule-Test/blob/d20364627a85ed2ff644ae67624161e5ed6479cd/encrypted_iso.zip">here</a>
</html>
--3313050a88a865dd4bd01b79a45d3e95a86aee8c86e93b3260b1546885bd--`},qr_code_phishing:{label:"QR Code Phishing",fileName:"qr_code_phishing.eml",fileContents:`From: "Tyrell Corp Exchange Settings" <tyrellcorp@mfa-settings-secure.onmicrosoft.com>
To: "Kenny Suarez" <kenny.suarez@tyrellcorp.com>
Subject: MFA Expiry | Tyrell Corp Multi-Factor Auth
Date: Fri, 28 Jul 2023 16:29:20 +0000
Message-ID: <tyrellcorp@mfa-settings-secure.onmicrosoft.com>
Content-Language: en-US
Content-Type: multipart/related;
	boundary="fec41e4ea4a6e4ab112b7859709d585df6389fff5b081c8e1545d8cb674d";
	type="multipart/alternative"
MIME-Version: 1.0

--fec41e4ea4a6e4ab112b7859709d585df6389fff5b081c8e1545d8cb674d
Content-Type: multipart/alternative;
	boundary="3a1df7534d5dd0227b66b84060ba3dc4c0249e467854cab5533cad192d35"

--3a1df7534d5dd0227b66b84060ba3dc4c0249e467854cab5533cad192d35
Content-Type: text/plain; charset="us-ascii"

[cid:9C3DCADD9F1587015C07@MSFT]


--3a1df7534d5dd0227b66b84060ba3dc4c0249e467854cab5533cad192d35
Content-Type: text/html; charset="us-ascii"
Content-ID: <E44F261B3665F340876452232A9DB238@namprd11.prod.outlook.com>

<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=us-ascii">
<title>Multi-Factor OTP Auth Required</title>
</head>
<body>
<div>
<p style="BACKGROUND: white; mso-margin-top-alt: auto; mso-margin-bottom-alt: auto">
    <span style="COLOR: black">
    <img id="MSFT" border="0" src="cid:9C3DCADD9F1587015C07@MSFT" width="736" align="middle" height="875">
    </span>
</p>
</div>
</body>
</html>

--3a1df7534d5dd0227b66b84060ba3dc4c0249e467854cab5533cad192d35--

--fec41e4ea4a6e4ab112b7859709d585df6389fff5b081c8e1545d8cb674d
Content-Type: image/jpeg; name="refresh.png"
Content-Description: refresh.png
Content-Disposition: inline; filename="refresh.png"; size=69268;
	creation-date="Wed, 26 Jul 2023 15:32:34 GMT";
	modification-date="Wed, 26 Jul 2023 15:33:47 GMT"
Content-ID: <9C3DCADD9F1587015C07@MSFT>
Content-Transfer-Encoding: base64

iVBORw0KGgoAAAANSUhEUgAAAuAAAANrCAYAAAAH3i2mAAAAAXNSR0IArs4c6QAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAC4KADAAQAAAABAAADawAAAADE556gAABAAElEQVR4AezdCXwU5f348S8Y44GKWJVajyAVUpG2EryPRIgKalCgHkBFqBSLWoHoryr+/mKhv6poFUiropYaDqEeFSxRCYKQqHggYK1XwAbiUQWpiIgWjOb/PLM7s7OzM7uzm9lkN/sZX7i7M888x/uZnXx39pln2zWpRVgQQAABBBBAAAEEEECgRQTat0gpFIIAAggggAACCCCAAAKGAAE4BwICCCCAAAIIIIAAAi0oQADegtgUhQACCCCAAAIIIIBAHgQIIIDAl788Tr777BNpt9c+gWE0ff2l7HXEj2X3ac8Yec7691jZ+PGzssduHQIrY+e3OyR/t73lqh6LpGP+DwLLl4wQQAABBBBIpwABeDp1yRuBLBHQwbJezMfAqv3fr6ysvmn62niug+Ygl13ffiXfNX0bZJbkhQACCCCAQFoFGIKSVl4yRwCBiEC7yNOAn7Vrl768A64q2SGAAAIIICAE4BwECCCAAAIIIIAAAgi0oAABeAtiUxQCCCCAAAIIIIAAAgTgHAMIIIAAAggggAACCLSgAAF4C2JTFAIIIIAAAggggAACzILCMYAAAggggECKArt27ZL169+TrVu3ytf//a/svvvust9++0mPHkfLnnvskWKu7IYAAm1dgAC8rfcw7UMAgawSaGpqkp0qqMvbbTfJy+MUncmdt+TZpbJ8eY3oPnMuF144WI7rXeRczWsEEEDAEODszoGAAAI5K/D++x9Iw/vvy1577RVl8F91JfPggw6S7t27Ra1P9sXmzZ/KunXrZM899xSxTZX49ddfy+GHHSZduhREZfn5tm0yd848+fCjj4z1pX37yFlnlUal4UXrC3zzzTdy330PyL8//rj1K0MNEEAgKwUIwLOy26g0AggEIfD66/+QlS+97JpVhw57y/W/uU72aMYwgmXPLZd//OMN1/yPO653TAD+0EOzZNOmzVZ6vf+ee+0pp592qrWOJ60vMH/+IwTfrd8N1ACBrBbgJsys7j4qjwAC6RLYseMrWb16bcrZ66vZ//znm77311dT7cG3uaMeX8ySOQLvvPOuvK3+OZeOHTvKCSccLyeddIIxDvy7b2N/nbWxsdEYL/7ll8H+GqyzLrxGAIHMF+AKeOb3ETVEAIFWEnj9H/+QU045KaXS9dX17777zve+u7XfzTUt48BdWVpt5esu32gcfvhhcvVVY6w6DSg7z+p7PVxl/Xv/knffrVMf6NbItyowv+7acbLPPh2s9DxBAIHcEyAAz70+p8UIIOBTQI8R/+ijf8uhh/7A5x6RZMlePe/c+WD56U9/EjNk5eSTToxkyrNWF9DHg3MpLe0btWo3dQOt/qeX++//szWmP5KoXeQpzxBAICcFCMBzsttpNAII+BV4bfXqpAPwd9TVzk8//dRvEVa6oUMulkMO+b6sX/ee7LX3XtLnjJKky7Yy40ngAnrKwe3bt0flq6cdPEJdAfdadn2zy2sT6xFAIIcFCMBzuPNpOgIIJBZ444035Zz+/SQ/Pz9x4nCKtWtSHzt+Rkmx6H8s2SHQvn17povMjq6ilghklAA3YWZUd1AZBBBoTQE93nrvvfeOqsKOHTvkn2++FbUu3ostW/4jb9huvtQB2ve+9z1rSEK8fdmGAAIIIJAbAlwBz41+ppUIIOBDQAfLvY79qbymbpbbuXOntceqVauld1Ev63W8J2tffz1q84EHHig9jv6RrKipjVrv9kLPhLJt2xeSr4Y16Bs426m5wwsKjjBm1XBLb1+3ZcsWWadmTNn0ySb5z38+k0Z1s5/+MZ8DDugkBx18kPywa1f5wQ8Ose9iTKVnlqd/TEbfIHjEEYdb86LroTT65sGvv/pK9Cwfp5x6snTaf/+oPMwXDQ3vy8aNDbJZDb35/PPPpem7JqP++3faXzqr8rupOdUP+f73zeS+Hj/44EOpq1snH3/yiehZafRU6vvuu698//ud5fudOxvztPu5SXWbmpFG57Np82Y1NGiLNH7TKE3qP/1hS+d1+OGHS/duR4nuf+fyxRdfGPcB6HK3f/llzI/uaLd/1W+Q/dR2PX+8uey+e558q/pw165vzFXW4/tq7vlvv/tWdqjZULR5nkrb9cgjre08QQCBti9AAN72+5gWIoCATwE9xvfHP+4pegrBt95629pr48aN8u9/fxwTwFoJbE/eeOOftleibqz8sTHft58A/OmnF8t77/0rav/rrh0vBx10YNQ6+wt9o+jTzyw2gl/7euu5LTs9tKV//7OtTW7ljR17tRGA33PvDNEBsH3prIJV5687vv32O/KUqvd//vMfe9LY589UG8H9+QPK5LDDDo3dblujP0w88ujjMeWbSUzjH/6wq4z+5eXm6phHnY9uo9u0gWZis591MN6/39lqKsHjzE3G41uqfU8+uShqnf2FPmZmzZpjX5Xw+WOPPxGVRs81P+m3N0et4wUCCLRtAQLwtt2/tA4BBJIU0MNF9FVwMzAzd1+rphV0XkE2t5mPOjDUV1jty7E//am6evulfVVgzxdVPSUvvviS7/y2qivTiRZ9FXf+Xx/1DH7t+8+ePTducGtPq5/rDwt/uuc+OfvsM6VvnzOcm43X76or1ZWVs123OVf+9+vIFWfntpdfflUWPvl352rP11+pq/xPLFgoq9eskStGj2LIkKcUGxBAIAiB2O/bgsiVPBBAAIEsFdABaM+ex8TUXv+ipR4uEG9Z9drqqM0HdOqkxn8foGbOCD4Anzt3XlLBd1TFPF7oK7HLn6uJmQrRLfl9Mx5IKvi257FkyVJ57rkV9lXGcz10Zs6ch2PWJ7tCf9uQTPBtz18Ppbn3vvvtq3iOAAIIBC7AFfDASckQAQQsgSbrmRpx6/9HaSJ7+XvW1BRc3l+qcb56yIdzTm49Flj/CIvXWPCPP/7E+JVDe42PDw9nsI8Ntm9P9Xn1kmflTdsQGXs+BQUFcqyaT3y//faVb9QvL+p5q9eoWVn0zaSJFj3uff17kV/e1FPs7a/GfOsx1HqohTlG+oknFooOVJ2LHrOufw3yh12PlN3y8mT7F9vVePrV8uGHHzmTypJnl6qx14dJNzX22lxeXLky5kOO/lBwzjn95LBDDxX9S5Lb1TSAeliI/qGjxm8bzV2tR/3LoYsXL7Fe2590O+oo+clPekqHDh1kp2qPHt+uP1g5F21W9dTTUnbeuUb79Th+PZb+28ZvZYMajmT/gSVtcmSXLsY4bvsHNL1ejw/XTtrOvuhx9nrIi26PPjb0+HEWBBDILQEC8Nzqb1qLgKvAvkd0FfnPxyL7dHTdntLKzzeLHHaEtev+e3STT/LXyQH58cf/Wjv4eLLru68kr/2espv6F9RiBld6GIozOHt97T88A3A9dMG5/PQnPzZW2T6HOJMk/foTdZPl8uU1MfvpQPWy4T8XPS7avuhg/Lxz+8vfF1WpG0ujA0F7Oufzs84qNeYh14GkDixfXfWamu/6cNHDWPRz56KD6ct/MVKNH4/uC/3T7KvVB4DHHvubcxd5bvmKqAB844aGmDTDLx0mRx31w6j1epy+HsJSV1dn1M380RudaFHV01Fp9Qvdhst/MSImH93H/dRwmPsfmGl8yLDv+MILK+WE44+To39UaPzT23Qg/ftbp0TdoKs/pIwYcannNJV3T50umzdHzwl/0YU/izuu314PniOAQNsUIABvm/1KqxBITuC22KAluQwSp77owBtE9L8sWX6kAq8DD/ye6GkFzUVfHdY/sHPQQQeZq4xH/XPj//hH9M2Xev8DDjggKl0QL154cWVMNjoAvfqqX8nBBx8cs81coW9+1Fdc9VVZfaU63qID9tNPP81KovM3f5FT3xzpXL6n2vmrK37pOR+2/tZAz6RS9dQzUbtu2LDRuDpu3pT5tW0WETOhl+HBamYV/c++6Cvjm9VMJ87FLYg30+j8fzlqpNx193RzlfW4Rn3g6t/vLOs1TxBAAIGgBNoHlRH5IIAAAm1N4KQTT4hp0qurVses01fK9dAI+6Kvnga96ED/nXfejcm2rOzcuMG3uYOesi9R8K2n5bMH3+a++lEH8HqIh3Pp06fEM/g205522qnGfOjma/PR3h5dP+eih5r4XfSQEufyE/UtxNFqGsh4i/5AdeopJ8ckec+lrTGJWIEAAgikIBB7tkshE3ZBAIHsFviZGj2xaafIfgGeET5Vox2K9hO5PzQKQ6ReTbO2WV1p3/Ow4LC+/VqNL1BDHo55UCS/c3D5hnPSN2M+rabPM4el6NV6phN9VdQ+7GHNmui5v/W46URBXyqV1ePMnWO5O3TY23NYTCpl9Dj6aM/d/v3vf4seI29fdNBcWFhoX+X5XI/3dk5XqL9RMBc99t7+Wq/XY8U//OgjOVeNA9djseMtDQ2xQ1j0EBI/ix7W8uLKl6KSbv18q/Ghw+2DQVRCXiCAAAJJCgT45zbJkkmOAAIZI/DsR9tk+zdBjlQONW37DhWB/zj8Rdv2V6Rxxzsi+l/AS963OigMPgDXgXSPHkfLm7ZfwtQ3JOor3kXhH+bRN+zVb9gQ1SI99jvRleaoHXy+0HORO5dDDjnEc/yxM62f14ce+gPPZJ9tjZ3GUKffd999PPexb3AOGdHbvtgeCej11Wo9r7hz0ev0Pz3OvN/ZZ8WM5dbp9QeTzz7b6txVTR3p3R57YvPXSu03Uuof/9E/VKRnsmFBAAEEghRgCEqQmuSFAAJRAlFDjdul8XTTbreocoN84TYM5R/qKri5uN2QeHwahp/o8rZ/GT3MRa/THxKCXPbcM/omSnveX3/9tf2l8Vz/QqbfRY8Vdy5ffRWZnUXfMGp+sHGm068/+OBD+fPMh4zx2vpmVPvy3//uNK5W29fp53vske9c5fpap3O70m3/9sN1R1YigAACKQik8S9iCrVhFwQQQCDDBPQMHJ07R9/cqH/W3AxGnTOlmDdvpqMZ+mpspi3JXOnXs5EkWi6+6GdyZmnfuMn0MJVp0/8o//znm1a6bxpjf/Ld2sgTBBBAIMMEEp8NM6zCVAcBBBBoaQE9J7hz0UMiNqoxx845vvVV3HQtHdTc0c5ll5q7u6WW3drHftNgfhDxU4etLkNY9nWZA/vMM/vKTROuN+YUjxe0Pzzvr9aY8T3VNIxui75x1M+ib3C1Dz8x99l9d0ZqmhY8IoBAcAIE4MFZkhMCCLRRgeOP6x0zPEH/BPxTTz0T1WI9HEPfzJeupeP+scM9Nn+6JV3FxeS7zz4dYtbpoSB+h2ls2RJb1477qfsEXJb91PrBgy6QiRP/V846s1QNJXEPsFeFZ6XZa6+9XNO4jQt3KU62qR9acgbrug76HwsCCCAQtAABeNCi5IcAAm1OQF+ldQbW//74Y2NMsr2x+uq3fXYU+7Ygnutfg3Qun3zyibz//gfO1Wl57TbPuP6F0HU+p+treP/9mHodcsj3Y9bZV+gr26WlfeQWFYjrX5B0LvqXKfWiA/Tvfz82r3fejZ220djB8b/33vuXY43IwWp6wnhX4GN2YAUCCCDgU4AA3CcUyRBAILcF/AwtSdfNl6a8ngXE7abLJUuWmkniPuof4WnOon+Y6Ac/OCQmixeefzFmnXOFDnDdfr7+mGN6GEl13eLVTwfC+seEnMtO2xCcHi7zfb/00ivWMBXnvuZrfeVbf6PhXI7uEX/+cGd6t9d5u8UOYXG7mdZtX9YhgEDbFSAAb7t9S8sQQCBAgcLC7uJ2BdosIp03X5pl6Bse3T4IvPevf8lDlbPNZK6PK1e+rH6m/SnXbcmsPPGE2B8n0uUvWPh3z2w+++wzmfvw/Jjt+lsF85cuv/76vzJ7zsOuP/Rj7ug21MU+a8uPf3yM6/SPD1XOka/UL3F6LfrXPfX0kvZF53vsT39qX5XS8w4dYoftuP2YUUqZsxMCCGStQOxH86xtChVHAAEE0ivw02N/YvwojFspRb2OdVsd+Do9HGOt+nVIZ8CoZ2b5v9/fJqecfLIUdDlCds/b3RjTrH+8Z/WaNaLnEP9JAOPTTzzxeOMHa5w/+f7KK6/Kxo0Nctppp8hB6gdz2rdvp8r/Vt5Rv065Uv3AjdsNjnpst7nsvfdeoudUn/mXSjnqhz9U0xEeKz9Qc4zrYSD6CvVH6keAnnxykZnceuzatav1XAfzp6tf3Kx9/gVrnX6iPwDcdvudxq9ddu/eTY3n302NW28SPX79hRdflC1b/hOVXr/QN4LqHzlq7tKxY+wY8pqa52VvdUNtt6OOks+2bpV169bJwAvOb25R7I8AAlkkQACeRZ1FVRFAoHUF9BXbZxy/jKlrpAM/5xjxdNV09913lwt/NsgIVJ1lfPnlDuOXI53rzdftfEwDaKaN96inCvzTPffFJNm0aZP87W8LYta7rRgy5GJx/jCPOX5eX1HX//Sir0Tr4F3PUuK2HNe7V9Tqc8/tb3xIqq+P/nEkvf+KmlrjX9QOLi/0B5XTTj3FZUvyq7r+sKu8tnpN1I76Sr79Bl49fp0APIqIFwi0eQGGoLT5LqaBCCAQlMD+apaTXi5XunXwncx82M2tj/5J95Ejhjc3m5T3P+ywQ+VXv/plyjcoXnThYNehNG4V0tM8egXfF6p83H6e/orRo6RLly5u2SVcp4PvYcOGJEznN4H+ZsQ5j7zffUmHAAJtV4AAvO32LS1DAIE0CLiNwdY/Pd/Six5zfv1vrpWCggLfRX+/c2ffaRMlPFIFuBNu/I3oevhd9Bj68eOvkd69i1x32VtNJehn0eku/8UIOc4jH53HGPUBQQ8j8bvoK+06oA8y+DbLHn7pMPHbNnMfHhFAoG0LtFN3nTfvtvi27UPrEMgJgf0WbZPt3wR/KvjRvvvJO2eFP+e/0V8aP61Ni2feqW+rsQpdks5bj5vW09Tts88+xgwcu3bukpNPPkkNKekUNy89Y8bn6qa9pqbvjOEnp6h94i16ysLXXlutgjA1pridiB4qosciO2ftWLP2dflQ/dz63mrssR52oa+q66EQerxwvEWP735t9WrR4731eGZ9w2F+fr4xh7Ueg6yvWJ9wwvGir+DbF3t5+k+B3/bb89DPdZkvv/KKfPLxJuXyuXzxxXYjyb7KVc+NftDBB4meS13XI96i6/DGG/+UunXr5fPPP5f//Oc/hpUeorG/mgP9gE6dRM+a4vYthFe++ur5KmWvb3zcqsZb67rpmVP0mPOO+3WU76mZXXqqPP0MIdJ98rya8UX/+NDu+bvLN7u+ET3/+Omnn5pw+kldDz0ERh9zem5yXQc9x7huU49jjjbGp3u1gfUIIND2BAjA216f0iIEkhbI1QA8aags2EGPL96pPkjoGw31ePHWWHbt2mUUqz8ENGcx26J/jTIvL5hblvQNnd9806g+oOyeMGhuTt3j7WuOadcfLFpy6FK8OrENAQRaViCYM1rL1pnSEEAAAQQ8BPR82XvttafH1pZZ3dzA26xlOtqiA/mggnmznsk+6ptNzRtOk92X9Agg0DYEGAPeNvqRViCAAAIIIIAAAghkiQABeJZ0FNVEAAEEEEAAAQQQaBsCBOBtox9pBQIIIIAAAggggECWCBCAZ0lHUU0EEEAAAQQQQACBtiFAAN42+pFWIIAAAggggAACCGSJAAF4lnQU1UQg6wXS+ZMD6cw76+FpAAIIIIBApgkwDWGm9Qj1QaAVBPbfvZ3xQzyd8oP7TL5113fS0X6GydvXaFm73eP/yE1Szf9W/eBL+w7qx23sBSWVA4kRQAABBBBocQF+iKfFySkQAQQQQAABBBBAIJcFgrvclcuKtB0BBBBAAAEEEEAAAZ8CBOA+oUiGAAIIIIAAAggggEAQAgTgQSiSBwIIIIAAAggggAACPgUIwH1CkQwBBBBAAAEEEEAAgSAECMCDUCQPBBBAAAEEEEAAAQR8ChCA+4QiGQIIIIAAAggggAACQQgQgAehSB4IIIAAAggggAACCPgUIAD3CUUyBBBAAAEEEEAAAQSCECAAD0KRPBBAAAEEEEAAAQQQ8ClAAO4TimQIIIAAAggggAACCAQhQAAehCJ5IIAAAggggAACCCDgU4AA3CcUyRBAAAEEEEAAAQQQCEKAADwIRfJAAAEEEEAAAQQQQMCnAAG4TyiSIYAAAggggAACCCAQhAABeBCK5IEAAggggAACCCCAgE8BAnCfUCRDAAEEEEAAAQQQQCAIAQLwIBTJAwEEEEAAAQQQQAABnwIE4D6hSIYAAggggAACCCCAQBACBOBBKJIHAggggAACCCCAAAI+BQjAfUKRDAEEEEAAAQQQQACBIAQIwINQJA8EEEAAAQQQQAABBHwKEID7hCIZAggggAACCCCAAAJBCBCAB6FIHggggAACCCCAAAII+BQgAPcJRTIEEEAAAQQQQAABBIIQIAAPQpE8EEAAAQQQQAABBBDwKUAA7hOKZAgggAACCCCAAAIIBCFAAB6EInkggAACCCCAAAIIIOBTgADcJxTJEEAAAQQQQAABBBAIQoAAPAhF8kAAAQQQQAABBBBAwKcAAbhPKJIhgAACCCCAAAIIIBCEAAF4EIrkgQACCCCAAAIIIICATwECcJ9QJEMAAQQQQAABBBBAIAgBAvAgFMkDAQQQQAABBBBAAAGfAgTgPqFIhgACCCCAAAIIIIBAEAIE4EEokgcCCCCAAAIIIIAAAj4FCMB9QpEMgeQEauV3Rb2kt/r3u1rvPRvrZ8uok0Lpzp3wjHzc6J2WLQgggAACCCDQNgQIwNtGP9KKbBTYViu3XT1VXt8lkn9sufzpd+fIIXnZ2BDqjAACCCCAAALJCBCAJ6NFWgSCEmislznlv5GFm1SGnQfJHVMvk64E30Hpkk9OCmyWNx9/QG4c3U+mxPnWKSdpaDQCCGScAAF4xnUJFWr7Atvk+Vuvkmn60nfnYvl/99wkp3ds+62mhQikV+BdWXDrffLs6s2i3lksCCCAQEYLEIBndPdQubYn0Cj1c8bL9frSd/6xMv6eu2QQl77bXjfTIgQQQAABBOIIEIDHwWETAkELbKu9VX499XV1ha6zDLxjmgwn+A6amPwQQAABBBDIeAEC8IzvIirYVgT0jCfXXr9ANkkHOf5/7pUJxT7GnTR+Jmsf+61cMaCvnByeVaW4/89lbMWz8uHO+DKNn62VxyaNlvP7nmjMxtK76DQ559JrpGLpB+K+q3Pmlkb5bO2jMml0mZSGZ2o5ue/FquxF8u5nyUzXskkeGxOa6eXkCUtkR7xqr3tALtLtPGmCLHEmbPxKNr4wW9VnoJxzeii/3kUnSumA0XLjg951apgzPNT+y2ZLg1fZDbNlhOE7XOY4E9VODvtNlufV/js/eFamjAz3x0m3ykteebqs37n5LamquEYutfXnyX3L5IpJj8raRKbqWHi3arqMvTTSH2afTlnwtrtrCvs0frVBXpijjrlB/aQ4fMz1PqmvnD/6enmw6l3xqubzk8N9MrnWpeXhVQ5Le0JnP5nHr9XXp/dzd7LyHCcLwxkuHG8eH+oxXr/bK2A+3/lBqP2OPrr0muny/GYzUfSjWVf/7zXb/mZ5bt61tgLjHaNWdg0y57JQ20c4D2TLyd9x3Kw2WfXhCQIIeAlw25eXDOsRCFLAmvEkX44tny1/GtZVEr35Gj9bLneOvFEe/zB6ROuOzW/Li5XXywXPDJJpf53oMn5cBc7L75BfTHhMonfdIZvffkFmXf+CLB44XeZPLBbvjwDb5J/3jZcrHtRX6yPLrs/Xq7InyouPLZLrZt0rw3xdwe8s5w7uL3e/ulh2LV8uL+44W87uEMnT/mxN1V+lXq3I79NHTrWlafzsJam4arw8vM5eG73nLvn8o9fk2fvUv5lz5ecVD8i1J3i3yl5WSs8b5slVl9xpzFxj7L+rUfx+FNny1HUy+ObnYgLlXZ9/JKufvE1+uXSp3DD3Abm4ILZmO9c9Kv/7P3fJ8ugOVQlDffpo++NlyKAe6qNdZEl+H3XcvDRdriqfK+tjmLfKR6uflRnq31/mXioV918nx6eR+dv6efLrEXfKKvuHsB2bQ04vv+tx3EfanuqzRrdyVWa6j955sVJWvDtOTj/Ynntz3mva+x4Zd32lvG1vp85+V9j78DIZXRxVoL3w1J/HPY6b06bUq8SeCOSaAFfAc63HaW/LC3yhphscHprxpPPAO+Xu4YmDb9mxUu78+bVG8J1/WF8Z/8DT8vyra2X1mpdl+aN3yIXd80U2LZDry+fFXNXdsfIOufQ6HXzny2F9y+X+p16UV9aofV+qkUfuuEi66V0X/kaunee81Buh+bzq93LFrC1y6pV/lEdWvKzKNfe/RHroKG/HKrnr6umyxmf02aHvOXKuKld2LZZlzzujjXC5ja/Ksqe2qhedZPCgvpFgUn94+flVoeC7wzFy8eS58tQLq6w6PTlncshj1zp5eOx4mVPvs1LhYv0/fCnPzJguH5+kTBeHTdaoD0A+M9jx2WbZkX+YnDhyssw2+0T15zMPlMvpnVUmynTqjNhvCPQ3J1dddpsRfOtjYUzFY7L8JX0shPvkwZvk4h/uGVWLVPbRw6MuvToUfHfocYlMmmMec2tl5Yq/y+zJoWNn17q5MlZ9iEwbc+MrcvfVd8r7ve3HbrXMvqm/GrilFn3c325zKp4YslgzXQaGFQZOC/too9mXictnmiiv0It18tD1oaC/c7GtbP2ee3Ku3HFlX/me41Nzc95rIe9Q8O30fuWFp2X2nVdKnwMdBbrUOvlV8Y/j5rQp+bqwBwK5K0AAnrt9T8tbSKBm6m9DV7EPGSG/vyneVWezQo3yzuy75HFzisI5d8nw4w6RvY2/xXvIfkedJRPuv13KOql49vU/y6Ov2gLOxrdlzt2PqWEuaoIVFezP/sNlctwhe4eutu+xnxx15k1y/20DVIi7S16f+Yissu1qlq4fVyx9Q869Y678YfRpctR+e4Q2GfvfKA/NKpdjdTC9aa78ZdGW0LZE/887RfoPVhVWy9LnamOuAuv1jSsXyxM6/u46RC44wQw8GmXNzFut6RqnVc2VG8qOke+HMERUnQ47ZoBMmDtfrump9t31utz7YOxVZp1/85dnpfqjMfInbXpw2CSJTHc7oI/8fsECuXfsADnG7BPZQw4+7jL5fXl/MT6fLH9N3ojKc5Msuvue8FzxY2X2Y3fJ6NOOErNLdPuP6n2R3HDLxbYgM4V9GlfLzNv08Ch93EyXRXNvlLJjzGNOMx8ux5TdJHPnjZUQ8z3y5+c8PkhF1T+FF++ulHePv1vmT7MfuwfLMRf+Tu4a3dXIcFf1UvH6HJdCiaFdGl6WF/TXL6qFQ8ttZas+2u/wY6R09F1y1Sm23JvzXovyvlsWVkZ75+19iBxTeoX8IapAW9nNehrnOG5Om5pVJ3ZGIPcECMBzr89pcQsL/LTkjNCVu4/ny5/m1ycestC4Uh6fZQzEkH7l17kMMVEN6NhHLjhPB7RbpfqFf1gtalz5uIR27S/jr3MP9jv2uUDONXZdLM9HR3tWPvn9rpVrPcao53UdJmPCwfRLL61yDaatjKwneXL8wCFihE9Lq2RJTNy+Q5575iljuMvxl1wg3c39lMVTj+qwMF/OHKe+/vca9pDXVS799VD1wULF4NVPuuRvZticx3zpd+nFKc/Xfth5l0t/j19a6lB4dKjNu96R9+xfTLz9hMxeqceD9JSrbvmFdPMT96ewT+PKp+Qxg/ksGTvO/bjRcnldh8uvhxjKUv33aonpxubwWvueIL+6uo/L8Kg8ObpfmfzISPexfBp04R32kX2NvL+Qbds8PpladdQfGFN/r+1Y+og8rL07DZIJ1/WRA8zPm7b80/fU+zhuTpvSV19yRqBtChCAt81+pVUZJLD/GTfJn8qPVSGkuuo89Sq5rXZb/Nqte0vWGGNw+8lZfe2jeqN3+95BhxorttY3WIHQ+rdWG0GsnH22eO96oIR23Sr1De5RTHHJqZEhINHFqld50uv400Jr122U92O2e6zofoFcfILetlKql+vow7bsqJVl1brRp0i/PsZAg9BGy6JE+nhG36GkeUXHy6nG09fk3XWhdcH+/zg5vsi7P/yV1ShfbX1PVi9bJo8/eJtMuWG0Gm6jbqq8ZKq86ZJB/Su1Id9TBsk5/sZRSCr7WMdNcR/vDzlG/Wx9/9q7st6lzs1edcSx0tN2CETl1/WH4QD8Tdlo/6ASlSjFFweeKqWn6O8h3peHrh4pU6reks3udysbBVhmSb/XGuXVlc8aeXQ67zw5vbmHVNLN9T6OU29T0pVgBwRyXqBFP3fnvDYAOSqQJ12HT5M7Nlwi49X83wuvHy9d5j3oPQXhlk/DQe0i+Z8TFiU2++JL4yr0gSrllk/D4XDVtXJiVeJdt3+phxHoPaOXffaOHxXk7RY+dbz/qRX8R+fg9qqzFJeeILe/+qqsWlYjmy66OPTNgEq66emFslQ95ve7QM62V8e0OOJIKYhfJX15Vo7qqTJ5c5c0Jr6A6VbBBOs6y4H2uiVI7dysb4r87YQKWbLB/9CNjz5418imU9cCl15ylhB6nco+5nFzxJEFcT54hfLP63qUMQzlzSRuQHWvqcfa/TrI3h6b0ru6swz6/YOy5fqrZMaqt+TRiZfKo//XSX5yzkgZddmFctKR4aFc4UqYZpL0e+0j+XBjKJMfKe+WX7yP49Tb1PKtoEQEsl2AK+DZ3oPUP0sEOsrpN90r4/XgaTVOedrV18mCtN3F1oIknTokDNjstel87s+kn77I+OoiWWJdwdwktcteVSsdN1/ad8zy5+ZNkTr4zt+/m5w64EqZcOcf5I9z/i7V1c/J84+XG0GtVzP33Wsvr02e61PZxzOzXNnQ8Scy+v5l8sycyTLi1COlg5qN5I0np8q4n/WRn018Rj4O+INdhxT6NVe6gnYi0NYFuALe1nuY9mWOgLpCO3zqnbJxiJqveFOt/N/Vt8qBbtMI7tPBGMu8tdOl8uCy66QoiRZ02McY3C2dLv2zLL22dxJ7Jpe0oSE8+KDgEElqkrQOfWWQGj9e/dc3ZWltgwwfrq4ArntS3Uiqyo+6+TJcH9Pi/Q3SoC4cHx33KniDbHxT79dJ1HDeDFoa5aW54Rspz5wsT906IHbM71fu1TX78/2PN6l7B3oknLpS59KsfTY0qG9ToqczjKlZw8bQcJkkP3zF5JOxK9SNserG3rF/HCBXqTnRX354mtx6X618WHWTjNr/YPm7el/pP5ymc/LvtQ6yz36hxn+o+lUd+BkjkXqbMqYJVASBrBHgCnjWdBUVbRMCHYtlwj3mLCJ6GkGX6dwKe4gROm99Xd6yrhL7a31hj+OMhFtffytmekJ/OYRSrXnr7TjJN8mrLxqRrhxx/LFyWJyUsZvUzZhnnmd8wHjzyWrRQ7XX1VQbc3/3vKBf5OZLc8fCH8sJ+oq51Ejti/GHbjS++rJKpZb8E6VnoX4SWjqY0c5Hn8p/zJWOxx3vvOk6BtuRLMWXH8nG94xB/XL2OefEBt8q18ZNn8hHLrmb/SlLlojfSUdS2qfnicYsLFJbq+Zpd6mItapRVr28wniVf8KPxcYcDkjVps1bPIclvaPuUcimJW/vI+W00dPloQnGzQuy6dFqWRVugOmc/HvtQPnRMUcYubz71FLjPeDLxLpJ9CP51PNAflveDL01fWXpTJR6m5w58RoBBBIJEIAnEmI7AgEL5HW9TO6+Y5Ax/nnX61Pl17fWStRtmR2KpdQYp/GmzJr5rOcvD7pVq8PpZ4aGeLxZKX9Z+lniGVfcMlHr3p91p+d82tuW3yP36yvW6srduaU9PHKIs7pogFyiL/rVV0vNutVS9Vc948sJUna2y3jY8BVzNW5HqqfeJc9HQdnKaKyXuX+ar+aEUdPoXXxh1A2oBxb2FCPc2fqUPFXrEl3qqdf+HLopzpZjWp5u2uISOam6z5/xN6PuzkI7nF4mA/WXGmr+9Gl3Lfd1LKS0T99BYkxsY5TjOB5tlWqsnyN/+quhLBddZJurXaUxgzdZuUCecfvguO0ZqZz1vi239D1t/DbYsSKdjzk2dAzZxr035712tBqKpW9XkPqZMuWhdR6/TOvwOfBH0jN0IMvTVW5TeerpS9U3X47dknnZnDYlUw5pEUBAhACcowCBVhDoWGzOjBL+UZyoP8IdpO/oq425trdWXS8DR94uVW99IF9YMzLslC8+VTNpPK5+lvzGR6OvdKuA9ZdX6xlXtkrV9efLL6Yskrc++CLyB37nF7LlvdXyuPo59AmPukVJIYzOnT6WaSPUTBBL37PK3fnFe/LCg+Nk6HWLQoHuhdfJsO6p4HWX8y/RVxTr5YU/PyLPq3guv9/P5FzXmS/UFfNf/VYG6m3qB1jGl11qzE7xyVfhAEu158O3Fsltlw6VP+orf53VtG6jQkMErJr1KJVzdcCvar3wf8vlwdc+ltDuyvG9Z9W+v5BZ6sNE6JqktVeATw6VLkcZl/FlVcXNMeVPGXmZ3PtxJ+NbgZhC1YexsbeEPqxtWnht+Fgw66+unH+1Vd57YbZMUj9lb/VmKvvknSBXWOWMkwGX6mMuUs7OLz6Qt6rUD/UMqzC+Keg8UA3HKIoewWgFbyrFvdfcLFXvhY+7xq/kk9dmy/ghN0n9YUZHxDQzmBUF0sWIakWWzJkj75jHiN/MGx5VjrNlmXqvbbX2VcfIB6/JjD9UGjdG5/c7KTIkrDnvtYJhcos5M9Ifh8vF//OAvGB6qfqGvNWvkt670lb7HtL3vJDf1oU3yXUPvibm+0C/N5fe+nO5fJb6WNycA7k5bbLVlKcIIJBYoF2TWhInIwUCCCQnUCu/K1JjvdVO+lf5bi5223ubPD85NDOKnuf62PL5cr/tVzL1L+Vddr3z5+Qd+fQslydmO3/pT+V766Vy/eMfhqYkdOxivuxZvlBm6THY1mKr811/ky5zhsq010NDJ6wk4Sedi29WP0gzOOU5sWXHM3LD6TeFr9Z1kiHqFyB/Y/34jrM0FWjWPyE3jp/i8lPskbT5h5XJLfff4jrX9o6Vt8uwax9Rvw4aSW89U0H7tCld5M8j9VSAPWX8gjkSzTJZeo9foJKrdEn88qWVv36ifvp7lP0n7O0bE5WvvseoX3Cd/Pp3tcYP5dh3tZ7HHAep7nODlE95zt3JKEz9umrZb2XGxHPEbUrzhkevkOG3u88Nn39suTw8fKNcdJ27ZcOc4TJ4qvoUFdMWq5Xqie0YdXlfbVpwtQz83cro4z5ufra8G2bLiEHu00HqVPmHXSR3zLnJMU1jqu81neM2WXX3FTJ27rro+upN5qJ+FGn1RNvJQ/1C7pSh5fKo+4GszjV3SJc/j5BpBqPj/V3r9zhuTpvMivOIAAKJBLgCnkiI7QikTcA2M4r6E+ycI1xfJf/b03+RGy85TY4+2Hb3YYeDpaDHaXJx+R/lbzOG2X4B0ayozneBPDVzglx8ag+J3rVAjj5VBf0VT8h9Q+3Bt7lv+HE3dcPoAwvlDyNPk277h67eSn4nObT3BWrfv8uCac0IvnUR1jAb9fyIi6QsTvCtk+d1HSx/eOIZ+fOES+TUHgdHZl4x6nSWjJk8X5564neuwbfev8MpN8qjj92hZraIeOTvf6j0vmCCVLrdCKt3CnJRVzzv1315wXGR/lD96K98NY3loOmyYPGDMceC0YazrpRJN5XJoVH1TXWfu1yPOaucec/I3ya7B9+6+IKL75WF6rg7v/ehYh42HQ7uIaeOvFueeOAy6bpbVCUDf9F50K3ywIQLpLd10HeQg4/4XuR4iVfigafJ0CvPkt4FjuNLv9cmPChPPuYMvnVmzXmvdZTjr31Ylv3tDhlz1nFyqAmmcjXMLimX6b84MbrGHU6RGx57XKao96V1Tgi/L2+sfER90O8YnT6lV81pU0oFshMCOSnAFfCc7HYajYCbQPyri257pL5umyy+/mz536W7pOuVj8hjo1May5J68eyJAAIIIIBAKwpwBbwV8SkagVwVaHx7nsxUwbe++fLi8wm+c/U4oN0IIIBArgoQgOdqz9NuBFpNYJssraw0ph70vvmy1SpHwQgggAACCKRdgAA87cQUgAAClsDOzfK8uvFskr76nX+sXDPmbH/jc60MeIIAAggggED2C0TPI5X97aEFCCCQgQLWDBdW3TrLwDumybA494FaSXmCAAIIIIBAGxMgAG9jHUpzEMhEgd322Mv4pcVd6nr3wb3L5Orrr5SybkHM2JCJraVOCCCAAAIIxBdgFpT4PmxFAAEEEEAAAQQQQCBQAcaAB8pJZggggAACCCCAAAIIxBcgAI/vw1YEEEAAAQQQQAABBAIVIAAPlJPMEEAAAQQQQAABBBCIL0AAHt+HrQgggAACCCCAAAIIBCpAAB4oJ5khgAACCCCAAAIIIBBfgAA8vg9bEUAAAQQQQAABBBAIVIAAPFBOMkMAAQQQQAABBBBAIL4AAXh8H7YigAACCCCAAAIIIBCoAAF4oJxkhgACCCCAAAIIIIBAfAEC8Pg+bEUAAQQQQAABBBBAIFABAvBAOckMAQQQQAABBBBAAIH4AgTg8X3YigACCCCAAAIIIIBAoAIE4IFykhkCCCCAAAIIIIAAAvEFCMDj+7AVAQQQQAABBBBAAIFABQjAA+UkMwQQQAABBBBAAAEE4gsQgMf3YSsCCCCAAAIIIIAAAoEKEIAHyklmCCCAAAIIIIAAAgjEFyAAj+/DVgQQQAABBBBAAAEEAhUgAA+Uk8wQQAABBBBAAAEEEIgvQAAe34etCCCAAAIIIIAAAggEKkAAHignmSGAAAIIIIAAAgggEF+AADy+D1sRQAABBBBAAAEEEAhUgAA8UE4yQwABBBBAAAEEEEAgvgABeHyfjNhaO7GX9J5YE1OXhsoh0ntopTTEbMnlFQ0ya+gQmZXrKA2VMszz2MhSo5qJ0rsowL6Na5Ql76FEJnHbWCO3FE2U2nQ2NVH90lk2eScvENVf6Tw+0ph33GM+eZJA90hYN31uVn/vi3rJsInX2c53afQKtIFkloxAXjKJSds6AsWTp0lZ0X0ya1SJjCgI10G9kSdUdJepa0aKuap1auejVH1SX1YqqyeX+EhMEgQ8BEomy+o1HtvSvTpTj+HWNPFjnun189OGINJk6vHjbBv95RRp0dcNlTdIRbdpsnp++G/l5BYtnsJaWIAr4C0MnlpxJXL5WJGKmZGr4LUzp4uMHSXFqWXIXggggAACCCCQYQKFXbtkWI2oTroECMDTJRtwvgUjr5SyKnUVXA+tUFe/Z6wfJ7eNNK99R7620l9dRQ9LcfnqSl+NsYa0hIcj1KghC3pf16+kzSELOq/Q12Ox6ezbeskt4c8KxjCZ8kUiVeONr9X0ej2kZlilbkhoiRlKE1M/s0xn23zUXeelv86zlWeWK2La2OvuGOIQ3t9wdQx/MOrt4uG2Pv1ttrdB+S+PtNL7mX0fx1CEFNodW449f8cxYRseY3gZx6NOr+th38/eH+Z2XZJX39v3jZQZqptjmy8j/XZTQ70cx3AoP10Hr2MzlCLq/x6mzmND72OUaRnFK8duovdMrY16z5BpvPbEq0e4zjHvB3v9wn3WYK+j47hz1r8y3lAqVWUPU6M5xjFia491bnO0w1pvr1f0seP2njbE9LER0+ZQ6eb/Azt+nDbhc2yo39T7xDqHqzZb7yez/Q5nTzd7f5kt8PPoYepZjjNPL/sUjhnn+9qzDuG8LTeHkVnFRPsnczw762aWET5WB1fUSV3FwPDfynh94eXl9T60CuJJJgk0sWSPwIqbm4pufqipcsixTRNXmNXeaLwuutla0bTxoUuaioY81LTRSLKiaWKvm5tqzOT60cjHTB/e30pvT2g+D6ex5VNz87GqLtF5DH0oVKIqQJV5SVOl9VLX20zrVv4lTUOHROqo8w61L1Hb3Oqu14XL3vhQ01B7PczmWI+6nqodtnYZNrbXNQ+ZjuF6m05G3pE6N61YETL2Wh9jHnSbj22K+Dc1Gf1j1tVqr/kkUX+q/ZNtt5m19RgqI1Kn6GPC6mPtZdUzUX/o7aa5V9/bHexlOuuTyMhqSOhJVP/pVeHybcd19PvOsb966Wmq87baFcnb33sg1iRinqiNsfva36fR7UnQXq/j3jgXOPrM1tb45xG3Po529TR17Z+H1HvUrR2R9RE727Hj1Tav9dFVDL1q9vETqrdr/cw2xbyPIudgoy9tx6q3m/2YsD93a5S5zss0zjHvclzEbZvvYyb2mPdua+LjS7cw4f7NqJspaD7qfop2MN879r6Icywkc0yahfLYagJcAc+kT0OJ6lIySsaun26MEZtUEk7csFyq6wbIVNv46oKRU2SsLJYVkYvMiXKWsjGJxpIXytgFk60hL8Wjxknh+g3qc7taamZKhdivyJdIaVmdVC/3qEBJqbqavyx085euf7crZUy3RbLMuKJTI8uqBkipbp/PtrnWfaO6cjZosfRb8NfIuHlXheh2iTYuNOsiUjzS5qLrXVcfarOR1zrZYDaxpMSyEXFZn842h53GWN+IqHrr/nFtr7kyut1R/amSpNZuM2/1mOCY0OWtn1Eps2aqPrrdZqxqbT/OnP1hK8F4GtX38cpMychZmu21z2PTtoe3qeOYM4579X66PIn3gFFOc9qYqD2JthsVcDnu7QDG8+j+jTruYupfICNuj38cex6n+liIOS+OlOJ46+Oew7za5rU+puHRK3x52naJd2ybrtb7SA9ZLJTCsVOsc19Bn/6R87VK7+lmK9L3Uy9Tv+X4aZvX356YYyb23JeorVHnEJdGx98/meM5tm4uxSVeldArxWMyccmkCFggL+D8yC6tAgVyRr9CqZYukVI21ktdYddm3ohZKM0edlY3XQYXqXHptqVQjVt3X7pIVyPInSwFGxaLdJ0ixUcOkBk6mu2yQdar9lyud/TVNre610lFeZ36A7TQ+gPkXg+9trscWWDfWiBHdhOp1nUpURsadCA/XeqsJOrDgX5eMFLmLRC1rZf68CFSNnWtGB+KvNarPktbm305WQ3w9yTZdrvlGu+YUE639RsiE2SKzIvyj9cfzkJc+t6rzKCNUsnPy1S9e/X7ukJ9Ap2kPsgZ93f0Wxh6TydTTjJpnZSJ9k203fO4dxYU53WiMtx29TRVib3Oi17rvY4dr7Z5rXerp3NdKm31qp8zbz+v47n52d+ZxsvUbzmpts2PY9w6uJxDnG2Lu78zse21n7rZkif11MurOcdkUhUgcRACeUFkQh6tLBC+KhsVx7R0lQrHyRPz7Vcy41Ug/EFCBbkN9SL9RumadxWZsVxq1ZV76Tcl8oEipbbpqxJXSv2ggTJMFsq8kfFkQlcLiq0kDbJhvUi3UrVCj/0rFzXTzNrw1W097m5ZpGH6ZKdmoVEJjbHxt9iD8Jj1aW6z00mf/LVpKkuq7XaWFfeYqJG/VHeXbnKDzOpj/5YiTn/IRmcJsa+9yqxRSYM00iU784utTWRNAlPjCmWF+lZoshjfAI1ZYx2QyZXjrFMyx4Fz30jtQ88Sbfd6PzjzSeZ1vPonME2mGCOt17GjN3q1zWu9n8ITeTrz8KyfuliQzBK0m1fZyZTTnLY5He3HTDJ1cGtHc/ePVze38vyu8/RSGTTnmPRbPukCEWgfSC5k0noC4a+vyyfqCCO0hKYyujJ89Td05XVGpXmSVjeezFA3RQa5lOihGdNlglVG4sx1wCHVN6ibSfvLGTrWKOgj/VTwPaNaxd99wsFHwrbFK6dEJq2ZJt3UDS3uN2Ca+6qr5bbZZQw78+t/ncR2Zaeh8j6pMndTJ2bzRlN12V5d3Q5v8FqvNqetzdpfFkmgfZxsu00X8zHuMaFvfhovMmayTLq9v1TfWGkb1pOgP8z83R7jlZnISF/lsm7Gc8vcsS6VY9PLVGet/miOKVNDnyYuk6qy0shwpmTKSdRGRxOiXiYqJ9H2OMd9VDnxXsT0n49zlZdpTF76y6xKqU1ivVVVr7Z5rbd2jPMkkadzV5d6O5Mk9drLzSuTeO8Pl7oZ1jovP+W47O9VjZj1et9E5z4/dYjJ2LYi1f391M1WjO+n8by8jkmj/+w3tPsujYRpFMhLY95k3SICapzk/GlSX6RmGTGjQ+PTcUm49NA4ymp1Nbi3Hiuhx9iOHSCirjwHt4SC3VuKzDJ0zmpc+prwmHF9wigP1S8yVEMH3NOl2rrara8Qq6kWq/vLbdbFv0RtS9QCVa8F49QwEVWvaq8r9KqepcvUXecqIDQWXe+RoSvw+o/kjIHW0JrCsePUyT4M16WrrFfDT3qbVShTc7dq8gaP9Tqd8SEjHW22tdPs46lq7OwMs3JJPqbS7pgivI8JmTgwNNetcYiqwLNbLxk88Ug1T7zOJE5/xJThXOFdZrEkMNJXzeyBb0zWzmM4yWMznmm4rOLSAVJevs4YAx8pPplyErQxkqnLs0TlJNju9X5wKcl7VZL1j2vqcizo8+LIJNab5zCvtsV7rzsbGXMOTODp3F8fv+qCguc5NiZ9nBVx3Tz2i/v+cKmb8TcozvkzqhiX/U37qHRuL9S+5jne7dyXSlvtxTRr/wR1s5eT1PM4Xp7HalIFkLiFBNrp2z9bqCyKQSDDBEJDSkrNDwoZVrvcq07r9UftxCGyYZR9KEzu6Wdki9UVPX7Eq/V7hvdH6/cBNWh7AlwBb3t9SosQQCBJgeLJf40M+0hyX5KnS0B9IFPzr5dNNb4aSVch5OtDgPeHDySSIJCkAAF4kmAkRwABBBBIh4C+N0ANT4pMORSZXSgdxZEnAggg0IoCDEFpRXyKRgABBBBAAAEEEMg9AWZByb0+p8UIIIAAAggggAACrShAAN6K+BSNAAIIIIAAAgggkHsCBOC51+e0GAEEEEAAAQQQQKAVBQjAWxGfohFAAAEEEEAAAQRyT4AAPPf6nBYjgAACCCCAAAIItKIAAXgr4lM0AggggAACCCCAQO4JEIDnXp/TYgQQQAABBBBAAIFWFCAAb0V8ikYAAQQQQAABBBDIPQEC8Nzrc1qMAAIIIIAAAggg0IoCBOCtiE/RCCCAAAIIIIAAArknQACee31OixFAAAEEEEAAAQRaUYAAvBXxKRoBBBBAAAEEEEAg9wQIwHOvz2kxAggggAACCCCAQCsKEIC3Ij5FI4AAAggggAACCOSeAAF47vU5LUYAAQQQQAABBBBoRQEC8FbEp2gEEEAAAQQQQACB3BMgAM+9PqfFCCCAAAIIIIAAAq0oQADeivgUjQACCCCAAAIIIJB7AgTgudfntBgBBBBAAAEEEECgFQUIwFsRn6IRQAABBBBAAAEEck+AADz3+pwWI4AAAggggAACCLSiAAF4K+JTNAIIIIAAAggggEDuCRCA516f02IEEEAAAQQQQACBVhQgAG9FfIpGAAEEEEAAAQQQyD0BAvAM7fPaib2k98SamNo1VA6R3kMrpSFmSxtfUTNRehcNkVlBNjwdebZWN7SltrSWYUaV2yCzhgZ5vOv81DmlqJcMq0z0JqqRW4omSq3hYX8eEFBWH6tB94sybaiUYWk5pyfT5wH1rVc2GdHnaeg7r/ayHgEfAnk+0pCkFQSKJ0+TsqL7ZNaoEhlREK6AOlFPqOguU9eMFHNVK1StdYosmSyr1zSzaP1HYFmprJ5cEsooiDybWaXAdm9LbTFRnP1lrk/3Y2uUm+YyGypvkIpu02T1/PCxn27DePln07Ga5n6Jx9TcbfR5cwXZH4H0CnAFPL2+zci9RC4fK1IxM3IVvHbmdJGxo6S4GbmyKwII5KZAYdcuudnwHG41fZ7DnU/TM16AADyDu6hg5JVSVqWugutvjNXV7xnrx8ltI81r35GvF/XXytHDUly+NtZXcqwhLeGv4mrUV596X+vrZidGvDK88tBlh77q8Krb2wAAQABJREFU1vW6pdLx9aquh7Xd/hV7OL8G+/7m1+C6XrY2ReURLstsW9S2SP7G0J3yRSJV443ybzE+19jyNJruo72e9XOzU+XHGNvbp3win6/CbfSyc9ZVJ7f3qX27z76xlW34WP1id4+0Sw+Lihm+oOtgfX0ez89ev3CeUfWPlKOfufeXscUaShF73EfnYeXj2i73fvAu1553oraY2+1lRI5Fe05WHWOOTTOVPQ9nv9i3OY8lc/9QnwyuqJO6ioG2Yz9eX5n7uj167+c8PgxL69hQeVn9bfro/HV+2sbelgTtdJ5ToqoZzs9636n3k3FuSCL/8Psi/rEQLz9vo1BV7fuqflse1YDQse96zEanC9lFzhfO92Fsn9v313XQzva62I9Rp6PZJ95tc/a/Li1yDJjlGWsD7XNnuZEyw+21jrvw66g2m+0yt3m3z0xhPjrLNdan6Xxo5W0dF376yt63XucHszU8topAE0tmC6y4uano5oeaKocc2zRxhVnVjcbroputFU0bH7qkqWjIQ00bjSQrmib2urmpxkyuH418zPTh/a309oTm80RluOURWjf0oVAtmlRtdL0j9WpqqnnIrGO4TlYdwmlt9a65We1rtdGlTbqqGx9qGmrlES//cHlWfnpne57h8m3bo00T1U/nZ19i2256RHx0+Zc0VRpcofSRbc797XUNlxPVp/btzn11emf+trK1oc29acWK6GPHbJYuz54unOdE47AKl+npZ6+fW/3NQmyPUe3T6xOVYdvXSO7VrjgWer+Ych35Rh034W1R++i2qmPXbhVj58gzan+9LdxWWx7R74cEbXBkr4/lmGPLV1/Z+y2Bf1QbdFpV5pDIeUjXP3SsuOTpu53hOtje89FNdW43+8J8nylZfa602h5KH7HR6SNpY4+FcP4J6hvJP1yeVV9neeqcpc9z5na/70Xz+LDa4Swn9DrSrmil0Lkv3jHqdNT7h9d5lRlzjIfSp73PfR934fqn3HcOw7jtTWCV8BziKEu9TPi30zyGjF1D5Uf633Fcx2bPmlYQ4Ap4q3zsSaLQklEydv10Y/zmJHP4ZsNyqa4bIFPNscwqu4KRU2SsLJYVDf7zLhsTZyy5zzKi8gjvM8a6Sl8gI24fJ4W2KhWPtJVZUipldfXqGpi5FMrYBZOtITbFo9S+6zfYtpvpzEd1teLGxdLv9kie8fM393N59NXeZOsnEuVTM1MqxP4tRomUltVJ9XIl4MPOpdZxV/ku28hlnWwwO6KkxOqDqAL0sVi4SJbVhNeG61yqj0tfflG5Jf8ipTJc2hWvH5Kvlcce0ceKOO089opeHZ1H1PuhOW1IyVHVLNF++v1ctSx086ZO2+1KGdPNPF5qZFnVADGOlehGqldx2hkuM945JSY7nZ91TtBD+QqlcOwU616agj79I+eVlBwT19fz3BzTHhGjX6Ma4XLMRm1XLxL1hTO96+vodrgdo1HnkERlOo9xnV6d7y43/25F1SG67KhjO8Yo9u9IVFZJHXeJy/Xsu6hC1Qu39qq/y+k6Hyb62xbVVykd184G8jrdAnnpLoD8mytQIGf0K1Qnsi6RjDbWS11h12beiFkocYeE+irDkYeffRrUkJRB06XOao06YVnPk3uibzKq7jdF5hXY9ks1fz91txXj76nDR+9UN10GF6mx/LalUI31l8DLT6LsgpEyb4GofumlPiCoDw1T14r1Yc9WT/UxzzgWK1QEPkkF6Q3LF6t7EqaEgvXA6x9VcOhFsmXEa5dXP7gUm9qq7nKk/bhUdkd2E6nWn3JKojaklr3eK9U2JOto1jDhfl2kq/EBbbIUbFDHRld1bBw5QGboNnfZIOvVOetyMy+/jwnL9JtRnHSpOrplmai+ibbHO2bt5SXKx57W83m8Y1Tv5DiHJCwz+vxg3LPUb2Hyf6cSluNsUEDHXdLlRrc37efDuH/bHH2liYI8rp3kvA5EgAA8EMZWyCR85TigP+XuDQiiDH1Sk66h/PX4uHJRs7isDV9h1WPUlrmXnWitymtwdX95Yr5NoLn5B9HeRPUuHKfqHLlibyU3rypbK9QTu519farPvcrW+ek//Gp2ndBYezVe0CMIN+5LUH1WO1lkmYrW+y2w+beEX7JluLVLtzeehd7e7CV0FbPY4mmQDetFupVaK5pdQrPakKyjWdu4+4UvFqiAu6FeHRujdFvVe3/GcnVVXAXk6sNyIK1vyfeF2e5kHuMaqYyc253tcTtmS1wq4MzHJUn8VfGOUfWhyW1JUKbx7UJF+PygvvEYsyaQHk9wLgzwuEvQPidJi50PU/nblvZznFOD18kKtE92B9JngED4q6/yiZGoLTTl1JXhr1lDVwRmVJonUTVUY4a6ATGZJWEZLpnprwLVp+4J8cq1XblvqLxPqlyySbxKBe7l62xfM9v2SDX/VNprK9bX0xgf214x25x91sw+jcnfVrY6uUduBtXl2LbFPNXDZtSwgonLpKrMPN5UooR+zay/rkfCMhyV9WpXPAtHFu4v/bSlLmoGI+P96fl1vHspcdc2pw3JOpoV8bGfDsCk+gZ1w3h/OUPHXgV9pJ8KvmdUq/i7TwrBWEw7ne8Ls3IpPsbkn2I+5m6JjHR5skg8z81ex6yZv/mYqBwzXdzHJI9RP2WqDw9jrPNDqftQtrh1Uhtj+iRxnwdy3PlpX0zdW/B8mMzfthhDW8X1lfSgf1PDlj1P/QtwBdy/VQalVGPi5k+T+iI1o4cZwRqfds3LJKExc9WD1KwHekyBHhM5doCIuirlf0lUhltOJTJpwTg1lMFW7lQ1jntGOK0+wc0YaA3BKBw7Tv0xSqpSRka1E8eHAvfwkAljZZma43hygvz1Sak8ZBY7zCKV9roZxFunfNZMU1f9TR+dVo3lX6PHvSewU9cO9Xj61Ps0Ttldusp6ZdnbrLq2NA8lc53tsbh0gJSrWTvKpqrL4NaSyC+F+sf0V6IyrMqEnni2K46F3jOmXEe+vvpC9WvpMjXryPjwzrqfXb75MLNOWKaZ0HxM0AYzmetjko5WHj72MwLu6cbQsFC4ra9OqulU1bdVt6UQf6vOiH9OseqW6pMEjkn3SyKjBO3xPGad7UtUjjO92+skj1F93Mf9uxMqI3R+UBdI1P08qS0JjNwyDeS489c+Z/Etcj5M+m9nguPa2Qhet4pAO33jZ6uUTKG5IaC/OrP/+E1utDqYVuorFTeK3OY2ZCWYElLLRffpjK7uQ2lSy7GN7RUaWlVqfLBqY03LhOZwTgmgF7LsGM3kPud8GMDxmJtZMAQlN/u9hVqth4qoK6XuUx+0UB0oJliB0NfBhf36qOthLAi0tADnlJYWb/3yMrnPOR+2/vGRvTVgCEr29l0G1lydjIYOFPWbH9YSO9TD2sSTLBPQPzxRroc86SEqIwm/s6z7srS6nFOytOOaUe3s6HPOh83oYnY1BBiCwoGAAAIIIIAAAggggEALCjAEpQWxKQoBBBBAAAEEEEAAAQJwjgEEEEAAAQQQQAABBFpQgAC8BbEpCgEEEEAAAQQQQAABAnCOAQQQQAABBBBAAAEEWlCAALwFsSkKAQQQQAABBBBAAAECcI4BBBBAAAEEEEAAAQRaUIAAvAWxKQoBBBBAAAEEEEAAAQJwjgEEEEAAAQQQQAABBFpQgAC8BbEpCgEEEEAAAQQQQAABAnCOAQQQQAABBBBAAAEEWlCAALwFsSkKAQQQQAABBBBAAAECcI4BBBBAAAEEEEAAAQRaUIAAvAWxKQoBBBBAAAEEEEAAAQJwjgEEEEAAAQQQQAABBFpQIC+VspqamlLZjX0QQAABBBBAAAEEEMgJgXbt2nm203cAroNuM/A2Hz1zZQMCCCCAAAIIIIAAAjksYAbg+tF8bnL4CsB1wP3dd9/JbrvtZu7HIwIIIIAAAggggAACCCQQ+Pbbb6V9+/ZRQXjCMeBm8K0DcBYEEEAAAQQQQAABBBDwL6BjaP3PPoLEVwCud9DROwsCCCCAAAIIIIAAAgj4F9AxtI6lfQfgZkL9yBVw/9CkRAABBBBAAAEEEEBAC9ivfpuxte8r4ATgHEQIIIAAAggggAACCCQnYAbgZvCt904YgOtEegf7TnodCwIIIIAAAggggAACCMQXcIujfQXg8bNlKwIIIIAAAggggAACCPgVIAD3K0U6BBBAAAEEEEAAAQQCECAADwCRLBBAAAEEEEAAAQQQ8CtAAO5XinQIIIAAAggggAACCAQgQAAeACJZIIAAAggggAACCCDgV4AA3K8U6RBAAAEEEEAAAQQQCECAADwARLJAAAEEEEAAAQQQQMCvAAG4XynSIYAAAggggAACCCAQgAABeACIZIEAAggggAACCCCAgF8BAnC/UqRDAAEEEEAAAQQQQCAAAQLwABDJAgEEEEAAAQQQQAABvwIE4H6lSIcAAggggAACCCCAQAACBOABIJIFAggggAACCCCAAAJ+BQjA/UqRDgEEEEAAAQQQQACBAAQIwANAJAsEEEAAAQQQQAABBPwKEID7lSIdAghkkUCDzBraS3oXqX9DK6XBpea1E+Nvd9nFsapGbtH5T6xxrE/9ZUPlEFXnITLLrcJmtjUTQ+0qmii15rpmPFoOXvlZ5YW9vNLFqUOoXb1kWGW8hsXJgE0IIIBAGxMgAG9jHUpzEEDAIVC3WFbExH01sqzKkS7BS1/BcYI8mrvZCJbLFzU3m8j+KrguVw5lU9fK6jWTpTiyJfxMfZBZ1lWeWKO363/TpEwWSbnHh5qY3Y0VDbKiuk7KygZIXcXMQD40uJfDWgQQQCB7BAjAs6evqCkCCCQrUFgohVIn1csdEXjNMqlSW9TmrFqKJ4cC4allwVS7YcM6lVGhdO3ilV+BjJg8UgqszSVy+ViFVlfv+q2Clcz+pGG5VNepMkq7qpIWybIa+0aeI4AAArkpQACem/1OqxHIEYH+0k8Fq9FXXtVV3RnqKnKZ2hajEB5WooeWqH/mkAl95XlwRZ1KXScVg9S2qCvAGyLDXWz7hLKOzi9meElDpQwLl6W3/aU+pkLNXOFdfkybfA6laajXDuElPDzlljhBdcPyxVJX2F/OKOkj/VTsXhUVgZvDeCo9DBNtNyvCIwIIIJBdAgTg2dVf1BYBBJIUOGPUuOgrr+ErsmNH9XHkpIO98VJVNi003GKqHjIxUHRwqa88P6Gv/Kqcxi5QV6Hn264KVy0WuV1fmV4oxsVha5hFOL/CcdYQjqllOoA3x3ir7YOmS51Z3porVXRqC24dtUv+ZfzyY9o0ucRHEeGhO2WlLsNV3Havkb+oDy6F/fqoq+gFckYoAo8dhmIZrhV9db+u4obocfCJtrsVzToEEEAggwUIwDO4c6gaAggEIFAQfeXVuiIbGVcRKiQ8LGXsqHAgWlKqxjs7r9i61KfsShlh5BUOMGWdbGhQ6cz8bo8E68XGh4HwkBhzu1mehId3uBSR0iozf6/yk85U39iqPqDoDxRmsF4y2fiwMskrdg/XoV+fEHZBn/7RH4bMOliG6sOO3cjvdjMdjwgggECWCORlST2pJgIIIJCiQCgwrqi4T2aNEqnXV2THTrGNaw5lGxoPHRpiUpFiSfbdQvnZ16jnBUdKN/WwXv1z3e5I3pyXrvnbyk8ubx18D5SKugEydU3kA0WiPGqXhW4Y1cN27KZ1ahjKpJJI1F5oH4TuUsdE2xPVg+0IIIBApgkQgGdaj1AfBBAIXKBg5JVSVjFeqm+8T43iVkHkSH1FVl+mdi56iMlfw1e0nduSe11wZHe1g77J0bY0bDCCb9uatD0Nrnx78O02U4pXE8zhKmpIj3nFXCXVs8kMrlgmtWqdOetKXf1GtSV0lVx9MokxSrTdqwasRwABBDJVgCEomdoz1AsBBAIUKJFSPba4To2x9hi/bATp+ibLmWrQt7nUqJsD3eJ0c3u8R2MIi8rvxsg85LUz1Zhv9QFgjPoAEBqOYS8vNF46XpZJbUtQvr+8EgTf8W7CNIafaO7IlW5dZuiDgWM2lCr17UTY2W5k1THRdishTxBAAIHsEOAKeHb0E7VEAIFmChhji6umSzdHQBjJtkQmLRgn6weNl97WHOF6yEUohXkV3RhOocdBzz8ysqvrM5Wfmjdb1I2dg4umh1Po/MJXkQtGyryp9dK73CxvgIzVd3Hax2o48tUzl+h5u0OLmo+7SA/x8Lpqn6B8M5t4jzUz1bATncAsy0xsa4e5yvEYGn4yQGK4jQ8Gi4zZUCaZsXlZd6nXs8sYeej2OK60J9ruKJuXCCCAQKYLtGtSi1cl9abvvvtOGhsbZdeuXbLvvvt6JWU9AggggAACSQrYZp6xDVOJZJJoeyQlzxBAAIFMFdi+fbvk5+dLXl6etG/fXtq1aycMQcnU3qJeCCCAAAIIIIAAAm1SgAC8TXYrjUIAAQQQQAABBBDIVAGGoGRqz1AvBBBAAAEEEEAAgawXYAhK1nchDUAAAQQQQAABBBDIdgGGoGR7D1J/BBBAAAEEEEAAgawSIADPqu6isggggAACCCCAAALZLkAAnu09SP0RQAABBBBAAAEEskqAADyruovKIoAAAggggAACCGS7AAF4tvcg9UcAAQQQQAABBBDIKgEC8KzqLiqLAAIIIIAAAgggkO0CBODZ3oPUHwEEEEAAAQQQQCCrBAjAs6q7qCwCCCCAAAIIIIBAtgsQgGd7D1J/BBBAAAEEEEAAgawSIADPqu6isggggAACCCCAAALZLkAAnu09SP0RQAABBBBAAAEEskqAADyruovKIoAAAggggAACCGS7AAF4tvcg9UcAAQQQQAABBBDIKgEC8KzqLiqLAAIIIIAAAgggkO0CBODZ3oPUHwEEEEAAAQQQQCCrBAjAs6q7qCwCCCCAAAIIIIBAtgsQgGd7D1J/BBBAAAEEEEAAgawSIADPqu6isggggAACCCCAAALZLkAAnu09SP0RQAABBBBAAAEEskqAADyruovKIoAAAggggAACCGS7AAF4tvcg9UcAAQQQQCCbBBoqZVhRL+lt/htaKQ3ZVH/qikAAAnkB5EEWCCCAAAIIIICAD4EGmXVjvYxZs1aKw6lrJ/aSwROPlNWTS3zsTxIE2oYAV8DbRj/SCgQQQAABBLJAoEBGzJ9sBd+6wsWjxknh+g1cBc+C3qOKwQkQgAdnSU4IIIAAAggggAACCCQUYAhKQiISIIAAAggggEB6BPSQlOnSbcxaKUhPAeSKQEYKEIBnZLdQqbYo8NmWzW2xWbQJAQRyQOCAAw9OSytrJw6U6n4LZR7Dv9PiS6aZK0AAnrl9Q83amEC6/oC1MSaagwACOSKgb74sl2myeiTXvnOky2mmTYAx4DYMniKAAAIIIIBA+gWs4JuZT9KPTQkZKcAV8IzsFiqFAAIIIIBA2xTQwfeMrgu58t02u5dW+RRo16QWr7R603fffSeNjY2ya9cu2Xfffb2Ssh4BBBBAAAEEEIgvUDNRepcvik1TOE6emD+SGzFjZVjTBgS2b98u+fn5kpeXJ+3bt5d27doJAXgb6FiagAACCCCAAAIIIJCZAm4BOGPAM7OvqBUCCCCAAAIIIIBAGxUgAG+jHUuzEEAAAQQQQAABBDJTgAA8M/uFWiGAAAIIIIAAAgi0UQEC8DbasTQLAQQQQAABBBBAIDMFCMAzs1+oFQIIIIAAAggggEAbFSAAb6MdS7MQQAABBBBAAAEEMlOAADwz+4VaIYAAAggggAACCLRRAQLwNtqxNAsBBBBAAAEEEEAgMwUIwDOzX6gVAggggAACCCCAQBsVIABvox1LsxBAAAEEEEAAAQQyU4AAPDP7hVohgAACCCCAAAIItFEBAvA22rE0CwEEEEAAAQQQQCAzBQjAM7NfqBUCCCCAAAIIIIBAGxUgAG+jHUuzPAQaKmVYUS+5pcZjO6sRQAABBBIK1E7sJb3VuTTyb4jMajB3a5BZQ+2vzfU8IoCAKUAAbkrwmBMCtTOnS7eyAVK1jAg8JzqcRiKAQNoECsculNVr1ob+Te0uFYMIutOGTcZtToAAvM11KQ3yFqiRZVUDpHRyqZRVLZNa74RsQQABBBBIRqBklIwtrJPq5dZl8GT2Ji0COSdAAJ5zXZ7DDa5ZJlVlpVIsJVJatkhmVNr/UNTILUUTVVCuH82vVe1XcxJtz2FXmo4AAgiEBbodWWCzsJ9P9fnVvuhhKua5Vj0OrZTIGdkcwhJvf/s2hhXaZXmeHQIE4NnRT9QyAIHaZYukrLTEyKm4dIDUVS+3nfD16kVSXrRMSqO+UrX/0Ui0PYBKkgUCCCCQhQINlTdIRZ36hjF0ilUtqFNDUiLn06nqokf5RHPonw6wB0pFt2nWEJYn+i2WwVFBeKL9x8t6awjMNJFy+wWTLASkyjknQACec12eow1WN1/O0MNPzD8OJWoYSt1iWRG55KJgCmXsgsnqCnl4Mb5SXSSR4eKJtps78ogAAgi0fYG6ioHWTZiDK7rL1DW286fjfFo8apwUrt8QuujRsFyqVbA+dbJ5QhYpGDlFxor9nBx9vo3av2amVMg4uW1kQRhZf6vJ8Je2f8S1rRbmta3m0BoE3AUali9W12Pq1BXuRdEJZtbICOuPQHeJ+vZUCuTIbiLVG1SUbvydiLfd/EMQnT2vEEAAgbYqoG/CnGcFwUm0cmO91BV2VWfYZix102Vw0fSoDArHRr3kBQIZLUAAntHdQ+WCEWiQFdV1UjZ1rUwyAulwrjUTpXe5uhlTBeChq97rRMfaxdZfhQbZsF6kW6lesVH9i7c9nCcPCCCAAAKJBerqjavh1uk28R7RKQrHyRPzRzYviI/OkVcItKgAQ1BalJvCWkUg/HWnNfzErETMEBM15lBdETcXY0yj+przcitoT7Td3JNHBBBAAAFPgfC5NzImXMQ433a7Ukb4iciNIYTTZUJl1BhCz+LYgEAmCnAFPBN7hToFKqDn/q4rmxYZ223lXiBn9CuUCjXIO3RlXI1JLF2mxjSOD6dQr9fYr7Ak2m5lzBMEEEAAAU+BAhkxf5rUq3Nt76pwIuOKtnW1w3PP0IYSmbRmmpqxSo1BrzCT6vO1fQy6uZ5HBDJToF2TWryqpjd999130tjYKLt27ZJ9993XKynrEchyAT2llb5j3+sEnmh7ljef6iOAAAIIIIBAWgS2b98u+fn5kpeXJ+3bt5d27doJQ1DSQk2mCCCAAAIIIIAAAgi4CxCAu7uwFgEEEEAAAQQQQACBtAgwBCUtrGSKAAIIIIAAAggggIAIQ1A4ChBAAAEEEEAAAQQQaGUBhqC0cgdQPAIIIIAAAggggEBuCRCA51Z/01oEEEAAAQQQQACBVhYgAG/lDqB4BBBAAAEEEEAAgdwSIADPrf6mtQgggAACCCCAAAKtLEAA3sodQPEIIIAAAggggAACuSVAAJ5b/U1rEUAAAQQQQAABBFpZgAC8lTuA4hFAAAEEEEAAAQRyS4AAPLf6m9YigAACCCCAAAIItLIAAXgrdwDFI4AAAggggAACCOSWAAF4bvU3rUUAAQQQQAABBBBoZQEC8FbuAIpHAAEEEEAAAQQQyC2BvGSa+9mWzckkJy0CCCCAAAIIIIAAAjktsPsee8W0P6kA/IADD47JgBUIIIAAAggggAACCCDgLrB9+/aYDQxBiSFhBQIIIIAAAggggAAC6RMgAE+fLTkjgAACCCCAAAIIIBAjQAAeQ8IKBBBAAAEEEEAAAQTSJ0AAnj5bckYAAQQQQAABBBBAIEaAADyGhBUIIIAAAggggAACCKRPgAA8fbbkjAACCCCAAAIIIIBAjAABeAwJKxBAAAEEEEAAAQQQSJ8AAXj6bMkZAQQQQAABBBBAAIEYAQLwGBJWIIAAAggggAACCCCQPgEC8PTZkjMCCCCAAAIIIIAAAjECBOAxJKxAAAEEEEAAAQQQQCB9AgTg6bMlZwQQQAABBBBAAAEEYgQIwGNIWIEAAggggAACCCCAQPoECMDTZ0vOCCCAAAIIIIAAAgjECBCAx5CwAgEEEEAAAQQQQACB9AkQgKfPlpwRQAABBBBAAAEEEIgRIACPIWEFAggggAACCCCAAALpEyAAT58tOSOAAAIIIIAAAgggECNAAB5DwgoEEEAAAQQQQAABBNInQACePltyRgABBBBAAAEEEEAgRoAAPIaEFQgggAACCCCAAAIIpE+AADx9tuSMAAIIIIAAAggggECMAAF4DAkrEEAAAQQQQAABBBBInwABePpsyRkBBBBAAAEEEEAAgRgBAvAYElYggAACCCCAAAIIIJA+AQLw9NmSMwIIIIAAAggggAACMQIE4DEkrEAAAQQQQAABBBBAIH0CBODpsyVnBBBAAAEEEEAAAQRiBAjAY0hYgQACCCCAAAIIIIBA+gQIwNNnS84IIIAAAggggAACCMQIEIDHkLACAQQQQAABBBBAAIH0CRCAp8+WnBFAAAEEEEAAAQQQiBEgAI8hYQUCLSnQIHMu6yUj5jS0ZKGUhUAbEOC90wY60UcTauV3Rb3kd7U+kpIEgSwSyMuiulJVBJol8PzkXjL+3xPk6RkXS+eUctohSyb0lQl73SmrJxanlENgO+1YKbddeLU8UzhJHpt2fortEWmYM1wGT30zfrUGTm/99savYQZs3Smb31oiTz66RGrWvCX/+mir7DJq1UEOLjhafnru+TLyZ+fIjw5wnHIbZsuIQVMlQQ9Eta9n+UKZNbwgtM5z/wTlRuWYzItGWXXH2TLmiRPltmW3ydkdktk3u9Ia54uFbnVWtj16yRkXXC6jB/USZ5e67ZHx6wI6n2R8O6kgAhkk4PhrkEE1oyoIpEPgqxqpfXWwXHRCCod+Q7W8ub27yF7pqFiKeebtJruluKu1W89yeWL2ZRIO6azVPPEn0PjxcrnrNzfLwn8fJQOvukZ+O/5o6dJpbzGOsJ1fyIfvvSrLH6+UK859QE64+vdy8/CfSEcz64LLZNaay8xX1qPxwejZs3z2S08Zv2COmDG5kYlRbo088acH5Bcz58pFFQ/ItSdYpVrlJP1kx3OyYNGJ0q/4OVnx4g45uy1H4BrH7cOnsn1v1V9lxh1j5Ly/XSwV918nxwdAm3RfpGOHIM4n6agXeSLQBgUYgtIGO5UmxRE4qqd8/uJzsiNOEvdN6spf7X+l0w/WuW9Ox9q6WXJF/9vlebe8O5wiE55ZK7V/OE8OdNue5evqZo2Wc6Zk/nfOjfWz5VeDbpS1RXfKU0sq5YYLe8tRZvCt+2CP/eSwY86U4bfMlWcfu0L2fmy0DJ1cK9vS3T9GuQNk7H1zpeJnjfLw2N/L4gAK3fHicnnhtD7yq5OPk+qltSm8j5JseLz3QJJZBZZc2R512hXyh8fmyKj8uTJhegs4BFZ5j4za+PnEo9WsRqBVBQjAW5Wfwlte4Bgp2ecZmZdsHK2u/L27T6kc1RgaWNAi9d7UIKs3t2B5LdIof4VsbnhNNu/0l7bVUm1bLr8bPVW2Df6j3H/tyQmHIuxx+ACZPOdOOfml38i1c+qlsUUq3lGOL79BhnR4VhYu2dTMErfIkr8/J6f1OVUKTimR45culKebm2WiGmXye2CP7jLyl4Nkx8JHZMmWRA1hOwIIIBAtQAAe7cGrHBDofv7Jsm7hq0kFQOvmvSx7npLayPEcIM3BJqr7AW6/UaoOHSt3XHtCZEhJIomOxXLthPOk4Z67ZFG6g1ezLnlFctypIqveqTPXpPa46TmpXlkixaeqgd+dT5RTe74qy2pbqhGpVTnde+X16Cm95TV5N9kP9OmuGPkjgEDGCxCAZ3wXUcHABTqfJ2d9uUCW+v1KvvFVqfr0JDmX+DvwrsjaDNc9LA9Wd5Ahvx4uXZO8naBD8a/kV8eulHseXt1Czc+TPF3H9zZKc+baaViySFad2UdON268LJDis3rKqkeelEyJPXd+8KxUXHOxlJ7US3qrWTNO7nuxjK1YLh+n86uGAw9UN0DvksZ0ltFCR0lrFhPqu5/LOaeH+q736f3k0hsfkJfT2nmt2WLKRkCEAJyjIAcFOkjfsk7y2KP+Qocdzy0VObOveE/4oKfJGi6JZhLUN9b1vmx2giAoNLWaDiB6j1+g+maBjNfPzX9q/HBoaa0p2HbKhy/MlinX/FzO73tiqF4n9ZUh10yX5Qn/WIb2nTR6YOQPbdFpcs6l18iUahUa6hk9wu0cr2efWDgu0m613m0asp0fvCBzplwjl/Y/zUpb3P/nMnbKo7L2M6+oyDat2c4PZOkUNd48/Ie/eMrLYd/4Dw2vPC/1R1wkZanczKtCthNO7Slbn1oha+IXE+zWLofLoSnnuE6WPPmmnHzy8db7oKD4LOlZXy018d5GRp9Odr+PwVYXPeNIb8exnfg9YGbwrdQvGCcXX71YOo2YLoteWCur17ws1Q+MlkNW3iiDr5iX4D1n5pPCY/2/5F35kRx+mMe++viqsB+foeO9YukHEneEVeNn8m7VdBl7aT8pDr8nQh8oFsl6feGgdrI63mNdtWPCKU2NPnGer7zOJ0m8V1Sd1z72W7liQF852ajziVI6YLRMemyteL4VlcL6OVfIWcNmydcXTJJ51atU362VV6orZcJpW2TaxaNlTv23HrisRiC7BZK8dpPdjaX2CJgCeScMlJNmLJRVv7hejo/7Llgn8545UMqmxk1kZhvAY4EMn71Whuuc9B/Z8SLT1kyU0wPIuflZ/EPuPf8KmSOnyeXXT5JZRV2k09550vjVx/L6326XiYNGy4fzHpThbpeEt70hD15/lczZUSbXT/ijlP9/9s4FzqZy/eM/nTk6J6ekRBcZTRikE+PSfRypBg2hciuMdJOTSyrpHJSKnKNcOpVD5VYqhJCMiFFHV7pRDRpG9S9SQjpoTvv/Pmvvtfdaa6+191pr9lz3b/XRXuu9PO/zft/3XfOsdz3vu+qfiROOhcq7Dzs3LcPzX34LZEV2BNG2gEOs7Q+LlNE1HH+dUIAmA0bg/hcmhHYeKcIv+3Zi08KncP/Vc3HBw2qRXKbDFhX/K8DcgX3xav0xeCr3KdQ77n/Ys+ewC0x7sendzajaeiAau0htlyT1nGaosW8zvvgayHAy3uwy+gorxM7tQN0Lawd3ZvEj47M1WFFwEfpealjym3oBLkmbhBVrPsPNDZv4keqQx9sYKPp0Gv6+t5laFNkfDVSfCh7H4oT6V2DkM8eiqPPd+PeqqzGuBHZs2b3xHXyR1hZj0vRyI79Hts7BkAHTcSh7DO6fPxH1gx0e3320EI+M6oyuG6bgBbWdaVTv3P8eHrv1TuTV6Yu771+Af9Y/AaoWWr/eMP1+DOi5AX8f8MdIQaVxFmesFP24Fv/MGYV3Gt6CUdPvQbPTZBegIziwfT2e+LvaLea1QXh+et+ot0W7F9+JvvPqYNwr96GtYT/HlONOwznZ9+G5JmqR89AJUHcHXFga9WQZJFCKBDgDXoqwWVR5ItAQnTsUYnYcR9yi95Zg60VXQ20+yEPteXFih2l4ddGjuPmS+prxLVDkj2XLPo/i0X4H8OTUFYhaj1akDN1ht+OdZk9i2XP3IvucoPEdzFtD7SjRF2P6XeCJ724143n9dODmeYsx8eZLDDuPpOC4GvVxyc2PYv4z3bD9b0PVDFqRreyfV83AwqZT8Nx9VyjjWx6wjkWtWlHmkE3ePditDOeGZ/qfT8bJp6jZ6EJ8t8dGfKKDCvOwenNTdOvo10hWOwAtX4BdF7WD0f5WBNAmKw27Fi7H+/aIE10TW3lfrP4WHcYYjW9DsmqZuPbaU0tkxxbZAee+RwvRZXCP6PvD/tcwuu88nPHwq5g74oqg8S1qpRyHU1v2xcSnRyJtxd0YZ92aRhsrd2JLmycxZ+ItuEQzvrWMWr++fMQsLLnnj3hi4quGSpb8acyxUvQZnr7lXmy/bg5entgXLTXjW3QKPQTNfhzdvp2EETM+M6+7ObQKUyZ8ieseNhvfxtqkpPXF6OtOQXKvNDAS4XllIkADvDK1JuviiUDtjlfjhPmxfFj3Y/Xig7iisjt/b56EbqHX3GFXl/C18VX1Reg90OnDIylonJWNtPVv4QPLHo9bZ96NJ3E7Rg807H/tqaUsibU/3J/jynvGoqvdbHso+bEN++Cu3gcw+R+LbP+Ar14LDLq1hY9Z4b34fhdQP7UYO6efcSbqYR8O/WypW6Ivj2zFrAeewPc3DEUvv+oWbcK63H1o1ebiqC0vG158OeruW4l1m8rQAr+oKzrEqFvjc1oAW3dCNVlCjiMHtuOtGcNxTb8FqDHiSZs3LIfw5hT1sa6O9+FOh7cvKWco//QBdbB63ism95jCF8ZgctEtMcZKCk5qOwQ3X3Q0IXVxKyTWWCl8YTxmHDcIo/uk2Y+lY1vj9mHt8fXshXjb0E32rnoFuc1uxPUZsd8uaq5ObhVlOhKoQARi9/wKVBGqSgKeCVS7DF2b98Ar792Iu+18ebe+hAU1OuHfzs7fnosslxkS9SGeuvVQH2/ge5kC15mpBayvvLgP3cZ3T9iHfg69uRq5p16H59rGm61WDwXdeqDVjDxs2NsdXQ3eE9IOVTt2wGW6nuWyYfwrdeTAV9i+fhGemL4A31zwCJ4b7OdBI1j+oTcWY9G+1sqYtFmF3KQNsupOx+yVGzCsdaa9Aea/Gq5y1j2nUdSDQVTGXd9Hv5mJSmQTIOsQrF/DPLUVuvfqiym5F4TenFjyHVqP5SpPx6czw8PAkkK71B5ennoXm/aqj2BpfTPoZ3/5TdPijJXquODSi4B1dlJLJsx5rHyG115WawP6TYqpc7WLM5F59J94/xPlTpchOhbh0w83oNH5w+N/xTdV7is8SKDyEaABXvnalDVyTSAFrbpk4R+PqRnS1tbP06vX7kvexgVdbikTo8J1FawJZYFVjE+bd5n8IUZlWjN5vz5y4Ht8te0T7NrxJd7fvh1fvrsVX+0txB6orzIaxX3yJnL3XYK/xZnlMmaJd/7Jpjzlf93Fnf917bPRsMZ4bP4M6Gqpd8OzUn22rdpVpKraVOTrr5WqdeKpax//zVfYqRbvtfWZ3Sx0MyarT6JPNgRWPfEMnNuqMzr/YynaNzrJZz1F4CH8Z+0bONp0EFrb2N9AE+WGUhczZr+GN4Znlsmn6U/4Uwk+RZm+hCk+zasw8c6HkLfjN9ymuS0ZoOunH6sPZKl1EuP+rAc4/J5QHSfhR+w/oOLFAN+7GR8XNMNFTePXp+bJto3hUFDxgx3Hytcf4f1djXDpeZanW2uR1arjxKr7sH+/TIGL2fENvt6p3iK1rWtNyWsSSBoCNMCTpqlZUVsCDa9Gd+UesXRrd7WQzJBi91LM3tUBo4xhhuhye+rwafNE6bv/k/mY/Ng0rNl1HBq1uhjnND0XrVq1wDUD6qLWCZ9jyoUzzEX9fAj7mtaPWnxlTuTtqkh9DKnhWW79r2viFJW04AeZljcbCf5dSOoiVblTr/lOPFN9WtDffK227zsTvRJiR9l8it4bUufUajZ3Te5RNB3WxnGGs3Gb9qg7YzrWvPl3XNk+vvHoXFh5jxGfZvmYUgpGZCn/7darMKG9zVsYtSfhUSzDXa2XuapQPXmOS1P/lD/SQZzlvKOKK2klk8hxrPyvSM1lf4HHr22Ox10U3fTrb1SqiL9Qyu9ogrjAxiSVlAB7fyVtWFbLLYHa6NitITrMXIXe468MvzLeunQ+Tuj8TPzXo26LqQTp9qtdWXqN/wG9xi3E35rbzap+Xglq6aYKddC8VV3se3uL8t9tYTAn3OQNptm6ZaOaVb4ajcu5vbp7xRKsFpUndUGLSbHrt2t5Lva272Z5zImdp0LGVu+A2wfNQ7cpT2PT5cNh+3InUW5dFQJQ13K0U1OFAEYlSUAjwEWY7AhJT6DaZV3R6b2XI5/VFr/lRWfhL/LFPx5BAorJ9AfWoe0Dj6KPrfGtkimXjJ12vL75Hj/YhfsMS1H+H99ojuZuBKgFk2rSrfbJ5tlvNzljpWl80WWovfkVrIq1B7ajgK3Iyy1Aq05Zvox3R7EJj9iN9WveQ9WsCViv9maW/Zmd/uWOUj7JG3KxNkm2q0jt1gdZ++Zj4RuWFcd6G/ju87uxN2obIV1oef31o/PvIJPf2wtdfBqq6H/m3VPKKwbqRQIeCdAA9wiMySshgZTWuLrnXsxfFNwma/fiZ5DbtquHBXriE7wZO2P+LVH7Vm/bXHHhffMFNitf7pa2033BahUVbIdytTYf6lPdF+77CFtisjFniXfVoHFL7Nuw0d0XGAu34ON9F6Gp3x34nJQ5r6faieJrvPTcWrj9oKouav/Kp/Hs1+3VtoAJ8T/RxSb+d+srmP9eDXTrGusjVMFia155NbKqqi/GrrI0tLKyUrAtztgowJdfJF79EpUoC7i7VVMf+3k+uh/67fOp9dGo6ufY7rBtprE+hYXbjJfhc3k43bzD0gbh2OCJjNOE3YlSz8F5NT5QayzEt9vLUQeNmtbA5k8/U6sM4hxbv8AncZIwmgQqIgEa4BWx1ahzwgk07NwDJ8+eizcObcXSl/aiR5fWHhauNUSjlsCmLVHmZ0TPQ2/g9VWRy8p3prZsXP6q8n21HDUvRruLtuKFlzcmbBZLM/a+fhEvrY/3p7sIn69Q20xmXY0rEzsBripZG53uHITUVQ9i3PJvXddN9o6+8/48ZN5/b5ksWLS0TszLrXm5KKjRHn+J8dAVFlDtYvylrTL+Xsk1G6R10nFOjc3Y/HmMttq6Gq9WNANc3R1a9chRXwJ9Ue2iZDE+VZ9v03ozlq6w7HsdhuV00hqXdDyEXLWjTAxaagMRtfOI+iqp3SEPp+pGBGdnsEN4Y1WuXVafYefh0qxqWLH8dc8PohnZPdW2pcuxKuZbE7Wl40K1B71P7ZiNBMozARrg5bl1qFvpEah9Fbq1fRPrnn0Vq2r2QGdPiy9r4srO7fHdwhex1nY6dD/efPRxbKvjccV/nTPVPhk/41DMv8alhOiMRmhaIxcrV9tVUM3uzx2KcWiDv0SpEzRUT5v/N4xf+6NrQ/WMMxsBagGnbdWrXYlbB6dixfiHsPJbi/FjKH//+nEYPvsE3HFbxLffEF3sU/lIyGP/uBxfPNQfdy3YGvvT4qq0I1vn465BTwD9ZuA+u8V7xdYokQI2YvmLBah7bXacL8XqZVbDZV2vQY2CV/GG6Tm0BbJ7pqn9rufDdmJXPjzzyBvBRYi6KONveRoDRr3kPPUaXJ91CIvmLLXsM18bXQffAsy4E+PX242XkCD1ddi1m4z+Jim4tN8QpK4Yh8cc8+3Hp0/9EzvU1zftDu3h9LsFeNH+RoT96x/FE9vqwOOdyK6oUJh6ELn1bmSuvx93zi1wHt9F32Lt+nyznIY9cPuVn+MfI+fY9w2VWvQd/3ZVrsUxk+NVJSFAA7ySNCSrUVwCYkB0xnszX0SDbld5vuFXu+xm3FH/Ddx36zis3n4gZIypz0fveAsz7roBE3E3Rl99gjcl09SsYtrreOHZD/Gj2JlH9mDLttL4dKKNmspN55YxV+HT+2/B+NU78Itm96r6fbsFy8ddj5wFDfDw37Jxol1WMVSnXoEtIzuj/4Rl2PLtL6E/1PJ5bfVRk7n3o8+E9aacaRe3RdrqeZj5YdBoP7JnC4xVT+09GdO7/YBx3XPwwNy3sP3AkVD+kE5Tb0avv32NrtMno3dk0wVTGYm4qJ55H+ZM742UuX1wxQ33Y+6aLfg6rIuarPxlH77esgxT7+iGKwYsxWn3LMG/E/VBokRUwEFG0Xvq0/P70tCxnXvfnZTW7dCxxi4sXLnRJLVh9yG49qdp+Otdc/BBuO2PYI/iMiHnJqxrOw63O23ZV57GgKlWchF86Ki24Xm1i5I5MqXJzZg6rjnevucG3DVD9c99ep9XWxl+pcbM1IG4Out2vPqtOR9Se6uHukx8cE8PDJV8el8q+gX7tsu9pD/+8etA3JdtN9JEpctw0+D6WDtSxul2RLLv0D4e1HcicNdo9QEyS7HFulSLUu+bngM80Tc4vr8y3P/08d22CyZvPmwppjra/m0absUTyMl5xHzflPvKhBvQ6Z4d6PXECH6G3kKOl5WDAHdBqRztyFokgECK2lu6RzOgmZ+vs6SkofcTS9F48VQ89deOGLFH5m6roVaT5uiQ8yTmX34mvptr2aIvrs4N0f/xx/DjyOG4qvU+HK1WCy1umorpDWrFzVkSCcTYfO6pRXj8ydvQ/p49ana6Kk4848/I7H4H5g2/BHWOXY91DgVXbz0cz624CiufewLj+0/A5xofRahWKhqd1xH9/nq+OWfDGzH10R9x3/AOOP+noypdS9w0ZQYiVa+Oc2+ejtfbv445/5qNO2cOxzcqnfq8jqZTq87d8WRuW/sPpZhLKvZV9T+rT4svuhY731mIl15SxuTD20O6KNGqzVIbnYcOVz+IhRPPQa1ji11cKQgowtsrX8Y+1Wbe3gQFZ7uff3EN3lcf/mml/3WpnomRCxai1b//gYnXP4Ft0k5Va+CMczPRZ/hCDFeLet8e61St8jUGrFpq94y0F/DSi+vRe7TxwzspOK39eCw+5y3Mf1b1z2v0/qnuCamNcV7Hzhi3dDLOsekQMs7mL8jU8t1x1R3QhorO6/anMVMWQa9faVUldJ2CtN5PYkljGaeDkK2NU+mGTdCsYw6eWHAF6nw3B0875PYbXP3PA/HvFW2D4/tmfXzLWKyPcy7Jwq1z1uKCs46LFn9sQ+RMfw3nyX1zWBeM+kbd57QxrPJd0RPTV3RAo5M24MHonAwhgQpPoEpAHU61kKjffvsNRbKv6dGjOP74452SMpwESIAESIAESKA0CKgtQVsMBbf/Kw3WLIMEEkDg4MGDqFq1KlJSUnDMMcegSpUqoAtKAsBSBAmQAAmQAAmQAAmQAAm4JUAD3C0ppiMBEiABEiABEiABEiCBBBCgAZ4AiBRBAiRAAiRAAiRAAiRAAm4J0AB3S4rpSIAESIAESIAESIAESCABBGiAJwAiRZAACZAACZAACZAACZCAWwLcBcUtKaYjARIgARIgARIgARIgAY8EuAuKR2BMTgIkQAIkQAIkQAIkQAKJJkAXlEQTpTwSIAESIAESIAESIAESiEGABngMOIwiARIgARIgARIgARIggUQToAGeaKKURwIkQAIkQAIkQAIkQAIxCNAAjwGHUSRAAiRAAiRAAiRAAiSQaAI0wBNNlPJIgARIgARIgARIgARIIAYBGuAx4DCKBEiABEiABEiABEiABBJNgAZ4oolSHgmQAAmQAAmQAAmQAAnEIEADPAYcRpEACZAACZAACZAACZBAognQAE80UcojARIgARIgARIgARIggRgEaIDHgMMoEiABEiABEiABEiABEkg0ARrgiSZKeSRAAiRAAiRAAiRAAiQQgwAN8BhwGEUCJEACJEACJEACJEACiSZAAzzRRCmPBEiABEiABEiABEiABGIQoAEeAw6jSIAESIAESIAESIAESCDRBGiAJ5oo5ZEACZAACZAACZAACZBADAI0wGPAYRQJkAAJkAAJkAAJkAAJJJoADfBEE6U8EiABEiABEiABEiABEohBgAZ4DDiMIgESIAESIAESIAESIIFEE6ABnmiilEcCJEACJEACJEACJEACMQjQAI8Bh1EkQAIkQAIkQAIkQAIkkGgCNMATTZTySIAESIAESIAESIAESCAGARrgMeAwigRIgARIgARIgARIgAQSTYAGeKKJUh4JkAAJkAAJkAAJkAAJxCBAAzwGHEaRAAmQAAmQAAmQAAmQQKIJ0ABPNFHKIwESIAESIAESIAESIIEYBGiAx4DDKBIgARIgARIgARIgARJINAEa4IkmSnkkQAIkQAIkQAIkQAIkEIMADfAYcBhFAiRAAiRAAiRAAiRAAokmQAM80UQpjwRIgARIgARIgARIgARiEKABHgMOo0iABEiABEiABEiABEgg0QRogCeaaJnLW48HM5qjxdj1Za5JcihA3snRziVRS/adkqBKmSRAAiRQEQikVAQlE65j0Y/4YuVcPPni69iy/Rv8dDRSQtNhSzC7T2okgGeeCBz56i3Mn/cSctd+iM/3HNLyVqvVBM3aXo3+N3dD85NsulzhHPTrOgmbLSVp+Trm4J5br0CdYy2RvCQBEiABEiABEiCBCkog+WbAiwowb1BnXP9EAVoNnYFlb32IjZs+xIZ1SzFnbA+kVRBD79Cmebj35ixMKDcT3UewbcEQdL36XqzClRg5cxXeVVw3bnoHy2cMQ6vv5+L2jl0xeuW3KHIYLPLwI22h/XvvP5j/UBscXXAPrhs4BwVOmRxkVYbg8tfGHqkW5mLCHd3x13mFHjPGTl46XA5h07x7cEv7R/BmbHUYSwIkQAIkQAKeCSSdAb578QQ8+n5t3Pzoo+jT8jQcF5qQPfaEM3FO9r0Y071izH7v3fIaXt+4B4bJe8+Nn8gMhfNuQ9/x+Wg2bgFmjuiEc047DkG0x+KEM1uiz8TFeH5QTbx+X3+MX78/ftEpx+HUlrfg0VHtgY+ewNNvBGfT42esPCnKWxt7Jlv4Lub/ZxsO/s9zzpgZSofLXmxZ+To27ikvIywmEkaSAAmQAAlUMAJJZ4Bv/fw91UTn4ZwmNq4QFazxyo26uxfhn1M/QrUu9+Fv7U8LGd5W7VKQ1ucR3Nl6N5aMfxqbXM5oV0tvjIbqMeOb3XutAnlNAiRAAiRAAiRAAhWSQNIZ4MFW+gn7XUzChlv0yFdYPfUO3ND+ErSQBY4Zl6DDDQ/iDd0mPFSAlTPU6+quWcjU4pvjwsu6Y+TcT2AuphBz+6r8fZVLxY8fYsEDN6PDpSKvOTLb34wJa53dM8K6iL+0St9tUtBjesnQYP4WGWOjXpUf+ep1TFUuAO0ukDTno12PEZj7iVkjXW502jsw1Y0+SsDWpc/j7aNp6NEzE9V0gba/tdGxW3tU3T0fr25waYHbyokdGKzL9WG2LS7Nwg0PrYHeXMHcR/D16ikYfEOkzTLbX4+RM97Bt7aqSfpHcEuny3Ch3gdufgSrvzriqEyRTRs/sMDaJ2yyu2rjIvz44Xw8cHN2qH2lz2XjlgnLsM2+iW0KCpFQ/WSCcmcK9l3VTzqpvrha9fmx0m+i+1X8eoUWFw5drBWweVIXrY+3yOiDuXG8UYq+fQcz7nVoOxdcDu14DTNG3Ixu4bHq0O/Xj9V0elC5cO3/ZA7u6ny+uu6PeV8DhXP7qPMumKwNscUYGhrT5oXNof7TI9QfLrgMPe+YgrW2ncd733FsLEaQAAmQAAlUDgKBGMdvv/0WKCoqChw+fDhw4MCBGCkrTtTPeQ8E2jVvFrig/5OBTT/8GlfxX798OTCkfbPApbdMCbxZcCggOX499H+B9+f8K/DqV6HsO18K3H//7MCb2/YHDmtBhwNfLbs30KF568CNz+80lLEzMKdPs0DG1TmBGzvlBJ56f7eW/tdDBYFl92YFMppnBR7dGF8nEbhzzg0qfbPA2DyDeO00LzBWhWf0kTIGB+ZvCep8ePf7gaf6tw5knJ8TMKmk8vz65ezAjee3DnQetTSw45Aq/9dDgc/mD7bR31qWXH8fWDRI6vRk4DO7aGvY9y8HBin92j36QSRm5+xAXxXWd46RVTA6WM9ugen5keTOZ78Gvlwkel8cuHXqm8G6qBY79H/vB+Y8sTygN1cgsDuQK7wVi0lvFgSkygHVErvfn6219QX9Zwe+NDXDT4H1D2cHLji/e2Dc66H0itGOZX8PdL6kdeAC4f2ApSF+Uu2g9Zt/B97fLb1CyV8/MdDj/GaBDg//J/CzcyXCMc5t/HPgs+k5qtyswMgFmwOaeKlnwarAuB6qjds/EFj/U1hMzJOf1HiQftrj4VURXgVLAyPbq3opXTOaK/wfxnIAAEAASURBVFlGCV7qpWRLH7VrV6PI8PnO51U/VHzuDfVDrU5vBqZPeSVg7BnOXNS4eGlM4P45bwa27Q+OxMDhXcGxZe33Id3GLlsRuEerp9T1hkCkC4bGqrX+mrKqn81R/M/PDoxaFuwPvx7aEpg/JNinzOPLR98JA+EJCZAACZBAZSAgNrTY0mJTi20tB2JVrDIa4IHAT4FPpt8cuFSMJvUHdOAU3fCwIfHrlsBT16h0fZ61GGQ2aaOCvgvMv1XlvWxiYGM4Tv+j3jpwz2sWC+lnZQgonS64N7eYxlnIAG/eLfDUFpMVGQhseTLQRZXR5cktYY0Cv34QeFQZihl9ZpuMnIDSIvdeMdjvDeTGtBb/ExgnBszdK1zpHQiE9DMarHYG+OHdgc0LlIF7flZgyKIvtQefiNL2Z7+q+l2r6tf32djpv1t0u2a82j3s6DKuNVj8v26cqBmpUW2m1NCNQbMB/p16KFHsLlPGq4Vd/vRuytBz90Chy7Y+ZOn6DFr0XTSIn4IGpat+FGr7C1TbWXqjeih7VnsoMhvgHuvl0QD/7MnOFiM4unoS4sTFPrUK/e6lwK2qX5ge+nTd5EH1yfdDDzFGCfpYtTyAqCRB/jYPFj/nBkaqsWBkr7eV+75j1IHnJEACJEAClYGAnQGehC4o1XHuzdOx7KWx6F5/H96ddQ+uuawr7pr7IX60uB4UbViI2QVVkXVDd6R5dhmvjVNPV29J9h1C9PLBLLS/vLr5FUq1JmjaFDha+A12m2P8XTXKxpVWP/cm5yBDSdv17e7wTiSH3liIBbuljtfAvPy0Gi5u00Yp9AY2fhxLhSIUyTq1P1WL434SS0YwLuKqoFwfLszCoLz6GLv0FUzumubgV26UWYS3F85CQdX2uL57rPRbsfT5DTja+kZcnxHdqClNuqF7a6Dg1TX4XBN/CG8smI/dNa7BtdY2U/GpHbriQqMacr71FczbcBRpPXviUotPTsOLL0ddFOCdD5Svg68jok+/TrWjJVS/Atd2q4GjuavxZnTHM6XX275j9hWw9EakpHVCl4tMyUu4XnpZB5R7mGUg6lF+f2ufijNU3n0/RwPZfFwHjBvYErVc734U4i/9rJt5xKDaxcjMVENm7Qf4RNM10lau+47fOjIfCZAACZBAhSKQhAZ4sH2qN+iEEc+tw+vPjERnZYivnXQjrrplJrYZXHq3bdmolv+1RKsMixVl18RH9mDLfxZgxiPj1faAXTQf1KFLJOE27LT6vTat72zQf/EVvrGT7zWs0dlIc8qzM1JG/uZ3HetYre5Zylg8iu07XRiLyriJNm+cFLAPD29D+HYuJt/QEEf+8wKWfnHYPnFU6FZs2aSeBFq2Qszm2rsZHxcANRqeDRvzVUmtjbMb1lBPKZvxheY0/gU2v6fkNq6Ps6LtdaBmzSg5e7d8rEzsGriwRcMoLZFaTy0qBT7buSs6zlVIHH3Uo8pZDRorSR/gs/zYAnd9+ZnW9k2tD2patpqoWcucv2TrBTTIugbNqu7CzEE5eGDuW9j5iz9D/MieLdiwcDomPCLrMrqotQBDoA3F7TsRNRQvPj+q/cy1tl6F+Nv2s2pIPauussC3YYc2ZOK0lU3fsZbGaxIgARIggcpJwM6kqJw1ta1VCk5q3h1jnstCt6eG4pYZUzHk0XQsuO8ibTZ37/diJLUQGyvmsf+9R3Hr4Ofwf2dcgqu6ZKFzpxvQ8PST8enjF+Mu7S9/zOxlGnno532q/A146MrmeMhBkxP+F2sfuTSc3Uxl3LoTQktMv5jH3r3aDH+jM+s4Jzu2Fi69cyruKeiMh+65D01feQJd7a1lg4y90JorQxmOhtCo00M/46AKPOMU51QnnyLzpQegTZjWVA8WgqhWHLmGgg79fEBd7cPzNzXH84Zw02mRP+MS6jEnnj41TxZYG6CqGvNw2791ISVbL6hZ9754csFpmDxqPJZMugNLJ1VDk6sH456h3XGudYpeV8r0ux/vP3YLBj/3DU6/OBtdsq5G9vUNcfrJm/GvS+4MGuGm9ED9VMsstiU++jLEf8ODyMp4MDpaCzkBwSETv60cBDCYBEiABEigkhNIcgNcb13lljJwMv627S8Ys3A1NikD/FIVlZJSVf3/ZxySqV2nSfCi9zB95HMozByLV8d1gvFDjxUBbrCOWZj43li09aVwHTRvpWb9ZmzAB4UD0TiOPXNo0/vYqGaHrzvPcX4+1Ci10fXuQViivpD5xL/X48rR8XZYSUGwuZTRE6O58DuVTsX/aOOOECoYP3wv7yBawmSjF/1Pc9txg+h3qgygEe5Y+AJy4lVTL9T1b/x67v1BnJjqmvV3lK9ciORZwEXFSrZeQQWPPfMKjJh1BYbKF1WfnYYZr4xHzjtfYcay4bDxGDLVqui9f2PkczuROfY1PJx9kqFKvzOlK95FiP+Vj+HdsW0NZcSQ6qHvxJDCKBIgARIggUpE4JhKVJdiVqU6qp9oFtGgcUsV8AE+3RJjtvIb9ZpZzZA2PPfPJuNbm6mMMwNpLs3bVbU/neAtg0PqYB0/Rv5WhwQught3vAZN1YfkX3h5Y9i33D7bbqxYtBJHm+bgGnFGj3ekXoObutTAviVTMPezGG2gyWmIRtJcGz9FzKR10nGOeJh8vNnB134vCgtUg6YpNyHtoSs0w//JF8qZyOYo+BJfWILrNGqqHjG+wOdbi+eUY9/G8eu5a8fnQNUmSIvzMHRWfXl14dT2BfjSUjHP9VLrAhRqX8exZ16CPmNmYdYdamGE2rYyV7bvDx32XIBv8j9V7x0aoum5RuNbZVJP0N6HYjXYD7EQf6f+oCup/XrvO6bsvCABEiABEqi0BJLMAC/E0rlroxZbBlt3K76QlVOtG2k+uhJW88qrkVV1HxbNWepgrAVzyv+L1CyX6Sh8GS+sNoUk9CLoZlB8kTUvaocLld/twoXr/ftwp/bGmGHNsO+5v2H82h8djHD1qfqZ9+Kxj5ph6P29LQs+nepRDZfe+lelX4HyrZ8X5b9rzlUTV3ZWe4zvexmzl8kMsNPRAtfkKKPuvWfx/KZoo77oswVqAWVVXHj91aF+UAftOqhVmbsWYOF6q0FdhE1LXooywPHnv6Cj8gJZPe/lODo76RgMt29jVc/uXVHDqZ77X8NL8/ehdvdrcZnTW5tQsXXadUAr5Thk1/ZFmxZjvsUA91yvk0/RFj/GrmWs2BTUPu00laAajv1DJJ09Fz2+KOT+oV+rfb0XzYP3oRjtAx+UWBMXtbsIVW37Q6TM4JmPvmMVwWsSIAESIIFKSSDJDHD10Y3X78RV3YZjxlvbcSC04PLIge1YPno4nv1aGYf3dIssyqp2JUb84zrU+uBB9B86Bx/sCWYo+mUH3poxBUtlRVdqG2Q1q4ovnnsUL3z2izI+i/DLjtcxfsQCfB/Xb7kYfSq9kTKegLzVrzs8ULiUXbsz7hzcCkeX3I3BkyIL34p+2Yftb03HXU9ucCFIvnI5GdMH1sXrwzujv/oYzJZvhYUcR3Bg+1uYcde16Pvsr+g1dTL6eNlSRuk3qJ/y49j8BJ5cuT+mLtWuvBf/uLYWNj7YD0PnfoBgc0l7qPKnLg0bw6m9HsDwVj/j+SG34/G3diC41u8I9nygPsgyfDoOdfknHjY4ndfuOgJDmx3Ckr8Nw4wP9qgaSbX24IMZt+Puzaep2X/LkdICA0ZehzpbJ2HgyAXYEuo3OHIAX29ZhgkPzA/rYslpvnRo42qZQzBG6jnhJoxeuMVQT9Xvbr0f65sMw78Gt4jvHlG7G+5RD06HltyH4TN0XsJhOv5612acZq2Y13qd0QhN1RT45tdXmRY3mysZuXr7Scu43PMB5s7PQ9VmOejy50g6OHBJzeygFnF+gecem4fPpVGLfsHO1eMwYsH3kTFtEBPvtGFj9eCFdVi92vxQWbvTcNzR6iiW3PNXTA73H9XP9m1X94XhMA4Zz30nnlKMJwESIAESqBQEkswAT0X3hx/H7RcfRd6EW5B1YfArkld0H4NV1frgyRUzoozD6pn3Yf6Cf6D9/5ZjROcLtK/nnZ91G6Z98ifUqSl9IBW9J83A0Fbf4+kbL8b5GRej071LUXPIbNx9YQn2EWU8jXm0B8586++4orWqx6WP4F1fxSnjufeTWPLMINTa+CD6XtJKq+Ol2X1w/0s/4vxLznEpNbi94+uvPIIrDy/FyOvbKhbC9wK0vfVpfH/eCCxY/RwGt3a1ms5QZgoa974Jl1c9itX/nBJna73quPQ+ta3iPzrgt+X34GqtfVuh/cCn8Gm1MyKLM1PS0PuJpXh68On4dMIAtBN+GZno9c/3kTZ8KRYrf3OTlip9n6cWYkJ2AIuGZeEiVa8LO/wVc/57HWY/1R/1Ddrqp3q/abN3NgaH+k2Ly6/D4Mlv4qTMS93NDDu2caieD12On5bciWvD9ZyPo9dMw6vT+zrvsqMrqP3Kg9M0xSsbv708FB1EzgUdMHj2f3Ht7GnIsamYp3qltMYtk4bhykOz0VOTfQvmf21SwHRx+tnH433juOw7CZ81ewgLnrLUx4mLehPz2PRhaPX907hR+vEl2bj3lZoYMmtE9FaRppLtL2p3vR8Te9TFW39vp/XlzAnvBBPq/WdQLXzwUB9cqvUfNe77jsH8H8/HpcYh46Pv2GvDUBIgARIggcpEoIpscO5UIYlSH+NR7hVFOHr0KI4//ninpAwngWgCRQWYe0svTP6sCYbOi364ic7AkPJDoAhrR7fCXf+5ATPWqAWQ5UcxakICJEACJEACFYrAwYMHUbVqVbW5RwqOOeYYVKlSBUk2A16h2qviKyuzf5P+iS41PsLkQePwZmwPkopf30pVg63IlzURLZogvVLVi5UhARIgARIggbInQAO87NugcmtQPRMjn38M1/7+VdzTZxSW7wj6hhf9ciDke125q19Ra7d/7YtYuKsGumTH2/6xotaQepMACZAACZBA2RGgAV527JOm5JST2mLkgoV48PKf8NyAoG/4+ZeorxN+lzQIymlF12PCDfdjrlqQvC+4ElWtW/wWW5aPw60jc1Ht2vsxODPOVirltGZUiwRIgARIgATKMwH6gJfn1qFuJFCiBPbgzRkTMXfFx/iicE9wG8qqNXDGuZm4rt8AdL/kTBxbouVTOAmQAAmQAAlUfgJ2PuA0wCt/u7OGJEACJEACJEACJEACZUTAzgCnC0oZNQaLJQESIAESIAESIAESSE4CNMCTs91ZaxIgARIgARIgARIggTIiQAO8jMCzWBIgARIgARIgARIggeQkQAM8OdudtSYBEiABEiABEiABEigjAjTAywg8iyUBEiABEiABEiABEkhOAjTAk7PdWWsSIAESIAESIAESIIEyIkADvIzAs1gSIAESIAESIAESIIHkJEADPDnbnbUmARIgARIgARIgARIoIwI0wMsIPIslARIgARIgARIgARJITgI0wJOz3VlrEiABEiABEiABEiCBMiJAA7yMwLNYEiABEiABEiABEiCB5CRAAzw52521JgESIAESIAESIAESKCMCNMDLCDyLJQESIAESIAESIAESSE4CNMCTs91ZaxIgARIgARIgARIggTIiQAO8jMCzWBIgARIgARIgARIggeQkQAM8OdudtSYBEiABEiABEiABEigjAjTAywg8iyUBEiABEiABEiABEkhOAjTAk7PdWWsSIAESIAESIAESIIEyIkADvIzAs1gSIAESIAESIAESIIHkJEADPDnbnbUmARIgARIgARIgARIoIwI0wMsIPIslARIgARIgARIgARJITgI0wJOz3VlrEiABEiABEiABEiCBMiJAA7yMwLNYEiABEiABEiABEiCB5CRAAzw52521JgESIAESIAESIAESKCMCSWaAF2J2r+YYk2dDO280Woy2i7BJWymChEVPzC6sFJVhJSo0gZLoi8Gx3iKjOcL/es2Cubu7SVNCYAtnoXeUPt7KWj/aULeoesZhKve7jBIa/ybZeRiTMRrrtaoZz73VtWxSx2FYNkqx1BInkLh218aojV1ROKsnWhRz/LvFELxP6GPQLpeMy+boPStyd7S7txjjIfcvlcfWlrIrgmG2BJLMALdlwEASqFgEKvrDYknrr/1x6IKpDSZj46YPw/8WZa1ENxujM3uSnmYJBmMKutn8wSyPHSRzrK73ZGSjEybpdX0hB6nxFG4zVnF5Ef3iJownyCY+0bIT0V/cyHCTxqa6DCrHBNy0qZs0PquYOVaNzeVPmSe61P1p5NSGmORmnPosNzrbMkwzGNjG+MJZT2G5MSB0nj54SfjeKffReTmRm8X6Z6agQXYnLF+TTJOWNpCKGUQDvJgAmZ0ESKA8EVCzV/dOAeSPx9g2JsVSc17EosHA1HutM+F6slT0u60TsG2HZaZcj+cvCZAACXgh0AY3yj3nmYihKsYrBg9AphcxxUybrYzl/Ny1Nve1PDw7FcjOTvdQQh7WLO+EdmPbqYeLNaG3Wx6yM2mYAA3wMArzifaKKPxa1/j6Jvi6Rn+t7fQKRl7hmF7ZiHh50g6/dpLXXIZXyOFwLaHhtW1IL9NTeugVWV7wNVCL8CveUFrtR3/da9TX7pWzMd5YTxESS8eQDoWx8hvj4r2uspSl10nqHW4Ho/5WBoqlNnNpLNNaH2OcUR+rrFA+x7KNnEPnjmmlTJFnLNtYj3jx5rK0fjlsGbB8qMYl0v8s/Ez9ySxDrpz7t0WO23aI2Q8i5TvrL2mMjNy2XUS2dla4Frn56chqG5mtMaZIzRmI7PyVWBd522qMdnHuwCfmWBGxxrqpvrfWWpQlPvL32prQ47VRrpGphEeunftDpDjrPU3LY+xn4XuUWXZEQuwzOx0c+4vjeIseywvldb/tmIno41iOlsSJoUQa44z3lIjs4JnOxJjeeB+I1jvotmPpb0bemmBLfLhNjeWY9bLjLKKcwoP6G//vVKYl3KSrxEl9jXpF+l/wb02seCnfmNdcp6i/VYpD+Wh3QLvn6LPgavZ72rYhGB+eTY7FTOprZCQIjK6yIaYx7YBQu7UboL3de9ZyX9Fmv7MH4sa0UDo3P3lrsDy7nXqAaIN22c4z625EJX2aQIzjt99+CxQVFQUOHz4cOHDgQIyUFSVqZ2BWz2aB0ets9F03KpAxKhSxc2agV/NRgTw92bp1ofNg/l4zd4Zi1gVGN+8RmKVf6unlV+QZZQSMZQfPw+Wp5Dtn9ghk9JypUmmZlVxD+VqQQb+QrEh6LZPlf6JbM7MOJp1COhjKyRul0usM9DLC11Yd3eV3xcq2rJka87yZOhNVPdE/zChUfvhar2+kPTSmYf2D6e31scoKonQu24JaXTqn1fUytKepHeLFR5elcQjXS+JD+hvCzP3JIiNO/470AWlzl+3g2I8sZcul1N+ga1h/Rxmx2s4i39RHLHHaZVDWaG2oG88lMtgWwTjnvEbdg3zi8bfqr/qLjLVw37XGix6RfmyniTlM0hv6lxYZ0skQbh7fhjyO/cFcirndRH6PQK+ekXJFfpCdQbbGVE9jDLfIjqVDVH+JNd5C9Q6zDZVjI8OiQcn2y1DfMv1NEJ3C7WOndyjMMFbM49ouXsZrMNz2XufE2Sk8ClLsMs1jw/g3LZQvXN/QGAjXzV28bZ1C9TWXLRzUUebtHgKo6THTYn/YsTQysxkvpvqE8lv7uqXNwuNS8prSSv7gfUb6VYRtsG2M10aRYXkSGCXTmJLnRgJiQ4stLTa12NZycAbc8RFsK3bos2Rt2gRfF+U9g6kwPr3KE2A+ctfqCQ3C2qgnzvRlCLtIaTNz6rWNvBUPnU8yvCJPzZmgnlC9zcxl3xbP1zMdgxePjbzqsuoEc3zmgCFI11+/u9IxRn4vrCRtvvJhNfHI0fTOzDHUsY165ZVfoOYa9UOV/4geL6/60pE+eELYrzW1bftIfVzoY+UZu2xdh+Bv7LRmTojTDtHx5rKirly1lTWXQ//22w6GfmbqR9ZiHa/NjEwyXLSdo1gXEcuH6W+inkLa4g/xgNlzJSLBqZ/G4x+Kvy086wVo9dMll1j9YjDVyw7/2vSHcFzoRMaf/spZ6tRgIG5roN/jQq+lndhZZdleu9AhlC/2eFOv1OPeG20VsAmMwdBzu5ll2Y1zk97x+pVTf4yrlxNnp3ADFqcy4+mqiTDX3zTG48XHqpOTTga1vZ/G0DWWLk4FyT1/2xRtXUr4/uKKmZPASLipz0SCo89EB7XGJTwLrtWjPf6SGp1UQvKndol++ywz+OJ+oo9zuScU642ifdnJEpqSLBUN1jMVZzUAcsWybmPudYU7tiI9bUAoWQ7mLQZ6d22uDG51M1eLtMKDJl8t0spQPlyGI135eEUfqfhLVjqmKgv8AWXAF65dqfy+JgSN4Z0FyE9Pg1mDaAmxQ9KRVi92CqAhzjIVYqx/nLyJ0NE1K6WLEw814Ht3nYL8sLpq8IfPPZ7E1MeGp5eyY6aN1w6x4k0NaF9hr22VGqN/l0Y72NcidmjMtjNkrZeG9NBDmj25nShQLirGsaOPb3GxGKZ8NfsZHgQNkoOndnzi8Y8XL5Ld1i9KoQQExOoPJvH1kKZNKoxF6g51P0tT97OzOmGa3E/r7cA2xeZGU3oPF651CMmMOd7M7etBC+9JPbVbrHEuRVv0dtNv7PqjiHLSy4mzU7jIsh52ZbrR1SrH67VTnUSOnU5e5XtJH0sXWzlBeyAX9SKxCWFm6TMR6TZnRpukHmZPW6YeVD/U7JDIpFYkmyzCNC68lJjCWSvV3+J8DMtQbpDGI95905iW52ECKeGzJDrJL9ipamv+81xYkI8G7QxhckPalKPSBf3OxogRrq6QPgSLXtBnXSXA+dB8vzLUIoWxwBplyWctNsiPaSQ4y/QWE5zRyAwXW4gd2xCqp92Qs0gvro4eWFlKDl6Kv9swaLs7BBesSFussU3qKtBRHxsWXsqOmzZWO+xUqseKd1Uz9Qc3+GYg3NTxsjn1b7t8cetnlynBYY5tZykntS2y0qeoFf9qkVNONA3N5zG9PRZFR0HbsSBjKMa0MzxwW8Q7Xsbjb42XP74wOF66rZ+jAsWMsOsPbawyQ0aEMrgLC9T9bIBAVHWYthbr1ds7ZE2w3FWt+eNcu9JBySgP/VGviqd2izXObe5BUoa13+jlxvuNpZcTZ6fweGXp8X511fPH+3WqU168jCUQ76SL16JKmplFn6BNonZlSWuovc1fFDXGLRlMl4VYl5tvnpCUeG08ip0T8hQw5eFFLALHxIqsjHHaay+1gC2yeE3VUnWgYcbXKuo6Ei+zPiES2uuWKRg5y+FmGQUsuEhhzWhZtDAw7Bqhv3ocNjpy5yicNUK9ntLTBGeaItsGqcUW6mnV+5FvWn2tlaFcaG50M+hCbhLOOsbRxgsrm7SFs2apP+rqMMxsOG2XFEeTYLRNGXHzeSk7Ztp47RAvPo6mXtvKQ/9OeDvEqYpttKe2UzuZPDJEbTvQJWoRtCwy66YehCNuS9bS2uCBSWprrWGWhU96Mhs9ND7x+Es+GBcrWcazjVy9yOB+u8bFeuGYxJ049QebEsStC7kj1EKy0KtreeBRxve0XGV/Oyx8tRETHeRBBy1zzPEWLb5EQmK1m22BHse5m36lZmKNf4+C/VHcAszhYXWcODuFhzOGTmzq7GoMWOV4vbYpNyzCJi583wonSuCJTXm+pMdrXyTKDjBqF9qVZarMfrubSAznDrnMhN1P9IhQPcLutno4f+MSSL4ZcHnKD7mXtAjjkT10Db7S6jX2NuV+Eo7PVvsJa0ar+gO9abKahVW+UeKboh2WvHpw6DezXScMUyvwsyeNNcQoI+GFyShQs20t9A04tSdq3TIOGhG5XfVylD/aYLU9mpp18nYo3dqtUX5cQ0PZRFe3gy6ejvE08cLKJq3GQ/msTesSdvlJHzxEGTKeIYQUtSlD2zvZ0O7GKslNxW3ZcdPGa4d48UbF1Ln8ARgW7DtB9wmPbeWlfye8Hez0t9Qv6tJj22kzeW3Vrgv6+AkJlLrE6/9qD+tJ2coVpVeazZsuGz1Eppppz4w5nlW+xUOUK5WujxrPk9R6i2l6RW3kxuqberZE/Tr2B5sCNIN7CnLDs90yK66ed3LbY3yqTXq3QbF0iOrvHsamXn6UDD3C8OsmjSG5Goge/x54HOfqfULsvxM25Wv90SZc709OnAud/uaZKqwubGS7GgNWOV6vbcrV6+Sok6hrvVfalOsmjSlbLF1MCeNcxGtfFa8mE4pvB5jV0NZGqX3Iowxpc7KoK9k+MV/ZQsG30cZoo2uLbsMY43nuRKCKrMR0ipQotVoTatUmjh49iuOPP94pKcOdCKiZhRbT7P6YO2VIVHjQXaOd8cEiUaIpxwOBeO0QL95DUUxqT0DzF16pXMBK6MMz9qUylAQMBDjODTB4SgJJR+DgwYOoWrUqUlJScMwxx6BKlSpIOheU0m314Kvm9Ky2xfONLF2lWRoJVC4CakZ8vHwMo2sJu3JULmqsDQmQAAmQQAkSoAFeQnBlR4UWylVFPodtXUlcQkVSLAmQgAMB+Qrmxklq4ZG4lqkPO0V9JMshH4NJgARIgARIoCQI0AWlJKhSJgmQAAmQAAmQAAmQAAkoAnRBYTcgARIgARIgARIgARIggTImQBeUMm4AFk8CJEACJEACJEACJJBcBGiAJ1d7s7YkQAIkQAIkQAIkQAJlTIAGeBk3AIsnARIgARIgARIgARJILgI0wJOrvVlbEiABEiABEiABEiCBMiaQvAa4fJxDbUcW+eR8cVpC7ffdqxT3GJaP+2QkuLySkFkcpMxLAiRAAiRAAiRAApWUQNIa4PJZ1QbZnbB8TZ73phVjdbSPfN5LCuawlqc+l71xUzG/6lcSMmPVz1perLSMKz4B8i4+Q0ogARIgARIggRIikKQGeB7WLO+EdmPbIXv5GqwvIbgUSwIkQAIkQAIkQAIkQAJWAslpgOetwfLsdshEG7TLXoZpswoNXPIwJmO02Sg3zCYWzuqJFsOWAcuHal/UM7uwSN7gl/ZaWGXAGGd0fdHdV4zxkfLty7PqKDL0cuU3lF/0DusTcVnxJbPXLEQoxdbZAFM7tS9Poix6m8owS5Evi0Z9vVDqF84TS5aVl5JtaNOgHopPXtAtKczPrEIwjw3PYDJL+XobWOvoFB6uh0hzqW+hlz5jrQyvSYAESIAESIAEyoxAIMbx22+/BYqKigKHDx8OHDhwIEbKihWVN6pZYPS6kM7rRgUyes4M7AxXYV1gdPNRgbzwtTqRNKP0DDbXKvesns0CGYZ8UkYkTzC+10y9FCmjR2CWdhkvr115Rh1D+Q367Zw5U9M/T/3qJWp1MNbTWqdAPJk9DJxc6GzkJ+dR5dnpbSzDIkDyG/gGQsxHa80ST5axbiG5Jn1C+Y18LMXLpTNPu/KlDbyEG+vuUl8DD3N/U8qa6mdTGQaRAAmQAAmQAAmUCgGxocWWFptabGs5km8GXC2+nCbuJ21CzzxtlBtK/kqsi0zv+nwYSsfgxWPVrHrwyBwwBOnbdqj5T3XkPYOpGILxOamhWJl5z0fuWr3QGHlDORx/RHZ+J0waq1cISM3J0fTIVL96idDqWRDUx1FYKKJwLXKjZE7AYBg5FUNnKcZVGQZF2wzA4PRlCLvsh/Jr7ehVlkGs8TT7NgMvY0To3JGnUxs4hSdE32Lyt6kfg0iABEiABEiABEqHQErpFFN+SilcuxL56r9hGcqNxHg8k4d+BiPWGJWQ8/wp6JYxxSQqfbDp0v9FelrE0DZKkZ1euk5RtdUP9eChn8b63VmAfCeZsfJ5ifNcRir+kpWOqcoCf6BNG2W/rwQGTwg+8HiWZadoOtLq2YUbwmLxdOJlF54QfQ168ZQESIAESIAESKBCEUgyA7wQ63LzkT3pQ2XEGdpJ/IGHqcWYygDXZ7ANsYk5TR+CRS/YzbDqs+CJKSYsRasTMGnTh6E6ib/wmnB03JP84Gx5eAY9bgYfCTyWkZozENmqDuvHAmumAlmLDdp5lOVZ2+LytBZY0vpay+M1CZAACZAACZBAuSGQXC4oRrcFYxOY3BvqIU25OkQWZqrFddMss+XGvG7ONfePKRg5qwSMbRvZhbNmYb3oZZh9LZz1FJa70VXShHgMM2y1WDhrBKY2GIh+BpvXrTjbdL7KCC6aXTNaFtEadIkrK0Ft6sTTqQ0cw4PuNM58E6SvEbzM3id673ijfJ6TAAmQAAmQAAm4JpBUBrjs/Z2v7X5i5RN0bwjuCZ6Kfo8MAaZ2Ce0gMkJNtXYyZxDDynYXFHOyyFUbPLBpMhqEZRp2Kokkcj6LWV607G65yg9cjFKI20twd5SRaI9sYwkxZSoGL0wO11F2UumW2x6LiuOiE1WevzIy26m925cvQ3bYiV8qFU+WizY1srE7j8nToQ3ULjvWdtfaplT09dpH7SrNMBIgARIgARIggZIgUEVWYjoJlii1WhNq1SaOHj2K448/3ikpw0mgdAiIK8i0NAd3ntJRgaWQAAmQAAmQAAmQgFsCBw8eRNWqVZGSkoJjjjkGVapUQVLNgLsFxXTllUDQHSg9q639otPyqjb1IgESIAESIAESIAEDgSRbhGmoOU8rFAH5EM8wcWLPnoyNOYlyRK9QCKgsCZAACZAACZBAJSFAF5RK0pCsBgmQAAmQAAmQAAmQQPkjQBeU8tcm1IgESIAESIAESIAESCDJCNAHPMkanNUlARIgARIgARIgARIoWwI0wMuWP0snARIgARIgARIgARJIMgI0wJOswVldEiABEiABEiABEiCBsiVAA7xs+bN0EiABEiABEiABEiCBJCNAAzzJGpzVJQESIAESIAESIAESKFsCNMDLlj9LJwESIAESIAESIAESSDICNMCTrMFZXRIgARIgARIgARIggbIlQAO8bPmzdBIgARIgARIgARIggSQjQAM8yRqc1SUBEiABEiABEiABEihbAjTAy5Y/SycBEiABEiABEiABEkgyAjTAk6zBWV0SIAESIAESIAESIIGyJUADvGz5s3QSIAESIAESIAESIIEkI0ADPMkanNUlARIgARIgARIgARIoWwI0wMuWP0snARIgARIgARIgARJIMgI0wJOswVldEiABEiABEiABEiCBsiVAA7xs+bN0EiABEiABEiABEiCBJCNAAzzJGpzVJQESIAESIAESIAESKFsCNMDLlj9LJwESIAESIAESIAESSDICyWuAF85C74zmGJNn1+KFmN2rOVqo+N6zCu0SMMw3AWHbE7MTijXSXtJm2r9es2Auwk0a35WKnVH6WpQ+sbNEx+ZhTMZorI+O8B6SN1oxSnQbeFej/OUoib6ZyFqWtH4J7GOJrDZlxSHAdosDiNEkUC4JJK0Bvv6ZKWiQ3QnL10Rb4IWzRmBqg8nYuOlDzMtJBcRgGR2drly2aHlTqqTZaQ9SXcLtJW0m/xZlrUQ3GyMze1IwfuOmJRiMKeiWjO3aZqxi9CL6qa7NgwQqJQE39x03aSobnGSsc2VrQ9an0hBIUgM8D2uWd0K7se2QvXyN7axielq9StPIlbciakbw3inA4CXYOLaNqZqpOS9i0WBg6r3WmXA9WSr63dYJ2LbDMlOux/OXBEiABEiABEiABEqGQHIa4HlrsDy7HTLRBu2yl2Fa2M0k6KbQbWo+8qd20VwZho/uiRbDlgHLh2rXEZcVee0XcncwubKEXhPnBV1cWti4DawfbePaIjMTYTeFoB727hQ2rxvjzGoUzlJ1COtqdGOwlKPrKvLC6Y2uCqG6FRrrbpRn7qRaubbsJF0sGcY4JzchJaJwLXLz05HV1n4qNzVnILLzV2Kd2RfFrGTMKwc+ymTXXZTs3V0s+q+1FmKJ9/VyxaMOs4xuMFK+3m7e2rRk+25IFw9jR+tj4XGjOJvGQixG8cvSZKlx4OyGVkz5Sl3PY1PrSsb+o7ej3sdi6SRp4sXrcmx+He8LNnJN/Styn4zcD2PpYeyfIT2i2lXuS/YcYt93gvKc08TSy4aJladTvY19VMuj9A/3c8VHexNnX5/gvVLa2RhvvC9b9TKmi9w/netsn94qldckQAIJJhCIcfz222+BoqKiwOHDhwMHDhyIkbJiReWNahYYvS6k87pRgYyeMwM7DVXYObNHoNdMQ4ikGaVnkIQ7A7N6NjOkWRcY3bxHYJaWJRhnlWkQHwiIvOajAnnhwGCeoE6h/IbyRJ+IPCnLmFcJidIvLFipOjPQy5h+3bpQuXblzNTi8mYaeJj4hPIY5AlLMxtD2XIapVs8GcH4CH8jWxvZlrYzpwjKMnINnmuKKY6GfmDOqK5CepraQfjYhRvbx6p/IKAxCutpjY9RP5NOxnb3qkMofVgHG1lu27RE+65VTxOA4IWpP0l6NVZ7RsZDZGy7YxQZVyI+KE8bx9q40ce0jR4u+4FZvkWO57EZqpNjW7mss6lPG/uusV9YdFWXce8LJrlOY8UpPI4eUe2u7juOHJSypvTRddFCotLE42eVY5feTf1C+UzjUeoT6W/aPT/MU9rFXF/z3xBjuwVlO94/HersmN5aZV6TAAn4IiA2tNjSYlOLbS1H8s2AK5/haeJ+onsstFFuKF5nSfOewVQMwXjxD9cOmUnPR+7ayFRr9m050GOjnpnaDMDg9GUIu59rM7khnULnkwwuFak5E5S/cnFmcrdih65amzZq5l8dUof8TjCXk6PFZeYYdNf4FKg5G/1Ix+DFY4MyVFDmgCFI9+zGEUOGC7a6Jn5+lw/TZ+OeQtriD/GA3g+swpz4xGufUPxt4b4RYqTLT0T9POug3G0eUe2k6xD1G6M9rGlLoe/GHjsGtzHh0GAgbmugj6WQa5m0aTxGoXrZlrVTvS3ouhJZi2P4yRdHvompt7EJ1YqO4y+eTvHiTXpFXzjeF5zGilN4MfUIahaDQ7Tq7kK86lWs+in9H9Hvs21w4+B0pA+eEF6Xkdq2veW+aq4vrONQr6HX+4vX9Ho5/CUBEig2gZRiS6hgAgrXroRyMMGwDOVWYjyeyUM/g9FrjLI9z1cL+DKU/7HhSFc+x8EjHbFdyFPxl6x0TFUW+APKIBadoG6+mmG8swD56WnOxrtehNvf1BzMWwxlUDRXDw2ALEIMG51O5aiHlN5dpyhK+qEeDvTT0viNydagQL00pOcHHw7sH3Z2okC5qBjbQq+/uFIMi9fmdnzitU+8eFHfbf0MVTWdxisjXrxJmNeLku675vaK1q4e0rSH17FI3aHGTZoaN2d1wjR5wqy3A9tUm90omVwxsCsrH1OH5StjaEnYGIrWoTjyDdL8jE1D9qjTeHWOFx8l0BIQ675gN1Yku114cfWwqJWwSz96lVr9GuIs000uFWc1AHKl31snEbzeX7ymTxhwCiKB5CaQZAZ4Idbl5puNUGl/8S8cphZjKgNcM4Ld9In0IVj0gj6DYcwQmSs2hlrPNf/kDCkTWKMs46zFhrtrTKPSKsnFtfyh35SjEgZ9/caIEe6UTWMBTFI7iQRZSJ41TqlLJtyRraW41LbISp+ifPgHINMw46ynKpz1FJant8ciA1o9LnPsZGRnDMWYdoYHEj0y3m+89rHGyx92pEWkuq1fJEf0mbWM6BTmEKsO5lhPV6Xad6M0Cz4AiOFRWKDGzQBpXMV22lqsV2+JkDUh8vDqlZFWlsw0DkRB1y7ojSXBXZCidAgF+JJvEeZlbFqy2l7G0ylevK1QFZjo+4JfPZz0S1R4ovRKlJxwvYJvSjLD97JC7NgGNGgnATvDqbQTr/cXr+nNpfGKBEjAJ4FjfOarmNlCrxjD7id6LZxe5+nx1l/NLWMKRs5yZ2xbswevgwtA14yWBaEDI7NtIV2Gjc4LZwtui6inCc4AmhaOTrPM5odzqhP1hzOycFTyhiJt6lCoFuqtl2jDrI5mxIaylMqPjV7O5QZdK6AWzFoXysmCo27qwSbymtcqpQ0emKS2oRxmXcQWSmejh8YnXvtIPlgW9hrbx0ZuWDOZYQwv4gqHRp+40UHNakX6p1pYZtQhWqLHkFLquw5ayet55I7AtG3t8RexP+RBTBnf03KV/a0vyI3HyEF2MFj1jU2T0cCmX4WzFUt+SIqfsRlWwOYknk7x4m1EmoKc7gs2fTo4VsS9z9gPZdGpusfE1cPjPc6kZDEu4uplke1Y76CLofM93CLH1aV6M6Pe2OmH9jdBuUHe2EYPCf3a6GRJYb6MlV67H8Va7GkWxSsSIAFvBJJqBlz2/s7Pnmwzy21+rR6FUG5Sw9QuKMt1F47gH+gxGWqnFPHr0A7lT70p4huth8b6zWzXCcPULiHZk8Yakimj8oXJKFCzs1KedmgzFPqdNmh05qoZumDZasZusNpOT80G2h7KTWObcj9poUeq+m/URNnUQStH/fGY1iXsXpM+eIgyKJ2E60Jj/Eaxi5FWi7LRCzHYajOIbdWuJDqPkHypi5r1F/vM8VD7YU/KVq4ovdJs3mbY6CEy1Ux7Zsz2UfkWD1EuPLo+qn0mKf/raboWNnL1+skstbY7j57W6TdeH4mng5Nc9+Gl0ned1NEM7inIDc92y/hVW07mtsf4cIPHY+QkXA83MMy1e9tVXPmqHK9jMwfYoatn+xtPp3jxtkKDgWKcOt4XbPq0NlacwuONIaWnWrPg+h5np7ab+05UGq98/NbPTuF4Yeoe2G6N2p1qaCih3BPt7m82Oun3F8kZVec46eOpxXgSIAHfBKrISkyn3BKlVmtCrdrE0aNHcfzxxzslZbgfAvJad5qd8edHGPNoBGTWJt4CunKKar3a8nLHgBgL/4qjt/S1Ne2i9kv3LZJ91zc6ZiQBbwSCboDtPE7weCuDqUmABEqSwMGDB1G1alWkpKTgmGOOQZUqVZBcLiglSdez7KBbQHpW29iztJ7lJnkGNSM+Xj7A07XivTrNHFtCxrf4/sublijfK799hX3XLznmIwESIAESIAEhkFQuKOWlybUdOMS9RNxBlEsDj8QSkK9gbjxLzfiGdn6RHS3mJRVnZSArlxz1Panwoe/+Eg7wecK+6xMcs5EACZAACZCAgQBdUAwweEoCJEACJEACJEACJEACiSRAF5RE0qQsEiABEiABEiABEiABEvBBgD7gPqAxCwmQAAmQAAmQAAmQAAn4JUAD3C855iMBEiABEiABEiABEiABHwRogPuAxiwkQAIkQAIkQAIkQAIk4JcADXC/5JiPBEiABEiABEiABEiABHwQoAHuAxqzkAAJkAAJkAAJkAAJkIBfAjTA/ZJjPhIgARIgARIgARIgARLwQYAGuA9ozEICJEACJEACJEACJEACfgnQAPdLjvlIgARIgARIgARIgARIwAcBGuA+oDELCZAACZAACZAACZAACfglQAPcLznmIwESIAESIAESIAESIAEfBGiA+4DGLCRAAiRAAiRAAiRAAiTglwANcL/kmI8ESIAESIAESIAESIAEfBCgAe4DGrOQAAmQAAmQAAmQAAmQgF8CNMD9kmM+EiABEiABEiABEiABEvBBgAa4D2jMQgIkQAIkQAIkQAIkQAJ+CdAA90uO+UiABEiABEiABEiABEjABwEa4D6gMQsJkAAJkAAJkAAJkAAJ+CVAA9wvOeYjARIgARIgARIgARIgAR8EaID7gMYsJEACJEACJEACJEACJOCXAA1wv+SYjwRIgARIgARIgARIgAR8EKAB7gMas5AACZAACZAACZAACZCAXwI0wP2SYz4SIAESIAESIAESIAES8EGABrgPaMxCAiRAAiRAAiRAAiRAAn4J0AD3S475SIAESIAESIAESIAESMAHARrgPqAxCwmQAAmQAAmQAAmQAAn4JUAD3C855iMBEiABEiABEiABEiABHwRogPuAxiwkQAIkQAIkQAIkQAIk4JcADXC/5JiPBEiABEiABEiABEiABHwQoAHuAxqzkAAJkAAJkAAJkAAJkIBfAjTA/ZJjPhIgARIgARIgARIgARLwQYAGuA9ozEICJEACJEACJEACJEACfgnQAPdLjvlIgARIgARIgARIgARIwAcBGuA+oDELCZAACZAACZAACZAACfglQAPcLznmIwESIAESIAESIAESIAEfBGiA+4DGLCRAAiRAAiRAAiRAAiTglwANcL/kmI8ESIAESIAESIAESIAEfBCgAe4DGrOQAAmQAAmQAAmQAAmQgF8CNMD9kmM+EiABEiABEiABEiABEvBBgAa4D2jMQgIkQAIkQAIkQAIkQAJ+CdAA90uO+UiABEiABEiABEiABEjABwEa4D6gMQsJkAAJkAAJkAAJkAAJ+CVAA9wvOeYjARIgARIgARIgARIgAR8EaID7gMYsJEACJEACJEACJEACJOCXQIrfjMxHAiRAAsUh8Ntvv+Ho0aMIBALFEVMieatWrYrf/e53UbIPHz4cpW9KSgp+//vfu0orMkW29Thy5AiEh5vj2GOPxTHHmOdOJK/IsB52aa1p9Gtpi//973/6pfZbpUoV/OEPfzCFycWvv/6KoqIiU7hTWpEpssvbIfpKW1hZljc9qQ8JkEDlJEADvHK2K2tFAuWewN69e7F27Vr897//LXe6tmzZEk2aNDEZZ2JwLlmyRDN0jQ8NZ599Ni666CKTwS7xr776Kn7++WeTwV63bl1cdtllUfVdvnw5Dh48GBVuF3DVVVfhlFNOMUX98MMPWnmmQHVx+eWXo06dOtZg2+u33noLu3btCseJgfqnP/0J3bp1g5zrhxjU77zzDr788ks9SIsXY//aa6+FPJDohzwYbN26Fe+++64eVG5+//jHPyIzMxOnnXZaudGJipAACSQRAfWHwvFQN8+A+qMTULM+gQMHDjimYwQJkAAJeCWQl5cXqF27tkx/l7t/EyZMCKgZZVOV5B544oknRul6ww03BH755RdTWmWkBpSxHVCGqyl9586dTen0i3r16pnSxWLy5ptv6tnCvxJml+eVV14Jp4l3IroZZYjuUgepi/GQukqdjWnlXNhY/04IwylTpkSlteYti+tatWoFVq1aZawaz0mABEigRAjIvVFsabGpxbaWw/weU90FeZAACZBAaRCwc/EojXLdlGHnUiKzwNWqVYvKbudSIolkhtV6yCyx3WHn5mGXTsLsuNmFSVrjbLRcxzrsdLOrg8iwq7OwMc6U62XZsdTjyvrXC5+y1pXlkwAJVC4CNMArV3uyNiRAAiRAAiRAAiRAAuWcAA3wct5AVI8ESKD8EFBvDaOUsQuLSlTJAuzqbBdWyarN6pAACZBAwghEVsskTCQFkQAJkIB/AtWrV9d23rBzZ/Av1T6nLBKUxaDyG+8QfWrUqBGVVlwsdu/eHbVbiCxWtB6yG8h3331nDY7afSQqQZwAcaU49dRTo1KVhIuF7opjLU/YuG0zSVezZk1bd5qoShQzQB4MhPu+ffuKKYnZSYAESCBxBGiAJ44lJZEACSSAwF133YV27drBzic5AeJNIn766Sf06tULe/bsMYXbXYif9gsvvKBtwWeM37BhA3r27GkKF6Pvm2++Me2AInnWr18P2cXEenz11VfWIE/XjRs3tt0FpX79+p7kuEks7SJt1L9/f1NyeRBx68su/uIzZszAmWeeaZJREheyZaLswjJkyJCSEE+ZJEACJOCLAA1wX9iYiQRIoKQIyLZ+zZs3d23MFUeP/fv32y4otJMpCx3PPffcqKiPPvoIn3zyiavtFGUWtiRmYmW7wIyMjCjdSiJAZq9TU1O1f37lC8tmzZoVS4bbsmX2+8cff3SbnOlIgARIoFQI0Ae8VDCzEBIgAbcEZMaytI7y+IGY0qp7WZdTmuytHw0q67qzfBIgARKgAc4+QAIkQALFIODW77kYRZRZVi6sLDP0LJgESKCSE6ALSiVvYFaPBCoDAX0hXXHqIj7Kxf3suMzaWo1SNws4db2l/OLui+3F4Je3CV70M/rdSzlOvGRG2brIVNLb7Q+u193Nr+ha3DcgooMXRm70YhoSIAESSDQBGuCJJkp5JEACCScgiyXl8+fqS2K+ZYvPcb169XwbZ2J0vv7665qBaDTCxQfcaow6KXn66aejVatWTtGuwmW3EbfH+++/r+3Q4ia9fLK+Y8eO4aRixNp9pl3qKj7vhYWFprTyYJGVleXp4z9hAepEmIpM4en3kEWgF1xwgbZbjV8ZzEcCJEACpUGABnhpUGYZJEACxSLw5Zdf4sYbb7Tdws+t4GnTpmky/M5Ai/Gfk5OjbVvotkxruksuuUTbScUaXlLX999/v/bQ4Eb+woUL8dhjj8VNKm8B1OflMWfOHFNa2VZwx44dkAWhfg55wFGfhsdtt93mJ7uWR7ZGXLZsGVq2bOlbBjOSAAmQQGkQoA94aVBmGSRAAsUi4OQK4UWo0+favcgwumh4yaendTtTrqcv7q+Xhw0vrip2+4sXl43UNRFtlIi+UlzuzE8CJEAC8QjQAI9HiPEkQAIkQAIkQAIkQAIkkEACNMATCJOiSIAESCAZCBh94PX62oXpcfwlARIgARIwE6APuJkHr0iABEig1An88MMPUQs5ZTePE088MUoX+ZCP251CSsrl5Y9//CNq1apl0k2+bsmDBEiABEjAHQEa4O44MRUJkAAJlBiBO++8E9bP0bdu3RqPPPJIVJl///vf8fnnn0eF2wXIbiWJPsTX+69//SuuvfbasGjZMUX8zcUw50ECJEACJBCfAA3w+IyYggRIgARKlMCbb76p7SBiLMRpQeK7776LjRs3GpOW6rkscmzcuLH2r1QLZmEkQAIkUIkI0Ae8EjUmq0ICJFAxCdjtIOL0URun8IpZc2pNAiRAAslJgAZ4crY7a00CJEACJgL8eqQJBy9IgARIoEQJ0AWlRPFSOAmQQGUnIC4ZTu4idnV3u4DSLq9TmBjPdntzy8dt3O5OUtzPwDvp4KQzw0mABEggmQnQAE/m1mfdSYAEik1Avr7YoEEDV0Z47dq1If7e1uOXX36xBnm6PuGEE9CiRYuoPLIIc+/evVHhdgFbtmyBfM3S7yGuMRdeeKErDn7LYD4SIAESqCwEaIBXlpZkPUiABMqEQMeOHTF16lRXO4DI597btWuXcD3POeccrFmzJkpudnY2Xn311ahwu4CxY8faBbsOk4eL7du3+/4UveuCmJAESIAEKgEB+oBXgkZkFUiABMqOgJdPuLt1B/FaGye5TuFe5btJb+cC4yYf05AACZBAMhKgAZ6Mrc46kwAJkAAJkAAJkAAJlBkBGuBlhp4FkwAJVDQCdjPKdmFO9fKy04iTXLtwL7PwTroxnARIgARIoPQI0Ae89FizJBIgAZ8ExHA9+eSTIbt6+D287FTiVIZ86dG6UNFuD2/JL5+Mt34K/siRI7aia9SoEbV4UVw67BZQyhcnrTok4guUspDTuse46C/1KK1D2shaNy9lSx/x8pDjRTbTkgAJkEAiCdAATyRNyiIBEigRAmeddRYmTpwIJwPWTaHNmjWz3arPTV5J84c//AFPPPEEDh8+bMpSt25dWI1wmaW+77778N1335m2Afzmm29MefWLhx9+GKeffrp+qf1K2ptuuskUJhd9+/bFKaecYgoXA764x8CBA7VdTHQ5UgfR//bbbzfVQY9P9K88cFx22WV4+umnfYuWdpC+woMESIAEyjsBGuDlvYWoHwmQAE488US0b9++TEmIgZiVleVKBzFeV6xYga+++sqV8dqhQwfUq1fPJHvVqlUYNGiQKUwuRo0aZbvlYFRCjwEXXXQROnfuHM4ldRD9ZUZZzkv6kHJSU1O1fyVdFuWTAAmQQFkToA94WbcAyycBEqiUBLy4hVhn1QWIk7vN0aNHS4SX3duF//73vyVSFoWSAAmQQLIToAGe7D2A9ScBEiilxgKMAABAAElEQVRzAuXVb7m86lXmDUYFSIAESKCYBOiCUkyAzE4CJJB4AjL7a13AmPhS4Nm1QnYbsbpjyKfo3Rqqkk7SWw+Ra1dfp4Wj1rROcq3l6Ndu5Eo9RS+RbU1vx0GX7fZX5Fvr4Tavl3RShrXNvORnWhIgARIoCQI0wEuCKmWSAAn4JrBjxw589NFHUQsbfQuMkVF2+Pj1119jpIhEidEpn3a3ppddO8R32c6wjuQOnsliybPPPtsajC+//BI///yzKXzPnj3IyMgwhcnFrl27ohaT/ulPf0Ljxo2j0toFiGtM06ZNo6KExaZNm8LhYrSKDvKJe6MBKxwKCwttd2gJZ45zIkbx5s2bsX///jgpix8t7SVf6ORBAiRAAuWJAA3w8tQa1IUESADySfTifhbdC0YxKN0cv/zyi7ZI0bqTSf/+/fH444+7+hS97PLx0ksvRRV37rnn4osvvjCFy8LMd955xxQmF5deemlU+IUXXoi33norKq1dgDws2Mnt1asXZCcU/ZCZ74YNG2oPHcaHC/ELHzx4MJ599lk9qedfedi47rrrPOdjBhIgARKoLARogFeWlmQ9SKCSEHBrEJdFdUU3q37G2eF4Ojm5ijjJNRq+umwpz6qD9VpP6/TrRq7oKnIlrTG98dxJvptwrzq7kck0JEACJFBRCEQ7I1YUzaknCZAACZAACZAACZAACVRAAjTAK2CjUWUSqAwEvMwcl3Z9nXSzWzRoF1aS+tqV5zSbLLPYbg87GXZliTw7Pl7SutWppNPZ1aOky6R8EiABEhACdEFhPyABEigTAvLVwrS0NMgn0Mvbcfzxx0ftbCLGbJ06dSBxxkMWYXoxdI15/ZzXrl0bDRo0MGWVxZ3btm0zhcmFl328pR5WuRImC0SNh+wXLl8FtaatXr16FAfhIgtErWmN8srqXD5bL/XgQQIkQAJlQYAGeFlQZ5kkQAKa8T1mzJhifV6+pDDKLiHWrffkgeGhhx6K0vfMM89E1apVS0qVKLl33303ZMcS4/H999/jrrvuMgZp51u2bIkKcwqQz9537NgxHC2zw7JY0ipXvggqX820fplU+Mg/4yFpZdHoxIkTjcHl4lx0LY8PBuUCDpUgARIocQI0wEscMQsgARKwIyAzkG4/7W6Xv7TDvHyKviR1E4PWemzcuBFiQBfnaNmypSm7GOCy5eENN9xgCpdtDDt16mT6bL0pgeFCZsDPOuss7Z8hmKckQAIkkPQE6AOe9F2AAEiABCo6gZL6PP3hw4dNO6DonOz8xfU4/pIACZAACcQnQAM8PiOmIAESIAESIAESIAESIIGEEaALSsJQUhAJkIAXAuLiUBIzqeL24GWvarvdOyS/yLEeXtJa88q11NlOhoRbD6e0Vt90ySe62oULX6tsJ7l25XttH7u6ObG0lifXopvXMq1y7DhImuLqZi2H1yRAAiRQHAI0wItDj3lJgAR8E5CFhJ9++ikS7T4hPsryZUgnQ8yosOzosWHDBhQVFRmDtS9A1q1b12SEiwH3n//8J2oR5mmnnYYmTZq4Mvrl0+5vvPGGqSy5kK9sWo8ffvjBNm2rVq1w4oknmpLLDiTylU3r8eGHH0Z9Ml7KstPBmleM4a+//toa7HgtLIWP0dAV4/uMM85Ao0aNHPPpEVLe//3f/+Gzzz7Tgzz/ymLY5s2bm3bWEYN+7969+Pjjj03yJK18gfSkk04yhfOCBEiABEqDQBV104ueegmVLFFy85I/TvJH0rr9VmkoyDJIgAQqJ4G8vDz069cPYpQm8pCtDd9++21X96vdu3drBttPP/1kUuGRRx7BbbfdZtrdRHYEOe+88/Ddd9+ZZpX79u2LSZMmmT5FL/dNMcq3bt1qSisPBXY7pojxap35dUq7du1anH/++SZ9xei1e5Dp2rUrcnNzTWnFKLbuVmJKYLmwbmUoDzj/+te/cOONN5pSivH85z//2fQwIXW99dZbMWHCBFNau4tff/0Vzz33HAYNGmQX7Srs1FNPxcsvv6y1qZ5BuLz22mvo1auXHqT91qpVC7Nnz0abNm1M4bwgARIggUQTOHjwoHbvl8X8+ltBzoAnmjLlkQAJuCIgBqcYd1YDz1XmGIlk4aDbQyYZZEbYqoNxFtcoSwxl62y1GI5uD5FrLcspr1Naq6Eu+cVYF8PYeti9BdC5W9MW91pYCh9j/aQOJcXHTl8p2zqnpE8kGfWSvHJtx9JOLsNIgARIINEEuAgz0UQpjwRIoEIRsPP1rlAVoLIkQAIkQAIVjgAN8ArXZFSYBEggFgEvs5p2M8Qi2zqLqpdnNzPupTxdTnF+nXS2k+lUD7u0XsLkFar18KKXNa9+XdyHIclvlWEXppdXUnx0+fwlARIgAScCdEFxIsNwEiCBMiEgi+LER9loSIkbgyxKtBq7shhRXC+MaeWz7MZrvRL79+/HoUOH9EvtV67FF/i4444zhdt9olxkimyr8VmtWjXb8kwCQxeiq8iwHuIHb10Iak2jX0s9xN/azSEcTz/9dDdJta9rWt007DKK0SrcrDqIXm4NWkkndTY+0Ej9pZ2t+kpa+dKnlY+0mXUxas2aNaN0E5l2ciWt+GPyIAESIIGyIMC7T1lQZ5kkQAKOBGThYHp6umkXk2+//RbTp0/HgQMHTPmuuuoqbeGf0ZASo8xuoeOKFSsgu4IYjT4x7m655ZYoA7p169ZRxtnvf/97DB06VDPwjIamfLbeWL5JQcuF1KtPnz6WUGiLFN0uRn322WejjNQogaEAWaxp9+VMu/Rz587FRx99ZBdlChNDeOnSpSgoKAiHCw8xysXQdXOIn/7jjz9u8heXfPKAMnz4cJMI8St/7LHHTLu5SFsI9x49epjSStuKbsY2lgTSH6xyxYCXr3TyIAESIIEyIaBunI6Hmm0KqJttQN0sA+oPn2M6RpAACZCAVwJqK7yAmn2WXZhM/5ShHFBGl0ncli1bAmq7P1M6yTdv3ryAmrU1pXW6UJ9UDyjDzSRDbd8XUDO3Tll8hysDMKCM7YCaNTeVp3bisJWpdkwxpbMy8Xu9atUq2/LsAkU3v+U45VOGb2DYsGFRxf34448BYW/MJ23Tv3//qLTyt6dBgwamtMpQDwwYMCAqrZqVD6itBU1pRYfs7OyotAwgARIggdIiIPcxsaXFphbbWo5oRz51R+RBAiRAAmVFQGZH1b3JVLxdmCSQ2VFrWlNGw4WdW4nMuFrdWgxZEn5qdaPQCygpHf6/vXMBu6oq8/ii0RnH0LyigAiiiCgYAjbi3RzHSyCoE4ZPg4wpmGMKU06aebdsBg1ybBK89zhdnHRMEDMvgeWtACst46IIykUhydSabp7Z//19+3xrr732d/a57++c33oeOnuvvda73vVbp8//Xudda2WdkZYfab5FPtbyU+E8Yu+mtDhyHx93llu2ZFez43by5dnPuYYABCDQDAII8GZQp00IQAACEIAABCAAgbYlgABv26Gn4xCAgAhknUEvh1Y9bJbTflQ2L35E/vAJAQhAAAIdBFiEyTcBAhDIFYEXX3wx3N3CXki5bt06M3LkSKPTxOy02267JXYlsZ+XutYpiT/+8Y9N7969Y0W1OE9HzCt8IUoKg1iyZEmmhYYSvr4dRXQkuo5rd5OvrFsmutdpk+6pxOLy85//PCpS/IxYFjOCC4V+jBo1ys5KvVbYzujRo1Of2w8U7iI+vnARu1zatZjpZFKXjxZ3KtSIBAEIQKCVCCDAW2k06QsEWoCAji3XriK2+D3ggAPM3Llzza677hrrobYALOdY9Vjl4EZH0OuIcndrwWuuucYEi/xiu6noBEwdv66j6EsliUnftnxPPfWUmTBhQqK6/MiaZs2alRDFS5cuNccff3zCxNVXXx3rgwrss88+5plnnkmUdTPEf8CAAeb++++PjYVbLroXl0MOOcS88847UVZZn4pBf+SRR4wY2SliaedxDQEIQKCnE0CA9/QRxH8ItBgBd6tBdU8zvNpecOedd65pbzVbu2XLloTNtBlpldV+5JUmzeRWO5u7/fbbJzgoz5fcXwxURvtfZ016Mclavtp+ySctttU/EgQgAIFWJ0AMeKuPMP2DQAsQsGfDG9GdtPbS8hvhU9SGZoTd5Mtzy0T35fYha0hJOT5EvvAJAQhAoF0JIMDbdeTpNwSaTKAcwaay5ZT3dS2rkFTdtLZ8W9/52qpnXppvWdtM4+CzW05/tYWgr3xae1n9TStXL7tp7ZEPAQhAoJYECEGpJU1sQQACmQlIsLkx3WmVtXAwOLwldjqmyir0wre/t8+OTj7UsfNZ9sZOs6n2XOGnkAlf2IzPB9lNCxfxlfflZT11U3V9p4Iqbt536qYWvYpPlDRTnuar+uuGiijcJThcJ7ZAVDZ9+31HbbifKusuMHXL6F4cNZ4kCEAAAj2VAAK8p44cfkOghxMYOHBguNBRu1yUShKD3/72txMz0xMnTjQf/OAHMx0Fr0WK2tnEFdC+trXzh3sojMTkJz/5ycQiQx3f/t3vfjfTQTbBiY5m0qRJviYz5/Xr1y9zWS341KJLOymuW8fAuyk4udMMGzYslq2YezdkJVos6R5brxn0T33qUzG+Yph1FxX5pePlTz755JgPvhu9hGhhLgkCEIBATyWAAO+pI4ffEOjhBAYNGmSCY8oz9eL5558Pd/nYsGFDrLxsBMe4ZxLgwXHkRv8qTRLgM2bMSFS/++67zcKFCzMJcAnMz3/+8wkb9cqYMmWK+fCHPxwzv3r1ajN48OBYnm7uvfdec+qppyby3Qz9gqCdUdRvO+20007hzLr74mKX6e46EuuN5NOdPzyDAAQgUE8CxIDXky62IQCBmhCQ6PPFKFcq9mriVKcR7SWeNTXyuHf55IaJKC9ttxJf/LbK+5JeRtyk8JG03WPcsmn3jeaT5gf5EIAABOpNAAFeb8LYhwAEIAABCEAAAhCAgEUAAW7B4BICEMgnATcOOfIyLT963i6faRx8+b68VuLk+6XEl9dKfaYvEIBAzyNADHjPGzM8hkBLENBOGi+//HKmXUlWrFjhLad4Zp0CWc1pmD6YOgFSx9w3Sqwqxt0NF9GOIvvuu2/CPR0v7542qTxfWrlyZeIgHe2AcvDBByeK77jjjom8RmZIJG/evNn85Cc/iTWrMCMtuMwyxltvvXViTYDCZdyFqLEGuIEABCDQBAII8CZAp0kIQMCYX/ziF+b8888PRVcpHoqz9h3XftNNN5nbb7+95kJZCwGnTp1qJOgakS688ELz0ksvxZo6+uijzV133RXL080ll1xinnvuuVh+Whz6tddem9gGcM899zTf+c53YvV1U+tTRhMNlMhQ/Pejjz5qli1bFivZu3dv8+CDDxotuC2VtO3i9ddfb1we5WyFWKoNnkMAAhCoBQEEeC0oYgMCECibgBbsvfbaa949qbMa07Hw1RwNn9aOZucbGbYgDmvXro2549urWwU2btyYKBuraN1s2rTJuuu41B7aEuF5TJrZd2f3tS941sWZmi3ffffd89g1fIIABCAQI0AMeAwHNxCAQKMINCq8o5L+aE/qRibfbi5pPqTlZ/W32vpZ26lluTx/V2rZT2xBAALtQ6Cx/5VpH670FAIQKEGgkTPMJVxJPC5H8JXTj3LKJpzqARm+F4lauF3OeNSiPWxAAAIQqDcBQlDqTRj7EICAl4DEmhb+ZQkv0B7V9QgLkbBT3LAr8HRa5pYtW2Ix4GlltchP/cgSZ6yyb775ZoJHltM5E5WsDJ0M6Ts2XsfDaw91O6ktnw92mehaY6TFoFmS7GqM7L3AxUx9fv/735/FhLeMXlp0WmoWnzW7r5hx8SBBAAIQyDMB/krleXTwDQItTGCPPfYwH//4xxMxv74uK5ZZR9FnObbeVz8tT8JQp0UqLtpOEpJ33nmnnRUeTT99+nSjmGQ77bfffuass85KCF27THStnTxuueWW6Lb4KbFfTdKOLWLpJi22dBd3qi2fD25diWeJevXZfUFxy+r+d7/7nZk3b14ouKPnEvAjR440f//3fx9llf2pFwiduqmTNksljec//uM/EgdeChTPIQCB5hMIZhdSUzCjUQhmpwrB9liF4D9IqeV4AAEIQKCeBIJt+gp9+/YtBH8xa/pPNt96662E68GR84Vg5jbWViAmC6+++mqibDkZwXHvMZvd9eekk07ymh47dmzCxmGHHeYtO378+ETZ7tq0nwWiuzBw4MBC8OtDzHYgtAvBC0cmu2IY7HQTq6+b4CWgECyWzGTD9qnUtWwG2xgm2iMDAhCAQDMJSENLS0tTS1srEQMe/EUnQQAC+SagbeWCv1c1d1I2FTrhJt+Mr0JMfPlu3e7uyznuvTs77jNfH1Sm2vbcXwbcdrPcN2orx8iXnrjINPKdTwhAoH0IIMDbZ6zpKQQgAAEIQAACEIBADgggwHMwCLgAAQh0T0CzmtXOPvta0Ayxz27aLGojF/elzWr78qud6fax6S6vnPZ8LMW8HBvd+cIzCEAAAj2RAIswe+Ko4TMEWpiATkPUwTS2QFu3bl24yK+abh9++OFmyJAhxhaEur7nnntieWpDR8O7QleLAb/1rW+Fu2zYfshmEIMdLtK088u5Pu2008LdWOw6WgB522232Vnh9Yc+9CEzfPjwWH4Qqx27r+eNXkKOPPLI2E4jCuXR7if/8z//E9vVRgzF0u2H8idOnBhjrLyVK1eaH/3oRzH3FcKisvYuL9o5Z/Xq1eaJJ56IleUGAhCAQE8hgADvKSOFnxBoEwISuYsWLYodJ64YcG2pV02aMGGCOfXUU2NbCwYLMM2kSZMSO7Ho2Ht3e0QJ8P/4j/9ICG3tuiFRrB0/Kk06in6Qc9T6s88+a/71X/81YfLWW281w4YNi+Vrd5VGJQnwU045xRx33HHFJiXAdSLpAw88EOMmhk8//bR58cUXi2V1oa0C9eJjb3Eovvfdd19CgKtvM2fONNo1J0rBYiazcOFCBHgEhE8IQKDHEUCA97ghw2EItDaBzZs3m2C3kZgAr0WPtY3dgAEDYgJciwzXr19vJMRLJc3QqqybtK1ftQtEdXy6fLPTCy+8EHKw83Qt0eqWdcvU817hI9r3XP/spP2+feE8enFyX57UB22duOuuuxZNSID7thqUTZePZtvd9ouGuIAABCDQAwgQA94DBgkXIdBOBBQW4hNy1TKQgHaTwlyqbcsOaXHtZ723w22iOmmi3tePqE4zP319SPNHzH3l0/rmy/flpbVHPgQgAIG8EUCA521E8AcCbU5AwjNNfNYaTS3aKsfXcsR6mt1ybFTLS0I56wuKQnB8ojrNB1/ITjl98/Epx980v8iHAAQg0AgChKA0gjJtQAACmQkoDEHxvor7LpV0PLnCEXxirFRdPVc8c//+/ROnW2apG5VRjLIWiWbZMzvLceqRXdmz456jfMWna5GqnRT+0adPHzsr9Vp9VkiHm+SbTrO0k8JC1FYpES7+8kt2VcdOCj9xQ3w0e71hwwbzhz/8oVhU9bKeCCp/tt122wSfXXbZJbTh8ik2Yl1I7O+8886mkfHzVvNcQgACbU4AAd7mXwC6D4G8EZg8ebI54ogjMs2m6rh4LVZ0RV/WPuno8osvvjiT2E+z+cYbb4SLM7OERGjnjqxp3333NVdeeWWiuBYfarcROw0KFnB+/vOft7NSrxV37bM7d+5cE5wiWawnUa2FlVdddVUxr7sLCVr5YL8MaRGmdir5xje+EauqRZRa0Gq/tIifdkHJkrQzykEHHZToh17a7r///sSLhM+mdlU555xzEgtafWXJgwAEIFBzAsEfy9QU/EHkKPpUOjyAAASaTUBHogcnVGY60vyWW24pBAKt5i7ffvvtmX0I/oB7fQ12CcnsV7DjSsLGwQcf7K2v4+zdNoMdVLxlTz/99ERZt25398GiykLwa0TMdjDDXZgzZ05VdrfbbrvCqlWrYnbTboJFsoWRI0dmai/4xaAQbHmZZop8CEAAAjUjwFH0wX89SBCAQOsQyDLrXO/eBn+h691EzL4vdlphJVlTmr/VspQP7taN8qlau1n7pXIKTSknjrycsuX4QVkIQAACpQiwCLMUIZ5DAAIQgAAEIAABCECghgQQ4DWEiSkIQKCxBDS7mjaj63pSr5nYWtgtZwbb7Vd3977YeN8stWzUaza4Fny666P7rJx+NNo311fuIQCB9iWQ/XfL9mVEzyEAgToQeP31182TTz5ptCDPTlqAqZ1JbCGlHToWL14c7nhil9VhLjqJMouQ2nvvvWM2ZUc7qCxYsCCxiHPUqFFGiyBtH+x27evBgwebIH66qoWcWqj44x//2DZr+vXrZ44++uhYXrk3xxxzTOywG9XXwkd3UaTy165dq49Y0kLFcePGxfK01eCSJUvMSy+9FMv33Yjf0KFDzRlnnBF7rBcDcRf/SpJ8WLNmjXnmmWdi1bUTi7vTjHzQ90nfKzupb77dYOwyXEMAAhCoFwEEeL3IYhcCEOiWwMsvv2xmzZoV7rRhF/zP//zP8JREba0XJZ1Aef3115tNmzZFWeGnjmqfMmVKpq3ktE2fGz/9zjvvmC996UuJkxo/+9nPGp9gjzXeeTN69GgzcODATC8BvvrKO/vss8Nt+eznhx12WNUC/MwzzzTvvvuubTZsR+25aePGjbEsxVNrW78rrrgitg2hXpiuvfbaTAJcM/vqh0S4nbQ14aJFiyoW4BLwy5YtS+yCImGuLSHtJB/233//RFl9FxDgNimuIQCBRhJAgDeSNm1BAAJFAtpzWiJc2/jZSYLRDSvRftEq64pE7QUtoRzshGKbyHwtwaaZXHefas2kuj6kGdWx6vpXTdKe2O4WfJpZrzZpFt2X3LZ8ZZSn7f6GDBkSE+CatdbscdbkO7ZevN2Xoaz2VE5jE+wqkGDms6EXCW03qX6QIAABCOSFADHgeRkJ/IBAmxFIC++QYHKTL09lsoSeuLbce5/tNN/curW694lRX14t2tNLRznJ9yJSLXefzXJ8UtlyxqgW7ZXrH+UhAAEIdEcAAd4dHZ5BAAINJ+ATxL48OVaOCEvriE+cpbWXZqPafJ+g9eWltVNPf322fXnyrRbjkdbHavJ9Y1yNPepCAAIQqJYAISjVEqQ+BCBQEQHF5uoocFdoKsZYJzDaMeBpISEKQ1BZ+0RFzRzvsMMOsbCJNAclGHfaaacw1MIuo1li2VUIRpQkOhVO4YpM+esLm4nq2Z/qky98Q3YVb22ncsJaFBO9efNmu3p4rbZsjsqU/25byldctn00vPIiDrqOkvqrf27SOIqZfZy9mOmo9969e7vFvfcaR7es7l3Br3v1y9cP13Aac7cc9xCAAAQaSQAB3kjatAUBCBQJ7LXXXuaiiy6KCTY9/NnPfhbujmLPWmrxpQSim3Ts+AsvvGDsbfwkqC+99NJMCzMl7i655JLEDiaKS//iF78YiwNXGzqW3RXGWgz4ne98J2HD9VX3wSmN4YJL99kFF1xgtmzZEsvWws6s6dVXX00sMlTdc8891wwfPjxmJu0o+uBEz3BhY1RY/CXqr7zyyigr/NQ2hs8991wsTzd6GdLiTPulRcwOP/zwcKeaRAUnQy9OWtA6efLk2BPZ04uanZTnO4reLhNdy245LKN6fEIAAhCoK4Hgj2xqCmY0OIo+lQ4PIACBehCYOHFiIZg1zXScePDHMVEuWLxY0LG/1aQZM2YUgpnTmO1gwWfhtddeS5i99dZbMx9Ff9pppyXql5sxduzYmF8+BlHegw8+mNn8Rz/60cx2I/ulPsVQLN0UvGwUgh1IYu0ForoQ7M7iFuUeAhCAQI8noP8mBb8chppa2lqJGPDgvyAkCEAgPwTccINyPau2vtrz2XBDTyK/fGWjZ+5nmg23XCvdl8OnlfpNXyAAAQh0RwAB3h0dnkEAAhCAAAQgAAEIQKDGBBDgNQaKOQhAoDoCWvgX/DpXnZEqa/u2ANRMrhb0uanRM7zltOcucHV9t+99fbaf1/raXfAp+4ovJ0EAAhBoBwIswmyHUaaPEMghAS2sfPbZZxM7bwwYMMBMmDAhtjuKFig+9dRT3t03qumadvN45JFHEgsoV61aFWtfbWinkYULFyZ26dDR5+PHjw93DIl80QuE7PoWjkZlSn3q0KEnn3wyUcw9al0FtEjx6KOPTpT1nfQon77//e8nygbx7Yk8X4aEuhaTDho0qPhY/ZWgfvjhhzOJaC3O1BH39o4psjtq1KiizehCovzRRx9NnOgZPS/1qbCfvn37mkMOOaRUUZ5DAAIQaBgBBHjDUNMQBCBgE9AJlDfccEO4dZ2d/+lPf9oceOCBsZ1NdHLj888/X3MBrqPor7vuOqNPO61fvz4mqPXsj3/8Y3hsvb3Lh/KPPPLIcDcXbbdnJ+0UIruVzuYvX7483HXFtqnrtWvXullGLy06Mt5NtkiOnunFR7u5uMln1y2je/X/1FNPDV86oufqo3ZBWRQcL59lFlsnmH7uc58LX2oiG5rZ1/aRbpKw//KXv5w4BdUtl3Yvfw899FAEeBog8iEAgaYQQIA3BTuNQgAC2jv7l7/8ZeIoeomwAw44IBbuIYFnbzVYK3qa1ZYP7lH0PvsK5/jVr36VeDRmzJjQ37/9278tPpO/riAvPsx4oZlqvXRkSTpqfcSIEVmKhjPVWe36DEoo77HHHon2JOyzhsdoVnq//fbzmU/kifuKFSvMmjVrEs+yZChsqH///lmKUgYCEIBAwwgQA94w1DQEAQjYBNJ2BJHgcmeNNavq5tm2Kr2WYMwqGtPa8NWXr9X6m8bH50c5sd4+f302u8vzzXLrF4J6pWpevtTfaurXq0/YhQAE2psAAry9x5/eQ6BpBKoVqLVwXOKsHn6kidy0/Fr0JQ826sGyFv3Kq1+16Bs2IACBnkmAEJSeOW54DYEeT0CL7rbbbjvz+9//PtYXzfy6QlX3KquwFTtpEaXCSOwksZV18aPaVviGO4PssysfVNb1Tf1Qe+6ssE/0yVefb7Jbzoy33V9dy3+fXYXFuLO/akcssyTZdZmn1Yv42P1Q+EfEx64XlXVZ2mWia5VRzLjrs1hqnOyksuqz2oySQoHkh8tHZbfZZpsEn6genxCAAATqSaBX8B+J1P2+9Eh/gPUfFv286P4BrKdj2IYABFqbgBb9LViwILYThnqsHVCC0yxjIur111839913X0IMfvvb3w6PrrdFuGLIp0yZEoshTyMpoaYdRFwhOH/+/HAHEm2JGCWJuH/7t39LHEUvES9xZ/8p1fUdd9xh3B1Lhg4dGlu8GNm+6KKLTJ8+faLb8FM7rnzkIx+J5aXd9OvXz5xxxhmJx5/4xCcSsdbyScfOl0rqg46inzVrVqxvErg33XSTOeuss2ImJNRvueWWxIuIdjpxxa9sfOYznzHbb799zIbvRv/t+frXv25+85vfFB9rvH/605+ae+65p5inC/03Sn4pRj1K6ods2PX1rHfv3ubjH/+42XvvvaOifEIAAhCoCwH9DdR/QzQhUpxkCv44paZAfHMUfSodHkAAAtUS0N8Y91+aTbec7s8880zvMfCBoC5k+RdsT1cIBGnCB99R9IFgK7z66quJsrfddltBx9S77QV/xWNHrUf3bjndv/jii4lu6xj5qE6WT5/dQMQn7CrDx9LNC14+Qr+C/1jE/AjEc0F99iXXRjBDXQh2MEmw2XHHHQsbNmzwmfDmuXYDsV8IXiJifomRjrdfsmRJrH/BC1Lh3nvvTfiw2267FX7wgx942yMTAhCAQC0J+I6iJwQl+KtNggAEmkMgEI2ZG/aV9eXJYPCHM5NdlZMN1457HxnzlY3aK6fNyF4tP33t+/LUZlr/XH+ylovqueWje9cP9z6qn/YZ2Yme697NS3sWlXXb1L2bF9ngEwIQgEC9CbAIs96EsQ8BCEAAAhCAAAQgAAGLAALcgsElBCDQswjYC/4q8Vyxwb6ZVHsRXyV2y61Tr5nYavuRtpe5u7Czu/6mlU2z3Z0tnkEAAhBoFQKEoLTKSNIPCLQIgSCGNzycJ4j7LdkjHZ9uL5RUBe0ocsQRR2Ta3UICVcecu2Jw9erViZ1RSjqToYAWS/qOW9eCwGpSEFNtDjvssISJV155JVzomniQIUMvBb/+9a8TJcVbB/loAW2ppMWSQXx7opgW9ou7FmOWShLwGk+NKwkCEIBAqxBAgLfKSNIPCLQIgf/+7/82zz77bGJ7QV/3JDDtHVBUZqeddjKXXHJJuHWdr46dpx1MLr300sRWiMFiy4Swt+tVej18+HDvkfG77rprpSbDenvuuafX7o033ugVwFkakwDXLwTui5B4B4sazaLg2PlSSXW1k4qbtDPKF7/4xUwvSdqCUCejIsBditxDAAI9mQACvCePHr5DoAUJvPTSS2bp0qWh+Kuke5rNPuiggzJtm6oZ3p///OeZjqKvxBe3jmaqdXR9rZNm0H1233jjDaNfFGqZJMz1C4H+VZokzLWNYJakrQX/8Ic/ZClKGQhAAAI9hgAx4D1mqHAUAu1BQCEHvrjsrL0vJ55as7nVtJXVp6icO5sc5Vf7mWa32hjwav2qVf1GjlGtfMYOBCAAge4IIMC7o8MzCECg4QTKEdC1cK7R7dXCZ9dGK/TB7VOl9z6x7sur1D71IAABCNSCACEotaCIDQhAoGYEFEKixXmV7nCi48WzJgkzxRgr1rlUkl8qp/hlW9Bp9tm3mFDHpFcjjDV77bPr81MnrCme3U3uAlU9F1d30albz7732bWfR9diUg77qJ79KX+zjIXa8vFR+wpXsX2WPf3S4bKs5jtm+8w1BCAAgUoIIMAroUYdCECgbgQuvvhic8455yQW/2VtUMJKojpL0rH1WvSpXTlKJQk7HRkfnGgWKzpixAhz9913xxYUSpSfffbZZt26dRWL8NGjR5vvfve7sbbSbtavX28mTJiQePzcc88l8vr372+CkywT+W6GXh60y0zWsdh5551Du67Qde2m3WsMHnnkETN79uy0IsV8vXAce+yxCT7vvPOO+epXv2pef/31YlkJdR0377KUDY0dCQIQgEAzCCDAm0GdNiEAgVQCBx54YMWiVUY1O5p19lwzwUceeWSqL/aD4Phzc9555xmJXTsNGDAg3CbPFp4Sr9Xu2iFB++EPf9huKvVau8Y8/vjjiee+2HC9nGSxqz6sXLkyYTMtQ4L2qKOOMpVuqahZagn+LEnj27dvXxMcJx8rvnHjRvOFL3whtsBTY5zW56zfk1gj3EAAAhCoAQEEeA0gYgICEKgdgUaLoqwLFVVOIRK+sA49s+34hG+5hKIwiyz1VNbnl69uVrsS4OWMhexqAa3Nwdd+Wp6YyUbW5OuH2pbfNgtdK69Sv7L6QzkIQAAC5RBgEWY5tCgLAQi0LQGJuHIEYjuCEiMSBCAAAQiUJoAAL82IEhCAAATCWVR7cV+EJMuiwahsvT4V/lGPpEWNtZjNr8Y3vfSUs2i0mraoCwEIQKBRBAhBaRRp2oEABGIEdAiODonJ4yErOrFy0KBBsRAMhVeMGzcuPLTHnunVATiNDG/44Q9/aLZs2RJjuWnTJnPyySfH8nSj2HB7QWKigJWhsbDj29VHLWp07UqQ6/CitWvXWrX9lyr7SnBa6QsvvBArIJaKQ8+ya4piw7/3ve+ZPn36FG0oNEaLSXXgEgkCEIBATySAAO+Jo4bPEGgBAi+//LK56qqrvEeVN7t72u1k6tSpMQEusXjFFVfE4ovl5/bbb2+23nrrhrk8a9Ys86tf/SrWnnb50LHzbjr33HMzC/Bbb701sZBzl112MXfddVfMrLZX1DHyWQS44q8fe+wxI5/tpNMtDz744EwCXO1pYaXNWDPixx13HALchso1BCDQowggwHvUcOEsBFqHgGa+JcKzztA2sudvv/12YicWhUIMHjy4kW542xIvd3eSnXbayQwZMiRR3t6ZJfHQydi8eXPMrvqrWXCJe3sxpsJwsu7wovpi6fqr7R/thZKOK7Fb2dAsup30MjRq1Cg7i2sIQAACPYoAMeA9arhwFgKtQyDPCxrz7Jsv3MUWyPY3ROI1a/LZ8LUle+XYrQdL2fT5m7WvlIMABCDQbAII8GaPAO1DAAIQgAAEIAABCLQVAUJQ2mq46SwE8k+g0TObjdzlQzPH1bbnm31Os+ubKW40X33j3DZrMSvu67PYun1W2277+f9/AR5CAAKtTgAB3uojTP8g0MMInH/++Wbs2LGmXlvr2Th0rPxnPvMZox1ZGpGeeeYZ89GPfrSqptx4ahlTns/uCSecYM4666xYe1oA2aik3U7Gjx9vBg4cGGtSiygVB15p0taPixYtSvRZMe/Tp083OkU0ShLfu+++e3TLJwQgAIFcEECA52IYcAICEIgIaGu5E0880ZSzgDCqW+6nhPdll11WbrWKy2ubvwULFlRcXxW1LZ+b3nzzTa/df/7nfzb/8A//ECtei9nnmMFubiR+tXB1zz33TJSq5gVLCzi1C8uGDRtidiW0Z8yYYQ488MBYPjPgMRzcQAACOSCAAM/BIOACBCDQRUBiSTOk1Qi0LmvdX2mGtpFJIRL1OLhH4Rg+u2LZCI7dMayXD74+i0G92uuujzyDAAQgUC4BFmGWS4zyEIAABCAAAQhAAAIQqIIAArwKeFSFAAQg4COgWdhGhnr4fFBeOUe4+2bQdQhO1qT+Vhs2VO1svXyo1kbW/lIOAhCAQDUEGvv7azWeUhcCEGhbAlos+bOf/ayqY+uHDRtm+vXrV3NhvG7dOrNixYrYwTIKj9Ax7lmTFp1mPdzGZ/Ott94yP/nJTxKPlCdf7KR21J6bRo4cad59991itsSsYqqzvkhIrH//+9+PnVhZNJbh4s9//nPiyHpV017kf/d3f2e23XbbohWF8mzcuNH88pe/LObpQoc7PfXUU+Gz2APPjYT68OHDjQ4xIkEAAhBoNAEEeKOJ0x4EIFA2AS24u/TSS6s6tv7yyy83p512WsUCMc3pH/3oR+bf//3fjTtb/MYbbyTEb5oNHbVezU4dOpr+1FNPTZj/r//6L9O7d+9Yvtp5/PHHY3m6Oeecc8zpp58ey5dIzSrAf/Ob35iZM2dWvOWfXhT0IuEmnXp53XXXmV133bX4SLP1jz76aLiDTTEzuNCL2pe+9KVMR9xLeM+aNcv7MmLb5BoCEIBAPQggwOtBFZsQgEBNCWhmU1vtadaz0qQj0euRNNMtAawj2itNe+yxh/co+az20vr26quvJkxoptmX+vfvb/Sv0iS7y5cvr7R6aj2F8wwYMMDstddexTJirV9E3CQfVq9e7WZ77/v06VPVmHmNkgkBCEAgIwFiwDOCohgEINA8AllnYbvzsBY2fPZrYVfb6lWTyqmfdrx8Ne3Xu67v8CJfXrl+1GLsym2T8hCAAAREAAHO9wACEIAABCAAAQhAAAINJIAAbyBsmoIABCDQbAK1mDl2F3Y2u0+Vtt8q/ai0/9SDAASaR4AY8Oaxp2UIQKAHEdAiy89+9rNGiw1t4aa4aS12tEM79Pziiy8OY9btsuV0VzHON9xwQ6KKFpPus88+iXxfxqc//WnzwQ9+MPZIMetTpkyJ5enm/PPPNx/60IcS+W6GFmaeffbZ5phjjik+Uh/FRXzcxajFQtaFdmLRYskPfOADxVzFbz/55JPmtttuK+bV4kKHLWmHlwsuuCBmTos7999//1geNxCAAAQaRQAB3ijStAMBCPRoAoqzfuCBB8ymTZtiAnzy5MnhbhzuHtja2aSaRaM6Zv3ee+9NMDvvvPMyC/AjjjjCHHfccTEbL7/8cmL3EBWYMGFCJgGuF40xY8aEojYyLAEuLp/73OeirG4/t956a3PyySebXXbZpVjuT3/6Uyjeay3A5a9ekrQDjp0U/82e4TYRriEAgUYSQIA3kjZtQQACPZaARKa2v7P3ylZnFNKhPaptAa68ahf4ycbvfve7BK9yZtQlMO39s2VM4tdnt5zQFNl1xau2ECynzzokyPZNAty1meh8hRnaScVuq0IzVIMABCBQMwLEgNcMJYYgAIFWJ+ATmL68vHDwiXVfXi38Ldeur7wvrxa+YQMCEIBA3gggwPM2IvgDAQi0BAHtXZ41aVbaTXZMuf1MMc1u8uWpTDmz2j4f3HZK3fuOs/fVkV++2e40H9x8vfSk9dltT6K+nG0a3frcQwACEKgHgeRf8nq0gk0IQAACbURAAlFx0n379o3Fi6ch0JHqiqG2k2LADznkEDsrvFYMtyso16xZ4y274447JuqnZbz44ouJ0zgVVnPggQdmCi2RSJa/WUS4FkD+9Kc/jYWFaBHmihUrEu6pr0uWLDHr168vPlMbOpjJTfJhv/32M1rkGSW9yOy2227mmWeeibLCT5UdMmSI2X777WP53EAAAhBoBAEEeCMo0wYEINBWBCTAr7322kxiVGAuvPBCs3nz5hij4cOHm3nz5sXydHPppZeaV155JZY/aNAgb1nlZ00333yz+eY3v1ksrj7o2PqHHnookwDX0e7aDSbLrLti0D/1qU/FdkzRTLV2UnGTdlXR4k57xjyt7A477GCuvvpqs/feexfNSNg///zzZtq0acU8Xchf7cTie8mJFeQGAhCAQB0IIMDrABWTEIAABIYOHZoZwrp16xKzvzqefsSIEQkbb7zxRigo7QdaYOgra5cpdb127dpYEQlw32LNWCHrRiEhBxxwgJWTfimhrZcId9bfV0OCPusR9/JBLx02C82W6xcCiXA76Sj6cvpn1+UaAhCAQLUEiAGvliD1IQABCFRJQLt0uEkC2Jd8ZX15vrrl5qXFoZdrx1e+HrY1M+7OwCtP/3wpjbGvLHkQgAAEakkg+Ve/ltaxBQEIQAACEIAABCAAAQjECCDAYzi4gQAE8kjAndWsxMda2Kik3UrrpM1qK6bZTdpDO2vKuntIVnuVlsuyWLNS29SDAAQgkHcCxIDnfYTwDwIQMAMHDjTXXXddVTG7hx9+eOy4+LxjVczyv/zLvyTcnDRpkpk6dWosX/HMvqRFkb/4xS9ij7SzyVe/+tVYnm50AuWyZcsS+fXIUMz6rFmzYosw09rRIkwtlswSL55mg3wIQAACeSOAAM/biOAPBCCQIKAdK3SUeFosb6KCJ0PCM21W2VO86VlamHn33Xcn/Jg/f37sGHgVSIunfuSRR8zjjz8es6FFij/84Q9jebp59NFHGybAtaOJXiSy/Crx9ttvhy8MCPDEkJEBAQj0YAII8B48eLgOgXYhIIG53XbbtUt3w34q1OS3v/1tos8Sr1n3rtZhQK4NzSj76ruH3SQarnFG7969M1nUQkkWS2ZCRSEIQKAHESAGvAcNFq5CAAIQKOdXAJ9wTfsVoBy7jAIEIAABCFRHAAFeHT9qQwACNSbQyJlY+3CXGnejLHO+hZVpBqoVyj5RrrZ8wlxlfflpvjU73+evLy/yM0sITFSWTwhAAAK1JEAISi1pYgsCEKiawEsvvWSee+458zd/8zdV2yplQAfCNHI3ji1btpjVq1cn3Np33329YSGJgkFG1tANX13lKQTFt9jyzTffTFT5/e9/b5YuXZopBEQvTvvvv38sHl0vCzo4SPHspZKEsmL9teC2VEor+4EPfCA8dMcW1nq5+fWvf21GjRoVM6u2fKE4sULcQAACEKgTAQR4ncBiFgIQqIzA9ddfb2666aZMoq+yFrpqSai5R8B3Pa391RNPPGHOPffchGEtrNTJl1nSzjvvnKVYahmdePmRj3wk8dw9Bl7i+bXXXjPjxo1LlPVlyK9nn33WvP/97y8+1vaI9913X3g8fDEz5UIC/pRTTjFf+cpXUkp0Zevl7Pjjjzc33HBDV2ZwpbE877zzzMqVK4v5sjt27Fjz4IMPFvN0oXUFCPAYEm4gAIEGEkCANxA2TUEAAqUJvPXWW0b/WjFptn3jxo2JrmmB6e67757Ir0fGX/7yF68PvrbKKatQFV94jGbcfX1225NQfvfdd91s771mwBU+5GP2zjvvxNqTWBd3X1mvcTIhAAEINIAAMeANgEwTEIAABLoj4BOu3ZXP4zOJ4mpTvWzUwm61faM+BCAAAZsAAtymwTUEIAABCEAAAhCAAATqTAABXmfAmIcABPwEFN6Q1+Q72l2z1L4QiXIWcabtdmIvGqwlE4V/NCqJjW8m38cyzSftW+5Lbr7acfNUz5fvy/O1QR4EIACBRhIgBryRtGkLAhAoEthvv/3CBXfaaSNvacyYMWarreJ/HnWS5te+9rVQ+NlCc++99w7jkbP0QYsB77jjjkTRfv36JfJqkXHxxRebf/qnf6qFqW5tKMRDsdZiZCcxPOmkk0yfPn3sbO+1FkXutddeiWfbbLON+fKXvxx7+ZFd324pO+ywg/nCF75gtNtMlGS3XnyjNviEAAQgUC6BXsF/SApplfRIMzOatdEsT7udRJfGhXwIQKB6Avrbor8r3fwJqr6RCi1ogZ+Em5s0o+z6KzGoBYRZkmb9fTPmEpn1iFNWW436pUH+qx9uSuuzW073Yu7bm93lrra06DNr2egFwdcmeRCAAATqTeDtt98O/17pvxf626W/SQjwelPHPgQgAAEIQAACEIBA2xLwCXBiwNv260DHIQABCEAAAhCAAASaQQAB3gzqtAkBCEAAAhCAAAQg0LYEEOBtO/R0HAIQgAAEIAABCECgGQQQ4M2gTpsQgAAEIAABCEAAAm1LAAHetkNPxyEAAQhAAAIQgAAEmkEAAd4M6rQJAQhAAAIQgAAEINC2BBDgbTv0dBwCEIAABCAAAQhAoBkEEODNoE6bEIAABCAAAQhAAAJtSwAB3rZDT8chAAEIQAACEIAABJpBAAHeDOq0CQEIQAACEIAABCDQtgQQ4G079HQcAhCAAAQgAAEIQKAZBBDgzaBOmxCAAAQgAAEIQAACbUsAAd62Q0/HIQABCEAAAhCAAASaQQAB3gzqtAkBCEAAAhCAAAQg0LYEEOBtO/R0HAIQgAAEIAABCECgGQQQ4M2gTpsQgAAEIAABCEAAAm1LAAHetkNPxyEAAQhAAAIQgAAEmkEAAd4M6rQJAQhAAAIQgAAEINC2BBDgbTv0dBwCEIAABCAAAQhAoBkEEODNoE6bEIAABCAAAQhAAAJtSwAB3rZDT8chAAEIQAACEIAABJpBAAHeDOq0CQEIQAACEIAABCDQtgQQ4G079HQcAhCAAAQgAAEIQKAZBBDgzaBOmxCAAAQgAAEIQAACbUsAAd62Q0/HIQABCEAAAhCAAASaQQAB3gzqtAkBCEAAAhCAAAQg0LYEEOBtO/R0HAIQgAAEIAABCECgGQQQ4M2gTpsQgAAEIAABCEAAAm1LAAHetkNPxyEAAQhAAAIQgAAEmkEAAd4M6rQJAQhAAAIQgAAEINC2BBDgbTv0dBwCEIAABCAAAQhAoBkEEODNoE6bEIAABCAAAQhAAAJtSwAB3rZDT8chAAEIQAACEIAABJpBAAHeDOq0CQEIQAACEIAABCDQtgTaV4CvudOcMeogc8Vid+wXmytGXW6ecLPzcr/4cjN61MfMXWuqcaiyPj5x+UFm9OUJYKEja+78WMezLP5lKRPr3gYz59ArzZxVscxc3Dw0fbqZ/lDcFV9evAR3mQk8dIvp1StvY6/v4/TAr+nm0DkbMnelkQWj76A+e/W6xThfUcuVZWa604+OOh39Ux8T/Vy1wBwa5Lvfe8solxCAAAQgUIJA2wrwJ277ihkybrxZ8JhfUBa5SSymiM5imXpeuO0fdbVZuuxb5syB9WzUb/vIY8ebAJjn5WSxuf3G5WbcsUcZk8U/t4zbR3/z3edKqE1fFi/jy4uXqO4uECLXzBtjJp5omfHlWY/b4rKW3E88xxQKV5oZ++SH3Ko5c83MEdMDv+aap2b0NaaW/a1FNxPfwSXmmpQXhVVzHjDzPG2OnX1l2D/1sdjPznIPzZpvRkwbY+bd7/z/zWOHLAhAAAIQ8BNoUwG+2Dy2YLw59upjzTivoPTDavvcowJeZr5JvLMsfswsMAHPQH+3U1q1YIkxs8eZuP5O5rUTk3bp69hhgfDOaXK/l9MCsfz0PUtN8gekZWbWTGOmTSunL8vM/XrpnDvaTJu3tJuZ9ZzCwS0IQAACOSHQngJcgnHcseZIc5Q5dtx8c/Od/niOMKxi5vxg1ndGEPZhh6sohCMIx+j81xXGssbcNTkID1ncEd4yOgxl6cxbY9dxQlzCkIzIXld4ib/9rvARhYSc4fge1pl8p+nokd2m7X/Xt89nw8ifoo2ussH0dsBLk+DxXw2eeGy+GXrBJwKeSl3+6S70p8gq6ndXGX8fVdOXOn4u7/hZvOtn9VVzrjS9TgqE77y54c/l+mncl2eM6quebSce3hDW6/zZvfjTffiTe7ycMRvMgnuMmTTOFi92XmfYzEMdP9eHPocz9HbbXX3Qz/6JcAbNrB66oEM46broV9KXKCQizqYrVKLb/KiNEHnEyOIfm+GNwoH8/fBzt2wF3MJwooxcusYssuHrk2sz4uqUjfWz8ztSZBrVUTtp9Tryh8zcYJ6eGXzngrqTpye/e5GnXZ+OvWJIiJMf80/PgnHOzClqzf4OduZNHGdmBy/Os5w4lHD2e9rJ5qJhUd0Mnw8tNfOmjQ5eOkeZidPSZ9YzWKIIBCAAgfYmUOgmvffee4U///nPhf/7v/8r/Pa3v+2mZM96tPiykYXLF3X6vOiywqiP3VF4pdiFRYXLD7qssDi61/PLosLKfKVw58dGFibfEdVQ+dMLd4a3Hc/i9jrzLJtq37a5+A6rfdefRPuWf3pm2Y186+hbd35mtRFBsD5fuaMwOdam3X+Vs2y7ZRct6uRqlQmruIyt9sLL9YXZY6cVAoVdWNj5aOG04H7a0q6CC+fF7/Ukkbe0MM3E7YRlIrsr5xfGRtdh/aUd7YX5VxRmr+xqLqw3dn7BzorndfpcLBO13WVn5ewrunyWr3bbhY760zo7vHC21ZbKFu12tmOxWBmUXdhZ32aUnh/4UbQnP7s4hz2OcaxwLIroyuRSsP0p0ddiH9SYr6zVz7SxLlUvsKxxGzt7fbFHye9Z1yO/H2njY/kX+VHsU4nvT9Rk7LsR/F8g+P9J+B1y8jv86vguuv1RnVj/ItvBZ9Ge8hI2rYJcQgACEIBAkYA0tLS0NLW0tVL7zYAHiy9vVvhJFC6hsIrl3zOL/JPgybezxbeZG82F5rqpAzufaVZ4uXn4B10Gxp071URPOwoNNRf879WdM8TGHPmJC83Qlas7Z6mD+6lW+dCfl4vPkg5YOUd9wlww1AoJWfMD83Dg21nqWwY/Q0s+G8stPlZz4eXAY8zxdpv6NWHoCeboeIetWivM6gjNUUcVGVgFMl72NbNXnlMM9zjxovFm7PPrPT+rlzIXt2NODGYHxy4x9xdnB9eZ5dFv9SeO6mhvn3HmKScO+aH7l5hpl40zdmhyMi9o6+tRmVHmotl9zdjZ04vxzPuMG9PVB9ePVUvNPU93xZefOCOyE/TvxODn/6c3mJXqajBDOjMot3DuqGLH9wnKnpiW32k3Xn56MEO6xCyI+l20lHYRZ1j+WJTBxXYhrU+dZWLjkamfnrHOVM92qsR1ms+Z2imfU/I72Omfvl/2LLj8MmPMOPsLbHUlmuHv+OWk8xcXN7Y8/B6W872xGuASAhCAQJsTaDsBvuYH3zPLg/8QzSyGRcwI4peXmxtvi4dVdPu9WP4Vc2qx/kFm5gK79FAzeJB9n+E6eCnQjiwdIS3yJ2saaI4+fmgxJEQLS83xx3SJ/279jNqI2xAfUwwnicrYn3b5ILzm5iD8xG4zVnSq+cb/nmAePqWjb12hOnahRl/3N0NjoqOvGTrCmOeXB7tZV3z4AAAADdpJREFUSGivHGPuGdKx80P6Lg+dcbB28HcQ1hLGxsbyyulbXzNuUt/iwjY3jteEYTDRzhRz4wvnxvY1Q3xN+fJXBuETvnxf/Tzmpfre1wyzIZTqZ9pYl6pXCROfz/Vop9vvoP39CsJbrkm+QNpdiy/C7FgEq+/k08GL2knFsB19DzeYmbNYjGmz4xoCEIBAFgJbZSnUOmXWmEUPB7t1zH7OXKVZ4igp5nlmsLvH1RlnaIdeaO77pjVrHdnJNm9dLB1ehG0Ha/mWPWfFUD8WL9PN3cBjTjBDb5TvJlxYeu4yayo61c9XYhYHTv2kGTeq08aNgYb/X8tGrGTHTUebXzN3HRuI62C2/NxvdlN+YCDCl00NKnbEo1/hsvfYr29Wx6zniUURvsEsf96YERM7Y7klzApBoHtnnPj0hXPNXEdUR7Gzcy1HfXnW40yX+8w42UzrFSxsCwzfHyyOm7Sy0yfFYJ9kzMJgR4oOVxR/vTSTTW+hztnzIgJvoRbILNVP31ir26Xq1QpNjdsp9R3s+H49YOYM6x/Mfo83K53vdffdUmz5BjPN/f9D+N3Ud7bz16LujfAUAhCAAAQ6CbTXDLhCNHzhFW4YRndfjzBE5CvmkjujuIruCmd8NnRwcdZ6zZ1fK2MGPLAfCNxzg4Wkj10eLSztbLMsPzsWo3bY+GTpLQ7DMJQg7Obm4NeEcDFrSj+Dl4uuWe9BZvDQlHINzY7P2IVbygVi5CKJkUBMdM16BzOqYzsdiy3C7FjkNvuirpCPaEFmPK+STnUsbLt/uha6nVwMVQktWbOoodCKzIdhAPPNFGubuVVzFpiHUvM7Qm5OsrZs7NhWL2pP/bYX13XMlkbNVfQZ41eRhY5KaX3ymewM6UntZ9pYl6rna8vNs/ub5nMt2om16/texgoENwqDMmbmzO5nv91a4X1nyExsy0096OxHVwiXtzaZEIAABCDgEGgrAa4QDb9gtMMqHEISsrFdUI4yVy2bY4bcOLG4C0rHbidOvay3Ev+mK6TlEnNCsNWflRLtW886L7U/94IFK4LIEXtavzw/O2zM79jLO9mEkzPQnHnueLN8eefe387T4u2gwWblzCi0ZqK5ccic+C8PUcEMfYyKpn5K6Fi7oITlfHlB3OvCiUuLO4oMmdnfLHyqM756SF/z/ElRmMeV4V7P7uy3kRBxY2d9eamOdv/gxInB/srzAoE00RL4EjlB2NSQzp/+pwTtTyuaGWXmFqabEZ27cihmd0iwO8uQQGz58/uaGU9NL7LqKD/GrCzGkAfPvx7s9160F0zHTxpTbC3ThZd7ppolCqX1yVetRD9Tx7pEPV9T3fY3zecK2vG1HeVl/A6G6w6C709CSEd2Uj619/fT4e4nbgE7tMV9xj0EIAABCKQR6KWVmGkP9ShYrWmCVZvmj3/8o9luu+3SipLf0wkoFObmwSmhNT29c5H/HaEbEwtdizmjJ1k/tV3gNcOu7DiApbOSLy+rvUQ5/aR/TV+zMnopSBQgAwJJAjX9DibNkwMBCEAAAlUQePvtt81f//Vfm6222sq8733vCyYBe5k2iwGvgl5LV40WU95fDIXJU3d7BSEZtUiFub2KZiqxqfpaaHlZoW9w6maHT768YiMZLwrBoSYdqSPcY+ykK82QGvU5owsU68EEavEdrEX3u77HtbCGDQhAAAKtTYAZ8NYe35K900E84S4u4+aYpcEi1NZO1c+A14uPZjBP0png04IjzovhIPVqDbsQgAAEIAABCDSKgG8GHAHeKPq0AwEIQAACEIAABCDQdgR8ArytFmG23YjTYQhAAAIQgAAEIACB3BFAgOduSHAIAhCAAAQgAAEIQKCVCSDAW3l06RsEIAABCEAAAhCAQO4IIMBzNyQ4BAEIQAACEIAABCDQygQQ4K08uvQNAhCAAAQgAAEIQCB3BBDguRsSHIIABCAAAQhAAAIQaGUCCPBWHl36BgEIQAACEIAABCCQOwII8NwNCQ5BAAIQgAAEIAABCLQyAQR4K48ufYMABCAAAQhAAAIQyB0BBHjuhgSHIAABCEAAAhCAAARamQACvJVHl75BAAIQgAAEIAABCOSOAAI8d0OCQxCAAAQgAAEIQAACrUwAAd7Ko0vfIAABCEAAAhCAAARyRwABnrshwSEIQAACEIAABCAAgVYmgABv5dGlbxCAAAQgAAEIQAACuSOAAM/dkOAQBCAAAQhAAAIQgEArE0CAt/Lo0jcIQAACEIAABCAAgdwRQIDnbkhwCAIQgAAEIAABCECglQkgwFt5dOkbBCAAAQhAAAIQgEDuCCDAczckOAQBCEAAAhCAAAQg0MoEEOCtPLr0DQIQgAAEIAABCEAgdwQQ4LkbEhyCAAQgAAEIQAACEGhlAgjwVh5d+gYBCEAAAhCAAAQgkDsCCPDcDQkOQQACEIAABCAAAQi0MgEEeCuPLn2DAAQgAAEIQAACEMgdAQR47oYEhyAAAQhAAAIQgAAEWpkAAryVR5e+QQACEIAABCAAAQjkjgACPHdDgkMQgAAEIAABCEAAAq1MAAHeyqNL3yAAAQhAAAIQgAAEckcAAZ67IcEhCEAAAhCAAAQgAIFWJoAAb+XRpW8QgAAEIAABCEAAArkjgADP3ZDgEAQgAAEIQAACEIBAKxNAgLfy6NI3CEAAAhCAAAQgAIHcEUCA525IcAgCEIAABCAAAQhAoJUJIMBbeXTpGwQgAAEIQAACEIBA7gggwHM3JDgEAQhAAAIQgAAEINDKBBDgrTy69A0CEIAABCAAAQhAIHcEEOC5GxIcggAEIAABCEAAAhBoZQII8FYeXfoGAQhAAAIQgAAEIJA7Agjw3A0JDkEAAhCAAAQgAAEItDIBBHgrjy59gwAEIAABCEAAAhDIHQEEeO6GBIcgAAEIQAACEIAABFqZAAK8lUeXvkEAAhCAAAQgAAEI5I4AAjx3Q4JDEIAABCAAAQhAAAKtTAAB3sqjS98gAAEIQAACEIAABHJHAAGeuyHBIQhAAAIQgAAEIACBViaAAG/l0aVvEIAABCAAAQhAAAK5I4AAz92Q4BAEIAABCEAAAhCAQCsTQIC38ujSNwhAAAIQgAAEIACB3BFAgOduSHAIAhCAAAQgAAEIQKCVCSDAW3l06RsEIAABCEAAAhCAQO4IIMBzNyQ4BAEIQAACEIAABCDQygQQ4K08uvQNAhCAAAQgAAEIQCB3BBDguRsSHIIABCAAAQhAAAIQaGUCCPBWHl36BgEIQAACEIAABCCQOwII8NwNCQ5BAAIQgAAEIAABCLQyAQR4K48ufYMABCAAAQhAAAIQyB0BBHjuhgSHIAABCEAAAhCAAARamQACvJVHl75BAAIQgAAEIAABCOSOAAI8d0OCQxCAAAQgAAEIQAACrUwAAd7Ko0vfIAABCEAAAhCAAARyRwABnrshwSEIQAACEIAABCAAgVYmgABv5dGlbxCAAAQgAAEIQAACuSOAAM/dkOAQBCAAAQhAAAIQgEArE9iqnM5t2rSpnOKUhQAEIAABCEAAAhCAQFsT2GabbRL9L0uAb7vttgkDZEAAAhCAAAQgAAEIQAACfgLvvfde4gEhKAkkZEAAAhCAAAQgAAEIQKB+BBDg9WOLZQhAAAIQgAAEIAABCCQIIMATSMiAAAQgAAEIQAACEIBA/QggwOvHFssQgAAEIAABCEAAAhBIEECAJ5CQAQEIQAACEIAABCAAgfoRQIDXjy2WIQABCEAAAhCAAAQgkCCAAE8gIQMCEIAABCAAAQhAAAL1I4AArx9bLEMAAhCAAAQgAAEIQCBBAAGeQEIGBCAAAQhAAAIQgAAE6kcAAV4/tliGAAQgAAEIQAACEIBAggACPIGEDAhAAAIQgAAEIAABCNSPAAK8fmyxDAEIQAACEIAABCAAgQQBBHgCCRkQgAAEIAABCEAAAhCoHwEEeP3YYhkCEIAABCAAAQhAAAIJAgjwBBIyIAABCEAAAhCAAAQgUD8CCPD6scUyBCAAAQhAAAIQgAAEEgQQ4AkkZEAAAhCAAAQgAAEIQKB+BBDg9WOLZQhAAAIQgAAEIAABCCQIIMATSMiAAAQgAAEIQAACEIBA/QggwOvHFssQgAAEIAABCEAAAhBIEECAJ5CQAQEIQAACEIAABCAAgfoRQIDXjy2WIQABCEAAAhCAAAQgkCCAAE8gIQMCEIAABCAAAQhAAAL1I4AArx9bLEMAAhCAAAQgAAEIQCBBAAGeQEIGBCAAAQhAAAIQgAAE6kcAAV4/tliGAAQgAAEIQAACEIBAggACPIGEDAhAAAIQgAAEIAABCNSPAAK8fmyxDAEIQAACEIAABCAAgQQBBHgCCRkQgAAEIAABCEAAAhCoHwEEeP3YYhkCEIAABCAAAQhAAAIJApkEeK9evYz+kSAAAQhAAAIQgAAEIACB7AR8OnqrUtWjSu973/vMn/70p/DfX/7yF/Pee++ZQqFQqjrPIQABCEAAAhCAAAQg0DYEpJ2lm//qr/7KbL311uG/SE9HELoV4CoskW0bUkUZVT4CPMLIJwQgAAEIQAACEIAABEyom6WdJcD1T7pZ90rRZ7cCPCoYGdF9pOgR36JBggAEIAABCEAAAhCAQJyAtLM0c6SbdR+Jb5XMJMBVWUkVo5lvBHiIhP+BAAQgAAEIQAACEIBAjEAkuKNPaWlbgPcKhHSmQO5IeMt6xioxR7iBAAQgAAEIQAACEIBAuxCIBHckwu1+/z9dcyILpIE1cwAAAABJRU5ErkJggg==

--fec41e4ea4a6e4ab112b7859709d585df6389fff5b081c8e1545d8cb674d--`},vba_macro:{label:"VBA Macro",fileName:"vba_macro.eml",fileContents:`Delivered-To: josh@sublimesecurity.com
Received: by 2002:aca:1a17:0:0:0:0:0 with SMTP id a23csp3083251oia;
        Tue, 30 Aug 2022 07:14:30 -0700 (PDT)
X-Google-Smtp-Source: AA6agR4flxsZ65dSL71UemeXdV2EMD3nbR45cVZxhLkPw3umjNES5+pkkDk+Rc+Luti/uAR/XdVu
X-Received: by 2002:ad4:5f49:0:b0:496:dcbf:d61e with SMTP id p9-20020ad45f49000000b00496dcbfd61emr15668088qvg.4.1661868869765;
        Tue, 30 Aug 2022 07:14:29 -0700 (PDT)
ARC-Seal: i=1; a=rsa-sha256; t=1661868869; cv=none;
        d=google.com; s=arc-20160816;
        b=lZ8/NaQ+d8HaAJJciC7qxoxfT5IBqWv/g3rozQdRFQdPinXqV3shwJU6n4praM3hFT
         n85qSxrxHOgars1DH6Alo0B459CpRWh51QzrlpsretUPrtjDTOilvGwaN0xZQySYGip7
         cwhI32bPpElLKvAq5kv0lCjMA8q3VkwKHZP5PjGWB0k4Nfs8nSF+lLJzZylDYJi7wiaI
         aerTZrfcuUs3OknfJWN8PY/9h7Gez1O+BXHH/P18OAVKysgCY65Ne5HScgfVNYQVk6cX
         0p+FSz3KhungVazl4tjdpwIHOKl7QZc7F9H4j3MJ12djoG37dLfiQcoSm8CPJJtkNq05
         c2Ig==
ARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=google.com; s=arc-20160816;
        h=to:subject:message-id:mime-version:from:date:dkim-signature;
        bh=8H0rLNS+pzVsoZv4qYbAV/O/HJ+JIEW7f6ql+S4JvPk=;
        b=PM3YHl4R6dQvnRUHFNUk/DhviSnlunyynLwsDn61j9vQYJHIGoMd1ersAG4woYzEb+
         lofByqJVsITNDFH505D0UMjVEcQ2mak00MrqArvaROiHcqr42vAT8OlImsiGpvUcviPS
         XiVok3ZVvbb+Bbkc0h1Fw5OLwOG2YxN3UaqdkYEc5PMOeYbuFUDZnek0qkMbO/CgX3Kv
         N/Bv4xs8uk1YzQQ/DLj6UviHpzv8wtScvL16G8Ghkd2kP38hty1zx4R8dLuj8EkEn5Eb
         FyIGLLrhDeHUneyVEfzG1E/rVuPYtqMpHF7US3Sfe6ThvI01h5uC495birxCRV1ITIlA
         ZkqA==
ARC-Authentication-Results: i=1; mx.google.com;
       dkim=pass header.i=@delivrto.me header.s=s1 header.b="dac0/Qn5";
       spf=pass (google.com: domain of bounces+26131460-0e71-josh=sublimesecurity.com@em8247.delivrto.me designates 149.72.54.131 as permitted sender) smtp.mailfrom="bounces+26131460-0e71-josh=sublimesecurity.com@em8247.delivrto.me"
Return-Path: <bounces+26131460-0e71-josh=sublimesecurity.com@em8247.delivrto.me>
Received: from wrqvpsvp.outbound-mail.sendgrid.net (wrqvpsvp.outbound-mail.sendgrid.net. [149.72.54.131])
        by mx.google.com with ESMTPS id n11-20020a67e04b000000b00391c19aa30fsi166902vsl.426.2022.08.30.07.14.29
        for <josh@sublimesecurity.com>
        (version=TLS1_3 cipher=TLS_AES_128_GCM_SHA256 bits=128/128);
        Tue, 30 Aug 2022 07:14:29 -0700 (PDT)
Received-SPF: pass (google.com: domain of bounces+26131460-0e71-josh=sublimesecurity.com@em8247.delivrto.me designates 149.72.54.131 as permitted sender) client-ip=149.72.54.131;
Authentication-Results: mx.google.com;
       dkim=pass header.i=@delivrto.me header.s=s1 header.b="dac0/Qn5";
       spf=pass (google.com: domain of bounces+26131460-0e71-josh=sublimesecurity.com@em8247.delivrto.me designates 149.72.54.131 as permitted sender) smtp.mailfrom="bounces+26131460-0e71-josh=sublimesecurity.com@em8247.delivrto.me"
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed; d=delivrto.me;
	h=content-type:from:mime-version:subject:to:cc;
	s=s1; bh=8H0rLNS+pzVsoZv4qYbAV/O/HJ+JIEW7f6ql+S4JvPk=;
	b=dac0/Qn5iVhjRfYLV0h7HzkD+fZMv4oVS7pBoZslQom5U5WjSqJ/WTjypDT6Qkn6fI2f
	9jFrJoKZkw29baPJo+WhG4jhaddzZEfL5fjBZIarXDb76fiDHxBDfrajTo3Q939njhMlNJ
	/wJiMnAF9EEXFKYoKbevz+c7cmuz5ocoT3A5HDWWotpALaRZ1nvJOpVL0hSEv3OgoJXw4o
	S5zAnMQSMdHc6oBjg3hYNay7dB9IaNoGugJ9jHnt+fVw4SRzJ8vTSqQ3RpuPmGnKxG+ej0
	ibwonFz6+n8Xs7RXkaCk7gp5FMg+GaybBUbhfFi6nmYG6Sosbvy9MD5nmjVO0lEQ==
Received: by filterdrecv-5657f5d76d-gbrt4 with SMTP id filterdrecv-5657f5d76d-gbrt4-1-630E1B43-CD
        2022-08-30 14:14:27.867189266 +0000 UTC m=+403418.697941449
Received: from MjYxMzE0NjA (unknown)
	by geopod-ismtpd-4-1 (SG) with HTTP
	id tPaly5D6TFKr74DH8QxYFA
	Tue, 30 Aug 2022 14:14:27.682 +0000 (UTC)
Content-Type: multipart/mixed; boundary=2bc4306318b49a5e653019f606e6960ddae78a6d46ad0489b0dc9043bbe6
Date: Tue, 30 Aug 2022 14:13:49 +0000 (UTC)
From: John Smith <john.smith@gmail.com>
Mime-Version: 1.0
Message-ID: <tPaly5D6TFKr74DH8QxYFA@geopod-ismtpd-4-1>
Subject: Attached
X-SG-EID: 
 =?us-ascii?Q?nNFctdm0BWd6iTjLSzehWcCERmdrJawkAoxBD3zdGSToSIpCkBasaFoatuFduW?=
 =?us-ascii?Q?T7BytT4L97XgKvNa5GIRAYNRNOMTyx44TOblikt?=
 =?us-ascii?Q?+rOlAZ4hQoUQ=2F0rLlunSMvg6PUs4fr8pZJ80MJj?=
 =?us-ascii?Q?xJhW+6qL+ofVROVXLakSWJP=2FjYoCyCuQHWi63kQ?=
 =?us-ascii?Q?A3tUWpDj+0b0JR0rFTPGfaUTP7k9qcJ1Mr8xx72?=
 =?us-ascii?Q?TCihNNTyqw6DRbmaQ=3D?=
To: josh@sublimesecurity.com
X-Entity-ID: UaW5x+lh5T3AtrT7tvfaWg==

--2bc4306318b49a5e653019f606e6960ddae78a6d46ad0489b0dc9043bbe6
Content-Transfer-Encoding: quoted-printable
Content-Type: text/html; charset=us-ascii
Mime-Version: 1.0


<!doctype html>
<html>
<div class="opiyyvaicn"></div>

<head>
  <meta name=3D"viewport" content=3D"width=3Ddevice-width, initial-scale=3D=
1.0">
  <meta http-equiv=3D"Content-Type" content=3D"text/html; charset=3DUTF-8">
  <title>Your delivr.to content.</title>
  <style>
    @media only screen and (max-width: 620px) {
      table.body h1 {
        font-size: 28px !important;
        margin-bottom: 10px !important;
      }

      table.body p,
      table.body ul,
      table.body ol,
      table.body td,
      table.body span,
      table.body a {
        font-size: 16px !important;
      }

      table.body .wrapper,
      table.body .article {
        padding: 10px !important;
      }

      table.body .content {
        padding: 0 !important;
      }

      table.body .container {
        padding: 0 !important;
        width: 100% !important;
      }

      table.body .main {
        border-left-width: 0 !important;
        border-radius: 0 !important;
        border-right-width: 0 !important;
      }

      table.body .btn table {
        width: 100% !important;
      }

      table.body .btn a {
        width: 100% !important;
      }

      table.body .img-responsive {
        height: auto !important;
        max-width: 100% !important;
        width: auto !important;
      }
    }

    @media all {
      .ExternalClass {
        width: 100%;
      }

      .ExternalClass,
      .ExternalClass p,
      .ExternalClass span,
      .ExternalClass font,
      .ExternalClass td,
      .ExternalClass div {
        line-height: 100%;
      }

      .apple-link a {
        color: inherit !important;
        font-family: inherit !important;
        font-size: inherit !important;
        font-weight: inherit !important;
        line-height: inherit !important;
        text-decoration: none !important;
      }

      #MessageViewBody a {
        color: inherit;
        text-decoration: none;
        font-size: inherit;
        font-family: inherit;
        font-weight: inherit;
        line-height: inherit;
      }

      .btn-primary table td:hover {
        background-color: #34495e !important;
      }

      .btn-primary a:hover {
        background-color: #34495e !important;
        border-color: #34495e !important;
      }
    }
  </style>
</head>

<body>
Hi Rachael, please see attached.
</body>

</html>

--2bc4306318b49a5e653019f606e6960ddae78a6d46ad0489b0dc9043bbe6
Content-Disposition: attachment; filename="WMI_Process_Create2.xls"
Content-Transfer-Encoding: base64
Content-Type: text/plain; name="WMI_Process_Create2.xls"

0M8R4KGxGuEAAAAAAAAAAAAAAAAAAAAAPgADAP7/CQAGAAAAAAAAAAAAAAABAAAAAQAAAAAAAAAA
EAAAIgAAAAEAAAD+////AAAAAAAAAAD/////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////9
////IQAAAAMAAAAEAAAABQAAAAYAAAAHAAAACAAAAAkAAAAKAAAACwAAAAwAAAANAAAADgAAAA8A
AAAQAAAAEQAAABIAAAATAAAAFAAAABUAAAAWAAAAFwAAABgAAAAZAAAAGgAAABsAAAAcAAAAHQAA
AB4AAAAfAAAAIAAAAP7///8tAAAA/v///yQAAAAlAAAAJgAAACcAAAAoAAAAKQAAACoAAAArAAAA
LAAAAC4AAAA8AAAAOgAAADAAAAAxAAAAMgAAADMAAAA0AAAANQAAADYAAAA3AAAAOAAAADkAAAD+
////OwAAAD0AAAD+/////v//////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////1IA
bwBvAHQAIABFAG4AdAByAHkAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAWAAUA//////////8CAAAAIAgCAAAAAADAAAAAAAAARgAAAAAAAAAAAAAAAACJ/ADDmtgB
IwAAAIAaAAAAAAAAVwBvAHIAawBiAG8AbwBrAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAABIAAgENAAAA//////////8AAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAACAAAAiTwAAAAAAABfAFYAQgBBAF8AUABSAE8ASgBFAEMAVABfAEMAVQBS
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIgABAQEAAAALAAAACgAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAEF31AMOa2AEAifwAw5rYAQAAAAAAAAAAAAAAAFYAQgBBAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAEA////////
//8GAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAp/cAw5rYARA/+gDDmtgBAAAAAAAAAAAAAAAACQgQ
AAAGBQBaT80HwQACAAYIAADhAAIAsATBAAIAAADiAAAAXABwAA0AAEFkbWluaXN0cmF0b3IgICAg
ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg
ICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBCAAIAsARhAQIAAADAAQAAPQECAAEA
0wAAALoBDwAMAABUaGlzV29ya2Jvb2ucAAIAEQAZAAIAAAASAAIAAAATAAIAAACvAQIAAAC8AQIA
AAA9ABIA/3//f7ZJph04AAAAAAABAFgCQAACAAAAjQACAAAAIgACAAAADgACAAEAtwECAAAA2gAC
AAAAMQAeANwAAAAIAJABAAAAAgACBwFDAGEAbABpAGIAcgBpADEAHgDcAAAACACQAQAAAAIAAgcB
QwBhAGwAaQBiAHIAaQAxAB4A3AAAAAgAkAEAAAACAAIHAUMAYQBsAGkAYgByAGkAMQAeANwAAAAI
AJABAAAAAgACBwFDAGEAbABpAGIAcgBpADEAHgDcAAAACACQAQAAAAIAAgcBQwBhAGwAaQBiAHIA
aQAxACoAaAEAADYAkAEAAAACAAINAUMAYQBsAGkAYgByAGkAIABMAGkAZwBoAHQAMQAeACwBAQA2
ALwCAAAAAgACBwFDAGEAbABpAGIAcgBpADEAHgAEAQEANgC8AgAAAAIAAgcBQwBhAGwAaQBiAHIA
aQAxAB4A3AABADYAvAIAAAACAAIHAUMAYQBsAGkAYgByAGkAMQAeANwAAAARAJABAAAAAgACBwFD
AGEAbABpAGIAcgBpADEAHgDcAAAAFACQAQAAAAIAAgcBQwBhAGwAaQBiAHIAaQAxAB4A3AAAADwA
kAEAAAACAAIHAUMAYQBsAGkAYgByAGkAMQAeANwAAAA+AJABAAAAAgACBwFDAGEAbABpAGIAcgBp
ADEAHgDcAAEAPwC8AgAAAAIAAgcBQwBhAGwAaQBiAHIAaQAxAB4A3AABADQAvAIAAAACAAIHAUMA
YQBsAGkAYgByAGkAMQAeANwAAAA0AJABAAAAAgACBwFDAGEAbABpAGIAcgBpADEAHgDcAAEACQC8
AgAAAAIAAgcBQwBhAGwAaQBiAHIAaQAxAB4A3AAAAAoAkAEAAAACAAIHAUMAYQBsAGkAYgByAGkA
MQAeANwAAgAXAJABAAAAAgACBwFDAGEAbABpAGIAcgBpADEAHgDcAAEACAC8AgAAAAIAAgcBQwBh
AGwAaQBiAHIAaQAxAB4A3AAAAAkAkAEAAAACAAIHAUMAYQBsAGkAYgByAGkAHgQcAAUAFwAAIiQi
IywjIzBfKTtcKCIkIiMsIyMwXCkeBCEABgAcAAAiJCIjLCMjMF8pO1tSZWRdXCgiJCIjLCMjMFwp
HgQiAAcAHQAAIiQiIywjIzAuMDBfKTtcKCIkIiMsIyMwLjAwXCkeBCcACAAiAAAiJCIjLCMjMC4w
MF8pO1tSZWRdXCgiJCIjLCMjMC4wMFwpHgQ3ACoAMgAAXygiJCIqICMsIyMwXyk7XygiJCIqIFwo
IywjIzBcKTtfKCIkIiogIi0iXyk7XyhAXykeBC4AKQApAABfKCogIywjIzBfKTtfKCogXCgjLCMj
MFwpO18oKiAiLSJfKTtfKEBfKR4EPwAsADoAAF8oIiQiKiAjLCMjMC4wMF8pO18oIiQiKiBcKCMs
IyMwLjAwXCk7XygiJCIqICItIj8/Xyk7XyhAXykeBDYAKwAxAABfKCogIywjIzAuMDBfKTtfKCog
XCgjLCMjMC4wMFwpO18oKiAiLSI/P18pO18oQF8p4AAUAAAAAAD1/yAAAAAAAAAAAAAAAMAg4AAU
AAEAAAD1/yAAAPQAAAAAAAAAAMAg4AAUAAEAAAD1/yAAAPQAAAAAAAAAAMAg4AAUAAIAAAD1/yAA
APQAAAAAAAAAAMAg4AAUAAIAAAD1/yAAAPQAAAAAAAAAAMAg4AAUAAAAAAD1/yAAAPQAAAAAAAAA
AMAg4AAUAAAAAAD1/yAAAPQAAAAAAAAAAMAg4AAUAAAAAAD1/yAAAPQAAAAAAAAAAMAg4AAUAAAA
AAD1/yAAAPQAAAAAAAAAAMAg4AAUAAAAAAD1/yAAAPQAAAAAAAAAAMAg4AAUAAAAAAD1/yAAAPQA
AAAAAAAAAMAg4AAUAAAAAAD1/yAAAPQAAAAAAAAAAMAg4AAUAAAAAAD1/yAAAPQAAAAAAAAAAMAg
4AAUAAAAAAD1/yAAAPQAAAAAAAAAAMAg4AAUAAAAAAD1/yAAAPQAAAAAAAAAAMAg4AAUAAAAAAAB
ACAAAAAAAAAAAAAAAsAg4AAUAAUAAAD1/yAAALQAAAAAAAAABJ8g4AAUAAUAAAD1/yAAALQAAAAA
AAAABK8g4AAUAAUAAAD1/yAAALQAAAAAAAAABIkg4AAUAAUAAAD1/yAAALQAAAAAAAAABJog4AAU
AAUAAAD1/yAAALQAAAAAAAAABJsg4AAUAAUAAAD1/yAAALQAAAAAAAAABKog4AAUAAUAAAD1/yAA
ALQAAAAAAAAABKwg4AAUAAUAAAD1/yAAALQAAAAAAAAABK8g4AAUAAUAAAD1/yAAALQAAAAAAAAA
BJYg4AAUAAUAAAD1/yAAALQAAAAAAAAABKsg4AAUAAUAAAD1/yAAALQAAAAAAAAABKwg4AAUAAUA
AAD1/yAAALQAAAAAAAAABKsg4AAUAAUAAAD1/yAAALQAAAAAAAAABLEg4AAUAAUAAAD1/yAAALQA
AAAAAAAABK8g4AAUAAUAAAD1/yAAALQAAAAAAAAABJYg4AAUAAUAAAD1/yAAALQAAAAAAAAABKsg
4AAUAAUAAAD1/yAAALQAAAAAAAAABKwg4AAUAAUAAAD1/yAAALQAAAAAAAAABLkg4AAUABUAAAD1
/yAAALQAAAAAAAAABL4g4AAUABUAAAD1/yAAALQAAAAAAAAABLUg4AAUABUAAAD1/yAAALQAAAAA
AAAABLcg4AAUABUAAAD1/yAAALQAAAAAAAAABLMg4AAUABUAAAD1/yAAALQAAAAAAAAABLEg4AAU
ABUAAAD1/yAAALQAAAAAAAAABLkg4AAUAAsAAAD1/yAAALQAAAAAAAAABK0g4AAUAA8AAAD1/yAA
AJQREZcLlwsABJYg4AAUABEAAAD1/yAAAJRmZr8fvx8ABLcg4AAUAAUAKwD1/yAAAPgAAAAAAAAA
AMAg4AAUAAUAKQD1/yAAAPgAAAAAAAAAAMAg4AAUAAUALAD1/yAAAPgAAAAAAAAAAMAg4AAUAAUA
KgD1/yAAAPgAAAAAAAAAAMAg4AAUABMAAAD1/yAAAPQAAAAAAAAAAMAg4AAUAAoAAAD1/yAAALQA
AAAAAAAABKog4AAUAAcAAAD1/yAAANQAUAAAAB8AAMAg4AAUAAgAAAD1/yAAANQAUAAAABYAAMAg
4AAUAAkAAAD1/yAAANQAIAAAgBgAAMAg4AAUAAkAAAD1/yAAAPQAAAAAAAAAAMAg4AAUAA0AAAD1
/yAAAJQREZcLlwsABK8g4AAUABAAAAD1/yAAANQAYAAAABoAAMAg4AAUAAwAAAD1/yAAALQAAAAA
AAAABKsg4AAUAAUAAAD1/yAAAJwRERYLFgsABJog4AAUAA4AAAD1/yAAAJQREb8fvx8ABJYg4AAU
AAUACQD1/yAAAPgAAAAAAAAAAMAg4AAUAAYAAAD1/yAAAPQAAAAAAAAAAMAg4AAUABQAAAD1/yAA
ANQAYQAAPh8AAMAg4AAUABIAAAD1/yAAAPQAAAAAAAAAAMAgfAgUAHwIAAAAAAAAAAAAAAAAPgDX
xGggfQgtAH0IAAAAAAAAAAAAAAAAAAAAAAIADQAUAAMAAAABAAAAMDBcKTtfKCoOAAUAAn0ILQB9
CAAAAAAAAAAAAAAAAAEAAAACAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAJ9CC0AfQgAAAAAAAAA
AAAAAAACAAAAAgANABQAAwAAAAEAAAAwMFwpO18oKg4ABQACfQgtAH0IAAAAAAAAAAAAAAAAAwAA
AAIADQAUAAMAAAABAAAAMDBcKTtfKCoOAAUAAn0ILQB9CAAAAAAAAAAAAAAAAAQAAAACAA0AFAAD
AAAAAQAAADAwXCk7XygqDgAFAAJ9CC0AfQgAAAAAAAAAAAAAAAAFAAAAAgANABQAAwAAAAEAAAAw
MFwpO18oKg4ABQACfQgtAH0IAAAAAAAAAAAAAAAABgAAAAIADQAUAAMAAAABAAAAMDBcKTtfKCoO
AAUAAn0ILQB9CAAAAAAAAAAAAAAAAAcAAAACAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAJ9CC0A
fQgAAAAAAAAAAAAAAAAIAAAAAgANABQAAwAAAAEAAAAwMFwpO18oKg4ABQACfQgtAH0IAAAAAAAA
AAAAAAAACQAAAAIADQAUAAMAAAABAAAAMDBcKTtfKCoOAAUAAn0ILQB9CAAAAAAAAAAAAAAAAAoA
AAACAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAJ9CC0AfQgAAAAAAAAAAAAAAAALAAAAAgANABQA
AwAAAAEAAAAwMFwpO18oKg4ABQACfQgtAH0IAAAAAAAAAAAAAAAADAAAAAIADQAUAAMAAAABAAAA
MDBcKTtfKCoOAAUAAn0ILQB9CAAAAAAAAAAAAAAAAA0AAAACAA0AFAADAAAAAQAAADAwXCk7Xygq
DgAFAAJ9CC0AfQgAAAAAAAAAAAAAAAAOAAAAAgANABQAAwAAAAEAAAAwMFwpO18oKg4ABQACfQgt
AH0IAAAAAAAAAAAAAAAADwAAAAIADQAUAAMAAAABAAAAMDBcKTtfKCoOAAUAAn0ILQB9CAAAAAAA
AAAAAAAAACsAAAACAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAJ9CC0AfQgAAAAAAAAAAAAAAAAs
AAAAAgANABQAAwAAAAEAAAAwMFwpO18oKg4ABQACfQgtAH0IAAAAAAAAAAAAAAAALQAAAAIADQAU
AAMAAAABAAAAMDBcKTtfKCoOAAUAAn0ILQB9CAAAAAAAAAAAAAAAAC4AAAACAA0AFAADAAAAAQAA
ADAwXCk7XygqDgAFAAJ9CC0AfQgAAAAAAAAAAAAAAAA6AAAAAgANABQAAwAAAAEAAAAwMFwpO18o
Kg4ABQACfQgtAH0IAAAAAAAAAAAAAAAAOwAAAAIADQAUAAMAAAADAAAAMDBcKTtfKCoOAAUAAX0I
QQB9CAAAAAAAAAAAAAAAADEAAAADAA0AFAADAAAAAwAAADAwXCk7XygqDgAFAAIIABQAAwAAAAQA
AAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAADIAAAADAA0AFAADAAAAAwAAADAwXCk7XygqDgAF
AAIIABQAAwD/PwQAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAADMAAAADAA0AFAADAAAAAwAA
ADAwXCk7XygqDgAFAAIIABQAAwAyMwQAAAA7XyhAXykgIH0ILQB9CAAAAAAAAAAAAAAAADQAAAAC
AA0AFAADAAAAAwAAADAwXCk7XygqDgAFAAJ9CEEAfQgAAAAAAAAAAAAAAAAwAAAAAwANABQAAgAA
AABhAP8wMFwpO18oKg4ABQACBAAUAAIAAADG787/O18oQF8pICB9CEEAfQgAAAAAAAAAAAAAAAAo
AAAAAwANABQAAgAAAJwABv8wMFwpO18oKg4ABQACBAAUAAIAAAD/x87/O18oQF8pICB9CEEAfQgA
AAAAAAAAAAAAAAA3AAAAAwANABQAAgAAAJxXAP8wMFwpO18oKg4ABQACBAAUAAIAAAD/65z/O18o
QF8pICB9CJEAfQgAAAAAAAAAAAAAAAA1AAAABwANABQAAgAAAD8/dv8wMFwpO18oKg4ABQACBAAU
AAIAAAD/zJn/O18oQF8pICAHABQAAgAAAH9/f/8gICAgICAgIAgAFAACAAAAf39//yAgICAgICAg
CQAUAAIAAAB/f3//AAAAAAAAAAAKABQAAgAAAH9/f/8AAAAAAAAAAH0IkQB9CAAAAAAAAAAAAAAA
ADkAAAAHAA0AFAACAAAAPz8//zAwXCk7XygqDgAFAAIEABQAAgAAAPLy8v87XyhAXykgIAcAFAAC
AAAAPz8//yAgICAgICAgCAAUAAIAAAA/Pz//ICAgICAgICAJABQAAgAAAD8/P/8AAAAAAAAAAAoA
FAACAAAAPz8//wAAAAAAAAAAfQiRAH0IAAAAAAAAAAAAAAAAKQAAAAcADQAUAAIAAAD6fQD/MDBc
KTtfKCoOAAUAAgQAFAACAAAA8vLy/ztfKEBfKSAgBwAUAAIAAAB/f3//ICAgICAgICAIABQAAgAA
AH9/f/8gICAgICAgIAkAFAACAAAAf39//wAAAAAAAAAACgAUAAIAAAB/f3//AAAAAAAAAAB9CEEA
fQgAAAAAAAAAAAAAAAA2AAAAAwANABQAAgAAAPp9AP8wMFwpO18oKg4ABQACCAAUAAIAAAD/gAH/
O18oQF8pICB9CJEAfQgAAAAAAAAAAAAAAAAqAAAABwANABQAAwAAAAAAAAAwMFwpO18oKg4ABQAC
BAAUAAIAAAClpaX/O18oQF8pICAHABQAAgAAAD8/P/8gICAgICAgIAgAFAACAAAAPz8//yAgICAg
ICAgCQAUAAIAAAA/Pz//AAAAAAAAAAAKABQAAgAAAD8/P/8AAAAAAAAAAH0ILQB9CAAAAAAAAAAA
AAAAAD0AAAACAA0AFAACAAAA/wAA/zAwXCk7XygqDgAFAAJ9CJEAfQgAAAAAAAAAAAAAAAA4AAAA
BwANABQAAwAAAAEAAAAwMFwpO18oKg4ABQACBAAUAAIAAAD//8z/O18oQF8pICAHABQAAgAAALKy
sv8gICAgICAgIAgAFAACAAAAsrKy/yAgICAgICAgCQAUAAIAAACysrL/AAAAAAAAAAAKABQAAgAA
ALKysv8AAAAAAAAAAH0ILQB9CAAAAAAAAAAAAAAAAC8AAAACAA0AFAACAAAAf39//zAwXCk7Xygq
DgAFAAJ9CFUAfQgAAAAAAAAAAAAAAAA8AAAABAANABQAAwAAAAEAAAAwMFwpO18oKg4ABQACBwAU
AAMAAAAEAAAAO18oQF8pICAIABQAAwAAAAQAAAAgICAgICAgIH0IQQB9CAAAAAAAAAAAAAAAACIA
AAADAA0AFAADAAAAAAAAADAwXCk7XygqDgAFAAIEABQAAwAAAAQAAAA7XyhAXykgIH0IQQB9CAAA
AAAAAAAAAAAAABAAAAADAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAIEABQAAwBlZgQAAAA7XyhA
XykgIH0IQQB9CAAAAAAAAAAAAAAAABYAAAADAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAIEABQA
AwDMTAQAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAABwAAAADAA0AFAADAAAAAQAAADAwXCk7
XygqDgAFAAIEABQAAwAyMwQAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAACMAAAADAA0AFAAD
AAAAAAAAADAwXCk7XygqDgAFAAIEABQAAwAAAAUAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAA
ABEAAAADAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAIEABQAAwBlZgUAAAA7XyhAXykgIH0IQQB9
CAAAAAAAAAAAAAAAABcAAAADAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAIEABQAAwDMTAUAAAA7
XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAAB0AAAADAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAIE
ABQAAwAyMwUAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAACQAAAADAA0AFAADAAAAAAAAADAw
XCk7XygqDgAFAAIEABQAAwAAAAYAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAABIAAAADAA0A
FAADAAAAAQAAADAwXCk7XygqDgAFAAIEABQAAwBlZgYAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAA
AAAAABgAAAADAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAIEABQAAwDMTAYAAAA7XyhAXykgIH0I
QQB9CAAAAAAAAAAAAAAAAB4AAAADAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAIEABQAAwAyMwYA
AAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAACUAAAADAA0AFAADAAAAAAAAADAwXCk7XygqDgAF
AAIEABQAAwAAAAcAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAABMAAAADAA0AFAADAAAAAQAA
ADAwXCk7XygqDgAFAAIEABQAAwBlZgcAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAABkAAAAD
AA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAIEABQAAwDMTAcAAAA7XyhAXykgIH0IQQB9CAAAAAAA
AAAAAAAAAB8AAAADAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAIEABQAAwAyMwcAAAA7XyhAXykg
IH0IQQB9CAAAAAAAAAAAAAAAACYAAAADAA0AFAADAAAAAAAAADAwXCk7XygqDgAFAAIEABQAAwAA
AAgAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAABQAAAADAA0AFAADAAAAAQAAADAwXCk7Xygq
DgAFAAIEABQAAwBlZggAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAABoAAAADAA0AFAADAAAA
AQAAADAwXCk7XygqDgAFAAIEABQAAwDMTAgAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAACAA
AAADAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAIEABQAAwAyMwgAAAA7XyhAXykgIH0IQQB9CAAA
AAAAAAAAAAAAACcAAAADAA0AFAADAAAAAAAAADAwXCk7XygqDgAFAAIEABQAAwAAAAkAAAA7XyhA
XykgIH0IQQB9CAAAAAAAAAAAAAAAABUAAAADAA0AFAADAAAAAQAAADAwXCk7XygqDgAFAAIEABQA
AwBlZgkAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAABsAAAADAA0AFAADAAAAAQAAADAwXCk7
XygqDgAFAAIEABQAAwDMTAkAAAA7XyhAXykgIH0IQQB9CAAAAAAAAAAAAAAAACEAAAADAA0AFAAD
AAAAAQAAADAwXCk7XygqDgAFAAIEABQAAwAyMwkAAAA7XyhAXykgIJMCEgAQAA0AADIwJSAtIEFj
Y2VudDGSCE0AkggAAAAAAAAAAAAAAQQe/w0AMgAwACUAIAAtACAAQQBjAGMAZQBuAHQAMQAAAAMA
AQAMAAcEZWbZ4fL/BQAMAAcBAAAAAAD/JQAFAAKTAhIAEQANAAAyMCUgLSBBY2NlbnQykghNAJII
AAAAAAAAAAAAAAEEIv8NADIAMAAlACAALQAgAEEAYwBjAGUAbgB0ADIAAAADAAEADAAHBWVm/OTW
/wUADAAHAQAAAAAA/yUABQACkwISABIADQAAMjAlIC0gQWNjZW50M5IITQCSCAAAAAAAAAAAAAAB
BCb/DQAyADAAJQAgAC0AIABBAGMAYwBlAG4AdAAzAAAAAwABAAwABwZlZu3t7f8FAAwABwEAAAAA
AP8lAAUAApMCEgATAA0AADIwJSAtIEFjY2VudDSSCE0AkggAAAAAAAAAAAAAAQQq/w0AMgAwACUA
IAAtACAAQQBjAGMAZQBuAHQANAAAAAMAAQAMAAcHZWb/8sz/BQAMAAcBAAAAAAD/JQAFAAKTAhIA
FAANAAAyMCUgLSBBY2NlbnQ1kghNAJIIAAAAAAAAAAAAAAEELv8NADIAMAAlACAALQAgAEEAYwBj
AGUAbgB0ADUAAAADAAEADAAHCGVm3ev3/wUADAAHAQAAAAAA/yUABQACkwISABUADQAAMjAlIC0g
QWNjZW50NpIITQCSCAAAAAAAAAAAAAABBDL/DQAyADAAJQAgAC0AIABBAGMAYwBlAG4AdAA2AAAA
AwABAAwABwllZuLv2v8FAAwABwEAAAAAAP8lAAUAApMCEgAWAA0AADQwJSAtIEFjY2VudDGSCE0A
kggAAAAAAAAAAAAAAQQf/w0ANAAwACUAIAAtACAAQQBjAGMAZQBuAHQAMQAAAAMAAQAMAAcEzEy0
xuf/BQAMAAcBAAAAAAD/JQAFAAKTAhIAFwANAAA0MCUgLSBBY2NlbnQykghNAJIIAAAAAAAAAAAA
AAEEI/8NADQAMAAlACAALQAgAEEAYwBjAGUAbgB0ADIAAAADAAEADAAHBcxM+Mut/wUADAAHAQAA
AAAA/yUABQACkwISABgADQAANDAlIC0gQWNjZW50M5IITQCSCAAAAAAAAAAAAAABBCf/DQA0ADAA
JQAgAC0AIABBAGMAYwBlAG4AdAAzAAAAAwABAAwABwbMTNvb2/8FAAwABwEAAAAAAP8lAAUAApMC
EgAZAA0AADQwJSAtIEFjY2VudDSSCE0AkggAAAAAAAAAAAAAAQQr/w0ANAAwACUAIAAtACAAQQBj
AGMAZQBuAHQANAAAAAMAAQAMAAcHzEz/5pn/BQAMAAcBAAAAAAD/JQAFAAKTAhIAGgANAAA0MCUg
LSBBY2NlbnQ1kghNAJIIAAAAAAAAAAAAAAEEL/8NADQAMAAlACAALQAgAEEAYwBjAGUAbgB0ADUA
AAADAAEADAAHCMxMvdfu/wUADAAHAQAAAAAA/yUABQACkwISABsADQAANDAlIC0gQWNjZW50NpII
TQCSCAAAAAAAAAAAAAABBDP/DQA0ADAAJQAgAC0AIABBAGMAYwBlAG4AdAA2AAAAAwABAAwABwnM
TMbgtP8FAAwABwEAAAAAAP8lAAUAApMCEgAcAA0AADYwJSAtIEFjY2VudDGSCE0AkggAAAAAAAAA
AAAAAQQg/w0ANgAwACUAIAAtACAAQQBjAGMAZQBuAHQAMQAAAAMAAQAMAAcEMjOOqdv/BQAMAAcB
AAAAAAD/JQAFAAKTAhIAHQANAAA2MCUgLSBBY2NlbnQykghNAJIIAAAAAAAAAAAAAAEEJP8NADYA
MAAlACAALQAgAEEAYwBjAGUAbgB0ADIAAAADAAEADAAHBTIz9LCE/wUADAAHAQAAAAAA/yUABQAC
kwISAB4ADQAANjAlIC0gQWNjZW50M5IITQCSCAAAAAAAAAAAAAABBCj/DQA2ADAAJQAgAC0AIABB
AGMAYwBlAG4AdAAzAAAAAwABAAwABwYyM8nJyf8FAAwABwEAAAAAAP8lAAUAApMCEgAfAA0AADYw
JSAtIEFjY2VudDSSCE0AkggAAAAAAAAAAAAAAQQs/w0ANgAwACUAIAAtACAAQQBjAGMAZQBuAHQA
NAAAAAMAAQAMAAcHMjP/2Wb/BQAMAAcBAAAAAAD/JQAFAAKTAhIAIAANAAA2MCUgLSBBY2NlbnQ1
kghNAJIIAAAAAAAAAAAAAAEEMP8NADYAMAAlACAALQAgAEEAYwBjAGUAbgB0ADUAAAADAAEADAAH
CDIzm8Lm/wUADAAHAQAAAAAA/yUABQACkwISACEADQAANjAlIC0gQWNjZW50NpIITQCSCAAAAAAA
AAAAAAABBDT/DQA2ADAAJQAgAC0AIABBAGMAYwBlAG4AdAA2AAAAAwABAAwABwkyM6nQjv8FAAwA
BwEAAAAAAP8lAAUAApMCDAAiAAcAAEFjY2VudDGSCEEAkggAAAAAAAAAAAAAAQQd/wcAQQBjAGMA
ZQBuAHQAMQAAAAMAAQAMAAcEAABEcsT/BQAMAAcAAAD/////JQAFAAKTAgwAIwAHAABBY2NlbnQy
kghBAJIIAAAAAAAAAAAAAAEEIf8HAEEAYwBjAGUAbgB0ADIAAAADAAEADAAHBQAA7X0x/wUADAAH
AAAA/////yUABQACkwIMACQABwAAQWNjZW50M5IIQQCSCAAAAAAAAAAAAAABBCX/BwBBAGMAYwBl
AG4AdAAzAAAAAwABAAwABwYAAKWlpf8FAAwABwAAAP////8lAAUAApMCDAAlAAcAAEFjY2VudDSS
CEEAkggAAAAAAAAAAAAAAQQp/wcAQQBjAGMAZQBuAHQANAAAAAMAAQAMAAcHAAD/wAD/BQAMAAcA
AAD/////JQAFAAKTAgwAJgAHAABBY2NlbnQ1kghBAJIIAAAAAAAAAAAAAAEELf8HAEEAYwBjAGUA
bgB0ADUAAAADAAEADAAHCAAAW5vV/wUADAAHAAAA/////yUABQACkwIMACcABwAAQWNjZW50NpII
QQCSCAAAAAAAAAAAAAABBDH/BwBBAGMAYwBlAG4AdAA2AAAAAwABAAwABwkAAHCtR/8FAAwABwAA
AP////8lAAUAApMCCAAoAAMAAEJhZJIIOQCSCAAAAAAAAAAAAAABARv/AwBCAGEAZAAAAAMAAQAM
AAX/AAD/x87/BQAMAAX/AACcAAb/JQAFAAKTAhAAKQALAABDYWxjdWxhdGlvbpIIgQCSCAAAAAAA
AAAAAAABAhb/CwBDAGEAbABjAHUAbABhAHQAaQBvAG4AAAAHAAEADAAF/wAA8vLy/wUADAAF/wAA
+n0A/yUABQACBgAOAAX/AAB/f3//AQAHAA4ABf8AAH9/f/8BAAgADgAF/wAAf39//wEACQAOAAX/
AAB/f3//AQCTAg8AKgAKAABDaGVjayBDZWxskgh/AJIIAAAAAAAAAAAAAAECF/8KAEMAaABlAGMA
awAgAEMAZQBsAGwAAAAHAAEADAAF/wAApaWl/wUADAAHAAAA/////yUABQACBgAOAAX/AAA/Pz//
BgAHAA4ABf8AAD8/P/8GAAgADgAF/wAAPz8//wYACQAOAAX/AAA/Pz//BgCTAgQAK4AD/5IIIACS
CAAAAAAAAAAAAAABBQP/BQBDAG8AbQBtAGEAAAAAAJMCBAAsgAb/kggoAJIIAAAAAAAAAAAAAAEF
Bv8JAEMAbwBtAG0AYQAgAFsAMABdAAAAAACTAgQALYAE/5IIJgCSCAAAAAAAAAAAAAABBQT/CABD
AHUAcgByAGUAbgBjAHkAAAAAAJMCBAAugAf/kgguAJIIAAAAAAAAAAAAAAEFB/8MAEMAdQByAHIA
ZQBuAGMAeQAgAFsAMABdAAAAAACTAhUALwAQAABFeHBsYW5hdG9yeSBUZXh0kghHAJIIAAAAAAAA
AAAAAAECNf8QAEUAeABwAGwAYQBuAGEAdABvAHIAeQAgAFQAZQB4AHQAAAACAAUADAAF/wAAf39/
/yUABQACkwIJADAABAAAR29vZJIIOwCSCAAAAAAAAAAAAAABARr/BABHAG8AbwBkAAAAAwABAAwA
Bf8AAMbvzv8FAAwABf8AAABhAP8lAAUAApMCDgAxAAkAAEhlYWRpbmcgMZIIRwCSCAAAAAAAAAAA
AAABAxD/CQBIAGUAYQBkAGkAbgBnACAAMQAAAAMABQAMAAcDAABEVGr/JQAFAAIHAA4ABwQAAERy
xP8FAJMCDgAyAAkAAEhlYWRpbmcgMpIIRwCSCAAAAAAAAAAAAAABAxH/CQBIAGUAYQBkAGkAbgBn
ACAAMgAAAAMABQAMAAcDAABEVGr/JQAFAAIHAA4ABwT/P6K44f8FAJMCDgAzAAkAAEhlYWRpbmcg
M5IIRwCSCAAAAAAAAAAAAAABAxL/CQBIAGUAYQBkAGkAbgBnACAAMwAAAAMABQAMAAcDAABEVGr/
JQAFAAIHAA4ABwQyM46p2/8CAJMCDgA0AAkAAEhlYWRpbmcgNJIIOQCSCAAAAAAAAAAAAAABAxP/
CQBIAGUAYQBkAGkAbgBnACAANAAAAAIABQAMAAcDAABEVGr/JQAFAAKTAgoANQAFAABJbnB1dJII
dQCSCAAAAAAAAAAAAAABAhT/BQBJAG4AcAB1AHQAAAAHAAEADAAF/wAA/8yZ/wUADAAF/wAAPz92
/yUABQACBgAOAAX/AAB/f3//AQAHAA4ABf8AAH9/f/8BAAgADgAF/wAAf39//wEACQAOAAX/AAB/
f3//AQCTAhAANgALAABMaW5rZWQgQ2VsbJIISwCSCAAAAAAAAAAAAAABAhj/CwBMAGkAbgBrAGUA
ZAAgAEMAZQBsAGwAAAADAAUADAAF/wAA+n0A/yUABQACBwAOAAX/AAD/gAH/BgCTAgwANwAHAABO
ZXV0cmFskghBAJIIAAAAAAAAAAAAAAEBHP8HAE4AZQB1AHQAcgBhAGwAAAADAAEADAAF/wAA/+uc
/wUADAAF/wAAnFcA/yUABQACkwIEAACAAP+SCDMAkggAAAAAAAAAAAAAAQEA/wYATgBvAHIAbQBh
AGwAAAACAAUADAAHAQAAAAAA/yUABQACkwIJADgABAAATm90ZZIIYgCSCAAAAAAAAAAAAAABAgr/
BABOAG8AdABlAAAABQABAAwABf8AAP//zP8GAA4ABf8AALKysv8BAAcADgAF/wAAsrKy/wEACAAO
AAX/AACysrL/AQAJAA4ABf8AALKysv8BAJMCCwA5AAYAAE91dHB1dJIIdwCSCAAAAAAAAAAAAAAB
AhX/BgBPAHUAdABwAHUAdAAAAAcAAQAMAAX/AADy8vL/BQAMAAX/AAA/Pz//JQAFAAIGAA4ABf8A
AD8/P/8BAAcADgAF/wAAPz8//wEACAAOAAX/AAA/Pz//AQAJAA4ABf8AAD8/P/8BAJMCBAA6gAX/
kggkAJIIAAAAAAAAAAAAAAEFBf8HAFAAZQByAGMAZQBuAHQAAAAAAJMCCgA7AAUAAFRpdGxlkggx
AJIIAAAAAAAAAAAAAAEDD/8FAFQAaQB0AGwAZQAAAAIABQAMAAcDAABEVGr/JQAFAAGTAgoAPAAF
AABUb3RhbJIITQCSCAAAAAAAAAAAAAABAxn/BQBUAG8AdABhAGwAAAAEAAUADAAHAQAAAAAA/yUA
BQACBgAOAAcEAABEcsT/AQAHAA4ABwQAAERyxP8GAJMCEQA9AAwAAFdhcm5pbmcgVGV4dJIIPwCS
CAAAAAAAAAAAAAABAgv/DABXAGEAcgBuAGkAbgBnACAAVABlAHgAdAAAAAIABQAMAAX/AAD/AAD/
JQAFAAKOCFgAjggAAAAAAAAAAAAAkAAAABEAEQBUAGEAYgBsAGUAUwB0AHkAbABlAE0AZQBkAGkA
dQBtADIAUABpAHYAbwB0AFMAdAB5AGwAZQBMAGkAZwBoAHQAMQA2AGABAgAAAIUADgDGOgAAAAAG
AFNoZWV0MZoIGACaCAAAAAAAAAAAAAABAAAAAAAAAAIAAACjCBAAowgAAAAAAAAAAAAAAAAAAIwA
BAABAAEAwQEIAMEBAAA16g4A/AA5AAEAAAABAAAALgAAT2ZmZW5zaXZlVkJBIHRlc3RpbmcgeGxz
IC0gV01JX1Byb2Nlc3NfQ3JlYXRlMv8ACgAIAMYtAAAMAAAAYwgWAGMIAAAAAAAAAAAAABYAAAAA
AAAAAgCWCFcMlggAAAAAAAAAAAAADYwCAFBLAwQUAAYACAAAACEA6d4Pv/8AAAAcAgAAEwAAAFtD
b250ZW50X1R5cGVzXS54bWyskctOwzAQRfdI/IPlLUqcskAIJemCx47HonzAyJkkFsnYsqdV+/dM
0lRCqCAWbCzZM/eeO+NyvR8HtcOYnKdKr/JCKyTrG0ddpd83T9mtVomBGhg8YaUPmPS6vrwoN4eA
SYmaUqV75nBnTLI9jpByH5Ck0vo4Ass1diaA/YAOzXVR3BjriZE448lD1+UDtrAdWD3u5fmYJOKQ
tLo/Nk6sSkMIg7PAktTsqPlGyRZCLsq5J/UupCuJoc1ZwlT5GbDoXmU10TWo3iDyC4wSw7AMiV/P
ZyAZLea/O56J7NvWWWy83Y6yjnw2XsxOwf8UYPU/6BPTzH9bfwIAAP//AwBQSwMEFAAGAAgAAAAh
AKXWp+fAAAAANgEAAAsAAABfcmVscy8ucmVsc4SPz2rDMAyH74W9g9F9UdLDGCV2L6WQQy+jfQDh
KH9oIhvbG+vbT8cGCrsIhKTv96k9/q6L+eGU5yAWmqoGw+JDP8to4XY9v3+CyYWkpyUIW3hwhqN7
27VfvFDRozzNMRulSLYwlRIPiNlPvFKuQmTRyRDSSkXbNGIkf6eRcV/XH5ieGeA2TNP1FlLXN2Cu
j6jJ/7PDMMyeT8F/ryzlRQRuN5RMaeRioagv41O9kKhlqtQe0LW4+db9AQAA//8DAFBLAwQUAAYA
CAAAACEAa3mWFoMAAACKAAAAHAAAAHRoZW1lL3RoZW1lL3RoZW1lTWFuYWdlci54bWwMzE0KwyAQ
QOF9oXeQ2TdjuyhFYrLLrrv2AEOcGkHHoNKf29fl44M3zt8U1ZtLDVksnAcNimXNLoi38Hwspxuo
2kgcxSxs4ccV5ul4GMm0jRPfSchzUX0j1ZCFrbXdINa1K9Uh7yzdXrkkaj2LR1fo0/cp4kXrKyYK
Ajj9AQAA//8DAFBLAwQUAAYACAAAACEATtJt0c8GAACwHwAAFgAAAHRoZW1lL3RoZW1lL3RoZW1l
MS54bWzsWUtvGzcQvhfof1jsvbFk6xEZkQPrFSexbCNSUuRISdQuLe5yQVJ2dCuSUy8FCqRFLwV6
66EoGqABGvTSH2MgQZv+iA650i4pUfEDRpEWtgBDS30z/DgzOzM7e+fus4h6J5gLwuK6X7xV8D0c
D9mIxEHdf9zvfHbb94RE8QhRFuO6P8PCv7vz6Sd30LYMcYQ9kI/FNqr7oZTJ9saGGMIyErdYgmP4
bcx4hCRc8mBjxNEp6I3oxmahUNmIEIl9L0YRqD0cj8kQe32l0t9ZKG9TuIylUAtDyntKNbYkNHY0
KSqEmIkm5d4JonUf9hmx0z5+Jn2PIiHhh7pf0H/+xs6dDbQ9F6Jyjawh19F/c7m5wGiyqffkwSDb
tFQqlyq7mX4NoHIV1662K+1Kpk8D0HAIJ0252Dqrm83SHGuA0q8O3a1qa6to4Q39Wyucd8vqY+E1
KNVfWsF3Ok2wooXXoBRfXsGXG7VGy9avQSm+soKvFnZbpaqlX4NCSuLJCrpQrmw1F6fNIGNG95zw
WrnUqW7OlecoiIYsutQWYxbLdbEWoWPGOwBQQIokiT05S/AYDSGKm4iSASfePglCCLwExUzAcmGz
0ClswX/1Kelv2qNoGyNDWvECJmJlSfHxxJCTRNb9B6DVNyBv37w5e/767PlvZy9enD3/Zb63VmXJ
7aE4MOXe//j1399/4f316w/vX36Tbr2MFyb+3c9fvvv9jw+phxPnpnj77at3r1+9/e6rP3966dC+
y9HAhPdJhIV3gE+9RyyCAzr44wG/nEQ/RMSSQCHodqhuy9ACHswQdeEa2DbhEw5ZxgW8Nz22uPZC
PpXEsfPDMLKAXcZog3GnAR6qvQwL96dx4N6cT03cI4ROXHs3UWw5uD1NIL0Sl8pmiC2aRxTFEgU4
xtJTv7EJxo7TPSXEsmuXDDkTbCy9p8RrIOI0SZ8MrEDKhfZIBH6ZuQiCqy3bdJ94DUZdp27hExsJ
twWiDvJ9TC0z3kNTiSKXyj6KqGnwfSRDF8nejA9NXFtI8HSAKfPaIyyES+aQw3kNpz+EDON2e5fO
IhvJJZm4dO4jxkxki02aIYoSF7ZH4tDE3hcTCFHkHTHpgneZfYeoa/ADite6+wnBlrvPTwSPIbma
lPIAUb9MucOX9zCz4rc3o2OEXVlml0dWdt3lxBkdjWlghfY+xhSdohHG3uP7DgYNllg2z0k/CCGr
7GFXYD1Adqyq6xgLaJNUX7OaIveJsEK2hwO2hk93tpR4ZiiOEF+n+QC8btq8DVXOmUoP6XBiAg8I
tH8QL06jHArQYQT3Wq1HIbJql7oW7nidcct/F7nH4L48tmhc4L4EGXxpGUjspswHbdNH1NogD5g+
ggbDlW5BxHJ/LqLqqhabOuXG9k2buwEaI6vfiUh8bvOz1PaU/522x3E3XE/D41ZspaxLtjrrUsre
UoOzDvcfbGtaaBofYagkqznrpqu56Wr8/31Xs+5evull1nUcN72MDz3GTS8zn6xcTy+Tty/Q2ahp
Rzrl0TOfaO3IZ0wo7ckZxftCT30EPNGMOrCo5PS4E2cjwCSEr6rMwQYWLuBIy3icyc+JDHshSmA0
VPSVkkDMVQfCS5iAiZFedupWeDqNumyUTjqLRTXVTCurQDJfL5SzdZhSyRRdqebTu0y9ZhvoKeuC
gJK9DAljM5vEloNEdbGojKRnumA0Bwl9smthUXOwuK3UL1y1wgKoZV6BR24PHtTrfrkEIiAEwzho
z0fKT6mrF97VzrxOT68zphUB0GIvIiD3dE1xXXs8dbo01C7gaYuEEW42CW0Z3eCJEB6E59GpVi9C
47K+ruUutegpU+j9ILRyGtXbH2JxVV+D3HJuoLGZKWjsndb9ylYZQmaIkro/hokxfI0SiB2hnroQ
DeC1y1Dy9Ia/SmZJuJAtJMLU4DrppNkgIhJzj5Ko7qvjZ26gsc4hmltxExLCR0uuBmnlYyMHTred
jMdjPJSm240VZen0EjJ8miucv2rxq4OVJJuCu3vh6NQb0Cl/hCDEytWiMuCICHhxUEytOSLwJixL
ZHn8LRWmedo1X0XpGErXEU1CNK8oZjJP4TqVZ3T0VWYD42p+ZjCoYZJ5IRwEqsCaRrWqaVY1Ug5r
q+75QspyRtLMa6aVVVTVdGcxa4dFGViy5dWKvMFqYWLIaWaFT1P3csqtLXLdUp+QVQkweGY/R9W9
QEEwqOWbWdQU49U0rHL2fNWuHYsDnkPtIkXCyPqVhdolu2U1wrkdLF6p8oPcctTC0njRV2pL61fm
5lttNjiG5NGCLndKpdCuhNkuR9AQ9XRPkqUNLbrzDwAAAP//AwBQSwMEFAAGAAgAAAAhAA3RkJ+2
AAAAGwEAACcAAAB0aGVtZS90aGVtZS9fcmVscy90aGVtZU1hbmFnZXIueG1sLnJlbHOEj00KwjAU
hPeCdwhvb9O6EJEm3YjQrdQDhOQ1DTY/JFHs7Q2uLAguh2G+mWm7l53JE2My3jFoqhoIOumVcZrB
bbjsjkBSFk6J2TtksGCCjm837RVnkUsoTSYkUiguMZhyDidKk5zQilT5gK44o49W5CKjpkHIu9BI
93V9oPGbAXzFJL1iEHvVABmWUJr/s/04GolnLx8WXf5RQXPZhQUoosbM4CObqkwEylu6usTfAAAA
//8DAFBLAQItABQABgAIAAAAIQDp3g+//wAAABwCAAATAAAAAAAAAAAAAAAAAAAAAABbQ29udGVu
dF9UeXBlc10ueG1sUEsBAi0AFAAGAAgAAAAhAKXWp+fAAAAANgEAAAsAAAAAAAAAAAAAAAAAMAEA
AF9yZWxzLy5yZWxzUEsBAi0AFAAGAAgAAAAhAGt5lhaDAAAAigAAABwAAAAAAAAAAAAAAAAAGQIA
AHRoZW1lL3RoZW1lL3RoZW1lTWFuYWdlci54bWxQSwECLQAUAAYACAAAACEATtJt0c8GAACwHwAA
FgAAAAAAAAAAAAAAAADWAgAAdGhlbWUvdGhlbWUvdGhlbWUxLnhtbFBLAQItABQABgAIAAAAIQAN
0ZCftgAAABsBAAAnAAAAAAAAAAAAAAAAANkJAAB0aGVtZS90aGVtZS9fcmVscy90aGVtZU1hbmFn
ZXIueG1sLnJlbHNQSwUGAAAAAAUABQBdAQAA1AoAAAAAmwgQAJsIAAAAAAAAAAAAAAEAAACMCBAA
jAgAAAAAAAAAAAAAAAAAAJcIHACXCAAAAAAAAAAAAADnAGauYnpsOd6VmUL6ndgeCgAAAAkIEAAA
BhAAWk/NB8EAAgAGCAAACwIUAAAAAAAAAAAAAQAAANw7AAAWPAAADQACAAEADAACAGQADwACAAEA
EQACAAAAEAAIAPyp8dJNYlA/XwACAAEAKgACAAAAKwACAAAAggACAAEAgAAIAAAAAAAAAAAAJQIE
AAAALAGBAAIAwQQUAAAAFQAAAIMAAgAAAIQAAgAAACYACABmZmZmZmbmPycACABmZmZmZmbmPygA
CAAAAAAAAADoPykACAAAAAAAAADoP6EAIgAAACwBAQABAAEABADnAGauMzMzMzMz0z8zMzMzMzPT
Pw+/nAgmAJwIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA8MwAAAAAAAAAAVQACAAgAAAIOAAAA
AAABAAAAAAABAAAACAIQAAAAAAABACwBAAAAAAABDwD9AAoAAAAAAA8AAAAAANcABgAiAAAAAAA+
AhIAtgYAAAAAQAAAAAAAAAAAAAAAiwgQAIsIAAAAAAAAAAAAAAAAAgAdAA8AAwAAAAAAAAEAAAAA
AAAAugEJAAYAAFNoZWV0MWcIFwBnCAAAAAAAAAAAAAACAAH/////A0QAAAoAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAABUAGgAaQBzAFcAbwByAGsAYgBvAG8AawAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGgACAf////8HAAAA/////wAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADnAwAAAAAAAFMAaABlAGUAdAAxAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAIBCAAAAP//////
////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAN8DAAAAAAAATQBvAGQA
dQBsAGUAMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
ABAAAgEFAAAABAAAAP////8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAvAAAA
iBQAAAAAAABfAFYAQgBBAF8AUABSAE8ASgBFAEMAVAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAGgACAP///////////////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAACAAAAADCwAAAAAAAAEAAAACAAAAAwAAAAQAAAAFAAAABgAAAAcAAAAIAAAACQAA
AAoAAAALAAAADAAAAA0AAAAOAAAADwAAAP7///8RAAAAEgAAABMAAAAUAAAAFQAAABYAAAAXAAAA
GAAAABkAAAAaAAAAGwAAABwAAAAdAAAAHgAAAB8AAAD+////IQAAACIAAAAjAAAAJAAAACUAAAAm
AAAAJwAAACgAAAApAAAAKgAAACsAAAAsAAAALQAAAC4AAAAvAAAAMAAAADEAAAAyAAAAMwAAADQA
AAA1AAAANgAAADcAAAA4AAAAOQAAADoAAAA7AAAAPAAAAD0AAAA+AAAAPwAAAEAAAABBAAAAQgAA
AEMAAABEAAAARQAAAEYAAABHAAAASAAAAEkAAABKAAAASwAAAEwAAAD+////TgAAAE8AAABQAAAA
UQAAAFIAAABTAAAAVAAAAFUAAAD+////VwAAAP7///9ZAAAAWgAAAFsAAABcAAAAXQAAAF4AAABf
AAAA/v///2EAAABiAAAAYwAAAP7///9lAAAAZgAAAGcAAAD+////aQAAAP7/////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////ARYDAADwAAAA0gIAANQAAAAAAgAA/////9kCAAAtAwAAAAAA
AAEAAACI4yDVAAD//yMBAACIAAAAtgD//wEBAAAAAP////8AAAAA////////AAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAMAAAAFAAAABwAA
AP//////////AQEIAAAA/////3gAAAAIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/
/wAAAABNRQAA////////AAAAAP//AAAAAP//AQEAAAAA3wD//wAAAAAYAP//////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
KAAAAAIAU0z/////AAABAFMQ/////wAAAQBTlP////8AAAAAAjz/////AAD//wEBAAAAAAEATgAw
AHsAMAAwADAAMgAwADgAMQA5AC0AMAAwADAAMAAtADAAMAAwADAALQBDADAAMAAwAC0AMAAwADAA
MAAwADAAMAAwADAAMAA0ADYAfQAAAAAAAAD/////AQFAAAAAAoD+//////8gAAAA/////zAAAAAC
Af//AAAAAAAAAAD//////////wAAAABXAgAAHQAAACUAAAD/////QAAAAAAA//8AAAEAAAAAAAAA
AAD///////////////8AAAAA//////////////////////////8AAAAA////////////////////
//////8AAAAAAQAAAP//AAD///////8AAAAA////////////////////////////////AAD/////
//8AAAAAAADfAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAA/soBAAAA/////wEBCAAAAP////94AAAA/////wAAAbCwAEF0dHJpYnV0AGUg
VkJfTmFtAGUgPSAiVGhpAHNXb3JrYm9vEGsiDQoKjEJhcwECjDB7MDAwMjBQODE5LQAQMAMIQwcA
FAISASQwMDQ2fYENfEdsb2JhbAHQEFNwYWMBkkZhbARzZQxkQ3JlYXQIYWJsFR9QcmVkkGVjbGEA
BklkALEIVHJ1DUJFeHBvBHNlFBxUZW1wbABhdGVEZXJpdgMCEpJCdXN0b21pBnoERAMyAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAEWAwAA8AAAANICAADUAAAAAAIAAP/////ZAgAALQMAAAAAAAAB
AAAAiOMbkAAA//8jAQAAiAAAALYA//8BAQAAAAD/////AAAAAP///////wAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAADAAAABQAAAAcAAAD/
/////////wEBCAAAAP////94AAAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//8A
AAAATUUAAP///////wAAAAD//wAAAAD//wEBAAAAAN8A//8AAAAAGAD/////////////////////
////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////ygA
AAACAFNM/////wAAAQBTEP////8AAAEAU5T/////AAAAAAI8/////wAA//8BAQAAAAABAE4AMAB7
ADAAMAAwADIAMAA4ADIAMAAtADAAMAAwADAALQAwADAAMAAwAC0AQwAwADAAMAAtADAAMAAwADAA
MAAwADAAMAAwADAANAA2AH0AAAAAAAAA/////wEBQAAAAAKA/v//////IAAAAP////8wAAAAAgH/
/wAAAAAAAAAA//////////8AAAAAVwIAAB0AAAAlAAAA/////0AAAAAAAP//AAABAAAAAAAAAAAA
////////////////AAAAAP//////////////////////////AAAAAP//////////////////////
////AAAAAAAAAAD//wAA////////AAAAAP///////////////////////////////wAA////////
AAAAAAAA3wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAP7KAQAAAP////8BAQgAAAD/////eAAAAP////8AAAGosABBdHRyaWJ1dABlIFZC
X05hbQBlID0gIlNoZUBldDEiDQoK6EIEYXMCdDB7MDAwwDIwODIwLQAgBAgOQwAUAhwBJDAwNDYC
fQ18R2xvYmFsIQHEU3BhYwGSRmEIbHNlDGRDcmVhEHRhYmwVH1ByZSBkZWNsYQAGSWQRAKtUcnUN
QkV4cAhvc2UUHFRlbXAAbGF0ZURlcmkGdgIkkkJ1c3RvbQxpegREAzIAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAADMYbUAAAMA/wkEAAAJBAAA5AQDAAAAAAAAAAAAAQAEAAIAIAEqAFwA
RwB7ADAAMAAwADIAMAA0AEUARgAtADAAMAAwADAALQAwADAAMAAwAC0AQwAwADAAMAAtADAAMAAw
ADAAMAAwADAAMAAwADAANAA2AH0AIwA0AC4AMgAjADkAIwBDADoAXABQAHIAbwBnAHIAYQBtACAA
RgBpAGwAZQBzAFwAQwBvAG0AbQBvAG4AIABGAGkAbABlAHMAXABNAGkAYwByAG8AcwBvAGYAdAAg
AFMAaABhAHIAZQBkAFwAVgBCAEEAXABWAEIAQQA3AC4AMQBcAFYAQgBFADcALgBEAEwATAAjAFYA
aQBzAHUAYQBsACAAQgBhAHMAaQBjACAARgBvAHIAIABBAHAAcABsAGkAYwBhAHQAaQBvAG4AcwAA
AAAAAAAAAAAAAAAaASoAXABHAHsAMAAwADAAMgAwADgAMQAzAC0AMAAwADAAMAAtADAAMAAwADAA
LQBDADAAMAAwAC0AMAAwADAAMAAwADAAMAAwADAAMAA0ADYAfQAjADEALgA5ACMAMAAjAEMAOgBc
AFAAcgBvAGcAcgBhAG0AIABGAGkAbABlAHMAXABNAGkAYwByAG8AcwBvAGYAdAAgAE8AZgBmAGkA
YwBlAFwAcgBvAG8AdABcAE8AZgBmAGkAYwBlADEANgBcAEUAWABDAEUATAAuAEUAWABFACMATQBp
AGMAcgBvAHMAbwBmAHQAIABFAHgAYwBlAGwAIAAxADYALgAwACAATwBiAGoAZQBjAHQAIABMAGkA
YgByAGEAcgB5AAAAAAAAAAAAAAAAALwAKgBcAEcAewAwADAAMAAyADAANAAzADAALQAwADAAMAAw
AC0AMAAwADAAMAAtAEMAMAAwADAALQAwADAAMAAwADAAMAAwADAAMAAwADQANgB9ACMAMgAuADAA
IwAwACMAQwA6AFwAVwBpAG4AZABvAHcAcwBcAFMAeQBzAHQAZQBtADMAMgBcAHMAdABkAG8AbABl
ADIALgB0AGwAYgAjAE8ATABFACAAQQB1AHQAbwBtAGEAdABpAG8AbgAAAAAAAAAAAAAAAAAoASoA
XABHAHsAMgBEAEYAOABEADAANABDAC0ANQBCAEYAQQAtADEAMAAxAEIALQBCAEQARQA1AC0AMAAw
AEEAQQAwADAANAA0AEQARQA1ADIAfQAjADIALgA4ACMAMAAjAEMAOgBcAFAAcgBvAGcAcgBhAG0A
IABGAGkAbABlAHMAXABDAG8AbQBtAG8AbgAgAEYAaQBsAGUAcwBcAE0AaQBjAHIAbwBzAG8AZgB0
ACAAUwBoAGEAcgBlAGQAXABPAEYARgBJAEMARQAxADYAXABNAFMATwAuAEQATABMACMATQBpAGMA
cgBvAHMAbwBmAHQAIABPAGYAZgBpAGMAZQAgADEANgAuADAAIABPAGIAagBlAGMAdAAgAEwAaQBi
AHIAYQByAHkAAAAAAAAAAAAAAAAAAwACAAIAAQAGABICAAAUAgEAFgIBABgCAAAaAgEAHAIBACIC
////////AAAAAP//AAB9D9VkBQD/////////////////////////////////////////////////
////AAD//wIAAQD/////////////////////AQAAAAAAAAAAAAAAAAAAAAAAAACI4wMAGABUAGgA
aQBzAFcAbwByAGsAYgBvAG8AawAUADAAMQA2ADQAZAA1ADAAZgA3AGQA//8nAhgAVABoAGkAcwBX
AG8AcgBrAGIAbwBvAGsA//8g1QAAAAAAAAACAAAAMwMAAP//DABTAGgAZQBlAHQAMQAUADAAMgA2
ADQAZAA1ADAAZgA3AGQA//8rAgwAUwBoAGUAZQB0ADEA//8bkAAAAAAAABgCAAAAMwMAAP//DgBN
AG8AZAB1AGwAZQAxABQAMAAzADYANABkADUAMABmADcAZAD//ywCDgBNAG8AZAB1AGwAZQAxAP//
0PwAAAAAAAAwAgAAADMOAAD///////8BAVACAAD/////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
/////xgCAAD/////////////////////////////////////////////////////////////////
//////////////////////////////////////////////8wAgAA////////////////////////
/////////////////////////////////////////////////////////////wACAAD/////////
////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////wVlvh8DFuZNnRWMJ7NCFJn/////AQAAAGhKmmHN
t6dEpI/Mye1K3Cj/////AQAAADFWlKLNEk9OjiuwRfOzPZn/////AQAAAP////8wAAAAgAAAAAAA
KAEiAAYBjC4AAAUERXhjZWyAKxAAAwRWQkH34hAABQRXaW4xNsF+EAAFBFdpbjMyB38QAAUEV2lu
NjR4fxAAAwRNYWOzshAABARWQkE2rSMQAAQEVkJBN64jEAAIBFByb2plY3QxChcQAAYEc3Rkb2xl
k2AQAAoEVkJBUHJvamVjdL6/EAAGBE9mZmljZRV1EAAMBFRoaXNXb3JrYm9va3zjEAAJgAAA/wMB
AF9FdmFsdWF0ZRjZEAAGBFNoZWV0MegaEAAHBE1vZHVsZTFiERAACQRBdXRvX09wZW5WIBAACQRT
V19OT1JNQUynaRAACwBzdHJDb21wdXRlcuL6EAAKAHN0ckNvbW1hbmQTBhAADQBvYmpXTUlTZXJ2
aWNl33MQAAkAR2V0T2JqZWN0esMQAAoAb2JqU3RhcnR1cKhcEAAJAG9iakNvbmZpZ0W6EAAOAFNw
YXduSW5zdGFuY2VfYYMQAAqAAAD/AwEAU2hvd1dpbmRvd0prEAAKAG9ialByb2Nlc3OKfRAACQBp
bnRSZXR1cm6TeBAABoAAAP8DAQBDcmVhdGW+TRAADABpbnRQcm9jZXNzSURIphAABwBXc2NyaXB0
GLEQAAQARWNob6gJEAAJAHZiTmV3TGluZXVhEAAIBFdvcmtib29raxgQAAL//wEBYAAAACACAgD/
/yIC/////yQCAwD//ycCAAADAP///////ysCAQADAC0CAgAFAA4CAQD//xACAAD/////////////
/////////////////////////////////////////////wYAEAAAAAEANgAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFNVQ0ggREFNQUdFAAAA
AAAAAJYEAAAAAAAA4wAAAGkAIFVzaW5nIHRoaXMgdGVjaG5pcXVlIHRoZSBuZXcBL7KAAQAEAAAA
AwAwqkoCkAIASAICSAkAwBIUBkgDAAFk5AQEBAAKAIRWQkFQckBvamVjdAUAGgBUAEACCgYCCj0C
CgcrAnIBFAgGEgkCEn0PoNVkBQAMAko8AgoEFgABOXN0ZG9sBGU+AhlzAHQAZAAAbwBsAGUADRQA
aAAlXgADKlxHAHswMDAyMDQz7DAtAAgEBEMACgIOARIAMDA0Nn0jMi4AMCMwI0M6XFcAaW5kb3dz
XFMAeXN0ZW0zMlxkAGkAcgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAACAACAP///////////////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAE0AAAAzAgAAAAAAAFAAUgBPAEoARQBDAFQAdwBtAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAIA////////////////AAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAVgAAAFYAAAAAAAAAUABSAE8ASgBFAEMAVAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAgEDAAAACQAA
AP////8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABYAAAA0wEAAAAAAAAFAFMA
dQBtAG0AYQByAHkASQBuAGYAbwByAG0AYQB0AGkAbwBuAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAKAACAf////8MAAAA/////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGAA
AADgAAAAAAAAAAEDZTIudGxiI08ATEUgQXV0b23gYXRpb24AMAABg0UgT2ZmaWOERU8AomaAAGkA
Y4JFnoARBpSAAYFFMkRGOEQAMDRDLTVCRkEALTEwMUItQkSkRTWARUFBgEM0gAUGMohFgJhncmFt
IABGaWxlc1xDbxBtbW9uBAZNaWMAcm9zb2Z0IFMAaGFyZWRcT0YARklDRTE2XE2AU08uRExMI4cQ
AYNNIDE2LjAgTwJigcEgTGlicmEscnkASwABD4LUAwAiE4IDiOMZgqhUaABpc1dvcmtib6Bva0cA
GIATVICrIGkAcwBXwFlyAKhrAGLAAW/AARrOC4oy2gscwBIAAEhCAWoxQngzgJMeQgIBBSxRwiEg
1SJCCCtCARkBQnxTaGVldDFHFcIbU0AjZUBYdAAxNAAaSAcyTgfjGxuQBcsbB8AdTW9kdWwaZQAc
DgEDgDtkAHXngpiBHAgIMgAPCFAdAAmRTTnQ/CGAFgAAQzkCEMICAAAAAAAAAAAAAAAAAFRoaXNX
b3JrYm9vawBUAGgAaQBzAFcAbwByAGsAYgBvAG8AawAAAFNoZWV0MQBTAGgAZQBlAHQAMQAAAE1v
ZHVsZTEATQBvAGQAdQBsAGUAMQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAARYDAADwAAAAkgIAANQAAACIAQAA/////5kCAAAtDgAAAAAAAAEAAACI49D8AAD/
/wMAAAAAAAAAtgD//wEBAAAAAP////8AAAAA////////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAAMAAAAFAAAABwAAAP//////////AQEI
AAAA/////3gAAAACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD//wAAAABNRQAA////
////AAAAAP//AAAAAP//AQEAAAAA3wD//wAAAAD/////////////////////////////////////
////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////AAAAAP//AQEAAAAA
AAAAAAAAAAD/////AQF4AAAACxIuAv//////////AAAAAP//////////AAAAAAAAAAAAAAAAAAAA
AP////8AAAAAAAAAAAAAAAD///////////////8YAAAAAAAAAAAAAACEAAACAAAAAECUMAL/////
//////////9MAP//AAAAAP////8IAAAAAQD//wAAAAAAAAAAAAAAAAAAAAD/////////////////
/////////wAAAAD//////////////////////////////////////////wAAAAAAAAAA//8AAP//
/////wAAAAD///////////////////////////////8AAP///////wAAAAAAAN8aAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD+ygEAMgAA
gAkAGgAAAAAAAAAAgAkAAAAAAP////8AgAkAKAAAACAAAAAAgAkAGgAAAEgAAAAAgAkAAAAAAP//
//8AgAkASAAAAGgAAAAAgAkAUgAAALAAAAAAgAkAAAAAAP////8AgAkAVAAAAAgBAAAAgAkAOgAA
AGABAAAAgAkAAAAAAP////8AgAkAUgAAAKABAAAAgAkAUgAAAPgBAAAAgAkAQAAAAFACAAAAgAkA
AAAAAP////8AgAkAUgAAAJACAAAAgAkAUAAAAOgCAAAAgAkAVAAAADgDAAAAgAkAUgAAAJADAAAA
gAkAUAAAAOgDAAAAgAkAUAAAADgEAAAAgAkAUAAAAIgEAAAAgAkAVAAAANgEAAAAgAkAVAAAADAF
AAAAgAkASgAAAIgFAAAAgAkAAAAAAP////8igQgABgAAANgFAAAAgAkAcAAAAOAFAAAAgAgADAAA
AFAGAAAAgQgACgAAAGAGAAAAgQgAFAAAAHAGAAAAgRgAaAAAAIgGAAAAgAkAAAAAAP////8AgAkA
NgAAAPAGAAAAgQgAKAAAACgHAAAAgQgADgAAAFAHAAAAgQgADAAAAGAHAAAAgAkAAAAAAP////8A
gAkAHgAAAHAHAAAAgQgAIgAAAJAHAAAAgRAAJAAAALgHAAAAgQgADAAAAOAHAAAAgRgEeAAAAPAH
AAAAgQgAAgAAAGgIAAAAgRgEaAAAAHAIAAAAgQgAAgAAANgIAAAAgAkAAAAAAP////8EgQgAAgAA
AOAIAAAAgAkAAAAAAP////8AgAkAAAAAAP//////////AQHwCAAA4wAAABQAQlNEIDItQ2xhdXNl
IExpY2Vuc2VyAFwAUwDjAAAAIgBDb3B5cmlnaHQgKGMpIDIwMjEsIFMzY3VyM1RoMXNTaDF04wAA
ABQAQWxsIHJpZ2h0cyByZXNlcnZlZC4wADAANADjAAAAQgBSZWRpc3RyaWJ1dGlvbiBhbmQgdXNl
IGluIHNvdXJjZSBhbmQgYmluYXJ5IGZvcm1zLCB3aXRoIG9yIHdpdGhvdXTjAAAASwBtb2RpZmlj
YXRpb24sIGFyZSBwZXJtaXR0ZWQgcHJvdmlkZWQgdGhhdCB0aGUgZm9sbG93aW5nIGNvbmRpdGlv
bnMgYXJlIG1ldDoAAAD4AAAA4wAAAE4AMS4gUmVkaXN0cmlidXRpb25zIG9mIHNvdXJjZSBjb2Rl
IG11c3QgcmV0YWluIHRoZSBhYm92ZSBjb3B5cmlnaHQgbm90aWNlLCB0aGlzAAAAAOMAAAAzACAg
IGxpc3Qgb2YgY29uZGl0aW9ucyBhbmQgdGhlIGZvbGxvd2luZyBkaXNjbGFpbWVyLgAAAAAAAADj
AAAATAAyLiBSZWRpc3RyaWJ1dGlvbnMgaW4gYmluYXJ5IGZvcm0gbXVzdCByZXByb2R1Y2UgdGhl
IGFib3ZlIGNvcHlyaWdodCBub3RpY2UsAAAAAAAA4wAAAEwAICAgdGhpcyBsaXN0IG9mIGNvbmRp
dGlvbnMgYW5kIHRoZSBmb2xsb3dpbmcgZGlzY2xhaW1lciBpbiB0aGUgZG9jdW1lbnRhdGlvbgAA
AAAAAOMAAAA5ACAgIGFuZC9vciBvdGhlciBtYXRlcmlhbHMgcHJvdmlkZWQgd2l0aCB0aGUgZGlz
dHJpYnV0aW9uLgDjAAAASwBUSElTIFNPRlRXQVJFIElTIFBST1ZJREVEIEJZIFRIRSBDT1BZUklH
SFQgSE9MREVSUyBBTkQgQ09OVFJJQlVUT1JTICJBUyBJUyIAAAAAAAAA4wAAAEkAQU5EIEFOWSBF
WFBSRVNTIE9SIElNUExJRUQgV0FSUkFOVElFUywgSU5DTFVESU5HLCBCVVQgTk9UIExJTUlURUQg
VE8sIFRIRQDjAAAATgBJTVBMSUVEIFdBUlJBTlRJRVMgT0YgTUVSQ0hBTlRBQklMSVRZIEFORCBG
SVRORVNTIEZPUiBBIFBBUlRJQ1VMQVIgUFVSUE9TRSBBUkUAAAAA4wAAAEwARElTQ0xBSU1FRC4g
SU4gTk8gRVZFTlQgU0hBTEwgVEhFIENPUFlSSUdIVCBIT0xERVIgT1IgQ09OVFJJQlVUT1JTIEJF
IExJQUJMRQAAAAAAAOMAAABKAEZPUiBBTlkgRElSRUNULCBJTkRJUkVDVCwgSU5DSURFTlRBTCwg
U1BFQ0lBTCwgRVhFTVBMQVJZLCBPUiBDT05TRVFVRU5USUFM4wAAAEoAREFNQUdFUyAoSU5DTFVE
SU5HLCBCVVQgTk9UIExJTUlURUQgVE8sIFBST0NVUkVNRU5UIE9GIFNVQlNUSVRVVEUgR09PRFMg
T1LjAAAASgBTRVJWSUNFUzsgTE9TUyBPRiBVU0UsIERBVEEsIE9SIFBST0ZJVFM7IE9SIEJVU0lO
RVNTIElOVEVSUlVQVElPTikgSE9XRVZFUuMAAABNAENBVVNFRCBBTkQgT04gQU5ZIFRIRU9SWSBP
RiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQ09OVFJBQ1QsIFNUUklDVCBMSUFCSUxJVFksAAAAAADj
AAAATQBPUiBUT1JUIChJTkNMVURJTkcgTkVHTElHRU5DRSBPUiBPVEhFUldJU0UpIEFSSVNJTkcg
SU4gQU5ZIFdBWSBPVVQgT0YgVEhFIFVTRQAAAAAA4wAAAEMAT0YgVEhJUyBTT0ZUV0FSRSwgRVZF
TiBJRiBBRFZJU0VEIE9GIFRIRSBQT1NTSUJJTElUWSBPRiBTVUNIIERBTUFHRQAAAAAAAACWBAAA
AAAAAOMAAABpACBVc2luZyB0aGlzIHRlY2huaXF1ZSB0aGUgbmV3IHByb2Nlc3Mgd2lsbCBiZSBz
cGF3bmVkIHVuZGVyIJN3bWlwcnZzZS5leGWUIGluc3RlYWQgb2YgdGhlIE9mZmljZSBwcm9jZXNz
LgBdBKwAAQD1CFgAAAAAAAAAuQABAC4AJwAyAgAAAAAAALkACwBOb3RlcGFkLmV4ZQAnADQCAAAA
AKYACAAGAAQACAAEAPAAuQAJAHdpbm1nbXRzOgC5ACMAe2ltcGVyc29uYXRpb25MZXZlbD1pbXBl
cnNvbmF0ZX0hXFwAEQAgADICEQC5AAsAXHJvb3RcY2ltdjIAEQAkADgCAQAuADYC4wAAAC8AIENv
bmZpZ3VyZSB0aGUgTm90ZXBhZCBwcm9jZXNzIHRvIHNob3cgYSB3aW5kb3cAAADwALkAFABXaW4z
Ml9Qcm9jZXNzU3RhcnR1cCAANgIlALYAAQAuADoC8AAgADoCIQA+Ai4APAIAACAAMAIgADwCKABA
AgAAAADjAAAAFwAgQ3JlYXRlIE5vdGVwYWQgcHJvY2VzcwAAAPAAuQANAFdpbjMyX1Byb2Nlc3MA
IAA2AiUAtgABAC4AQgIAAAAAAACmAAQABQAEACAANAK6CCAAPAIgAEgCIABCAiUARgIEACcARAIA
AAAAIABEAqwAAAAGAJwAAAAAAKYACAAFAAgACwAIALkAHQBQcm9jZXNzIGNvdWxkIG5vdCBiZSBj
cmVhdGVkLgAgAE4CEQC5AA4AQ29tbWFuZCBsaW5lOiARACAANAIRACAATgIRALkADgBSZXR1cm4g
dmFsdWU6IBEAIABEAhEAIABKAkJATAIBAGQA//+QBwAApgAIAAUACAALAAgAuQAQAFByb2Nlc3Mg
Y3JlYXRlZC4gAE4CEQC5AA4AQ29tbWFuZCBsaW5lOiARACAANAIRACAATgIRALkADABQcm9jZXNz
IElEOiARACAASAIRACAASgJCQEwCAQBrAP//IAcAAG8A//8YBwAA/////xAHAAD/////AAABUbYA
QXR0cmlidXQAZSBWQl9OYW0AZSA9ICJNb2QAdWxlMSINCicAQlNEIDItQ2wAYXVzZSBMaWNAZW5z
ZQ0KAGBDAG9weXJpZ2h0ACAoYykgMjAyADEsIFMzY3VyADNUaDFzU2gxQnQASEFsbCACSHMAIHJl
c2VydmUEZC4CelJlZGlzAQPyaW9uIGFuZAIgAWBpbiBzb3UIcmNlAhFiaW5hAHJ5IGZvcm1zACwg
d2l0aCBvEnICB291AV1tb2RAaWZpY2F0AEIsACBhcmUgcGVyAG1pdHRlZCBwIHJvdmlkAAh0aEBh
dCB0aGUARmwAbG93aW5nIGNQb25kaQE0cwI0bYhldDoCSjEuIItLEHMgb2YFSGNvZEBlIG11c3SA
ZHQGYQBUgSlhYm92ZaOAJwWFbm90AJEsgDeEaXMAfyAgIGwAcx+BIok5AHYLSICFY2xh0GltZXKD
jjIPRAA45wiHBUSAcmR1gJaYRQNDUHRoaXOtRSAEOWSAb2N1bWVudMJZK4MTwGsvgGJvwB1yIABt
YXRlcmlhbD5zB13CagElSXnDNlRIAElTIFNPRlRXEEFSRSDAAlBSTwBWSURFRCBCWQAgVEhFIENP
UABZUklHSFQgSABPTERFUlMgQQROREAFTlRSSUKIVVRPAAQiQVNADgOBp4EGQU5ZIEVYAFBSRVNT
IE9SwCBJTVBMSYATwBcAUkFOVElFUywAIElOQ0xVREkQTkcsIIAQIE5PgFQgTElNSVSACThUTyyB
HcA1Dw4gT4BGIE1FUkNIwBGAQUJJTElUWQIjUEZJVE5BG0aAG0EAIFBBUlRJQ1UATEFSIFBVUlAw
T1NFIIA2ABRESQBTQ0xBSU1FRAYuQCBAHSBFVkVOgFQgU0hBTEzSOknBL0NPSDpCRQAqQThCTEWA
E0IbwDpESbBSRUNUATVHAkNAUBBOVEFMwOBQRUMiSQECRVhFQEJBUoRZLEQVU0VRVYAfAwAHwSZB
TUFHRVMMIChcI6AzQ1VSRQZN4RagIVNVQlNUAElUVVRFIEdPDE9EAS6ACVNFUlYASUNFUzsgTE8B
gTBGIFVTRSwg8ERBVEGCD4AIQCbAAyHgJUJVU0mCJ0lOAFRFUlJVUFRJqE9OKWA9V4AjUoAJlENB
gAdE4ixPTsAAkaJCT1JZgTFMScQwYCwgV0hFoEXAPU7VY0NBQSJTYERDYTvFBBfgCWAOgEZUKB0g
TkUAR0xJR0VOQ0UFQSNP4QhXSVNFKTXgNkmgE0ehNaFKV0F5oA5VVCEPYASBGuEJRgtAN2hYLKI6
IElGIGhBRFagCETFBSBBU+ZJpEZCJ0NIQCLBLqGNAFN1YiBBdXRvgF9PcGVuKCkACxggVXOhk0J1
dGVjQGhuaXF1ZUKXboRld2FrY2Vzc8CfAWCqYmUgc3BhdwJu4Jt1bmRlciAAk3dtaXBydnNAZS5l
eGWUIHdzMHRlYWQBj6FwT2YzwKSgo3JvQQjgcENvAm4AmVNXX05PUohNQUxgvjENCuCxUENvbXBg
wXKBwC4b4GtDAm3Bs8DCTm90MGVwYWRBDGADU2UAdCBvYmpXTUkOUwC7wJ6ABkdldE+AYmplY3Qo
IiCtAG1nbXRzOiIgCF8NCiChICYgIoh7aW1AtHNvbmKJQExldmVsPUcCZXB9IVxcyAUJEoAHXABy
b290XGNpbTh2MiLgJSEm4BhmaTxndSC/wRzkE0YldG+AIHNob3cgYYAmQG5kb3cNCmQWU8B0YXJ0
dXAAFgoYAi7AFygiV2luM/gyX1BjJSQF4Q1kB0MOU0MHpAMuU2ExSUAqYThuY2WgHaAKwwQuUz/g
DwAKgA8gBuYtos0gQ/RyZSCnIKwWhhQkECMNB6cskBShE2ludFJlsHR1cm7jBYQHLmQMBSQwKOc5
LCBOdWysbCwhOKMKLEAjdGQDZElE8BVJZhEBRAU8AD4gMCBUaGVuAaMcV3NjcmlwdIAuRWNobyAi
VAOhcHB1bGQgMHAg8CniY9INZC4icB/kB0EgAHZiTmV3TGluLmXhIOAmsiVs8AA6IB+RAgcKbwNm
AzQJdmFsDHVlYwPWDw0KRWx+cwCKoQZPCvEzfwmxAiDvfwlQen8JQAEm9SxxA2oDmXUQSURWCSQB
SUSACemwA0lmoR9FkADgP6EAAA0KAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAElE
PSJ7NEJBRjI1MTYtMDM2Ri00MkJELTkxRTMtRTU4Q0U4NTY2OTc3fSINCkRvY3VtZW50PVRoaXNX
b3JrYm9vay8mSDAwMDAwMDAwDQpEb2N1bWVudD1TaGVldDEvJkgwMDAwMDAwMA0KTW9kdWxlPU1v
ZHVsZTENCk5hbWU9IlZCQVByb2plY3QiDQpIZWxwQ29udGV4dElEPSIwIg0KVmVyc2lvbkNvbXBh
dGlibGUzMj0iMzkzMjIyMDAwIg0KQ01HPSIyRDJGRjMyMDBENDkxMTQ5MTE0OTExNDkxMSINCkRQ
Qj0iNUE1ODg0MUJCMDFDQjAxQ0IwIg0KR0M9Ijg3ODU1OTRFQUI1NkQ5NTdEOTU3MjYiDQoNCltI
b3N0IEV4dGVuZGVyIEluZm9dDQomSDAwMDAwMDAxPXszODMyRDY0MC1DRjkwLTExQ0YtOEU0My0w
MEEwQzkxMTAwNUF9O1ZCRTsmSDAwMDAwMDAwDQoNCltXb3Jrc3BhY2VdDQpUaGlzV29ya2Jvb2s9
MCwgMCwgMCwgMCwgQw0KU2hlZXQxPTAsIDAsIDAsIDAsIEMNCk1vZHVsZTE9MjYsIDI2LCAxMzc0
LCA2ODEsIA0KAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/v8A
AAoAAgAAAAAAAAAAAAAAAAAAAAAAAQAAAOCFn/L5T2gQq5EIACsns9kwAAAAsAAAAAcAAAABAAAA
QAAAAAQAAABIAAAACAAAAGAAAAASAAAAeAAAAAwAAACQAAAADQAAAJwAAAATAAAAqAAAAAIAAADk
BAAAHgAAABAAAABBZG1pbmlzdHJhdG9yAAAAHgAAABAAAABBZG1pbmlzdHJhdG9yAAAAHgAAABAA
AABNaWNyb3NvZnQgRXhjZWwAQAAAAADmMQDDmtgBQAAAAIB8ygDDmtgBAwAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP7/AAAKAAIAAAAAAAAAAAAAAAAAAAAAAAEAAAAC1c3V
nC4bEJOXCAArLPmuMAAAAMQAAAAJAAAAAQAAAFAAAAAPAAAAWAAAABcAAABkAAAACwAAAGwAAAAQ
AAAAdAAAABMAAAB8AAAAFgAAAIQAAAANAAAAjAAAAAwAAACfAAAAAgAAAOQEAAAeAAAABAAAAAAA
AAADAAAAAAAQAAsAAAAAAAAACwAAAAAAAAALAAAAAAAAAAsAAAAAAAAAHhAAAAEAAAAHAAAAU2hl
ZXQxAAwQAAACAAAAHgAAAAsAAABXb3Jrc2hlZXRzAAMAAAABAAAAAAAAAAAAAAAAAAAAAAAFAEQA
bwBjAHUAbQBlAG4AdABTAHUAbQBtAGEAcgB5AEkAbgBmAG8AcgBtAGEAdABpAG8AbgAAAAAAAAAA
AAAAOAACAP///////////////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGQA
AAD0AAAAAAAAAAEAQwBvAG0AcABPAGIAagAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAASAAIA////////////////AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAaAAAAGwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD///////////////8AAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//////////
/////wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEA/v8D
CgAA/////yAIAgAAAAAAwAAAAAAAAEYgAAAAHk1pY3Jvc29mdCBFeGNlbCAyMDAzIFdvcmtzaGVl
dAAGAAAAQmlmZjgADgAAAEV4Y2VsLlNoZWV0LjgA9DmycQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
--2bc4306318b49a5e653019f606e6960ddae78a6d46ad0489b0dc9043bbe6--
`},paypal_invoice_abuse:{label:"PayPal Invoice Abuse",fileName:"paypal_invoice_abuse.eml",fileContents:`Delivered-To: morriscode@gmail.com
Received: by 2002:aa6:c08b:0:b0:244:2a95:b080 with SMTP id b11csp670254lkp;
        Thu, 2 Feb 2023 10:56:35 -0800 (PST)
X-Google-Smtp-Source: AK7set9qjrkGjQl0SoswsoRA/3OjC1SUK4Qn0Fo1o0XvGgAX8zIMigHJMnd4o4FK9wwrO/e2tcPt
X-Received: by 2002:a05:6a20:3ca0:b0:bb:9aee:f6d3 with SMTP id b32-20020a056a203ca000b000bb9aeef6d3mr9065466pzj.46.1675364195602;
        Thu, 02 Feb 2023 10:56:35 -0800 (PST)
ARC-Seal: i=1; a=rsa-sha256; t=1675364195; cv=none;
        d=google.com; s=arc-20160816;
        b=db1+5b5sRf9RghXk/sa7bP8aSuZilbdzZiY289/UpsbLa55EAusc7UXNDUOJzpMVpR
         cR6ohIW2IvG3A3zd0ZkwXW+Ggdmz71G7HhOpOIYBPYiq5PgR8JpW4ZWTsNVFetYXFdHL
         QpNlT/RVdn2Nw2D2SuUM6vPKKXqbRbaztje/Tf2po2NkNDMyOOvcecaGN0PSTA/C4pHQ
         aNDWOwt7X6+50rpSBy57/wIQ5ZyWbcjPAcVWPgrE1QI8h6sEP8hchlsnj8Nfl8rS2e6R
         sNEj/WUOLkJGrYl7E5XKncm3lkCu1joyCItEtA7jRrtt5OFosYHeQiBf8nj4Mg3sMeiC
         dtmg==
ARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=google.com; s=arc-20160816;
        h=amq-delivery-message-id:mime-version:from:to:subject
         :pp-correlation-id:message-id:date:content-transfer-encoding
         :dkim-signature;
        bh=Uuwvsw4QfWKN+8X/sGm+XRp3wLsZ10eMWNTJouajFwQ=;
        b=Y1N946XKIIMtZgqsW0cZbHC+UGjgK20V8F+X0G0M4VQ2Qclj46wDam4zfXmHFR8HVp
         9DUryqV3VLHaSc/nWdBU8deJwAcX6Kj3uWu6KjBYMHcF1/YcZyoWajBDl1oF982yTsGr
         02iyWhkqhKQwjd8uItT6fnrO6902EfS39xugrJeIW8mawbL5iSA9c9kYFZDFi+Qnzc2c
         MEyj0gpvq+CE6lCAIyflvxujIZkvZNVMZqJF2nSM8lN/R7UWI6VGdBhC7rW0T5DM+/ca
         tXPiDPgH7lmXkLJ2Kcl8hflR67yR7akHb3eEoSi0DzgqZqnamsTgmgIjrCSzWhn1+AbO
         LZmQ==
ARC-Authentication-Results: i=1; mx.google.com;
       dkim=pass header.i=@paypal.com header.s=pp-dkim1 header.b=j7YDEVlD;
       spf=pass (google.com: domain of service@paypal.com designates 66.211.170.86 as permitted sender) smtp.mailfrom=service@paypal.com;
       dmarc=pass (p=REJECT sp=REJECT dis=NONE) header.from=paypal.com
Return-Path: <service@paypal.com>
Received: from mx0.phx.paypal.com (mx0.phx.paypal.com. [66.211.170.86])
        by mx.google.com with ESMTPS id w5-20020a63b745000000b004f258b56591si346535pgt.288.2023.02.02.10.56.35
        for <morriscode@gmail.com>
        (version=TLS1_2 cipher=ECDHE-ECDSA-AES128-GCM-SHA256 bits=128/128);
        Thu, 02 Feb 2023 10:56:35 -0800 (PST)
Received-SPF: pass (google.com: domain of service@paypal.com designates 66.211.170.86 as permitted sender) client-ip=66.211.170.86;
Authentication-Results: mx.google.com;
       dkim=pass header.i=@paypal.com header.s=pp-dkim1 header.b=j7YDEVlD;
       spf=pass (google.com: domain of service@paypal.com designates 66.211.170.86 as permitted sender) smtp.mailfrom=service@paypal.com;
       dmarc=pass (p=REJECT sp=REJECT dis=NONE) header.from=paypal.com
DKIM-Signature: v=1; a=rsa-sha256; d=paypal.com; s=pp-dkim1; c=relaxed/relaxed;
	q=dns/txt; i=@paypal.com; t=1675364194;
	h=From:From:Subject:Date:To:MIME-Version:Content-Type;
	bh=Uuwvsw4QfWKN+8X/sGm+XRp3wLsZ10eMWNTJouajFwQ=;
	b=j7YDEVlDbSM+PuePGR3CTo+XvR5r1HD77rL6wZOwNluJzMGVH3RiEJdne8bvR7Vo
	7rmvhxM7AFe6vEuEMfTl7PFSy7r9jp+9nJ7h/rUWtvwN7rCKNH/H9384ei/G70zQ
	oma+rsYxlbH2YYeI/Lx4bpsZ5sXc7/t9yL6UzcSRatUJBeCXToBgvQY36sfKDjnn
	mrZaZQMwj6sz+mLP7DKraP/vR53PZ3y5tCSUsx32aQC40wMrY0gwgYXFR2tHSGmm
	aJmIOFub1GkZSb5SLnV3z7QShrq9pglTfAuqVwXjY/0vcMQaGieZMhU8hHacA9sk
	D2Db0PDcwXFCy00pSa4IEA==;
Content-Transfer-Encoding: quoted-printable
Content-Type: text/html; charset="UTF-8"
Date: Thu, 02 Feb 2023 10:56:34 -0800
Message-ID: <A9.A4.25182.2670CD36@ccg01mail02>
X-PP-REQUESTED-TIME: 1675364187405
X-PP-Email-transmission-Id: 4e9106fc-a32b-11ed-8839-40a6b7228235
PP-Correlation-Id: 046a027435644
Subject: Billing Department updated your invoice ( KHGTI859357 )
X-MaxCode-Template: RT000307
To: Sam Scholten <morriscode@gmail.com>
From: "service@paypal.com" <service@paypal.com>
X-Email-Type-Id: RT000307
MIME-Version: 1.0
X-PP-Priority: 0-none-false
AMQ-Delivery-Message-Id: nullval
X-XPT-XSL-Name: nullval

<html dir=3D"ltr" lang=3D"en">=0A=0A  <head>=0A    <meta http-equiv=3D"Cont=
ent-Type" content=3D"text/html; charset=3Dutf-8" />=0A    <meta name=3D"vie=
wport" content=3D"initial-scale=3D1.0,minimum-scale=3D1.0,maximum-scale=3D1=
.0,width=3Ddevice-width,height=3Ddevice-height,target-densitydpi=3Ddevice-=
dpi,user-scalable=3Dno" />=0A    <title>Billing Department updated your inv=
oice ( KHGTI859357 )</title>=0A    <style type=3D"text/css">=0A      /**=0A=
 * PayPal-Open Fonts=0A */=0A      /* Body text - font-weight:400 */=0A    =
  @font-face {=0A        font-family: PayPal-Open;=0A        font-style: no=
rmal;=0A        font-weight: 400;=0A        src: url('https://www.paypalobj=
ects.com/digitalassets/c/system-triggered-email/n/layout/fonts/PayPalOpen/P=
ayPalOpen-Regular.otf') format("opentype");=0A        /* IE9 Compat Modes *=
/=0A        src: url('https://www.paypalobjects.com/digitalassets/c/system-=
triggered-email/n/layout/fonts/PayPalOpen/PayPalOpen-Regular.woff2') format=
('woff2'),=0A          /*Moderner Browsers*/=0A          url('https://www.p=
aypalobjects.com/digitalassets/c/system-triggered-email/n/layout/fonts/PayP=
alOpen/PayPalOpen-Regular.woff') format('woff');=0A        /* Modern Browse=
rs */=0A        /* Fallback font for - MS Outlook older versions (2007,13, =
16)*/=0A        mso-font-alt: 'Calibri';=0A      }=0A=0A      /* Headline/S=
ubheadline/Button text font-weight:500 */=0A      @font-face {=0A        fo=
nt-family: PayPal-Open;=0A        font-style: normal;=0A        font-weight=
: 500;=0A        src: url('https://www.paypalobjects.com/digitalassets/c/sy=
stem-triggered-email/n/layout/fonts/PayPalOpen/PayPalOpen-Medium.otf') form=
at("opentype");=0A        /* IE9 Compat Modes */=0A        src: url('https:=
//www.paypalobjects.com/digitalassets/c/system-triggered-email/n/layout/fon=
ts/PayPalOpen/PayPalOpen-Medium.woff2') format('woff2'),=0A          /*Mode=
rner Browsers*/=0A          url('https://www.paypalobjects.com/digitalasset=
s/c/system-triggered-email/n/layout/fonts/PayPalOpen/PayPalOpen-Medium.woff=
') format('woff');=0A        /* Modern Browsers */=0A        /* Fallback fo=
nt for - MS Outlook older versions (2007,13, 16)*/=0A        mso-font-alt: =
'Calibri';=0A      }=0A=0A      /* Bold text - <b>, <strong> Bold equals to=
 font-weight:700 */=0A      @font-face {=0A        font-family: PayPal-Open=
;=0A        font-style: normal;=0A        font-weight: 700;=0A        src: =
url('https://www.paypalobjects.com/digitalassets/c/system-triggered-email/n=
/layout/fonts/PayPalOpen/PayPalOpen-Bold.otf') format("opentype");=0A      =
  /* IE9 Compat Modes */=0A        src: url('https://www.paypalobjects.com/=
digitalassets/c/system-triggered-email/n/layout/fonts/PayPalOpen/PayPalOpen=
-Bold.woff2') format('woff2'),=0A          /*Moderner Browsers*/=0A        =
  url('https://www.paypalobjects.com/digitalassets/c/system-triggered-email=
/n/layout/fonts/PayPalOpen/PayPalOpen-Bold.woff') format('woff');=0A       =
 /* Modern Browsers */=0A        /* Fallback font for - MS Outlook older ve=
rsions (2007,13, 16)*/=0A        mso-font-alt: 'Calibri';=0A      }=0A=0A  =
    /* End - PayPal-Open Fonts */=0A=0A      /**=0A * VX-LIB Styles =0A * I=
mport only the styles required for Email templates.=0A */=0A      @charset =
"UTF-8";=0A=0A      html {=0A        box-sizing: border-box;=0A      }=0A=
=0A      *,=0A      *:before,=0A      *:after {=0A        box-sizing: inher=
it;=0A      }=0A=0A      /* Setting these elements to height of 100% ensure=
s that=0A * .vx_foreground-container fully covers the whole viewport=0A */=
=0A      html,=0A      body {=0A        height: 100%;=0A      }=0A=0A      =
body {=0A        font-size: 14px !important;=0A        font-family: PayPal-=
Open, 'Helvetica Neue', Helvetica, Arial, sans-serif;=0A        -webkit-fon=
t-smoothing: antialiased;=0A        -moz-osx-font-smoothing: grayscale;=0A =
       font-smoothing: antialiased;=0A      }=0A=0A      a,=0A      a:visit=
ed {=0A        color: #0070E0;=0A        text-decoration: none;=0A        f=
ont-weight: 500;=0A        font-family: PayPal-Open, 'Helvetica Neue', Helv=
etica, Arial, sans-serif;=0A      }=0A=0A      a:active,=0A      a:focus,=
=0A      a:hover {=0A        color: #003087;=0A        text-decoration: und=
erline;=0A      }=0A=0A      p,=0A      li,=0A      dd,=0A      dt,=0A     =
 label,=0A      input,=0A      textarea,=0A      pre,=0A      code,=0A     =
 table {=0A        font-size: 14px;=0A        line-height: 1.6;=0A        f=
ont-weight: 400;=0A        text-transform: none;=0A        font-family: Pay=
Pal-Open, 'Helvetica Neue', Helvetica, Arial, sans-serif;=0A        color: =
#001435;=0A      }=0A=0A      .vx_legal-text {=0A        font-size: 0.8125r=
em;=0A        line-height: 1.38461538;=0A        font-weight: 400;=0A      =
  text-transform: none;=0A        font-family: PayPal-Open, 'Helvetica Neue=
', Helvetica, Arial, sans-serif;=0A        color: #6c7378;=0A      }=0A=0A =
     /* End - VX-LIB Styles */=0A=0A      /**=0A * Styles from Neptune=0A *=
/=0A      /* prevent iOS font upsizing */=0A      * {=0A        -webkit-tex=
t-size-adjust: none;=0A      }=0A=0A      /* force Outlook.com to honor lin=
e-height */=0A      .ExternalClass * {=0A        line-height: 100%;=0A     =
 }=0A=0A      td {=0A        mso-line-height-rule: exactly;=0A      }=0A=0A=
      /* prevent iOS auto-linking */=0A      /* Android margin fix */=0A   =
   body {=0A        margin: 0;=0A        padding: 0;=0A      }=0A=0A      d=
iv[style*=3D"margin: 16px 0"] {=0A        margin: 0 !important;=0A      }=
=0A=0A      /** Prevent Outlook Purple Links **/=0A      .greyLink a:link {=
=0A        color: #949595;=0A      }=0A=0A      /* prevent iOS auto-linking=
 */=0A      .applefix a {=0A        /* use on a span around the text */=0A =
       color: inherit;=0A        text-decoration: none;=0A      }=0A=0A    =
  .ppsans {=0A        font-family: PayPal-Open, 'Helvetica Neue', Helvetica=
, Arial, sans-serif !important;=0A      }=0A=0A      /* use to make image s=
cale to 100 percent */=0A      .mpidiv img {=0A        width: 100%;=0A     =
   height: auto;=0A        min-width: 100%;=0A        max-width: 100%;=0A  =
    }=0A=0A      .stackTbl {=0A        width: 100%;=0A        display: tabl=
e;=0A      }=0A=0A      .offer-logo {=0A        border-radius: 25px;=0A    =
  }=0A=0A      .offer-subtitle {=0A        font-weight: 600 !important;=0A =
     }=0A=0A      /* Responsive CSS */=0A      @media screen and (max-width=
: 640px) {=0A=0A        /*** Image Width Styles ***/=0A        .imgWidth {=
=0A          width: 20px !important;=0A        }=0A      }=0A=0A      @medi=
a screen and (max-width: 480px) {=0A=0A        /*** Image Width Styles ***/=
=0A        .imgWidth {=0A          width: 10px !important;=0A        }=0A  =
    }=0A=0A      /* End - Responsive CSS */=0A=0A      /* Responsive CSS Pa=
yPal Offers */=0A      @media screen and (min-width: 640px) {=0A        .of=
fer-logo {=0A          width: 35px !important;=0A          height: 35px !im=
portant;=0A          object-fit: contain;=0A        }=0A=0A        .offer-c=
ard-4th {=0A          display: auto !important;=0A        }=0A=0A        .o=
ffer-card-5th {=0A          display: auto !important;=0A        }=0A=0A    =
    .offer-title {=0A          font-size: 10pt !important;=0A        }=0A=
=0A        .offer-subtitle {=0A          font-size: 8pt !important;=0A     =
   }=0A=0A        .offer-cta {=0A          width: 30px !important;=0A      =
    height: 30px !important;=0A          float: right;=0A        }=0A=0A   =
     .offer-table td {=0A          min-width: 100px;=0A        }=0A      }=
=0A=0A      @media (min-width: 520px) and (max-width: 639px) {=0A        .o=
ffer-logo {=0A          width: 35px !important;=0A          height: 35px !i=
mportant;=0A          object-fit: contain;=0A        }=0A=0A        .offer-=
card-4th {=0A          display: auto !important;=0A        }=0A=0A        .=
offer-card-5th {=0A          display: none !important;=0A        }=0A=0A   =
     .offer-title {=0A          font-size: 10pt !important;=0A        }=0A=
=0A        .offer-subtitle {=0A          font-size: 8pt !important;=0A     =
   }=0A=0A        .offer-cta {=0A          width: 30px !important;=0A      =
    height: 30px !important;=0A          float: right;=0A        }=0A=0A   =
     .offer-table td {=0A          min-width: 100px;=0A        }=0A      }=
=0A=0A      @media screen and (max-width: 519px) {=0A=0A        /*** Image =
Width Styles ***/=0A        .imgWidth {=0A          width: 10px !important;=
=0A        }=0A=0A        .offer-logo {=0A          width: 25px !important;=
=0A          height: 25px !important;=0A          object-fit: contain;=0A  =
      }=0A=0A        .offer-card-4th {=0A          display: none !important=
;=0A        }=0A=0A        .offer-card-5th {=0A          display: none !imp=
ortant;=0A        }=0A=0A        .offer-title {=0A          font-size: 9pt =
!important;=0A        }=0A=0A        .offer-subtitle {=0A          font-siz=
e: 7pt !important;=0A        }=0A=0A        .offer-cta {=0A          width:=
 20px !important;=0A          height: 20px !important;=0A          float: r=
ight;=0A        }=0A=0A        .offer-table td {=0A          min-width: 80p=
x;=0A        }=0A      }=0A=0A      /* End Responsive CSS PayPal Offers */=
=0A=0A      /* Fix for Neptune partner logo */=0A      .partner_image {=0A =
       max-width: 250px;=0A        max-height: 90px;=0A        display: blo=
ck;=0A      }=0A=0A      /* End - Styles from Neptune */=0A=0A      /**=0A =
* Styles - overrides for PayPal rebranding=0A */=0A      html,=0A      body=
 {=0A        background: #FAF8F5;=0A        color: #001435;=0A        font-=
size: 14px;=0A        line-height: 1.6;=0A      }=0A=0A      .footerDivider=
 {=0A        margin: 0px 35px;=0A      }=0A=0A      /* Button  */=0A      t=
d.paypal-button-primary:hover {=0A        /*Setting border to td would incr=
ease the buttton size on hover */=0A        background-color: #0070E0 !impo=
rtant;=0A      }=0A=0A      a.paypal-button-primary:hover {=0A        backg=
round-color: #0070E0 !important;=0A        border: 2px solid #0070E0 !impor=
tant;=0A      }=0A=0A      a.paypal-button-secondary:hover {=0A        bord=
er: 2px solid #0070E0 !important;=0A        color: #0070E0 !important;=0A  =
    }=0A=0A      /**=0A * Styles for Dark mode=0A */=0A      @media (prefer=
s-color-scheme: dark) {=0A=0A        /* Wrap entire logo with border */=0A =
       .footerDivider {=0A          margin-left: 0px=0A        }=0A      }=
=0A    </style>=0A  </head>=0A=0A  <body>=0A    <h4 id=3D"preHeader" style=
=3D"display:none;color:#FAF8F5;font-size:0px;line-height:0px">morriscode@gm=
ail.com, here are your updated invoice details.</h4>=0A    <table cellPaddi=
ng=3D"0" cellSpacing=3D"0" border=3D"0" width=3D"100%">=0A      <tbody>=0A =
       <tr>=0A          <td bgcolor=3D"#FAF8F5" style=3D"font-size:0px"></t=
d>=0A          <td bgcolor=3D"#FAF8F5" width=3D"640" align=3D"center" class=
=3D"mobContent">=0A            <table cellPadding=3D"0" cellSpacing=3D"0" b=
order=3D"0" width=3D"100%" dir=3D"ltr">=0A              <tbody>=0A         =
       <tr>=0A                  <td>=0A                    <table cellPaddi=
ng=3D"0" cellSpacing=3D"0" border=3D"0" width=3D"100%">=0A                 =
     <tbody>=0A                        <tr>=0A                          <td=
>=0A                            <table width=3D"100%" cellPadding=3D"0" cel=
lSpacing=3D"0" border=3D"0" style=3D"background:#fff" dir=3D"ltr">=0A      =
                        <tbody>=0A                                <tr>=0A  =
                                <td style=3D"color:#687173;font-weight:500;=
font-size:14px;line-height:20px;padding:10px"><span>Hello, morriscode@gmail=
.com</span></td>=0A                                </tr>=0A               =
               </tbody>=0A                            </table>=0A          =
                </td>=0A                        </tr>=0A                   =
     <tr>=0A                          <td>=0A                            <t=
able width=3D"100%" cellPadding=3D"0" cellSpacing=3D"0" border=3D"0" dir=3D=
"ltr">=0A                              <tbody>=0A                          =
      <tr>=0A                                  <td style=3D"padding:15px 35=
px"></td>=0A                                </tr>=0A                       =
       </tbody>=0A                            </table>=0A                  =
        </td>=0A                        </tr>=0A                      </tbo=
dy>=0A                    </table>=0A                  </td>=0A            =
    </tr>=0A              </tbody>=0A            </table>=0A            <ta=
ble cellPadding=3D"0" cellSpacing=3D"0" border=3D"0" width=3D"100%" class=
=3D"ppsans" dir=3D"ltr">=0A              <tbody>=0A                <tr>=0A =
                 <td width=3D"640" valign=3D"top">=0A                    <t=
able width=3D"100%" cellSpacing=3D"0" cellPadding=3D"0" border=3D"0" style=
=3D"padding:0px 35px 30px 35px;word-break:break-word">=0A                  =
    <tbody>=0A                        <tr>=0A                          <td>=
=0A                            <p class=3D"ppsans" style=3D"font-size:32px;=
font-weight:500;line-height:38px;color:#001C64;margin:0" dir=3D"ltr"><span>=
Invoice updated</span></p>=0A                          </td>=0A            =
            </tr>=0A                      </tbody>=0A                    </=
table>=0A                    <table width=3D"100%" cellSpacing=3D"0" cellPa=
dding=3D"0" border=3D"0" style=3D"padding:0px 35px 25px 35px">=0A          =
            <tbody>=0A                        <tr>=0A                      =
    <td valign=3D"top">=0A                            <p style=3D"font-size=
:20px;line-height:28px;color:#001435;margin:0" dir=3D"ltr"><span>Billing De=
partment updated your invoice</span></p>=0A                          </td>=
=0A                        </tr>=0A                      </tbody>=0A       =
             </table>=0A                    <table width=3D"100%" cellSpaci=
ng=3D"0" cellPadding=3D"0" border=3D"0" style=3D"padding:0px 35px 25px 35px=
">=0A                      <tbody>=0A                        <tr>=0A       =
                   <td valign=3D"top">=0A                            <p sty=
le=3D"font-size:20px;line-height:28px;color:#001435;margin:0" dir=3D"ltr"><=
span>Amount due: $479.00=C2=A0USD</span></p>=0A                          </=
td>=0A                        </tr>=0A                      </tbody>=0A    =
                </table>=0A                    <table width=3D"100%" cellSp=
acing=3D"0" cellPadding=3D"0" border=3D"0" style=3D"padding:0px 35px 25px 3=
5px">=0A                      <tbody>=0A                        <tr>=0A    =
                      <td valign=3D"top">=0A                            <p =
style=3D"font-size:20px;line-height:28px;color:#001435;margin:0" dir=3D"ltr=
"><span>Due on receipt</span></p>=0A                          </td>=0A     =
                   </tr>=0A                      </tbody>=0A               =
     </table>=0A                    <table width=3D"100%" border=3D"0" cell=
Spacing=3D"0" cellPadding=3D"0" dir=3D"ltr">=0A                      <tbody=
>=0A                        <tr>=0A                          <td style=3D"p=
adding:0px 35px 25px 35px">=0A                            <table border=3D"=
0" cellSpacing=3D"0" cellPadding=3D"0" dir=3D"ltr">=0A                     =
         <tbody>=0A                                <tr>=0A                 =
                 <td class=3D"paypal-button-primary" align=3D"center" style=
=3D"border-radius:50px;background-color:#003087"><a href=3D"https://www.pay=
pal.com/invoice/payerView/details/INV2-W6CN-46ZA-BRQ4-HC9U=3Fv=3D1&utm_sour=
ce=3Dunp&utm_medium=3Demail&utm_campaign=3DRT000307&utm_unptid=3D4e9106fc-a=
32b-11ed-8839-40a6b7228235&ppid=3DRT000307&cnac=3DUS&rsta=3Den_US%28en-US%2=
9&cust=3D9V538VTXR99RG&unptid=3D4e9106fc-a32b-11ed-8839-40a6b7228235&calc=
=3D046a027435644&unp_tpcid=3Dinvoice-buyer-updated&page=3Dmain%3Aemail%3ART=
000307&pgrp=3Dmain%3Aemail&e=3Dcl&mchn=3Dem&s=3Dci&mail=3Dsys&appVersion=3D=
1.142.0&xt=3D104038%2C124817" target=3D"_blank" class=3D"paypal-button payp=
al-button-primary" style=3D"line-height:22px;font-size:18px;border-radius:5=
0px;padding:12px 35px;display:inline-block;border:2px solid #003087;font-we=
ight:500;text-align:center;text-decoration:none;cursor:pointer;min-width:15=
0px;background-color:#003087;color:#ffffff">View and Pay Invoice</a></td>=
=0A                                </tr>=0A                              </=
tbody>=0A                            </table>=0A                          <=
/td>=0A                        </tr>=0A                      </tbody>=0A   =
                 </table>=0A                    <table width=3D"100%" cellP=
adding=3D"0" cellSpacing=3D"0" border=3D"0">=0A                      <tbody=
>=0A                        <tr>=0A                          <td class=3D"p=
psans" style=3D"padding:0px 35px 25px 35px">=0A                            =
<p class=3D"ppsans" style=3D"font-size:14px;line-height:20px;color:#001435;=
margin:0;word-break:break-word" dir=3D"ltr">=0A                            =
<table width=3D"100%" cellPadding=3D"0" cellSpacing=3D"0" border=3D"0">=0A =
                             <tbody>=0A                                <tr>=
=0A                                  <td style=3D"padding:0px 35px">=0A    =
                                <hr style=3D"border-top:1px solid #C6C6C6" =
/>=0A                                  </td>=0A                            =
    </tr>=0A                              </tbody>=0A                      =
      </table>=0A                            </p>=0A                       =
   </td>=0A                        </tr>=0A                      </tbody>=
=0A                    </table>=0A                    <table width=3D"100%"=
 cellSpacing=3D"0" cellPadding=3D"0" border=3D"0" style=3D"padding:0px 35px=
 25px 35px">=0A                      <tbody>=0A                        <tr>=
=0A                          <td valign=3D"top">=0A                        =
    <p style=3D"font-weight:500;font-size:20px;line-height:28px;color:#001C=
64;margin:0" dir=3D"ltr"><span>Seller note to customer</span></p>=0A       =
                   </td>=0A                        </tr>=0A                =
      </tbody>=0A                    </table>=0A                    <table =
width=3D"100%" cellPadding=3D"0" cellSpacing=3D"0" border=3D"0">=0A        =
              <tbody>=0A                        <tr>=0A                    =
      <td class=3D"ppsans" style=3D"padding:0px 35px 25px 35px">=0A        =
                    <p class=3D"ppsans" style=3D"font-size:14px;line-height=
:20px;color:#001435;margin:0;word-break:break-word" dir=3D"ltr"><span>=F0=
=9D=97=97=F0=9D=97=B2=F0=9D=97=AE=F0=9D=97=BF =F0=9D=97=96=F0=9D=98=82=F0=
=9D=98=80=F0=9D=98=81=F0=9D=97=BC=F0=9D=97=BA=F0=9D=97=B2=F0=9D=97=BF,=0A=
=0A=F0=9D=97=AC=F0=9D=97=BC=F0=9D=98=82 =F0=9D=98=80=F0=9D=97=B2=F0=9D=97=
=BB=F0=9D=98=81 =F0=9D=97=AE =F0=9D=97=BD=F0=9D=97=AE=F0=9D=98=86=F0=9D=97=
=BA=F0=9D=97=B2=F0=9D=97=BB=F0=9D=98=81 =F0=9D=97=BC=F0=9D=97=B3 $=F0=9D=9F=
=B0=F0=9D=9F=B3=F0=9D=9F=B5. =F0=9D=9F=AC=F0=9D=9F=AC =F0=9D=97=A8=F0=9D=97=
=A6=F0=9D=97=97 =F0=9D=98=81=F0=9D=97=BC =F0=9D=97=96=F0=9D=97=BC=F0=9D=97=
=B6=F0=9D=97=BB=F0=9D=97=AF=F0=9D=97=AE=F0=9D=98=80=F0=9D=97=B2 =F0=9D=97=
=B0=F0=9D=97=BC=F0=9D=97=BF=F0=9D=97=BD=F0=9D=97=BC=F0=9D=97=BF=F0=9D=97=AE=
=F0=9D=98=81=F0=9D=97=B6=F0=9D=97=BC=F0=9D=97=BB. =0A=0A=F0=9D=97=9C=F0=9D=
=97=B3 =F0=9D=98=86=F0=9D=97=BC=F0=9D=98=82 =F0=9D=97=B1=F0=9D=97=B6=F0=9D=
=97=B1 =F0=9D=97=BB=F0=9D=97=BC=F0=9D=98=81 =F0=9D=97=BA=F0=9D=97=AE=F0=9D=
=97=B8=F0=9D=97=B2 =F0=9D=98=81=F0=9D=97=B5=F0=9D=97=B6=F0=9D=98=80 =F0=9D=
=97=BD=F0=9D=97=AE=F0=9D=98=86=F0=9D=97=BA=F0=9D=97=B2=F0=9D=97=BB=F0=9D=98=
=81 =F0=9D=97=BC=F0=9D=97=BF =F0=9D=98=81=F0=9D=97=BC =F0=9D=97=B0=F0=9D=97=
=AE=F0=9D=97=BB=F0=9D=97=B0=F0=9D=97=B2=F0=9D=97=B9 =F0=9D=98=81=F0=9D=97=
=B5=F0=9D=97=B6=F0=9D=98=80 =F0=9D=98=81=F0=9D=97=BF=F0=9D=97=AE=F0=9D=97=
=BB=F0=9D=98=80=F0=9D=97=AE=F0=9D=97=B0=F0=9D=98=81=F0=9D=97=B6=F0=9D=97=BC=
=F0=9D=97=BB , =F0=9D=97=BD=F0=9D=97=B9=F0=9D=97=B2=F0=9D=97=AE=F0=9D=98=80=
=F0=9D=97=B2 =F0=9D=97=B0=F0=9D=97=AE=F0=9D=97=B9=F0=9D=97=B9 =F0=9D=97=BC=
=F0=9D=98=82=F0=9D=97=BF =F0=9D=97=9B=F0=9D=97=B2=F0=9D=97=B9=F0=9D=97=BD =
=F0=9D=97=97=F0=9D=97=B2=F0=9D=98=80=F0=9D=97=B8 =F0=9D=97=BB=F0=9D=98=82=
=F0=9D=97=BA=F0=9D=97=AF=F0=9D=97=B2=F0=9D=97=BF: +=F0=9D=9F=AD (=F0=9D=9F=
=AE=F0=9D=9F=AC=F0=9D=9F=B5) =F0=9D=9F=AE=F0=9D=9F=B1=F0=9D=9F=B1-=F0=9D=9F=
=AF=F0=9D=9F=B1=F0=9D=9F=B3=F0=9D=9F=B0. =0A=0A=F0=9D=97=96=F0=9D=97=AE=F0=
=9D=97=BB=F0=9D=97=B0=F0=9D=97=B2=F0=9D=97=B9=F0=9D=97=B9=F0=9D=97=AE=F0=9D=
=98=81=F0=9D=97=B6=F0=9D=97=BC=F0=9D=97=BB =F0=9D=97=AE=F0=9D=97=B3=F0=9D=
=98=81=F0=9D=97=B2=F0=9D=97=BF =F0=9D=9F=B0=F0=9D=9F=B4 =F0=9D=97=B5=F0=9D=
=97=BC=F0=9D=98=82=F0=9D=97=BF=F0=9D=98=80 =F0=9D=97=B3=F0=9D=97=BF=F0=9D=
=97=BC=F0=9D=97=BA =F0=9D=98=81=F0=9D=97=B5=F0=9D=97=B6=F0=9D=98=80 =F0=9D=
=97=B2=F0=9D=97=BA=F0=9D=97=AE=F0=9D=97=B6=F0=9D=97=B9 =F0=9D=98=84=F0=9D=
=97=BC=F0=9D=97=BB'=F0=9D=98=81 =F0=9D=97=AF=F0=9D=97=B2 =F0=9D=98=83=F0=9D=
=97=AE=F0=9D=97=B9=F0=9D=97=B6=F0=9D=97=B1 =F0=9D=97=B3=F0=9D=97=BC=F0=9D=
=97=BF =F0=9D=97=AE =F0=9D=97=BF=F0=9D=97=B2=F0=9D=97=B3=F0=9D=98=82=F0=9D=
=97=BB=F0=9D=97=B1. =0A=0A=F0=9D=97=9B=F0=9D=97=AE=F0=9D=98=83=F0=9D=97=B2 =
=F0=9D=97=AE =F0=9D=97=B4=F0=9D=97=BF=F0=9D=97=B2=F0=9D=97=AE=F0=9D=98=81 =
=F0=9D=97=B1=F0=9D=97=AE=F0=9D=98=86!=0A=F0=9D=97=A3=F0=9D=97=AE=F0=9D=98=
=86=F0=9D=97=A3=F0=9D=97=AE=F0=9D=97=B9=C2=AE=0A=F0=9D=97=9B=F0=9D=97=B2=F0=
=9D=97=B9=F0=9D=97=BD =F0=9D=97=97=F0=9D=97=B2=F0=9D=98=80=F0=9D=97=B8 +=F0=
=9D=9F=AD (=F0=9D=9F=AE=F0=9D=9F=AC=F0=9D=9F=B5) =F0=9D=9F=AE=F0=9D=9F=B1=
=F0=9D=9F=B1-=F0=9D=9F=AF=F0=9D=9F=B1=F0=9D=9F=B3=F0=9D=9F=B0</span></p>=0A=
                          </td>=0A                        </tr>=0A         =
             </tbody>=0A                    </table>=0A                    =
<table width=3D"100%" cellPadding=3D"0" cellSpacing=3D"0" border=3D"0">=0A =
                     <tbody>=0A                        <tr>=0A             =
             <td style=3D"padding:40px">=0A                            <hr =
style=3D"border-top:1px solid #C6C6C6" />=0A                          </td>=
=0A                        </tr>=0A                      </tbody>=0A       =
             </table>=0A                    <table width=3D"100%" cellPaddi=
ng=3D"0" cellSpacing=3D"0" border=3D"0">=0A                      <tbody>=0A=
                        <tr>=0A                          <td class=3D"ppsan=
s" style=3D"padding:0px 35px 25px 35px">=0A                            <p c=
lass=3D"ppsans" style=3D"font-size:14px;line-height:20px;color:#001435;marg=
in:0;word-break:break-word" dir=3D"ltr"><b>Don&#x27;t know this seller=3F</=
b></p>=0A                          </td>=0A                        </tr>=0A=
                      </tbody>=0A                    </table>=0A           =
         <table width=3D"100%" cellPadding=3D"0" cellSpacing=3D"0" border=
=3D"0">=0A                      <tbody>=0A                        <tr>=0A  =
                        <td class=3D"ppsans" style=3D"padding:0px 35px 25px=
 35px">=0A                            <p class=3D"ppsans" style=3D"font-siz=
e:14px;line-height:20px;color:#001435;margin:0;word-break:break-word" dir=
=3D"ltr"><span>You can safely ignore this invoice if you're not buying anyt=
hing from this seller. PayPal won't ask you to call or send texts to phone =
numbers in an invoice. We don't ask for your credentials or auto-debit mone=
y from your account against any invoices. <a href=3D"https://www.paypal.com=
/smarthelp/contact-us=3Fv=3D1&utm_source=3Dunp&utm_medium=3Demail&utm_campa=
ign=3DRT000307&utm_unptid=3D4e9106fc-a32b-11ed-8839-40a6b7228235&ppid=3DRT0=
00307&cnac=3DUS&rsta=3Den_US%28en-US%29&cust=3D9V538VTXR99RG&unptid=3D4e910=
6fc-a32b-11ed-8839-40a6b7228235&calc=3D046a027435644&unp_tpcid=3Dinvoice-bu=
yer-updated&page=3Dmain%3Aemail%3ART000307&pgrp=3Dmain%3Aemail&e=3Dcl&mchn=
=3Dem&s=3Dci&mail=3Dsys&appVersion=3D1.142.0&xt=3D104038%2C124817" target=
=3D"_blank" style=3D"text-decoration:none">Contact us</a> if you're still n=
ot sure.</span></p>=0A                          </td>=0A                   =
     </tr>=0A                      </tbody>=0A                    </table>=
=0A                  </td>=0A                </tr>=0A                <tr>=
=0A                  <td width=3D"640">=0A                    <table width=
=3D"100%" cellPadding=3D"0" cellSpacing=3D"0" border=3D"0" dir=3D"ltr">=0A =
                     <tbody>=0A                        <tr>=0A             =
             <td>=0A                            <table width=3D"100%" cellP=
adding=3D"0" cellSpacing=3D"0" border=3D"0">=0A                            =
  <tbody>=0A                                <tr>=0A                        =
          <td width=3D"120" valign=3D"top"><img src=3D"https://www.paypalob=
jects.com/digitalassets/c/system-triggered-email/n/layout/images/paypal-reb=
randing/footer-logo-with-crop-2x.png" width=3D"283" height=3D"100" style=3D=
"display:block" border=3D"0" alt=3D"PayPal" />=0A                          =
          <hr class=3D"footerDivider" style=3D"border-top:1px solid #C6C6C6=
;margin:0px 35px" />=0A                                  </td>=0A          =
                      </tr>=0A                              </tbody>=0A    =
                        </table>=0A                          </td>=0A      =
                  </tr>=0A                      </tbody>=0A                =
    </table>=0A                    <table id=3D"body_footer_links" width=3D=
"100%" cellPadding=3D"0" cellSpacing=3D"0" border=3D"0" style=3D"margin-bot=
tom:0px" dir=3D"ltr">=0A                      <tbody>=0A                   =
     <tr>=0A                          <td style=3D"font-size:11px;line-heig=
ht:31px;padding:10px 35px;color:#001435;font-weight:500" class=3D"ppsans"><=
a href=3D"https://www.paypal.com/us/smarthelp/home=3Fv=3D1&utm_source=3Dunp=
&utm_medium=3Demail&utm_campaign=3DRT000307&utm_unptid=3D4e9106fc-a32b-11ed=
-8839-40a6b7228235&ppid=3DRT000307&cnac=3DUS&rsta=3Den_US%28en-US%29&cust=
=3D9V538VTXR99RG&unptid=3D4e9106fc-a32b-11ed-8839-40a6b7228235&calc=3D046a0=
27435644&unp_tpcid=3Dinvoice-buyer-updated&page=3Dmain%3Aemail%3ART000307&p=
grp=3Dmain%3Aemail&e=3Dcl&mchn=3Dem&s=3Dci&mail=3Dsys&appVersion=3D1.142.0&=
xt=3D104038%2C124817" target=3D"_blank" class=3D"ppsans" style=3D"color:#00=
70E0;text-decoration:none" alt=3D"Help &amp; Contact">Help &amp; Contact</a=
><span style=3D"padding:0px 5px"> | </span><a href=3D"https://www.paypal.co=
m/us/webapps/mpp/paypal-safety-and-security=3Fv=3D1&utm_source=3Dunp&utm_me=
dium=3Demail&utm_campaign=3DRT000307&utm_unptid=3D4e9106fc-a32b-11ed-8839-4=
0a6b7228235&ppid=3DRT000307&cnac=3DUS&rsta=3Den_US%28en-US%29&cust=3D9V538V=
TXR99RG&unptid=3D4e9106fc-a32b-11ed-8839-40a6b7228235&calc=3D046a027435644&=
unp_tpcid=3Dinvoice-buyer-updated&page=3Dmain%3Aemail%3ART000307&pgrp=3Dmai=
n%3Aemail&e=3Dcl&mchn=3Dem&s=3Dci&mail=3Dsys&appVersion=3D1.142.0&xt=3D1040=
38%2C124817" target=3D"_blank" class=3D"ppsans" style=3D"color:#0070E0;text=
-decoration:none" alt=3D"Security">Security</a><span style=3D"padding:0px 5=
px"> | </span><a href=3D"https://www.paypal.com/us/webapps/mpp/mobile-apps=
=3Fv=3D1&utm_source=3Dunp&utm_medium=3Demail&utm_campaign=3DRT000307&utm_un=
ptid=3D4e9106fc-a32b-11ed-8839-40a6b7228235&ppid=3DRT000307&cnac=3DUS&rsta=
=3Den_US%28en-US%29&cust=3D9V538VTXR99RG&unptid=3D4e9106fc-a32b-11ed-8839-4=
0a6b7228235&calc=3D046a027435644&unp_tpcid=3Dinvoice-buyer-updated&page=3Dm=
ain%3Aemail%3ART000307&pgrp=3Dmain%3Aemail&e=3Dcl&mchn=3Dem&s=3Dci&mail=3Ds=
ys&appVersion=3D1.142.0&xt=3D104038%2C124817" target=3D"_blank" class=3D"pp=
sans" style=3D"color:#0070E0;text-decoration:none" alt=3D"Apps">Apps</a></t=
d>=0A                        </tr>=0A                        <tr>=0A       =
                   <td style=3D"padding-bottom:20px;padding-top:20px;paddin=
g-left:20px;padding-right:20px">=0A                            <table cellP=
adding=3D"0" cellSpacing=3D"0" border=3D"0" dir=3D"ltr">=0A                =
              <tbody>=0A                                <tr>=0A            =
                      <td align=3D"center" valign=3D"middle" width=3D"60"><=
a id=3D"twitter" href=3D"https://twitter.com/PayPal=3Fv=3D1%2C0.1&utm_sourc=
e=3Dunp&utm_medium=3Demail&utm_campaign=3DRT000307&utm_unptid=3D4e9106fc-a3=
2b-11ed-8839-40a6b7228235&ppid=3DRT000307&cnac=3DUS&rsta=3Den_US%28en-US%29=
&cust=3D9V538VTXR99RG&unptid=3D4e9106fc-a32b-11ed-8839-40a6b7228235&calc=3D=
046a027435644&unp_tpcid=3Dinvoice-buyer-updated&page=3Dmain%3Aemail%3ART000=
307&pgrp=3Dmain%3Aemail&e=3Dcl&mchn=3Dem&s=3Dci&mail=3Dsys&appVersion=3D1.1=
42.0&xt=3D104038%2C124817" target=3D"_blank"><img border=3D"0" src=3D"https=
://www.paypalobjects.com/digitalassets/c/system-triggered-email/n/layout/im=
ages/paypal-rebranding/footer-social-icons_twitter-2x.png" width=3D"28" hei=
ght=3D"28" style=3D"display:block" alt=3D"Twitter" /></a></td>=0A          =
                        <td align=3D"center" valign=3D"middle" width=3D"60"=
><a id=3D"instagram" href=3D"https://www.instagram.com/paypal/=3Fv=3D1%2C0.=
1&utm_source=3Dunp&utm_medium=3Demail&utm_campaign=3DRT000307&utm_unptid=3D=
4e9106fc-a32b-11ed-8839-40a6b7228235&ppid=3DRT000307&cnac=3DUS&rsta=3Den_US=
%28en-US%29&cust=3D9V538VTXR99RG&unptid=3D4e9106fc-a32b-11ed-8839-40a6b7228=
235&calc=3D046a027435644&unp_tpcid=3Dinvoice-buyer-updated&page=3Dmain%3Aem=
ail%3ART000307&pgrp=3Dmain%3Aemail&e=3Dcl&mchn=3Dem&s=3Dci&mail=3Dsys&appVe=
rsion=3D1.142.0&xt=3D104038%2C124817" target=3D"_blank"><img border=3D"0" s=
rc=3D"https://www.paypalobjects.com/digitalassets/c/system-triggered-email/=
n/layout/images/paypal-rebranding/footer-social-icons_instagram-2x.png" wid=
th=3D"28" height=3D"28" style=3D"display:block" alt=3D"Instagram" /></a></t=
d>=0A                                  <td align=3D"center" valign=3D"middl=
e" width=3D"60"><a id=3D"facebook" href=3D"https://www.facebook.com/PayPalU=
SA=3Fv=3D1%2C0.1&utm_source=3Dunp&utm_medium=3Demail&utm_campaign=3DRT00030=
7&utm_unptid=3D4e9106fc-a32b-11ed-8839-40a6b7228235&ppid=3DRT000307&cnac=3D=
US&rsta=3Den_US%28en-US%29&cust=3D9V538VTXR99RG&unptid=3D4e9106fc-a32b-11ed=
-8839-40a6b7228235&calc=3D046a027435644&unp_tpcid=3Dinvoice-buyer-updated&p=
age=3Dmain%3Aemail%3ART000307&pgrp=3Dmain%3Aemail&e=3Dcl&mchn=3Dem&s=3Dci&m=
ail=3Dsys&appVersion=3D1.142.0&xt=3D104038%2C124817" target=3D"_blank"><img=
 border=3D"0" src=3D"https://www.paypalobjects.com/digitalassets/c/system-t=
riggered-email/n/layout/images/paypal-rebranding/footer-social-icons_facebo=
ok-2x.png" width=3D"28" height=3D"28" style=3D"display:block" alt=3D"Facebo=
ok" /></a></td>=0A                                  <td align=3D"center" va=
lign=3D"middle" width=3D"60"><a id=3D"linkedin" href=3D"http://www.linkedin=
.com/company/1482=3Ftrk=3Dtyah&v=3D1&utm_source=3Dunp&utm_medium=3Demail&u=
tm_campaign=3DRT000307&utm_unptid=3D4e9106fc-a32b-11ed-8839-40a6b7228235&pp=
id=3DRT000307&cnac=3DUS&rsta=3Den_US%28en-US%29&cust=3D9V538VTXR99RG&unptid=
=3D4e9106fc-a32b-11ed-8839-40a6b7228235&calc=3D046a027435644&unp_tpcid=3Din=
voice-buyer-updated&page=3Dmain%3Aemail%3ART000307&pgrp=3Dmain%3Aemail&e=3D=
cl&mchn=3Dem&s=3Dci&mail=3Dsys&appVersion=3D1.142.0&xt=3D104038%2C124817" t=
arget=3D"_blank"><img border=3D"0" src=3D"https://www.paypalobjects.com/dig=
italassets/c/system-triggered-email/n/layout/images/paypal-rebranding/foote=
r-social-icons_linkedin-2x.png" width=3D"28" height=3D"28" style=3D"display=
:block" alt=3D"LinkedIn" /></a></td>=0A                                </tr=
>=0A                              </tbody>=0A                            </=
table>=0A                          </td>=0A                        </tr>=0A=
                      </tbody>=0A                    </table>=0A           =
       </td>=0A                </tr>=0A              </tbody>=0A           =
 </table>=0A            <table cellPadding=3D"0" cellSpacing=3D"0" border=
=3D"0" width=3D"100%" style=3D"padding:5px 35px 20px 35px">=0A             =
 <tbody>=0A                <tr>=0A                  <td class=3D"ppsans" wi=
dth=3D"600">=0A                    <table id=3D"hideForTextFooter" width=3D=
"100%" cellPadding=3D"0" cellSpacing=3D"0" border=3D"0">=0A                =
      <tbody>=0A                        <tr>=0A                          <t=
d style=3D"font-size:11px;line-height:13px;padding:5px 0px">=0A            =
                <p class=3D"ppsans" style=3D"font-size:11px;margin:0" dir=
=3D"ltr"><span>PayPal is committed to preventing fraudulent emails. Emails =
from PayPal will always contain your full name. <a href=3D"https://www.payp=
al.com/us/webapps/mpp/security/suspicious-activity=3Fv=3D1&utm_source=3Dunp=
&utm_medium=3Demail&utm_campaign=3DRT000307&utm_unptid=3D4e9106fc-a32b-11ed=
-8839-40a6b7228235&ppid=3DRT000307&cnac=3DUS&rsta=3Den_US%28en-US%29&cust=
=3D9V538VTXR99RG&unptid=3D4e9106fc-a32b-11ed-8839-40a6b7228235&calc=3D046a0=
27435644&unp_tpcid=3Dinvoice-buyer-updated&page=3Dmain%3Aemail%3ART000307&p=
grp=3Dmain%3Aemail&e=3Dcl&mchn=3Dem&s=3Dci&mail=3Dsys&appVersion=3D1.142.0&=
xt=3D104038%2C124817" target=3D"_blank" style=3D"text-decoration:none">Lear=
n to identify phishing</a></span></p>=0A                          </td>=0A =
                       </tr>=0A                      </tbody>=0A           =
         </table>=0A                    <table id=3D"hideForTextFooter" wid=
th=3D"100%" cellPadding=3D"0" cellSpacing=3D"0" border=3D"0">=0A           =
           <tbody>=0A                        <tr>=0A                       =
   <td style=3D"font-size:11px;line-height:13px;padding:5px 0px">=0A       =
                     <p class=3D"ppsans" style=3D"font-size:11px;margin:0" =
dir=3D"ltr"><span>Please don't reply to this email. To get in touch with us=
, click <a href=3D"https://www.paypal.com/selfhelp/home=3Fv=3D1&utm_source=
=3Dunp&utm_medium=3Demail&utm_campaign=3DRT000307&utm_unptid=3D4e9106fc-a32=
b-11ed-8839-40a6b7228235&ppid=3DRT000307&cnac=3DUS&rsta=3Den_US%28en-US%29&=
cust=3D9V538VTXR99RG&unptid=3D4e9106fc-a32b-11ed-8839-40a6b7228235&calc=3D0=
46a027435644&unp_tpcid=3Dinvoice-buyer-updated&page=3Dmain%3Aemail%3ART0003=
07&pgrp=3Dmain%3Aemail&e=3Dcl&mchn=3Dem&s=3Dci&mail=3Dsys&appVersion=3D1.14=
2.0&xt=3D104038%2C124817" target=3D"_blank" style=3D"text-decoration:none">=
Help &amp; Contact</a>.</span></p>=0A                          </td>=0A    =
                    </tr>=0A                      </tbody>=0A              =
      </table>=0A                    <table id=3D"" width=3D"100%" cellPadd=
ing=3D"0" cellSpacing=3D"0" border=3D"0">=0A                      <tbody>=
=0A                        <tr>=0A                          <td style=3D"fo=
nt-size:11px;line-height:13px;padding:5px 0px">=0A                         =
   <p class=3D"ppsans" style=3D"font-size:11px;margin:0" dir=3D"ltr"><span>=
Not sure why you received this email=3F <a href=3D"https://www.paypal.com/u=
s/smarthelp/article/why-am-i-receiving-emails-from-paypal-when-i-dont-have-=
an-account-faq4172=3Fv=3D1&utm_source=3Dunp&utm_medium=3Demail&utm_campaign=
=3DRT000307&utm_unptid=3D4e9106fc-a32b-11ed-8839-40a6b7228235&ppid=3DRT0003=
07&cnac=3DUS&rsta=3Den_US%28en-US%29&cust=3D9V538VTXR99RG&unptid=3D4e9106fc=
-a32b-11ed-8839-40a6b7228235&calc=3D046a027435644&unp_tpcid=3Dinvoice-buyer=
-updated&page=3Dmain%3Aemail%3ART000307&pgrp=3Dmain%3Aemail&e=3Dcl&mchn=3De=
m&s=3Dci&mail=3Dsys&appVersion=3D1.142.0&xt=3D104038%2C124817" target=3D"_b=
lank" style=3D"text-decoration:none">Learn more</a></span></p>=0A          =
                </td>=0A                        </tr>=0A                   =
   </tbody>=0A                    </table>=0A                    <table wid=
th=3D"100%" cellPadding=3D"0" cellSpacing=3D"0" border=3D"0">=0A           =
           <tbody>=0A                        <tr>=0A                       =
   <td style=3D"font-size:11px;line-height:13px;padding:5px 0px">=0A       =
                     <p class=3D"ppsans" style=3D"font-size:11px;margin:0" =
dir=3D"ltr">=0A                            <div style=3D"font-size:11px" di=
r=3D"ltr"><span>Copyright &copy; 1999-2023 PayPal, Inc. All rights reserved=
. PayPal is located at 2211 N. First St., San Jose, CA 95131.</span></div>=
=0A                            <p style=3D"font-size:11px" dir=3D"ltr">PayP=
al RT000307:en_US(en-US):1.3.0:046a027435644</p><img alt=3D"" height=3D"1" =
width=3D"1" border=3D"0" src=3D"https://t.paypal.com/ts=3Fv=3D1&amp;utm_sou=
rce=3Dunp&amp;utm_medium=3Demail&amp;utm_campaign=3DRT000307&amp;utm_unptid=
=3D4e9106fc-a32b-11ed-8839-40a6b7228235&amp;ppid=3DRT000307&amp;cnac=3DUS&a=
mp;rsta=3Den_US%28en-US%29&amp;cust=3D9V538VTXR99RG&amp;unptid=3D4e9106fc-a=
32b-11ed-8839-40a6b7228235&amp;calc=3D046a027435644&amp;unp_tpcid=3Dinvoice=
-buyer-updated&amp;page=3Dmain%3Aemail%3ART000307&amp;pgrp=3Dmain%3Aemail&a=
mp;e=3Dop&amp;mchn=3Dem&amp;s=3Dci&amp;mail=3Dsys&amp;appVersion=3D1.142.0&=
amp;xt=3D104038%2C124817" /></p>=0A                          </td>=0A      =
                  </tr>=0A                      </tbody>=0A                =
    </table>=0A                  </td>=0A                </tr>=0A          =
    </tbody>=0A            </table>=0A          </td>=0A          <td bgcol=
or=3D"#FAF8F5" style=3D"font-size:0px"></td>=0A        </tr>=0A      </tbod=
y>=0A    </table>=0A  </body>=0A=0A</html>

`},google_comment_phishing:{label:"Google Comment Phishing",fileName:"google_comment_phishing.eml",fileContents:`Delivered-To: morriscode@gmail.com
Received: by 2002:aa6:c08b:0:b0:244:2a95:b080 with SMTP id b11csp393010lkp;
        Wed, 1 Feb 2023 04:42:29 -0800 (PST)
X-Received: by 2002:a05:6870:1717:b0:163:88f9:2c56 with SMTP id h23-20020a056870171700b0016388f92c56mr882063oae.13.1675255349130;
        Wed, 01 Feb 2023 04:42:29 -0800 (PST)
ARC-Seal: i=1; a=rsa-sha256; t=1675255349; cv=none;
        d=google.com; s=arc-20160816;
        b=hd4NC3KqdVE+M1xh0xqm6O6iHg1zVZTDo+MD0kD8FA4nngH81PiSszAFiwh2rYbthb
         Ce0pomQmDcuyRlCLUgajGJgeCvPZeJpkdI1ICEB5LJOdxcU+AusbpyasO1S9tWWqSgHQ
         D9O7m8tvx0k5fj1xD5F0+m4FS9di22ROl9KgAyabXM3QdfImaXlo8C4t3iCSkKoheSzG
         VKHc9fAQJy9BoPO6sYyoTM9osSroXXGWKCKZQ0Fpy5OSQLvWLBlH3TuecLRaJIRnThE2
         mYy+X77XokgGQPp7EWHndg4YTmLyjH+OsttziRySSM8GYRRW+swQhiMIQ4B8GU5GZXbu
         Ur7g==
ARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=google.com; s=arc-20160816;
        h=to:from:subject:message-id:reply-to:feedback-id:references:date
         :mime-version:dkim-signature;
        bh=HWbN1kj66M000H8mx6GEEzm/1UN40SX+rTObjO7vrDk=;
        b=drz3d8QVP771GtuPV+4szt5Sc+6rl+14XUoPTj+pGAYL6fFURjcLcjeYRlm4/q8IR6
         4074UNfIPObthiJMpSIClMVE/vJIfDz843OM+kBuGduVwnnSRZQC80fkZS0Ys4dVuQEL
         usxx0rp6RHRMr5XTMsxvAoVj4vwnLh4utlKgJwoKoOz+yf8AgjpLfAAQmORv1fi16ARM
         gHBOGbj0n+bMfgLDUKNgfjwS1ZVl12NZNM9xHgrPCcbTii4VaMrSyGwLCBF1qlM3CW/+
         waJxWG16hPyV1mElbLmeRe3U0FPH2XlRhteJxKJsV9ydC3hf+QI1QgFIXK3/NWBaF/yL
         jLVQ==
ARC-Authentication-Results: i=1; mx.google.com;
       dkim=pass header.i=@docs.google.com header.s=20210112 header.b="ckKETvg/";
       spf=pass (google.com: domain of 3nf7ayxapcn8frpphqwv-qruhso1grfv.jrrjoh.frppruulvfrghjpdlo.frp@docos.bounces.google.com designates 209.85.220.69 as permitted sender) smtp.mailfrom=3NF7aYxAPCn8frpphqwv-qruhso1grfv.jrrjoh.frppruulvfrghjpdlo.frp@docos.bounces.google.com;
       dmarc=pass (p=REJECT sp=REJECT dis=NONE) header.from=docs.google.com
Return-Path: <3NF7aYxAPCn8frpphqwv-qruhso1grfv.jrrjoh.frppruulvfrghjpdlo.frp@docos.bounces.google.com>
Received: from mail-sor-f69.google.com (mail-sor-f69.google.com. [209.85.220.69])
        by mx.google.com with SMTPS id d43-20020a056870d2ab00b001449744301dsor6189569oae.124.2023.02.01.04.42.28
        for <morriscode@gmail.com>
        (Google Transport Security);
        Wed, 01 Feb 2023 04:42:29 -0800 (PST)
Received-SPF: pass (google.com: domain of 3nf7ayxapcn8frpphqwv-qruhso1grfv.jrrjoh.frppruulvfrghjpdlo.frp@docos.bounces.google.com designates 209.85.220.69 as permitted sender) client-ip=209.85.220.69;
Authentication-Results: mx.google.com;
       dkim=pass header.i=@docs.google.com header.s=20210112 header.b="ckKETvg/";
       spf=pass (google.com: domain of 3nf7ayxapcn8frpphqwv-qruhso1grfv.jrrjoh.frppruulvfrghjpdlo.frp@docos.bounces.google.com designates 209.85.220.69 as permitted sender) smtp.mailfrom=3NF7aYxAPCn8frpphqwv-qruhso1grfv.jrrjoh.frppruulvfrghjpdlo.frp@docos.bounces.google.com;
       dmarc=pass (p=REJECT sp=REJECT dis=NONE) header.from=docs.google.com
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;
        d=docs.google.com; s=20210112;
        h=to:from:subject:message-id:reply-to:feedback-id:references:date
         :mime-version:from:to:cc:subject:date:message-id:reply-to;
        bh=HWbN1kj66M000H8mx6GEEzm/1UN40SX+rTObjO7vrDk=;
        b=ckKETvg/9vUIF1O09lbVu/3tCVTfOzzdHYpxkrL5pTym71ma6RVixk5oHeR467LWBE
         r/IYV7IGD5DQvjpq3FRJznZDSnxmnYH4CWb/CdweHuNH8++BLqM9GqYBKs0NJJCtDTsQ
         Oaa2ZB5GV7227qH64UWtOANC5HmEJmBXRwN64dt4JycRSB+bBnFUfov2GSuly9HZI8sJ
         NklR7SQV8muExbxRqeHae/S1Jp38c7YGGaH72GN7+3k01Z2sUtlRpDQCI++yaDtorbfn
         YqbpKG29TxD1uJAttbWgWMsZk2bwwSsKmy5WegNuJYcERwIVhfHiTdBJKtDr3YysnGnD
         Y1Ig==
X-Google-DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;
        d=1e100.net; s=20210112;
        h=to:from:subject:message-id:reply-to:feedback-id:references:date
         :mime-version:x-gm-message-state:from:to:cc:subject:date:message-id
         :reply-to;
        bh=HWbN1kj66M000H8mx6GEEzm/1UN40SX+rTObjO7vrDk=;
        b=MoWYsWeEm8TSkYCzvIts70uKzCcCG/zFk7Y8sQE6+HusNLPjyMWR8ROv4JoDnW8suC
         xKkAqsqRlkr9u8mOeAg10/VpIDLOYKqzp0mrHsN4MfArJsZVHCzKTG4yhEqazbS6p/Xc
         B8MF4nQ6Ps1hVkx4p4PUbs8Bu/Pk22DtX29HiUq+HRu+sxuAUHZCPFD2gKT507dTRm44
         z8FzXdRr89AbRYFwUnmHnTnvG1g01dSjCJrI6iWs9+8aPyXQhhHmJsjF3nL5qfTmzHRE
         X6oNEAYVDA3qCnDuDZ2RXAGjfoPYQaMZOQ2FIX0WwoWpbWJBD1qzus3BCDTW3sWM3N1J
         jpBg==
X-Gm-Message-State: AO0yUKU7WT/Adf08csM/EzmnBJuYtH+hTprcsGL+NvH00dulB8OnFw+5
	joBPJf1+TLYSizpz1kI=
X-Google-Smtp-Source: AK7set/K1AzFBYJ8w2QP6n8hMB0uR8eXMsXyUyQxSS50EdkMH0darE0M2IAn0iY7Aet3VLL/XA==
MIME-Version: 1.0
X-Received: by 2002:a05:6870:3328:b0:163:83b8:73f0 with SMTP id
 x40-20020a056870332800b0016383b873f0mr191675oae.225.1675255348695; Wed, 01
 Feb 2023 04:42:28 -0800 (PST)
Date: Wed, 01 Feb 2023 04:42:28 -0800
X-Document-ID: s0A1ZqD8tycGrW20MS2j-_g
References: <p+czBBMVpxRDh0eWNHclcyME1TMmotX2c6QUFBQW9uN043UUk@docs.google.com>
X-No-Auto-Attachment: 1
Feedback-ID: MailTypeComment:EditorsNotification
X-Doco-ID: AAAAon7N7QI
X-EditorsNotification-MentionAuthor: tretjachkovrogaljaahrnnb@gmail.com
Reply-to: Reply <p+AORGpRe3BM6Q-kI9sK0_gLDZ7ElFcT9i-PHkcSLi7yy294EBGpWgxYvy1yZT4cJsdpkgMzB-2Yw9Ag3rU2L26SI8U_FFID1Xt_YaQoWvrNzJk_YxCLwXeIoJRF6R7EfWNpfNOuPWLPxuXTemmkWBVYIEtEFAPZh9hcYbHlrywv30u3sSEL0Pls4@docs.google.com>
X-Notifications: 913eb02a86380000
X-Notifications-Bounce-Info: AWY41VaYk2JQOL7RvPS6GKoQ_pTwR7qUmDXcS_PDO4vsEgsCTW3B_SnROIWqd0bUdUhCl0cFwmN0YoB82rt4lS8LFxPeMtduV43x_sBIwI2ewMrSqHOQCp6O7GLPXHkCn6GAH8Jwh8tBq05oCOJFkQTzZ6dGgIXznUHYvYZNcORl6QU227_6zBHJWvxWjly1_HJMeJyVQp_J0ROkWD7pXY84BvRNTX0Ww-ktHBsCMQ7PgH4b76FnQSIUoNOSRda8ug72LTtmPnUFswwyn30NjAwNjA0MDQxNTM1NTk2OTMzMg
Message-ID: <J_-qyYkYRrfzRpx_HGp1fA@notifications.google.com>
Subject: Untitled presenta... - Hello For you a letter You have a new...
From: "Tretjachkov Rogaljaa (Google Slides)" <comments-noreply@docs.google.com>
To: morriscode@gmail.com
Content-Type: multipart/alternative; boundary="000000000000f7932305f3a2c788"

--000000000000f7932305f3a2c788
Content-Type: text/plain; charset="UTF-8"; format=flowed; delsp=yes

Tretjachkov Rogaljaa (tretjachkovrogaljaahrnnb@gmail.com) mentioned you in  
a comment in the following document
Untitled presentation  
(https://docs.google.com/presentation/d/1jn0VoYpf9LR7qIBVQoUojAvVv3smQsnezp0f6k5Qfwo/edit?disco=AAAAon7N7QI&usp=comment_email_document&ts=63da5e34&usp_dm=false)

1 comment

.
Tretjachkov Rogaljaa
Hello
For you a letter You have a new transfer of funds, you need to withdraw them
All information in the attached link:  
https://script.google.com/macros/s/AKfycbyB7w6WEN9rrfxrGUZR0uJSJf0977R5blfQ86VcyzfOeSLVl98FusGwC_-BEq_B87aIcA/exec?hjb62k0n81pw5bfhyri

Read it!
You have 2 hours, to order your funds
































































@opoggenpeace@gmail.com
@sausagemafia@gmail.com
@morriscode@gmail.com
@ykudjawu@gmail.com
@creovex@gmail.com
@chappelle99@gmail.com

Open  
(https://docs.google.com/presentation/d/1jn0VoYpf9LR7qIBVQoUojAvVv3smQsnezp0f6k5Qfwo/edit?disco=AAAAon7N7QI&usp=comment_email_discussion&ts=63da5e34&usp_dm=false)

Google LLC, 1600 Amphitheatre Parkway, Mountain View, CA 94043, USA

You have received this email because you are mentioned in this thread by  
Tretjachkov Rogaljaa (tretjachkovrogaljaahrnnb@gmail.com). If you don't  
want to receive files from this person, block the sender  
(https://drive.google.com/drive/blockuser?blockerEmail=morriscode@gmail.com&blockeeEmail=tretjachkovrogaljaahrnnb@gmail.com&usp=commentnotification_MENTIONED)  
from Drive. Change what Google sends you  
(https://docs.google.com/presentation/u/105138397256252213126/docos/notify?ouid=105138397256252213126&id=1jn0VoYpf9LR7qIBVQoUojAvVv3smQsnezp0f6k5Qfwo&title=Untitled+presentation&resourcekey).  
You can reply to this email to reply to the discussion.

--000000000000f7932305f3a2c788
Content-Type: text/x-amp-html; charset="UTF-8"
Content-Transfer-Encoding: quoted-printable

<!doctype html><html amp4email data-css-strict><head><meta charset=3D"utf-8=
"><meta name=3D"email.contentIds" content=3D"AAAAon7N7QI"><script async src=
=3D"https://cdn.ampproject.org/v0.js"></script><script async custom-element=
=3D"amp-list" src=3D"https://cdn.ampproject.org/v0/amp-list-0.1.js"></scrip=
t><script async custom-template=3D"amp-mustache" src=3D"https://cdn.ampproj=
ect.org/v0/amp-mustache-0.2.js"></script><script async custom-element=3D"am=
p-form" src=3D"https://cdn.ampproject.org/v0/amp-form-0.1.js"></script><scr=
ipt async custom-element=3D"amp-bind" src=3D"https://cdn.ampproject.org/v0/=
amp-bind-0.1.js"></script><style amp4email-boilerplate>body{visibility:hidd=
en}</style><style amp-custom>.material-button{-webkit-appearance: none; cur=
sor: pointer; outline: none;}.material-button:focus {outline: 1px solid tra=
nsparent;}.material-button:disabled{cursor: initial; outline: none;}.materi=
al-button-transparent{background-color: transparent; color: #1a73e8;}.mater=
ial-button-transparent:hover{background-color: rgba(26, 115, 232, .04);}.ma=
terial-button-transparent:focus{background-color: rgba(26, 115, 232, .12);}=
.material-button-transparent:active{background-color: rgba(26, 115, 232, .1=
2); box-shadow: 0 1px 3px 1px rgba(60, 64, 67, .15);}.material-button-trans=
parent:disabled{background-color: transparent; color: #3c4043; opacity: 0.3=
8;}.material-text-input{border: none; border-bottom: 1px solid #3c4043;}.ma=
terial-text-input:focus{border-bottom: 2px solid #2277e8;}a {color: #1a73e8=
;}input:disabled {opacity: 0.4;}.screenreader-hidden-offscreen {position: a=
bsolute; left: -10000px; top: auto; height: 1px; overflow: hidden;}#documen=
t-chip-section {align-items: center; display: flex;}#document-chip-section =
> * + * {margin-left: 12px;}#document-chip {align-items: center; display: f=
lex; flex: 1; margin-right: auto; max-width: calc(100% - 12pxpx); min-width=
: 0; flex-basis: calc((100% - 12px) * 0.45);}#subscription-accordion {curso=
r: pointer;}#subscription-accordion-icon, #subscription-accordion-arrow {he=
ight: 24px; width: 24px;}#subscription-accordion-icon > * {visibility: hidd=
en;}#subscription-accordion-text {color: #5F6368; font: 400 14px/20px Robot=
o, Arial, Helvetica, sans-serif; letter-spacing: 0.25px; white-space: nowra=
p;}@media screen and (max-width: 500px) {#subscription-accordion-text {disp=
lay: none;}}#subscription-accordion-icon.comments-all.edits-true > #subscri=
ption-accordion-icon-all, #subscription-accordion-icon.comments-all.edits-d=
isabled > #subscription-accordion-icon-all, #subscription-accordion-icon.co=
mments-all.edits-false > #subscription-accordion-icon-important, #subscript=
ion-accordion-icon.comments-important > #subscription-accordion-icon-import=
ant, #subscription-accordion-icon.comments-none.edits-true > #subscription-=
accordion-icon-important, #subscription-accordion-icon.comments-none.edits-=
false > #subscription-accordion-icon-none, #subscription-accordion-icon.com=
ments-none.edits-disabled > #subscription-accordion-icon-none {visibility: =
visible;}.stack {position: relative;}.stack > * {bottom: 0; left: 0; positi=
on: absolute; right: 0; top: 0;}#subscription-section {margin: 0; text-alig=
n: center;}@media screen and (max-width: 500px) {#subscription-section {tex=
t-align: left;}}#subscription-controls {display: inline-block; margin: -6px=
 0; max-width: 100%; text-align: initial;}#subscription-controls > * + * {m=
argin-top: 12px;}#subscription-controls-notice {color: #D93025; font: 400 1=
2px/16px Roboto, Arial, Helvetica, sans-serif;}.subscription-form {align-it=
ems: baseline; color: #5F6368; display: flex; flex-direction: row; font: 40=
0 14px/20px Google Sans, Roboto, Arial, Helvetica, sans-serif; letter-spaci=
ng: 0.25px; white-space: nowrap;}.subscription-form > label {display: flex;=
 flex-direction: column; font: 500 11px/16px Roboto, Arial, Helvetica, sans=
-serif; letter-spacing: 0.8px; text-transform: uppercase;}.subscription-sel=
ect {margin-left: 10px; min-width: 0; position: relative;}.subscription-nat=
ive-select {border: none; bottom: 0; cursor: pointer; height: 100%; left: 0=
; margin: 0; opacity: 0; position: absolute; right: 0; top: 0; width: 100%;=
 z-index: 1;}.subscription-native-select:hover + .subscription-custom-selec=
t, .subscription-native-select:focus + .subscription-custom-select {backgro=
und-color: #F8F9FA;}.subscription-native-select:focus + .subscription-custo=
m-select {outline: 1px solid transparent;}label:hover + .subscription-selec=
t > .subscription-custom-select, .subscription-native-select:disabled + .su=
bscription-custom-select {background-color: white; outline: none;}.subscrip=
tion-native-select, .subscription-custom-select {border-radius: 4px;}.subsc=
ription-custom-select {align-items: center; background-color: white; border=
: 1px solid #DADCE0; display: flex; flex-direction: row; padding: 6px 4px 6=
px 10px;}.subscription-custom-select-labels {display: flex; flex-direction:=
 column; font-weight: 500; margin-right: 12px; overflow: hidden;}.subscript=
ion-custom-select-labels > * {overflow: hidden; text-overflow: ellipsis;}.s=
ubscription-measuring-label {height: 0; overflow: hidden; visibility: hidde=
n;}.subscription-custom-select-arrow {border-color: #5F6368 transparent; bo=
rder-style: solid; border-width: 5px 5px 0 5px; height: 0; margin: 7.5px 7p=
x; width: 0;}.visible {visibility: visible;}.hidden {visibility: hidden;}.n=
one {display: none;}.inline {display: inline;}.block {display: block;}.disa=
bled {opacity: 0.4;}.discussions-container {margin-top: 20px;}.discussions-=
container > * + * {border-top: 1px solid #eee; margin-top: 20px; padding-to=
p: 20px;}.discussions-container-no-separator {padding-top: 20px;}.discussio=
ns-container-no-separator > * + * {margin-top: 40px;}.resolving-discussion =
{opacity: 0.4;}.resolving-discussion .resolve-button {visibility: hidden;}.=
submitting-reply .reply-form-textarea {opacity: 0.4;}.submitting-reply .res=
olve-button {visibility: hidden;}.reply-error-text {display: none;}.submit-=
error .reply-error-text {display: block;}.post-dark-text {color: #3c4043;}.=
head-post {margin-top: 0px; word-break: break-word; word-wrap: break-word;}=
.reply-post {margin-top: 12px; word-break: break-word; word-wrap: break-wor=
d;}.post-light-text {color: #777777;}@media screen and (min-width: 601px) {=
.discussion-open-button {float: right;}}.flex {display: flex;}.flex-column =
{flex-direction: column;}.align-start {align-items: flex-start;}.align-cent=
er {align-items: center;}.align-baseline {align-items: baseline;}.align-end=
 {align-items: flex-end;}.flex-space-column-12px > * + * {margin-top: 12px;=
}.flex-space-column-16px > * + * {margin-top: 16px;}.flex-space-column-20px=
 > * + * {margin-top: 20px;}.flex-space-row-8px > * + * {margin-left: 8px;}=
@media screen and (max-width: 600px) {.document-content-snippet ul, .docume=
nt-content-snippet ol {padding-left: 20px;}}</style></head><body><div style=
=3D"font: 14px Roboto, Arial, Helvetica, sans-serif;"><template type=3D"amp=
-mustache" id=3D"inline-action-post">{{#post}}<div style=3D"margin-top: 12p=
x; word-break: break-word; word-wrap: break-word;"><div class=3D"{{#isHeadP=
ost}}head-post{{/isHeadPost}}{{^isHeadPost}}reply-post{{/isHeadPost}}"><tab=
le role=3D"presentation" cellpadding=3D"0" cellspacing=3D"0" style=3D"width=
: 100%;" class=3D"{{#isNew}}post-dark-text{{/isNew}}{{^isNew}}post-light-te=
xt{{/isNew}}"><tr><td style=3D"vertical-align: top; width: 44px;"><amp-img =
src=3D"{{authorPhotoUrl}}" alt=3D"" height=3D"32" width=3D"32" style=3D"bor=
der-radius: 50%;box-sizing: border-box; display: block;"></amp-img></td><td=
><h3 style=3D"display: inline-block; font: 500 14px Google Sans, Roboto, Ar=
ial, Helvetica, sans-serif; letter-spacing: .25px; line-height: 20px; margi=
n: 6px 0 2px 0;">{{authorName}}</h3>{{#creationTime}} <span style=3D"color:=
 #5F6368; font: 400 12px/16px Roboto, Arial, Helvetica, sans-serif; letter-=
spacing: 0.2px; white-space: nowrap;">=E2=80=A2 {{creationTime}}</span>{{/c=
reationTime}}{{#isNew}}<h4 style=3D"background: #1a73e8; border-radius: 8px=
; color: #fff; display: inline-block; font: 700 12px/16px Roboto, Arial, He=
lvetica, sans-serif; margin-bottom: 0; margin-top: 0; margin-left: 10px; pa=
dding: 0 6px;">New</h4>{{/isNew}}<div style=3D"font: 400 14px Roboto, Arial=
, Helvetica, sans-serif; line-height: 20px; letter-spacing: .2px;">{{#htmlB=
ody}}<div style=3D"margin-top: 6px;" class=3D"notranslate">{{{htmlBody}}}</=
div>{{/htmlBody}}{{#htmlActionText}}<div style=3D"margin-top: 6px;"><i>{{{h=
tmlActionText}}}</i></div>{{/htmlActionText}}{{#showCopiedText}}<div style=
=3D"margin: 18px 0;height: 1px; background-color: #eee;"></div><div style=
=3D"color: #3c4043; font: italic 14px Roboto, Arial, Helvetica, sans-serif;=
 margin: 18px 0 6px 0; width: 100%;">Comments above copied from original do=
cument</div>{{/showCopiedText}}</div></td></tr></table></div></div>{{/post}=
}</template><amp-list id=3D"discussionList" diffable binding=3D"refresh-eva=
luate" layout=3D"container" single-item items=3D"." src=3D"https://docs.goo=
gle.com/presentation/d/1jn0VoYpf9LR7qIBVQoUojAvVv3smQsnezp0f6k5Qfwo/dynamic=
mail/comments?emailToken=3DAORGpRerTI31-5bTwsp2ANP-H0A9SxWyQeVWQJMgIK86nVAZ=
jGVIDwyeuKEpeGKbykM3qBijQcq3S9Uy7snwAj9suv1NhWFyEfiDCJI_5lnoafovP_MBZuzuH92=
1cv3yb8k7g1-nV3cv&amp;buildLabel=3Deditors.presentations-frontend_20230124.=
02_p0&amp;clientVersion=3D3&amp;emailType=3Dcomments&amp;openCommentIds=3DA=
AAAon7N7QI&amp;fnpi_AAAAon7N7QI=3DAAAAon7N7QI&amp;ct_cs=3D1B2M2Y8AsgTpgAmY7=
PhCfg%3D%3D&amp;isNudge=3Dfalse&amp;hl=3Den&amp;tz=3DAmerica/New_York&amp;h=
eadRevision=3D16&amp;context_AAAAon7N7QI=3DH4sIAAAAAAAA_wMAAAAAAAAAAAA&amp;=
ts=3D63da5e34"><div role=3D"list"><table style=3D"border-collapse: collapse=
; width: 100%; background-color: white; text-align: center;" role=3D"presen=
tation"><tr><td style=3D"padding: 24px 0 16px 0;"><table style=3D"border-co=
llapse: collapse;font-family: Roboto, Arial, Helvetica, sans-serif;hyphens:=
 auto; overflow-wrap: break-word; word-wrap: break-word; word-break: break-=
word;display: inline-block; width: 90%;max-width: 700px;min-width: 280px; t=
ext-align: left;" role=3D"presentation"><tr><td style=3D"padding: 0;"><div =
class=3D"flex flex-column flex-space-column-16px"><div><table style=3D"widt=
h:100%; table-layout:fixed;" role=3D"presentation"><tr><td style=3D"padding=
: 0;" dir=3D"ltr"><div id=3D"overview-card-contents"><div class=3D"flex fle=
x-column flex-space-column-12px"><div><h1 style=3D"color: #3c4043; font: 40=
0 18px Google Sans, Roboto, Arial, Helvetica, sans-serif; margin: 0;">Tretj=
achkov Rogaljaa (tretjachkovrogaljaahrnnb@gmail.com) mentioned you in a com=
ment in the following document</h1></div><div><div class=3D"flex flex-colum=
n flex-space-column-12px"><div id=3D"document-chip-section"><div id=3D"docu=
ment-chip"><a href=3D"https://docs.google.com/presentation/d/1jn0VoYpf9LR7q=
IBVQoUojAvVv3smQsnezp0f6k5Qfwo/edit?disco=3DAAAAon7N7QI&amp;usp=3Dcomment_e=
mail_document&amp;ts=3D63da5e34&amp;usp_dm=3Dtrue" target=3D"_blank" style=
=3D"color: #3c4043; display: inline-block; max-width: 100%; text-decoration=
: none; vertical-align: top;border: 1px solid #DADCE0; border-radius: 16px;=
 white-space: nowrap;min-width: 0;"><div style=3D"line-height: 18px; overfl=
ow: hidden; text-overflow: ellipsis;padding: 6px 12px;"><span style=3D"disp=
lay: inline-block; vertical-align: top; min-width: 26px; width: 26px;"><amp=
-img src=3D"https://ssl.gstatic.com/docs/doclist/images/mediatype/icon_1_pr=
esentation_x64.png" width=3D"18" height=3D"18" style=3D"vertical-align: top=
;" role=3D"presentation"></amp-img></span><span style=3D"font: 500 14px/18p=
x Google Sans, Roboto, Arial, Helvetica, sans-serif; display: inline; lette=
r-spacing: 0.2px;">Untitled presentation</span></div></a></div></div></div>=
</div></div></div></td></tr></table></div><div><table style=3D"width:100%; =
border: 1px solid #dadce0; border-radius: 8px; border-spacing: 0; table-lay=
out:fixed; border-collapse: separate;" role=3D"presentation"><tr><td style=
=3D"padding: 4.5%;" dir=3D"ltr"><div class=3D"flex flex-column flex-space-c=
olumn-20px"><div><div><table role=3D"presentation" cellpadding=3D"0" cellsp=
acing=3D"0" style=3D"width: 100%"><tr><td style=3D"vertical-align: top; wid=
th: 32px;"><div style=3D"background: #F1F3F4; border-radius: 50%; display: =
inline-block; height: 18px; padding: 7px; width: 18px;"><amp-img src=3D"htt=
ps://fonts.gstatic.com/s/i/googlematerialicons/comment/v18/gm_grey-48dp/1x/=
gm_comment_gm_grey_48dp.png" height=3D"18px" width=3D"18px" aria-hidden=3D"=
true" style=3D"flex-shrink: 0;"></amp-img></div></td><td style=3D"vertical-=
align: top;"><h2 style=3D"color: #3c4043; display: inline-block; font: 400 =
16px/32px Google Sans, Roboto, Arial, Helvetica, sans-serif; letter-spacing=
: .1px; margin: 0 0 0 10px;">1 comment</h2></td></tr></table><div><div styl=
e=3D"margin-top: 20px;overflow: visible; line-height: 20px;"><div style=3D"=
margin-top: 0px; word-break: break-word; word-wrap: break-word;"><table rol=
e=3D"presentation" cellpadding=3D"0" cellspacing=3D"0" style=3D"color: #3c4=
043; width: 100%;"><tr><td style=3D"vertical-align: top; width: 44px;"><amp=
-img src=3D"https://lh3.googleusercontent.com/a/AEdFTp4cmh8DYqajlGlmqg1JQ_i=
ykUOy-Ajgdm9d49Ba=3Ds50-c-k-no" alt=3D"" height=3D"32" width=3D"32" style=
=3D"border-radius: 50%;box-sizing: border-box; display: block;"></amp-img><=
/td><td><h3 style=3D"display: inline-block; font: 500 14px Google Sans, Rob=
oto, Arial, Helvetica, sans-serif; letter-spacing: .25px; line-height: 20px=
; margin: 6px 0 2px 0;">Tretjachkov Rogaljaa</h3> <span style=3D"color: #5F=
6368; font: 400 12px/16px Roboto, Arial, Helvetica, sans-serif; letter-spac=
ing: 0.2px; white-space: nowrap;">=E2=80=A2 7:37=E2=80=AFAM, Feb 1 (EST)</s=
pan><h4 style=3D"background: #1a73e8; border-radius: 8px; color: #fff; disp=
lay: inline-block; font: 700 12px/16px Roboto, Arial, Helvetica, sans-serif=
; margin-bottom: 0; margin-top: 0; margin-left: 10px; padding: 0 6px;">New<=
/h4><div style=3D"font: 400 14px Roboto, Arial, Helvetica, sans-serif; line=
-height: 20px; letter-spacing: .2px;"><div style=3D"margin-top: 6px;" class=
=3D"notranslate">Hello<br>For you a letter You have a new transfer of funds=
, you need to withdraw them<br>All information in the attached link: <a hre=
f=3D"https://www.google.com/url?q=3Dhttps://script.google.com/macros/s/AKfy=
cbyB7w6WEN9rrfxrGUZR0uJSJf0977R5blfQ86VcyzfOeSLVl98FusGwC_-BEq_B87aIcA/exec=
?hjb62k0n81pw5bfhyri&amp;sa=3DD&amp;source=3Deditors&amp;ust=3D167525864788=
3626&amp;usg=3DAOvVaw1cQpBXcDfBcDR5suqvPg3Q" target=3D"_blank">https://scri=
pt.google.com/macros/s/AKfycbyB7w6WEN9rrfxrGUZR0uJSJf0977R5blfQ86VcyzfOeSLV=
l98FusGwC_-BEq_B87aIcA/exec?hjb62k0n81pw5bfhyri</a><br><br>Read it!<br>You =
have 2 hours, to order your funds<br><br><br><br><br><br><br><br><br><br><b=
r><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><=
br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>=
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>@<a hre=
f=3D"mailto:opoggenpeace@gmail.com" target=3D"_blank">opoggenpeace@gmail.co=
m</a><br>@<a href=3D"mailto:sausagemafia@gmail.com" target=3D"_blank">sausa=
gemafia@gmail.com</a><br>@<a href=3D"mailto:morriscode@gmail.com" target=3D=
"_blank">morriscode@gmail.com</a><br>@<a href=3D"mailto:ykudjawu@gmail.com"=
 target=3D"_blank">ykudjawu@gmail.com</a><br>@<a href=3D"mailto:creovex@gma=
il.com" target=3D"_blank">creovex@gmail.com</a><br>@<a href=3D"mailto:chapp=
elle99@gmail.com" target=3D"_blank">chappelle99@gmail.com</a></div></div></=
td></tr></table></div><div style=3D"margin: 10px 0 0 42px; overflow: auto; =
padding: 2px;"><a href=3D"https://docs.google.com/presentation/d/1jn0VoYpf9=
LR7qIBVQoUojAvVv3smQsnezp0f6k5Qfwo/edit?disco=3DAAAAon7N7QI&amp;usp=3Dcomme=
nt_email_discussion&amp;ts=3D63da5e34&amp;usp_dm=3Dtrue" class=3D"material-=
button material-button-transparent" target=3D"_blank" tabindex=3D"0" role=
=3D"button" style=3D"padding: 0 8px;font: 500 14px/36px Google Sans, Roboto=
, Arial, Helvetica, sans-serif; border: none; border-radius: 18px; box-sizi=
ng: border-box; display: inline-block; letter-spacing: .25px; min-height: 3=
6px; text-align: center; text-decoration: none;float: right;">Open</a></div=
></div></div></div></div></div></td></tr></table></div></div><table style=
=3D"border-collapse: collapse; width: 100%;" role=3D"presentation"><tr><td =
style=3D"padding: 24px 4.5%"><table style=3D"border-collapse: collapse; wid=
th: 100%;" dir=3D"ltr"><tr><td style=3D"padding: 0;font-family: Roboto, Ari=
al, Helvetica, sans-serif; color: #5F6368; width: 100%; font-size: 12px; li=
ne-height: 16px; min-height: 40px; letter-spacing: .3px;"><p style=3D"margi=
n: 0; padding: 0;">Google LLC, 1600 Amphitheatre Parkway, Mountain View, CA=
 94043, USA<br><br>You have received this email because you are mentioned i=
n this thread by Tretjachkov Rogaljaa (tretjachkovrogaljaahrnnb@gmail.com).=
 If you don't want to receive files from this person, <a target=3D"_blank" =
style=3D"color: #1a73e8; text-decoration: none;" href=3D"https://drive.goog=
le.com/drive/blockuser?blockerEmail=3Dmorriscode@gmail.com&amp;blockeeEmail=
=3Dtretjachkovrogaljaahrnnb@gmail.com&amp;usp=3Dcommentnotification_MENTION=
ED">block the sender</a> from Drive. <a target=3D"_blank" style=3D"color: #=
1a73e8; text-decoration: none;" href=3D"https://docs.google.com/presentatio=
n/u/105138397256252213126/docos/notify?ouid=3D105138397256252213126&amp;id=
=3D1jn0VoYpf9LR7qIBVQoUojAvVv3smQsnezp0f6k5Qfwo&amp;title=3DUntitled+presen=
tation&amp;resourcekey">Change what Google sends you</a>. You can reply to =
this email to reply to the discussion.</p></td><td style=3D"padding: 0;padd=
ing-left: 20px; min-width: 96px"><amp-img src=3D"https://www.gstatic.com/im=
ages/branding/googlelogo/2x/googlelogo_tm_black54_color_96x40dp.png" width=
=3D"96px" height=3D"40px"></amp-img></td></tr></table></td></tr></table></t=
d></tr></table></td></tr></table></div><template type=3D"amp-mustache">{{#e=
ventInfos}}<table style=3D"border-collapse: collapse; width: 100%; backgrou=
nd-color: white; text-align: center;" role=3D"presentation"><tr><td style=
=3D"padding: 24px 0 16px 0;"><table style=3D"border-collapse: collapse;font=
-family: Roboto, Arial, Helvetica, sans-serif;hyphens: auto; overflow-wrap:=
 break-word; word-wrap: break-word; word-break: break-word;display: inline-=
block; width: 90%;max-width: 700px;min-width: 280px; text-align: left;" rol=
e=3D"presentation"><tr><td style=3D"padding: 0;"><div class=3D"flex flex-co=
lumn flex-space-column-16px"><div><table style=3D"width:100%; table-layout:=
fixed;" role=3D"presentation"><tr><td style=3D"padding: 0;" dir=3D"ltr"><di=
v id=3D"overview-card-contents"><div class=3D"flex flex-column flex-space-c=
olumn-12px"><div><h1 style=3D"color: #3c4043; font: 400 18px Google Sans, R=
oboto, Arial, Helvetica, sans-serif; margin: 0;">Tretjachkov Rogaljaa (tret=
jachkovrogaljaahrnnb@gmail.com) mentioned you in a comment in the following=
 document</h1></div><div><div class=3D"flex flex-column flex-space-column-1=
2px"><div id=3D"document-chip-section"><div id=3D"document-chip"><a href=3D=
"https://docs.google.com/presentation/d/1jn0VoYpf9LR7qIBVQoUojAvVv3smQsnezp=
0f6k5Qfwo/edit?disco=3DAAAAon7N7QI&amp;usp=3Dcomment_email_document&amp;ts=
=3D63da5e34&amp;usp_dm=3Dtrue" target=3D"_blank" style=3D"color: #3c4043; d=
isplay: inline-block; max-width: 100%; text-decoration: none; vertical-alig=
n: top;border: 1px solid #DADCE0; border-radius: 16px; white-space: nowrap;=
min-width: 0;"><div style=3D"line-height: 18px; overflow: hidden; text-over=
flow: ellipsis;padding: 6px 12px;"><span style=3D"display: inline-block; ve=
rtical-align: top; min-width: 26px; width: 26px;"><amp-img src=3D"https://s=
sl.gstatic.com/docs/doclist/images/mediatype/icon_1_presentation_x64.png" w=
idth=3D"18" height=3D"18" style=3D"vertical-align: top;" role=3D"presentati=
on"></amp-img></span><span style=3D"font: 500 14px/18px Google Sans, Roboto=
, Arial, Helvetica, sans-serif; display: inline; letter-spacing: 0.2px;">Un=
titled presentation</span></div></a></div>{{#subscriptions}}<div id=3D"subs=
cription-accordion" role=3D"button" tabindex=3D"0" aria-label=3D"Notificati=
on settings" aria-controls=3D"subscription-section" aria-expanded=3D"false"=
 data-amp-bind-aria-expanded=3D"!!(subscriptions &amp;&amp; subscriptions.e=
xpanded) ? 'true' : 'false'" on=3D"tap: AMP.setState({subscriptions: {expan=
ded: !!!(subscriptions &amp;&amp; subscriptions.expanded)}})"><div class=3D=
"flex align-center flex-space-row-8px"><div id=3D"subscription-accordion-ic=
on" aria-hidden=3D"true" class=3D"stack comments-{{comments.value}} {{#edit=
s}}edits-{{value}}{{/edits}}{{^edits}}edits-disabled{{/edits}}" data-amp-bi=
nd-class=3D"'stack comments-' + ( (subscriptions &amp;&amp; subscriptions.c=
omments &amp;&amp; subscriptions.comments.current) || &#39;{{comments.value=
}}&#39; ) +{{#edits}}' edits-' + ( (subscriptions &amp;&amp; subscriptions.=
edits &amp;&amp; subscriptions.edits.current) || &#39;{{edits.value}}&#39; =
){{/edits}}{{^edits}}' edits-disabled'{{/edits}}"><amp-img id=3D"subscripti=
on-accordion-icon-all" src=3D"https://fonts.gstatic.com/s/i/googlemateriali=
cons/notifications_active/v11/gm_grey-48dp/2x/gm_notifications_active_gm_gr=
ey_48dp.png" width=3D"24" height=3D"24"></amp-img><amp-img id=3D"subscripti=
on-accordion-icon-important" src=3D"https://fonts.gstatic.com/s/i/googlemat=
erialicons/notifications/v13/gm_grey-48dp/2x/gm_notifications_gm_grey_48dp.=
png" width=3D"24" height=3D"24"></amp-img><amp-img id=3D"subscription-accor=
dion-icon-none" src=3D"https://fonts.gstatic.com/s/i/googlematerialicons/no=
tifications_off/v10/gm_grey-48dp/2x/gm_notifications_off_gm_grey_48dp.png" =
width=3D"24" height=3D"24"></amp-img></div><div id=3D"subscription-accordio=
n-text" aria-hidden=3D"true">Notification settings</div><div id=3D"subscrip=
tion-accordion-arrow" class=3D"stack" aria-hidden=3D"true"><amp-img src=3D"=
https://fonts.gstatic.com/s/i/googlematerialicons/expand_more/v12/gm_grey-4=
8dp/2x/gm_expand_more_gm_grey_48dp.png" width=3D"24" height=3D"24" data-amp=
-bind-class=3D"!!(subscriptions &amp;&amp; subscriptions.expanded) ? 'hidde=
n' : 'visible'"></amp-img><amp-img src=3D"https://fonts.gstatic.com/s/i/goo=
glematerialicons/expand_less/v10/gm_grey-48dp/2x/gm_expand_less_gm_grey_48d=
p.png" width=3D"24" height=3D"24" class=3D"hidden" data-amp-bind-class=3D"!=
!(subscriptions &amp;&amp; subscriptions.expanded) ? 'visible' : 'hidden'">=
</amp-img></div></div></div>{{/subscriptions}}</div>{{#subscriptions}}<div =
id=3D"subscription-section" role=3D"region" aria-labelledby=3D"subscription=
-accordion" class=3D"none" data-amp-bind-class=3D"!!(subscriptions &amp;&am=
p; subscriptions.expanded) ? 'block' : 'none'"><div style=3D"margin: 18px 0=
;height: 1px; background-color: #eee;"></div><div id=3D"subscription-contro=
ls">{{#comments}}<form id=3D"comments-subscription-form" class=3D"subscript=
ion-form" action-xhr=3D"https://docs.google.com/presentation/d/1jn0VoYpf9LR=
7qIBVQoUojAvVv3smQsnezp0f6k5Qfwo/dynamicmail/subscribe?emailToken=3DAORGpRe=
rTI31-5bTwsp2ANP-H0A9SxWyQeVWQJMgIK86nVAZjGVIDwyeuKEpeGKbykM3qBijQcq3S9Uy7s=
nwAj9suv1NhWFyEfiDCJI_5lnoafovP_MBZuzuH921cv3yb8k7g1-nV3cv&amp;buildLabel=
=3Deditors.presentations-frontend_20230124.02_p0&amp;clientVersion=3D3&amp;=
emailType=3Dcomments&amp;ts=3D63da5e34" method=3D"post" on=3D"submit-succes=
s: AMP.setState({subscriptions: {comments: {next: null}}}); submit-error: A=
MP.setState({subscriptions: {comments: {current: subscriptions.comments.pre=
vious, next: null}, error: true}});"><input type=3D"hidden" name=3D"type" v=
alue=3D"comments"><input type=3D"hidden" name=3D"value" data-amp-bind-value=
=3D"subscriptions.comments.next"><label for=3D"comments-subscription-native=
-select"><span>Comments</span><span class=3D"subscription-measuring-label" =
aria-hidden=3D"true">Comments<br>Edits</span></label><div id=3D"comments-su=
bscription-select" class=3D"subscription-select"><select id=3D"comments-sub=
scription-native-select" class=3D"subscription-native-select" on=3D"change:=
 AMP.setState({subscriptions: {comments: {previous: ( (subscriptions &amp;&=
amp; subscriptions.comments &amp;&amp; subscriptions.comments.current) || &=
#39;{{comments.value}}&#39; ), current: event.value, next: event.value}, er=
ror: false}}),comments-subscription-form.submit;" data-amp-bind-disabled=3D=
"!!(subscriptions &amp;&amp; ( (subscriptions.comments &amp;&amp; subscript=
ions.comments.next) || (subscriptions.edits &amp;&amp; subscriptions.edits.=
next) ))">{{#options.all}}<option value=3D"all" data-amp-bind-disabled=3D"!=
!(subscriptions &amp;&amp; ( (subscriptions.comments &amp;&amp; subscriptio=
ns.comments.next) || (subscriptions.edits &amp;&amp; subscriptions.edits.ne=
xt) ))" selected data-amp-bind-selected=3D"( (subscriptions &amp;&amp; subs=
criptions.comments &amp;&amp; subscriptions.comments.current) || &#39;{{com=
ments.value}}&#39; ) =3D=3D 'all'">All</option>{{/options.all}}{{^options.a=
ll}}<option value=3D"all" data-amp-bind-disabled=3D"!!(subscriptions &amp;&=
amp; ( (subscriptions.comments &amp;&amp; subscriptions.comments.next) || (=
subscriptions.edits &amp;&amp; subscriptions.edits.next) ))" data-amp-bind-=
selected=3D"( (subscriptions &amp;&amp; subscriptions.comments &amp;&amp; s=
ubscriptions.comments.current) || &#39;{{comments.value}}&#39; ) =3D=3D 'al=
l'">All</option>{{/options.all}}{{#options.important}}<option value=3D"impo=
rtant" data-amp-bind-disabled=3D"!!(subscriptions &amp;&amp; ( (subscriptio=
ns.comments &amp;&amp; subscriptions.comments.next) || (subscriptions.edits=
 &amp;&amp; subscriptions.edits.next) ))" selected data-amp-bind-selected=
=3D"( (subscriptions &amp;&amp; subscriptions.comments &amp;&amp; subscript=
ions.comments.current) || &#39;{{comments.value}}&#39; ) =3D=3D 'important'=
">For you</option>{{/options.important}}{{^options.important}}<option value=
=3D"important" data-amp-bind-disabled=3D"!!(subscriptions &amp;&amp; ( (sub=
scriptions.comments &amp;&amp; subscriptions.comments.next) || (subscriptio=
ns.edits &amp;&amp; subscriptions.edits.next) ))" data-amp-bind-selected=3D=
"( (subscriptions &amp;&amp; subscriptions.comments &amp;&amp; subscription=
s.comments.current) || &#39;{{comments.value}}&#39; ) =3D=3D 'important'">F=
or you</option>{{/options.important}}{{#options.none}}<option value=3D"none=
" data-amp-bind-disabled=3D"!!(subscriptions &amp;&amp; ( (subscriptions.co=
mments &amp;&amp; subscriptions.comments.next) || (subscriptions.edits &amp=
;&amp; subscriptions.edits.next) ))" selected data-amp-bind-selected=3D"( (=
subscriptions &amp;&amp; subscriptions.comments &amp;&amp; subscriptions.co=
mments.current) || &#39;{{comments.value}}&#39; ) =3D=3D 'none'">None</opti=
on>{{/options.none}}{{^options.none}}<option value=3D"none" data-amp-bind-d=
isabled=3D"!!(subscriptions &amp;&amp; ( (subscriptions.comments &amp;&amp;=
 subscriptions.comments.next) || (subscriptions.edits &amp;&amp; subscripti=
ons.edits.next) ))" data-amp-bind-selected=3D"( (subscriptions &amp;&amp; s=
ubscriptions.comments &amp;&amp; subscriptions.comments.current) || &#39;{{=
comments.value}}&#39; ) =3D=3D 'none'">None</option>{{/options.none}}</sele=
ct><div class=3D"subscription-custom-select" aria-hidden=3D"true" data-amp-=
bind-class=3D"'subscription-custom-select' + (!!(subscriptions &amp;&amp; (=
 (subscriptions.comments &amp;&amp; subscriptions.comments.next) || (subscr=
iptions.edits &amp;&amp; subscriptions.edits.next) )) ? ' disabled' : '')">=
<div class=3D"subscription-custom-select-labels"><span class=3D"{{#options.=
all}}inline{{/options.all}}{{^options.all}}none{{/options.all}}" data-amp-b=
ind-class=3D"( (subscriptions &amp;&amp; subscriptions.comments &amp;&amp; =
subscriptions.comments.current) || &#39;{{comments.value}}&#39; ) =3D=3D 'a=
ll' ? 'inline' : 'none'">All</span><span class=3D"subscription-measuring-la=
bel">All</span><span class=3D"{{#options.important}}inline{{/options.import=
ant}}{{^options.important}}none{{/options.important}}" data-amp-bind-class=
=3D"( (subscriptions &amp;&amp; subscriptions.comments &amp;&amp; subscript=
ions.comments.current) || &#39;{{comments.value}}&#39; ) =3D=3D 'important'=
 ? 'inline' : 'none'">For you</span><span class=3D"subscription-measuring-l=
abel">For you</span><span class=3D"{{#options.none}}inline{{/options.none}}=
{{^options.none}}none{{/options.none}}" data-amp-bind-class=3D"( (subscript=
ions &amp;&amp; subscriptions.comments &amp;&amp; subscriptions.comments.cu=
rrent) || &#39;{{comments.value}}&#39; ) =3D=3D 'none' ? 'inline' : 'none'"=
>None</span><span class=3D"subscription-measuring-label">None</span></div><=
div class=3D"subscription-custom-select-arrow">&nbsp;</div></div></div></fo=
rm>{{/comments}}{{#edits}}<form id=3D"edits-subscription-form" class=3D"sub=
scription-form" action-xhr=3D"https://docs.google.com/presentation/d/1jn0Vo=
Ypf9LR7qIBVQoUojAvVv3smQsnezp0f6k5Qfwo/dynamicmail/subscribe?emailToken=3DA=
ORGpRerTI31-5bTwsp2ANP-H0A9SxWyQeVWQJMgIK86nVAZjGVIDwyeuKEpeGKbykM3qBijQcq3=
S9Uy7snwAj9suv1NhWFyEfiDCJI_5lnoafovP_MBZuzuH921cv3yb8k7g1-nV3cv&amp;buildL=
abel=3Deditors.presentations-frontend_20230124.02_p0&amp;clientVersion=3D3&=
amp;emailType=3Dcomments&amp;ts=3D63da5e34" method=3D"post" on=3D"submit-su=
ccess: AMP.setState({subscriptions: {edits: {next: null}}}); submit-error: =
AMP.setState({subscriptions: {edits: {current: subscriptions.edits.previous=
, next: null}, error: true}});"><input type=3D"hidden" name=3D"type" value=
=3D"edits"><input type=3D"hidden" name=3D"value" data-amp-bind-value=3D"sub=
scriptions.edits.next"><label for=3D"edits-subscription-native-select"><spa=
n>Edits</span><span class=3D"subscription-measuring-label" aria-hidden=3D"t=
rue">Comments<br>Edits</span></label><div id=3D"edits-subscription-select" =
class=3D"subscription-select"><select id=3D"edits-subscription-native-selec=
t" class=3D"subscription-native-select" on=3D"change: AMP.setState({subscri=
ptions: {edits: {previous: ( (subscriptions &amp;&amp; subscriptions.edits =
&amp;&amp; subscriptions.edits.current) || &#39;{{edits.value}}&#39; ), cur=
rent: event.value, next: event.value}, error: false}}),edits-subscription-f=
orm.submit;" data-amp-bind-disabled=3D"!!(subscriptions &amp;&amp; ( (subsc=
riptions.comments &amp;&amp; subscriptions.comments.next) || (subscriptions=
.edits &amp;&amp; subscriptions.edits.next) ))">{{#options.true}}<option va=
lue=3D"true" data-amp-bind-disabled=3D"!!(subscriptions &amp;&amp; ( (subsc=
riptions.comments &amp;&amp; subscriptions.comments.next) || (subscriptions=
.edits &amp;&amp; subscriptions.edits.next) ))" selected data-amp-bind-sele=
cted=3D"( (subscriptions &amp;&amp; subscriptions.edits &amp;&amp; subscrip=
tions.edits.current) || &#39;{{edits.value}}&#39; ) =3D=3D 'true'">Added or=
 removed content</option>{{/options.true}}{{^options.true}}<option value=3D=
"true" data-amp-bind-disabled=3D"!!(subscriptions &amp;&amp; ( (subscriptio=
ns.comments &amp;&amp; subscriptions.comments.next) || (subscriptions.edits=
 &amp;&amp; subscriptions.edits.next) ))" data-amp-bind-selected=3D"( (subs=
criptions &amp;&amp; subscriptions.edits &amp;&amp; subscriptions.edits.cur=
rent) || &#39;{{edits.value}}&#39; ) =3D=3D 'true'">Added or removed conten=
t</option>{{/options.true}}{{#options.false}}<option value=3D"false" data-a=
mp-bind-disabled=3D"!!(subscriptions &amp;&amp; ( (subscriptions.comments &=
amp;&amp; subscriptions.comments.next) || (subscriptions.edits &amp;&amp; s=
ubscriptions.edits.next) ))" selected data-amp-bind-selected=3D"( (subscrip=
tions &amp;&amp; subscriptions.edits &amp;&amp; subscriptions.edits.current=
) || &#39;{{edits.value}}&#39; ) =3D=3D 'false'">None</option>{{/options.fa=
lse}}{{^options.false}}<option value=3D"false" data-amp-bind-disabled=3D"!!=
(subscriptions &amp;&amp; ( (subscriptions.comments &amp;&amp; subscription=
s.comments.next) || (subscriptions.edits &amp;&amp; subscriptions.edits.nex=
t) ))" data-amp-bind-selected=3D"( (subscriptions &amp;&amp; subscriptions.=
edits &amp;&amp; subscriptions.edits.current) || &#39;{{edits.value}}&#39; =
) =3D=3D 'false'">None</option>{{/options.false}}</select><div class=3D"sub=
scription-custom-select" aria-hidden=3D"true" data-amp-bind-class=3D"'subsc=
ription-custom-select' + (!!(subscriptions &amp;&amp; ( (subscriptions.comm=
ents &amp;&amp; subscriptions.comments.next) || (subscriptions.edits &amp;&=
amp; subscriptions.edits.next) )) ? ' disabled' : '')"><div class=3D"subscr=
iption-custom-select-labels"><span class=3D"{{#options.true}}inline{{/optio=
ns.true}}{{^options.true}}none{{/options.true}}" data-amp-bind-class=3D"( (=
subscriptions &amp;&amp; subscriptions.edits &amp;&amp; subscriptions.edits=
.current) || &#39;{{edits.value}}&#39; ) =3D=3D 'true' ? 'inline' : 'none'"=
>Added or removed content</span><span class=3D"subscription-measuring-label=
">Added or removed content</span><span class=3D"{{#options.false}}inline{{/=
options.false}}{{^options.false}}none{{/options.false}}" data-amp-bind-clas=
s=3D"( (subscriptions &amp;&amp; subscriptions.edits &amp;&amp; subscriptio=
ns.edits.current) || &#39;{{edits.value}}&#39; ) =3D=3D 'false' ? 'inline' =
: 'none'">None</span><span class=3D"subscription-measuring-label">None</spa=
n></div><div class=3D"subscription-custom-select-arrow">&nbsp;</div></div><=
/div></form>{{/edits}}<span id=3D"subscription-controls-notice" class=3D"no=
ne" data-amp-bind-class=3D"subscriptions && subscriptions.error ? 'block' :=
 'none'">Something went wrong, please retry</span></div></div>{{/subscripti=
ons}}</div></div></div></div></td></tr></table></div><div><table style=3D"w=
idth:100%; border: 1px solid #dadce0; border-radius: 8px; border-spacing: 0=
; table-layout:fixed; border-collapse: separate;" role=3D"presentation"><tr=
><td style=3D"padding: 4.5%;" dir=3D"ltr"><div class=3D"flex flex-column fl=
ex-space-column-20px"><div><div><table role=3D"presentation" cellpadding=3D=
"0" cellspacing=3D"0" style=3D"width: 100%"><tr><td style=3D"vertical-align=
: top; width: 32px;"><div style=3D"background: #F1F3F4; border-radius: 50%;=
 display: inline-block; height: 18px; padding: 7px; width: 18px;"><amp-img =
src=3D"https://fonts.gstatic.com/s/i/googlematerialicons/comment/v18/gm_gre=
y-48dp/1x/gm_comment_gm_grey_48dp.png" height=3D"18px" width=3D"18px" aria-=
hidden=3D"true" style=3D"flex-shrink: 0;"></amp-img></div></td><td style=3D=
"vertical-align: top;"><h2 style=3D"color: #3c4043; display: inline-block; =
font: 400 16px/32px Google Sans, Roboto, Arial, Helvetica, sans-serif; lett=
er-spacing: .1px; margin: 0 0 0 10px;">1 comment</h2></td></tr></table><div=
 class=3D"discussions-container">{{#openCommentsAndTodos}}<div id=3D"discus=
sion-{{docoId}}" style=3D"overflow: visible; line-height: 20px;">{{^isDelet=
ed}}{{#htmlQuote}}<div class=3D"document-content-snippet" style=3D"border: =
1px solid #DADCE0; border-radius: 8px; padding: 12px 16px;hyphens: auto; ov=
erflow-wrap: break-word; word-wrap: break-word; word-break: break-word;"><s=
pan class=3D"notranslate" style=3D"font: 400 14px Roboto, Arial, Helvetica,=
 sans-serif; line-height: 20px; color: #3c4043;">{{{htmlQuote}}}</span></di=
v><div style=3D"height: 18px;"></div>{{/htmlQuote}}{{#posts}}<div class=3D"=
{{#isHeadPost}}head-post{{/isHeadPost}}{{^isHeadPost}}reply-post{{/isHeadPo=
st}}"><table role=3D"presentation" cellpadding=3D"0" cellspacing=3D"0" styl=
e=3D"width: 100%;" class=3D"{{#isNew}}post-dark-text{{/isNew}}{{^isNew}}pos=
t-light-text{{/isNew}}"><tr><td style=3D"vertical-align: top; width: 44px;"=
><amp-img src=3D"{{authorPhotoUrl}}" alt=3D"" height=3D"32" width=3D"32" st=
yle=3D"border-radius: 50%;box-sizing: border-box; display: block;"></amp-im=
g></td><td><h3 style=3D"display: inline-block; font: 500 14px Google Sans, =
Roboto, Arial, Helvetica, sans-serif; letter-spacing: .25px; line-height: 2=
0px; margin: 6px 0 2px 0;">{{authorName}}</h3>{{#creationTime}} <span style=
=3D"color: #5F6368; font: 400 12px/16px Roboto, Arial, Helvetica, sans-seri=
f; letter-spacing: 0.2px; white-space: nowrap;">=E2=80=A2 {{creationTime}}<=
/span>{{/creationTime}}{{#isNew}}<h4 style=3D"background: #1a73e8; border-r=
adius: 8px; color: #fff; display: inline-block; font: 700 12px/16px Roboto,=
 Arial, Helvetica, sans-serif; margin-bottom: 0; margin-top: 0; margin-left=
: 10px; padding: 0 6px;">New</h4>{{/isNew}}<div style=3D"font: 400 14px Rob=
oto, Arial, Helvetica, sans-serif; line-height: 20px; letter-spacing: .2px;=
">{{#htmlBody}}<div style=3D"margin-top: 6px;" class=3D"notranslate">{{{htm=
lBody}}}</div>{{/htmlBody}}{{#htmlActionText}}<div style=3D"margin-top: 6px=
;"><i>{{{htmlActionText}}}</i></div>{{/htmlActionText}}{{#showCopiedText}}<=
div style=3D"margin: 18px 0;height: 1px; background-color: #eee;"></div><di=
v style=3D"color: #3c4043; font: italic 14px Roboto, Arial, Helvetica, sans=
-serif; margin: 18px 0 6px 0; width: 100%;">Comments above copied from orig=
inal document</div>{{/showCopiedText}}</div></td></tr></table></div>{{/post=
s}}{{/isDeleted}}{{#isDeleted}}<div style=3D"color: #3c4043; font: italic 1=
4px Roboto, Arial, Helvetica, sans-serif; margin: 0 0 6px 0; width: 100%;">=
Comment was deleted</div>{{/isDeleted}}{{#canResolve}}<form id=3D"resolve-f=
orm-{{docoId}}" method=3D"post" action-xhr=3D"https://docs.google.com/prese=
ntation/d/1jn0VoYpf9LR7qIBVQoUojAvVv3smQsnezp0f6k5Qfwo/dynamicmail/resolve?=
emailToken=3DAORGpRerTI31-5bTwsp2ANP-H0A9SxWyQeVWQJMgIK86nVAZjGVIDwyeuKEpeG=
KbykM3qBijQcq3S9Uy7snwAj9suv1NhWFyEfiDCJI_5lnoafovP_MBZuzuH921cv3yb8k7g1-nV=
3cv&amp;buildLabel=3Deditors.presentations-frontend_20230124.02_p0&amp;clie=
ntVersion=3D3&amp;emailType=3Dcomments&amp;ts=3D63da5e34" on=3D"submit-succ=
ess: discussionList.refresh, AMP.setState({scope: {'pendingReply{{docoId}}'=
: false}, pendingReplies: {'{{docoId}}': ''}, cachedReplies: {'{{docoId}}':=
 ''}}); submit: discussion-{{docoId}}.toggleClass('class' =3D 'resolving-di=
scussion'), AMP.setState({scope: {'replyButton{{docoId}}Disabled': true, 'p=
endingReply{{docoId}}': true}, cachedReplies: pendingReplies}); submit-erro=
r: discussion-{{docoId}}.toggleClass('class' =3D 'submit-error', force=3Dtr=
ue), discussion-{{docoId}}.toggleClass('class' =3D 'resolving-discussion'),=
 AMP.setState({scope: {'replyButton{{docoId}}Disabled': pendingReplies['{{d=
ocoId}}'] =3D=3D null || pendingReplies['{{docoId}}'] =3D=3D '', 'pendingRe=
ply{{docoId}}': false}});"><div submit-success template=3D"inline-action-po=
st"></div><input type=3D"hidden" name=3D"replyText" data-amp-bind-value=3D"=
pendingReplies['{{docoId}}']"><input type=3D"hidden" name=3D"commentId" val=
ue=3D"{{docoId}}"><input type=3D"hidden" name=3D"clientId" value=3D"{{reply=
ClientId}}"></form>{{/canResolve}}{{#canReply}}<form id=3D"reply-form-{{doc=
oId}}" method=3D"post" autocomplete=3D"off" action-xhr=3D"https://docs.goog=
le.com/presentation/d/1jn0VoYpf9LR7qIBVQoUojAvVv3smQsnezp0f6k5Qfwo/dynamicm=
ail/reply?emailToken=3DAORGpRerTI31-5bTwsp2ANP-H0A9SxWyQeVWQJMgIK86nVAZjGVI=
DwyeuKEpeGKbykM3qBijQcq3S9Uy7snwAj9suv1NhWFyEfiDCJI_5lnoafovP_MBZuzuH921cv3=
yb8k7g1-nV3cv&amp;buildLabel=3Deditors.presentations-frontend_20230124.02_p=
0&amp;clientVersion=3D3&amp;emailType=3Dcomments&amp;ts=3D63da5e34" custom-=
validation-reporting=3D"as-you-go" on=3D"submit-success: discussionList.ref=
resh, AMP.setState({scope: {'pendingReply{{docoId}}': false}, pendingReplie=
s: {'{{docoId}}': ''}, cachedReplies: {'{{docoId}}': ''}}); submit: discuss=
ion-{{docoId}}.toggleClass('class' =3D 'submitting-reply'), AMP.setState({s=
cope: {'replyButton{{docoId}}Disabled': true, 'pendingReply{{docoId}}': tru=
e}, cachedReplies: pendingReplies}); submit-error: discussion-{{docoId}}.to=
ggleClass('class' =3D 'submit-error', force=3Dtrue), discussion-{{docoId}}.=
toggleClass('class' =3D 'submitting-reply'), AMP.setState({scope: {'replyBu=
tton{{docoId}}Disabled': false, 'pendingReply{{docoId}}': false}}); valid: =
AMP.setState({scope: {'replyButton{{docoId}}Disabled': false}}); invalid: A=
MP.setState({scope: {'replyButton{{docoId}}Disabled': true}});"><div submit=
-success template=3D"inline-action-post"></div><div class=3D"reply-form-tex=
tarea" style=3D"margin-top: 12px; word-break: break-word; word-wrap: break-=
word;"><table role=3D"presentation" cellpadding=3D"0" cellspacing=3D"0" sty=
le=3D"width: 100%;"><tr><td style=3D"vertical-align: top; width: 44px; padd=
ing-top: 11px;"><amp-img src=3D"{{requestor.photoUrl}}" alt=3D"" height=3D"=
32" width=3D"32" style=3D"border-radius: 50%;box-sizing: border-box; displa=
y: block;"></amp-img></td><td><textarea autoexpand style=3D"font-family: Ro=
boto, Arial, Helvetica, sans-serif; font-size: 14px; background-color: #f8f=
9fa; border-radius: 4px 4px 0 0; box-sizing: border-box; color: #3c4043; he=
ight: 54px; letter-spacing: .2px; line-height: 20px; outline: none; padding=
: 16px 10px; resize: none; width: 100%; word-break: break-word; vertical-al=
ign: top;" class=3D"material-text-input" name=3D"replyText" autocomplete=3D=
"off" placeholder=3D"Reply" maxlength=3D"2048" on=3D"input-throttled: AMP.s=
etState({pendingReplies: {'{{docoId}}': event.value}});" data-amp-bind-text=
=3D"cachedReplies['{{docoId}}'] || ''" data-amp-bind-disabled=3D"scope['pen=
dingReply{{docoId}}']" pattern=3D".*\\S+.*" aria-label=3D"Reply" required></=
textarea><input type=3D"hidden" name=3D"commentId" value=3D"{{docoId}}"><in=
put type=3D"hidden" name=3D"clientId" value=3D"{{replyClientId}}"></td></tr=
></table></div></form>{{/canReply}}<div style=3D"margin: 10px 0 0 42px; ove=
rflow: auto; padding: 2px;">{{#canReply}}<input id=3D"discussion-reply-butt=
on-{{docoId}}" type=3D"submit" style=3D"padding: 0 8px;font: 500 14px/36px =
Google Sans, Roboto, Arial, Helvetica, sans-serif; border: none; border-rad=
ius: 18px; box-sizing: border-box; display: inline-block; letter-spacing: .=
25px; min-height: 36px; text-align: center; text-decoration: none;margin-ri=
ght: 12px;" role=3D"button" on=3D"tap:reply-form-{{docoId}}.submit()" class=
=3D"material-button material-button-transparent" value=3D"Reply" title=3D"R=
eply to comment" disabled data-amp-bind-disabled=3D"scope['replyButton{{doc=
oId}}Disabled']" tabindex=3D"0">{{/canReply}}{{#canResolve}}<input id=3D"di=
scussion-resolve-button-{{docoId}}" type=3D"submit" style=3D"padding: 0 8px=
;font: 500 14px/36px Google Sans, Roboto, Arial, Helvetica, sans-serif; bor=
der: none; border-radius: 18px; box-sizing: border-box; display: inline-blo=
ck; letter-spacing: .25px; min-height: 36px; text-align: center; text-decor=
ation: none;margin-right: 12px;" role=3D"button" on=3D"tap:resolve-form-{{d=
ocoId}}.submit()" class=3D"material-button material-button-transparent reso=
lve-button" value=3D"{{#isTodo}}Mark as done{{/isTodo}}{{^isTodo}}Resolve{{=
/isTodo}}" title=3D"{{#isTodo}}Mark action item as done{{/isTodo}}{{^isTodo=
}}Mark as resolved{{/isTodo}}" tabindex=3D"0">{{/canResolve}}<a id=3D"discu=
ssion-open-button-{{docoId}}" href=3D"{{discussionLink}}" class=3D"material=
-button material-button-transparent discussion-open-button" target=3D"_blan=
k" tabindex=3D"0" role=3D"button" style=3D"padding: 0 8px;font: 500 14px/36=
px Google Sans, Roboto, Arial, Helvetica, sans-serif; border: none; border-=
radius: 18px; box-sizing: border-box; display: inline-block; letter-spacing=
: .25px; min-height: 36px; text-align: center; text-decoration: none;">Open=
</a></div><div style=3D"color: #d93025; font: 14px Roboto, Arial, Helvetica=
, sans-serif; height: 36px; line-height: 36px; letter-spacing: 0.25px; marg=
in-left: 36px; padding-left: 8px;" class=3D"reply-error-text">Something wen=
t wrong, please retry</div></div>{{/openCommentsAndTodos}}</div></div></div=
></div></td></tr></table></div></div><table style=3D"border-collapse: colla=
pse; width: 100%;" role=3D"presentation"><tr><td style=3D"padding: 24px 4.5=
%"><table style=3D"border-collapse: collapse; width: 100%;" dir=3D"ltr"><tr=
><td style=3D"padding: 0;font-family: Roboto, Arial, Helvetica, sans-serif;=
 color: #5F6368; width: 100%; font-size: 12px; line-height: 16px; min-heigh=
t: 40px; letter-spacing: .3px;"><p style=3D"margin: 0; padding: 0;">Google =
LLC, 1600 Amphitheatre Parkway, Mountain View, CA 94043, USA<br><br>You hav=
e received this email because you are mentioned in this thread by Tretjachk=
ov Rogaljaa (tretjachkovrogaljaahrnnb@gmail.com). If you don't want to rece=
ive files from this person, <a target=3D"_blank" style=3D"color: #1a73e8; t=
ext-decoration: none;" href=3D"https://drive.google.com/drive/blockuser?blo=
ckerEmail=3Dmorriscode@gmail.com&amp;blockeeEmail=3Dtretjachkovrogaljaahrnn=
b@gmail.com&amp;usp=3Dcommentnotification_MENTIONED">block the sender</a> f=
rom Drive. <a target=3D"_blank" style=3D"color: #1a73e8; text-decoration: n=
one;" href=3D"https://docs.google.com/presentation/u/105138397256252213126/=
docos/notify?ouid=3D105138397256252213126&amp;id=3D1jn0VoYpf9LR7qIBVQoUojAv=
Vv3smQsnezp0f6k5Qfwo&amp;title=3DUntitled+presentation&amp;resourcekey">Cha=
nge what Google sends you</a>. You can reply to this email to reply to the =
discussion.</p></td><td style=3D"padding: 0;padding-left: 20px; min-width: =
96px"><amp-img src=3D"https://www.gstatic.com/images/branding/googlelogo/2x=
/googlelogo_tm_black54_color_96x40dp.png" width=3D"96px" height=3D"40px"></=
amp-img></td></tr></table></td></tr></table></td></tr></table></td></tr></t=
able>{{/eventInfos}}</template></amp-list></div></body></html>
--000000000000f7932305f3a2c788
Content-Type: text/html; charset="UTF-8"
Content-Transfer-Encoding: quoted-printable

<div itemscope itemtype=3D"http://schema.org/EmailMessage" style=3D"font: 1=
4px Roboto, Arial, Helvetica, sans-serif;"><div itemprop=3D"about" itemscop=
e itemtype=3D"http://schema.org/CreativeWork"><meta itemprop=3D"name" conte=
nt=3D"Untitled presentation"><meta itemprop=3D"url" content=3D"https://docs=
.google.com/presentation/d/1jn0VoYpf9LR7qIBVQoUojAvVv3smQsnezp0f6k5Qfwo/edi=
t?disco=3DAAAAon7N7QI&amp;usp=3Dcomment_email_document&amp;ts=3D63da5e34"><=
table style=3D"border-collapse: collapse; width: 100%; background-color: wh=
ite; text-align: center;" role=3D"presentation"><tr><td style=3D"padding: 2=
4px 0 16px 0;"><table style=3D"border-collapse: collapse;font-family: Robot=
o, Arial, Helvetica, sans-serif;hyphens: auto; overflow-wrap: break-word; w=
ord-wrap: break-word; word-break: break-word;display: inline-block; width: =
90%;max-width: 700px;min-width: 280px; text-align: left;" role=3D"presentat=
ion"><tr><td style=3D"padding: 0;"><div><div><table style=3D"width:100%; ta=
ble-layout:fixed;" role=3D"presentation"><tr><td style=3D"padding: 0;" dir=
=3D"ltr"><div id=3D"overview-card-contents"><div><div><h1 style=3D"color: #=
3c4043; font: 400 18px Google Sans, Roboto, Arial, Helvetica, sans-serif; m=
argin: 0;">Tretjachkov Rogaljaa (tretjachkovrogaljaahrnnb@gmail.com) mentio=
ned you in a comment in the following document</h1></div><div style=3D"marg=
in-top: 12px;"><div><div><div id=3D"document-chip-section"><div id=3D"docum=
ent-chip"><a href=3D"https://docs.google.com/presentation/d/1jn0VoYpf9LR7qI=
BVQoUojAvVv3smQsnezp0f6k5Qfwo/edit?disco=3DAAAAon7N7QI&amp;usp=3Dcomment_em=
ail_document&amp;ts=3D63da5e34&amp;usp_dm=3Dfalse" target=3D"_blank" style=
=3D"color: #3c4043; display: inline-block; max-width: 100%; text-decoration=
: none; vertical-align: top;border: 1px solid #DADCE0; border-radius: 16px;=
 white-space: nowrap;min-width: 0;"><div style=3D"line-height: 18px; overfl=
ow: hidden; text-overflow: ellipsis;padding: 6px 12px;"><span style=3D"disp=
lay: inline-block; vertical-align: top; min-width: 26px; width: 26px;"><img=
 src=3D"https://ssl.gstatic.com/docs/doclist/images/mediatype/icon_1_presen=
tation_x64.png" width=3D"18" height=3D"18" style=3D"vertical-align: top;" r=
ole=3D"presentation"></span><span style=3D"font: 500 14px/18px Google Sans,=
 Roboto, Arial, Helvetica, sans-serif; display: inline; letter-spacing: 0.2=
px;">Untitled presentation</span></div></a></div></div></div></div></div></=
div></div></td></tr></table></div><div style=3D"margin-top: 16px;"><table s=
tyle=3D"width:100%; border: 1px solid #dadce0; border-radius: 8px; border-s=
pacing: 0; table-layout:fixed; border-collapse: separate;" role=3D"presenta=
tion"><tr><td style=3D"padding: 4.5%;" dir=3D"ltr"><div><div><div><table ro=
le=3D"presentation" cellpadding=3D"0" cellspacing=3D"0" style=3D"width: 100=
%"><tr><td style=3D"vertical-align: top; width: 32px;"><div style=3D"backgr=
ound: #F1F3F4; border-radius: 50%; display: inline-block; height: 18px; pad=
ding: 7px; width: 18px;"><img src=3D"https://fonts.gstatic.com/s/i/googlema=
terialicons/comment/v18/gm_grey-48dp/1x/gm_comment_gm_grey_48dp.png" height=
=3D"18px" width=3D"18px" aria-hidden=3D"true" style=3D"flex-shrink: 0;"></d=
iv></td><td style=3D"vertical-align: top;"><h2 style=3D"color: #3c4043; dis=
play: inline-block; font: 400 16px/32px Google Sans, Roboto, Arial, Helveti=
ca, sans-serif; letter-spacing: .1px; margin: 0 0 0 10px;">1 comment</h2></=
td></tr></table><div itemprop=3D"action" itemscope itemtype=3D"http://schem=
a.org/ViewAction"><meta itemprop=3D"url" content=3D"https://docs.google.com=
/presentation/d/1jn0VoYpf9LR7qIBVQoUojAvVv3smQsnezp0f6k5Qfwo/edit?disco=3DA=
AAAon7N7QI&amp;usp=3Dcomment_email_discussion&amp;ts=3D63da5e34"><meta item=
prop=3D"name" content=3D"Open Discussion"></div><div><div style=3D"margin-t=
op: 20px;overflow: visible; line-height: 20px;"><div style=3D"margin-top: 0=
px; word-break: break-word; word-wrap: break-word;"><table role=3D"presenta=
tion" cellpadding=3D"0" cellspacing=3D"0" style=3D"color: #3c4043; width: 1=
00%;"><tr><td style=3D"vertical-align: top; width: 44px;"><img src=3D"https=
://lh3.googleusercontent.com/a/AEdFTp4cmh8DYqajlGlmqg1JQ_iykUOy-Ajgdm9d49Ba=
=3Ds50-c-k-no" alt=3D"" height=3D"32" width=3D"32" style=3D"border-radius: =
50%;box-sizing: border-box; display: block;"></td><td><h3 style=3D"display:=
 inline-block; font: 500 14px Google Sans, Roboto, Arial, Helvetica, sans-s=
erif; letter-spacing: .25px; line-height: 20px; margin: 6px 0 2px 0;">Tretj=
achkov Rogaljaa</h3> <span style=3D"color: #5F6368; font: 400 12px/16px Rob=
oto, Arial, Helvetica, sans-serif; letter-spacing: 0.2px; white-space: nowr=
ap;">=E2=80=A2 7:37=E2=80=AFAM, Feb 1 (EST)</span><h4 style=3D"background: =
#1a73e8; border-radius: 8px; color: #fff; display: inline-block; font: 700 =
12px/16px Roboto, Arial, Helvetica, sans-serif; margin-bottom: 0; margin-to=
p: 0; margin-left: 10px; padding: 0 6px;">New</h4><div style=3D"font: 400 1=
4px Roboto, Arial, Helvetica, sans-serif; line-height: 20px; letter-spacing=
: .2px;"><div style=3D"margin-top: 6px;" class=3D"notranslate">Hello<br>For=
 you a letter You have a new transfer of funds, you need to withdraw them<b=
r>All information in the attached link: <a href=3D"https://www.google.com/u=
rl?q=3Dhttps://script.google.com/macros/s/AKfycbyB7w6WEN9rrfxrGUZR0uJSJf097=
7R5blfQ86VcyzfOeSLVl98FusGwC_-BEq_B87aIcA/exec?hjb62k0n81pw5bfhyri&amp;sa=
=3DD&amp;source=3Deditors&amp;ust=3D1675258647883626&amp;usg=3DAOvVaw1cQpBX=
cDfBcDR5suqvPg3Q" target=3D"_blank">https://script.google.com/macros/s/AKfy=
cbyB7w6WEN9rrfxrGUZR0uJSJf0977R5blfQ86VcyzfOeSLVl98FusGwC_-BEq_B87aIcA/exec=
?hjb62k0n81pw5bfhyri</a><br><br>Read it!<br>You have 2 hours, to order your=
 funds<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><=
br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>=
<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br=
><br><br><br><br><br><br><br><br><br><br>@<a href=3D"mailto:opoggenpeace@gm=
ail.com" target=3D"_blank">opoggenpeace@gmail.com</a><br>@<a href=3D"mailto=
:sausagemafia@gmail.com" target=3D"_blank">sausagemafia@gmail.com</a><br>@<=
a href=3D"mailto:morriscode@gmail.com" target=3D"_blank">morriscode@gmail.c=
om</a><br>@<a href=3D"mailto:ykudjawu@gmail.com" target=3D"_blank">ykudjawu=
@gmail.com</a><br>@<a href=3D"mailto:creovex@gmail.com" target=3D"_blank">c=
reovex@gmail.com</a><br>@<a href=3D"mailto:chappelle99@gmail.com" target=3D=
"_blank">chappelle99@gmail.com</a></div></div></td></tr></table></div><div =
style=3D"margin: 10px 0 0 42px; overflow: auto; padding: 2px;"><a href=3D"h=
ttps://docs.google.com/presentation/d/1jn0VoYpf9LR7qIBVQoUojAvVv3smQsnezp0f=
6k5Qfwo/edit?disco=3DAAAAon7N7QI&amp;usp=3Dcomment_email_discussion&amp;ts=
=3D63da5e34&amp;usp_dm=3Dfalse" class=3D"material-button material-button-tr=
ansparent" target=3D"_blank" tabindex=3D"0" role=3D"button" style=3D"paddin=
g: 0 8px;font: 500 14px/36px Google Sans, Roboto, Arial, Helvetica, sans-se=
rif; border: none; border-radius: 18px; box-sizing: border-box; display: in=
line-block; letter-spacing: .25px; min-height: 36px; text-align: center; te=
xt-decoration: none;background-color: transparent; color: #1a73e8; cursor: =
pointer;float: right;">Open</a></div></div></div></div></div></div></td></t=
r></table></div></div><table style=3D"border-collapse: collapse; width: 100=
%;" role=3D"presentation"><tr><td style=3D"padding: 24px 4.5%"><table style=
=3D"border-collapse: collapse; width: 100%;" dir=3D"ltr"><tr><td style=3D"p=
adding: 0;font-family: Roboto, Arial, Helvetica, sans-serif; color: #5F6368=
; width: 100%; font-size: 12px; line-height: 16px; min-height: 40px; letter=
-spacing: .3px;"><p style=3D"margin: 0; padding: 0;">Google LLC, 1600 Amphi=
theatre Parkway, Mountain View, CA 94043, USA<br><br>You have received this=
 email because you are mentioned in this thread by Tretjachkov Rogaljaa (tr=
etjachkovrogaljaahrnnb@gmail.com). If you don't want to receive files from =
this person, <a target=3D"_blank" style=3D"color: #1a73e8; text-decoration:=
 none;" href=3D"https://drive.google.com/drive/blockuser?blockerEmail=3Dmor=
riscode@gmail.com&amp;blockeeEmail=3Dtretjachkovrogaljaahrnnb@gmail.com&amp=
;usp=3Dcommentnotification_MENTIONED">block the sender</a> from Drive. <a t=
arget=3D"_blank" style=3D"color: #1a73e8; text-decoration: none;" href=3D"h=
ttps://docs.google.com/presentation/u/105138397256252213126/docos/notify?ou=
id=3D105138397256252213126&amp;id=3D1jn0VoYpf9LR7qIBVQoUojAvVv3smQsnezp0f6k=
5Qfwo&amp;title=3DUntitled+presentation&amp;resourcekey">Change what Google=
 sends you</a>. You can reply to this email to reply to the discussion.</p>=
</td><td style=3D"padding: 0;padding-left: 20px; min-width: 96px"><img src=
=3D"https://www.gstatic.com/images/branding/googlelogo/2x/googlelogo_tm_bla=
ck54_color_96x40dp.png" width=3D"96px" height=3D"40px"></td></tr></table></=
td></tr></table></td></tr></table></td></tr></table></div></div>
--000000000000f7932305f3a2c788--
`},callback_phishing:{label:"Callback Phishing",fileName:"callback_phishing.eml",fileContents:`Delivered-To: morriscode@gmail.com
Received: by 2002:aa6:c08b:0:b0:244:2a95:b080 with SMTP id b11csp393234lkp;
        Thu, 2 Feb 2023 04:03:53 -0800 (PST)
X-Received: by 2002:a05:6870:a413:b0:15f:be68:501 with SMTP id m19-20020a056870a41300b0015fbe680501mr3065130oal.21.1675339433618;
        Thu, 02 Feb 2023 04:03:53 -0800 (PST)
ARC-Seal: i=1; a=rsa-sha256; t=1675339433; cv=none;
        d=google.com; s=arc-20160816;
        b=bb1t0xWloJY2ogGJjQH8eLLOeBzwOGb26tbceHhye7Xupjl/HW5xfn4Qe5qfqMQzt9
         XzvQ1d9MYB36RTeqGeOZv2mTqY7EgLD6suuZGeg2LEm38eN2/7BJr3tDQggHVr4ehhbU
         aI5pEAVNoNsqk6L71xjIyXlleG9dKTHzQTfCTYsYefu3nPEESYz3ufwd3QiOW9+VdIPE
         Wc0AQKyNGGNWvJqraeS98SLyXPxZUWFJqFkzjtk87Oj2Xbby40De4TWfoC8GJ2Ng6/o4
         dvamG9OfgBocXjpIE/y+UP5iQpVMxJSNxmJqzaOgcGax49sn0yxss3iJIZRFn0WhOlNu
         h3kQ==
ARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=google.com; s=arc-20160816;
        h=to:subject:message-id:date:from:mime-version:dkim-signature;
        bh=H2n+/CwTJxzRRICOylTmmqOfYZh+IY5bFiABqXBy7tk=;
        b=MA1erLxZqTGZXCCAbLokhk7E5eHCqO14v4hgt4A+Asib3ukwwz35HPmCH0hiZicCC2
         CGR0wkYsPiXkrQa6W4iY5s5oLongt6Az2KUeA2T+nriL/kxniH/HhW5vNFJumBw/FbOg
         vO5h+pH79uuV3eG7OE1VJg66P9GrfevzGpiczw4shWeQ8dwvhUHRH18FOhnwhUrHXo8g
         blRvqSG7BVeqp8aUCNu5WXmAhbg1mOVccXl0SGDSycQZ2pvRiVjWOYEMHZXUd5dJympK
         x9wm9tyes78hAD7pTfrFLlywdUEQi1UGhksjJNRatXABzn32mcRvUxY8/Phqa8kQx0m9
         XpPw==
ARC-Authentication-Results: i=1; mx.google.com;
       dkim=pass header.i=@gmail.com header.s=20210112 header.b=YtshbfKI;
       spf=pass (google.com: domain of davidgonx728@gmail.com designates 209.85.220.41 as permitted sender) smtp.mailfrom=davidgonx728@gmail.com;
       dmarc=pass (p=NONE sp=QUARANTINE dis=NONE) header.from=gmail.com
Return-Path: <davidgonx728@gmail.com>
Received: from mail-sor-f41.google.com (mail-sor-f41.google.com. [209.85.220.41])
        by mx.google.com with SMTPS id ee49-20020a056870c83100b0015fc06a0d5esor1388610oab.29.2023.02.02.04.03.53
        for <morriscode@gmail.com>
        (Google Transport Security);
        Thu, 02 Feb 2023 04:03:53 -0800 (PST)
Received-SPF: pass (google.com: domain of davidgonx728@gmail.com designates 209.85.220.41 as permitted sender) client-ip=209.85.220.41;
Authentication-Results: mx.google.com;
       dkim=pass header.i=@gmail.com header.s=20210112 header.b=YtshbfKI;
       spf=pass (google.com: domain of davidgonx728@gmail.com designates 209.85.220.41 as permitted sender) smtp.mailfrom=davidgonx728@gmail.com;
       dmarc=pass (p=NONE sp=QUARANTINE dis=NONE) header.from=gmail.com
DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;
        d=gmail.com; s=20210112;
        h=to:subject:message-id:date:from:mime-version:from:to:cc:subject
         :date:message-id:reply-to;
        bh=H2n+/CwTJxzRRICOylTmmqOfYZh+IY5bFiABqXBy7tk=;
        b=YtshbfKIevwWOmzWm5YL5pbMSfUfGxGE+PmO08dWJUbS36NisWOyxEzp+MiTOJTGLP
         DPr2a65t8g/pXemSPUkLE44HQoQIooc7J+TACwjlSw/ZPEV3U5/lRBG4M+2/aL79m1Vp
         aG4tWxQeg2xcEx25VeWinL8zHqCIbsvG7pCD9Bsy4VaM5Gqwt6S7Gthg+qxV7d0I05Dp
         PhmoocsO3+IN8bDd/DlfFFHd/7u7irvauq1TZ49Fj99NzrS8mYaFBcpmOyWN2VxS7ibt
         K/LLtwOqwlPl5eCvwVrNOTiwQsJ8im69RKZUMBZMhISQKjXyggTx+Sckor234LTv3Gv6
         0OZg==
X-Google-DKIM-Signature: v=1; a=rsa-sha256; c=relaxed/relaxed;
        d=1e100.net; s=20210112;
        h=to:subject:message-id:date:from:mime-version:x-gm-message-state
         :from:to:cc:subject:date:message-id:reply-to;
        bh=H2n+/CwTJxzRRICOylTmmqOfYZh+IY5bFiABqXBy7tk=;
        b=TNzWAYQLmC8lP3WD/LooSsToHJIvPVA4YugwhOSJjWKCLUE05Ae7fKSzuKPO3a+bYG
         NB7bpeUVf0xxXGVpqhyK25kMbWZsnqQUwmHwbUYl1SQlRt/e8iTnyGQ7h4YfnNoCp0U/
         8YXNkKQSiz/nCEMmt96YqONKTur5GaMRambPxUcNHoXALfB5WjBzYdnBk9GV1pIxFjnF
         J2DFs7UklpmBNEc38TsEuL1aNZnGr3r0RCH5bgdHc3Gbg59uw/iuz08w/oQ7Y9nZ6TzV
         WDeHYi8EYH8gM1Y4CCa5YpPQxtCdNV0QNF0/gZPHTHeCTyz1wuolWQ7eJ7beywp+OTJS
         voIg==
X-Gm-Message-State: AO0yUKWs7btV842qVdLhjoIVt6OImI44jL82gDuhB3R3qXntaYBq2QGq
	uoQGQdOWcA99edbXOGtWvrXa0Uiw8LFZwCVER58=
X-Google-Smtp-Source: AK7set+M/ZtOW/7d3or4pqrdxVnyzJqB5WxeR1nzmXYgY+c5a8TEej8zL/hxBKGqWvDJlKO2ioKRxs6boopX8fd4WpA=
X-Received: by 2002:a05:6870:47a6:b0:163:745c:eab6 with SMTP id
 c38-20020a05687047a600b00163745ceab6mr238247oaq.297.1675339432963; Thu, 02
 Feb 2023 04:03:52 -0800 (PST)
MIME-Version: 1.0
From: Stonr Jon <davidgonx728@gmail.com>
Date: Thu, 2 Feb 2023 17:33:40 +0530
Message-ID: <CAKwkksV8jiTfRbaiLEb8apemY0cJfoK1qEXetzigSaDkxfpLOw@mail.gmail.com>
Subject: INVOICE VVDC02022023BRC
To: nortoncc2023@outlook.com
Content-Type: multipart/alternative; boundary="000000000000c7b5b305f3b65b85"
Bcc: morriscode@gmail.com

--000000000000c7b5b305f3b65b85
Content-Type: text/plain; charset="UTF-8"
Content-Transfer-Encoding: quoted-printable

Thank you for your order, Here is your details



INVOICE NO. Product Details



VVDC02022023BRC NORTON Total All Round Security


*Order Summary*


*INVOICE NUM:* VVDC02022023BRC
*START DATE:* *2023.02.02*
*END DATE:* *1 year from START DATE*
*Payment Mode:* Auto debit from account
*Status:* Completed


*PRODUCT NAME* *Quantity* *Total Amount*
NORTON Total All Round Security (VVDC02022023BRC) 1 $484.00 USD
Sub-total $484.00 USD
Discount 00.00
Total $484.00 USD

If you wish to not to continue subscription and claim a REIMBURSE then
please feel free to call our Billing Dept. as soon as possible.

You can Reach us on : * +1 =E2=80=93 ( 808 ) =E2=80=93 ( 400 ) =E2=80=93 83=
79 *


Sincerely,


Billing Dept.

--000000000000c7b5b305f3b65b85
Content-Type: text/html; charset="UTF-8"
Content-Transfer-Encoding: quoted-printable

<div dir=3D"ltr"><div><br></div><br><div>Thank you for your order, Here is =
your details</div>
<div><br></div><br>
<br>
<table width=3D"588px" cellspacing=3D"0" cellpadding=3D"0" align=3D"left">
	<tbody><tr>
		<th align=3D"left">INVOICE NO.</th>
		<th align=3D"left">Product Details</th>
	</tr>
	<tr>
		<td>=C2=A0<br><br></td>
		<td>=C2=A0</td>
	</tr>
	<tr>
		<td>VVDC02022023BRC</td>
		<td>NORTON Total All Round Security</td>
	</tr>
</tbody></table>
<div style=3D"clear:both"></div>
<br><br>
<div><strong>Order Summary</strong></div>
<div><br></div><br>
<div>
	<table width=3D"588px" cellspacing=3D"0" cellpadding=3D"0" align=3D"left">
	<tbody><tr>
		<td width=3D"30%"><strong>INVOICE NUM:</strong></td>
		<td width=3D"30%">VVDC02022023BRC</td>
		<td width=3D"30%"></td>
		<td width=3D"10%"></td>
	</tr>
	<tr>
		<td width=3D"30%"><strong>START DATE:</strong></td>
		<td width=3D"30%"><b>2023.02.02</b></td>
		<td width=3D"30%">=C2=A0</td>
		<td width=3D"10%">=C2=A0</td>
	</tr>
	<tr>
		<td width=3D"30%"><strong>END DATE:</strong></td>
		<td width=3D"30%"><b>1 year from START DATE</b></td>
		<td width=3D"30%">=C2=A0</td>
		<td width=3D"10%">=C2=A0</td>
	</tr>
	<tr>
		<td width=3D"30%"><strong>Payment Mode:</strong></td>
		<td width=3D"30%">Auto debit from account</td>
		<td width=3D"30%">=C2=A0</td>
		<td width=3D"10%">=C2=A0</td>
	</tr>
	<tr>
		<td width=3D"30%"><strong>Status:</strong></td>
		<td width=3D"30%">Completed</td>
		<td width=3D"30%">=C2=A0</td>
		<td width=3D"10%">=C2=A0</td>
	</tr>
</tbody></table>
</div>
<div style=3D"clear:both"></div>
<br>
<br>
<table style=3D"width:588px" cellspacing=3D"0" cellpadding=3D"5" border=3D"=
0"><tbody><tr><td style=3D"border-bottom:1px solid rgb(0,0,0);background:rg=
b(204,204,204)"><b>PRODUCT NAME</b></td>
		<td style=3D"border-bottom:1px solid rgb(0,0,0);background:rgb(204,204,20=
4)"><b>Quantity</b></td>
		<td style=3D"border-bottom:1px solid rgb(0,0,0);background:rgb(204,204,20=
4)" align=3D"right"><b>Total Amount</b></td></tr><tr><td>NORTON Total All R=
ound Security (VVDC02022023BRC)</td>
		<td>1</td>
		<td align=3D"right">$484.00 USD</td></tr><tr><td style=3D"border-bottom:1=
px solid rgb(0,0,0);padding:10px 5px" colspan=3D"2" align=3D"right">Sub-tot=
al</td>
		<td style=3D"padding:10px 5px;border-bottom:1px solid rgb(0,0,0)" align=
=3D"right">$484.00 USD</td></tr><tr><td style=3D"border-bottom:1px solid rg=
b(0,0,0);padding:10px 5px" colspan=3D"2" align=3D"right">Discount</td>
		<td style=3D"padding:10px 5px;border-bottom:1px solid rgb(0,0,0)" align=
=3D"right">00.00</td></tr><tr><td colspan=3D"2" style=3D"padding:10px 5px" =
align=3D"right">Total</td><td style=3D"padding:10px 5px" align=3D"right">$4=
84.00 USD</td></tr></tbody></table><br><br>If
 you wish to not to continue subscription and claim a REIMBURSE then=20
please feel free to call our Billing Dept. as soon as possible.<div><br><di=
v>You can Reach us on=C2=A0:=C2=A0<font size=3D"4" face=3D"arial, sans-seri=
f"><b>=C2=A0+1=C2=A0=E2=80=93=C2=A0(=C2=A0808=C2=A0)=C2=A0=E2=80=93=C2=A0(=
=C2=A0400=C2=A0)=C2=A0=E2=80=93=C2=A08379 </b></font></div><div><br></div><=
br><div>Sincerely,</div><div><br></div><div><br></div><div>Billing Dept.</d=
iv></div></div>

--000000000000c7b5b305f3b65b85--
`},spam:{label:"Spam",fileName:"spam.eml",fileContents:`Delivered-To: morriscode@gmail.com
Received: by 2002:aa6:c08b:0:b0:244:2a95:b080 with SMTP id b11csp1902006lkp;
        Sat, 11 Feb 2023 08:24:37 -0800 (PST)
X-Google-Smtp-Source: AK7set+YdKRyZY9hNrgpZrRG3T+CFJFD1oiCJRgW4hehqICm9DQB0oUvS11YoEKZP+qrP5stSTaG
X-Received: by 2002:a5d:4112:0:b0:2c5:3d7d:1b50 with SMTP id l18-20020a5d4112000000b002c53d7d1b50mr7657555wrp.58.1676132677714;
        Sat, 11 Feb 2023 08:24:37 -0800 (PST)
ARC-Seal: i=1; a=rsa-sha256; t=1676132677; cv=none;
        d=google.com; s=arc-20160816;
        b=vGreHjMaTBGsHYHJGJ/9ioCwJrPfvmXnzw+c8Zw08MtbfUQerp/1xFZkUgFHzG9dkT
         lfp9TdspDy8Wafik9WVJw6sgDuyjPT+R6bU6lG6VP1ekW3ButzIVvaTraMS/7998O9fK
         5isNYirVpd/dgDInNL5MF3o1hfirUn6naBCYo++3u7wWgAa8E4UfjBIl5rHZFusKXMXu
         vnm5t0FHgvoyuJkJ+tlfeTPcY7jrOwWB8xvRbAi4LCqvMVNc7gsEJzni3Z5GGZngXMIr
         jLM2SNpX104MPamXis+vS7T3dBjUD8RIr8mo5fcCl+y+E1aV4mRzipbGl6/uK+4uS04p
         o+VA==
ARC-Message-Signature: i=1; a=rsa-sha256; c=relaxed/relaxed; d=google.com; s=arc-20160816;
        h=message-id:date:subject:from:to:mime-version;
        bh=hLozRTCqc7XuravIPk+i0HRIrCo6C6kOq6CJrjBq5cc=;
        b=VN7OumIxJrI0twRNu1+edkbUd+vma0A3BXrCZumhUj4XoRMAxDQwRx6VKQR4vdxkek
         +Xzi5U3uYXIGXCCmQbfeNZPPYhwvV81FYDlMwwMFPxADUiubRZkMfKoKL2dv42XjZeHE
         S7OjrDaf9YIf/2Z16aCSsrdX3l7w2Xrtk2IRdG+qyEv9WTRMQ/QcJeELkr5fq2dUu1Xn
         GfH+TUoQxuuMVmCHWSw4wOnw7LQmE4UTh8lFfZfvdcXsR+eti65YBy7rZqklM7+Injix
         N5FzMke9DbDqNliE1wYteM4DxsXWufu/8RXdrFP8YfL+F0uu0ufJJPHWILBZ3WX5AI/1
         KO3A==
ARC-Authentication-Results: i=1; mx.google.com;
       spf=pass (google.com: domain of info@msora.server-on.net designates 178.79.138.43 as permitted sender) smtp.mailfrom=info@msora.server-on.net;
       dmarc=fail (p=NONE sp=NONE dis=NONE) header.from=thenational.scot
Return-Path: <info@msora.server-on.net>
Received: from clk13371.com (178-79-138-43.ip.linodeusercontent.com. [178.79.138.43])
        by mx.google.com with ESMTP id v13-20020a5d6b0d000000b002be52e02ec0si6279330wrw.224.2023.02.11.08.24.37
        for <morriscode@gmail.com>;
        Sat, 11 Feb 2023 08:24:37 -0800 (PST)
Received-SPF: pass (google.com: domain of info@msora.server-on.net designates 178.79.138.43 as permitted sender) client-ip=178.79.138.43;
Authentication-Results: mx.google.com;
       spf=pass (google.com: domain of info@msora.server-on.net designates 178.79.138.43 as permitted sender) smtp.mailfrom=info@msora.server-on.net;
       dmarc=fail (p=NONE sp=NONE dis=NONE) header.from=thenational.scot
MIME-version: 1.0
Content-type: text/html
To:morriscode@gmail.com
From: SamsClub\xae️<donotreply@thenational.scot>
Subject: MORRISCODE , 2nd Attempt: You Are A 𝐖𝐢𝐧𝐧𝐞𝐫 💲500 𝐒𝐚𝐦𝐬𝐂𝐥𝐮𝐛 For You ✔️ 🎁   -- #_41225806   -- Sat, 11 Feb 2023 11:24:34 -0500 --
Date: Sat, 11 Feb 2023 11:24:34 -0500
X-Mailer: 520434352
Message-ID: <9f2zSd4JzkKYCGTUwX_520434352@agyaxyxcsfjn.com>

<center>


 
<html>
 

 


<body style="background:#044588;">
<center>
<br>

<a href='http://storage.googleapis.com/teampass/Ha231120/hrf2zsdf/newb2.html#2537313NH6763378Rt520434352km14664Vk24qKr171571jE' style="text-decoration:none"> 
<div style="font-size:40px;color:#FFFF00;font-family:Algerian;text-decoration: underline">
  <span>S<span>a<span>m<span>'<span>s<span> <span>c<span>l<span>u<span>b<span> <span>h<span>a<span>s<span> <span>a<span> <span>s<span>u<span>r<span>p<span>r<span>i<span>s<span>e<span> <span>f<span>o<span>r<span> <span>Y<span>o<span>u<span> 
</div>
<div  style=" width:570px;  display:block; border: 0px solid  #ebebeb; height:auto; background:white;  border-radius:50px; border:9px double #74a339;">
<br><br>
    <div style="font-size:100px;line-height:60px;color:#044588;padding-bottom:0px;font-family: Georgia, serif;">  <span>S<span>a<span>m<span>'<span>s<span></div>
  <div style="font-size:40px;font-family:Arial;color:#044588;"> <b><span>C<span>L<span>U<span>B<span></b><span style="font-size:25px;"> \xae  </span></div>
    <div style="font-size:20px;"><br> <table cellpadding="0" cellspacing="0" border="0" align="center">
<tr><td height='1px' class="ee_columns ee_Timothylgrassielem" style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#ffffff,#fefefe,#ffffff,#cfd0d6,#4b4d61,#232543,#222544,#202444,#202246,#202346,#212447,#212447,#212447,#212447,#212447,#212447,#222548,#222548,#22264a,#22264b,#22264b,#21254a,#23274b,#23274d,#242750,#242750,#252851,#262952,#272a53,#262952,#282b54,#282b54,#282b54,#292c55,#282e55,#272f54,#272f54,#272f54,#272f54,#282f54,#2a3055,#2a3055,#2a3055,#2a3055,#2a3055,#2b305a,#2b305a,#2b305a,#2b305a,#2b305a,#29315a,#28315a,#28315a,#28315a,#28315a,#29325a,#2a335b,#2a335b,#2a335b,#2a335b,#2a335b,#28345b,#28345b,#28345c,#29355d,#29355d,#29355d,#29355d,#29355d,#29355d,#29355d,#29355e,#283660,#293760,#2a3861,#2b3962,#2c3a64,#2d3b66,#2e3b67,#2d3d6a,#2c3e6d,#2c3f70,#294272,#294575,#2a4778,#2b4a7d,#2c4e80,#2e4d8a,#344f93,#577091,#cddbdf,#fcfefe,#fbf7fa,#ffffff,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fefefe,#fffffe,#e7e7eb,#343346,#0b0a28,#121337,#101337,#101437,#131639,#131639,#14173a,#14173a,#14173a,#14173a,#14173a,#14173a,#15183b,#15183b,#15193d,#15193e,#15193e,#15193e,#161a3e,#171a41,#171a43,#171a43,#181b44,#191c45,#1a1d46,#1a1d46,#1b1e47,#1b1e47,#1b1e47,#1d1f48,#1b2149,#1a2249,#1a2249,#1a2249,#1a2249,#1a2249,#1b234a,#1b234a,#1b234a,#1b234a,#1b234a,#1c234d,#1c234d,#1c234d,#1c234d,#1c234d,#1b244d,#1b254d,#1b244d,#1a244d,#1a244d,#1b254e,#1c264f,#1c264f,#1c264f,#1c264f,#1c264f,#1a274f,#1a274f,#1a284f,#1b2850,#1b2850,#1c2950,#1b2950,#1c2950,#1b2950,#1c2950,#1b2851,#1a2a54,#1c2b55,#1d2c56,#1e2d57,#1f2e58,#202e5a,#20305c,#1f305e,#1f3162,#1f3364,#1c3565,#1c3868,#1d3a6c,#1d3c6f,#1f3f73,#1d3e76,#1e417c,#1c3b70,#395174,#dce5ed,#fdfcfb,#fefefd,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fbfbfc,#ffffff,#9795a3,#04021f,#1a193f,#15153f,#15163f,#13173b,#131639,#131639,#14173a,#14173a,#14173a,#14173a,#14173a,#15183b,#16193c,#16193c,#15193d,#15193e,#15193e,#15193e,#161a3f,#171a41,#171a43,#171a43,#181b44,#181b44,#1a1d46,#191c45,#1b1e47,#1b1e47,#1b1e47,#1c1f48,#1b214a,#1a214a,#1a214a,#1b224b,#1a214a,#182049,#1a244c,#1a234b,#1b244c,#1c254d,#1b244d,#1c2551,#1b2450,#1c2551,#1c2551,#1d2651,#1b2651,#18244f,#192550,#1a2751,#1a2651,#1a2751,#192650,#1b2752,#192651,#1b2752,#1a2751,#192851,#192852,#1a2952,#1b2a53,#1c2b55,#1a2852,#1b2a53,#1a2852,#1b2953,#1a2953,#1b2a54,#182a55,#1b2c57,#1a2c57,#1c2d58,#1c2d59,#1e2e5b,#1c2d5b,#1e3161,#1c3163,#1c3265,#1c3666,#1c3868,#1c396b,#1c3c6e,#1c3c71,#1c4070,#1b4578,#244c93,#0f2f73,#8d9eb5,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#868496,#080627,#1a183f,#16163f,#14163b,#131839,#14173a,#14173a,#14173a,#14173a,#14173a,#15183b,#15183b,#15183b,#16193c,#16193c,#15193d,#15193e,#15193e,#161a3f,#161a3f,#171a41,#181b44,#181b44,#171a43,#171a43,#181b44,#191c45,#1a1d46,#1b1e47,#1a1e47,#1c1f47,#1b204b,#1a214d,#1a214d,#1b224e,#1b214e,#19224e,#17234d,#17234d,#19254f,#18234e,#17234d,#172250,#192452,#172250,#16214f,#182350,#1b2955,#162450,#192753,#1a2854,#1a2855,#192753,#1a2854,#1a2854,#1b2956,#182652,#1b2955,#182955,#182955,#162753,#192a55,#192a55,#1a2b57,#172854,#1a2a56,#192a56,#192a56,#162854,#162956,#172b57,#182b58,#172b57,#1b2e5b,#1c2e5d,#192c5c,#1a2f61,#1b3164,#1b3367,#193465,#1c3867,#1a3869,#1b3b6d,#1b3c71,#1a3d6d,#194375,#19458e,#0f347e,#7e91ae,#ffffff,#fdfcfc,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#898797,#070524,#1a193b,#16173a,#141835,#131835,#14173b,#14173a,#14173a,#14173a,#14173a,#15183b,#15183b,#15183b,#16193c,#16193c,#15193d,#15193e,#15193e,#161a3f,#161a3f,#171a41,#191b45,#181b44,#171a43,#171943,#181b44,#191c45,#1a1d46,#1b1e47,#1b1e48,#1d1f47,#1b204d,#1a2150,#1a214f,#19204e,#1f2553,#1e2754,#1a2752,#1a2753,#182550,#1b2854,#17244f,#1e2b58,#172450,#1b2855,#1a2753,#1c2956,#172551,#1f2d5a,#172652,#1d2c58,#192754,#1f2d59,#192753,#202e5a,#192753,#212f5b,#1a2855,#1b2d58,#162953,#1c2e59,#172a55,#1f315c,#182a55,#1e305b,#182a55,#1a2d58,#162853,#192d58,#182d5a,#172c5a,#192e5c,#1b305e,#172c5a,#1c3060,#1c3062,#1b3163,#1a3266,#193269,#1d386a,#1b3766,#1d3b6c,#19396b,#1f4075,#1c3c6f,#1d4078,#194687,#113975,#8292ac,#ffffff,#fcfcfd,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878598,#070424,#1b1838,#181639,#171637,#161737,#141738,#141737,#151739,#14173a,#14173b,#151842,#14163f,#15183d,#15193b,#131737,#14193a,#141a3d,#141940,#151a42,#151a42,#151a41,#151a40,#191e44,#161b41,#191e44,#191e44,#171b43,#191d45,#1a1e47,#191e46,#1a1f47,#1a1f4b,#1b1f4c,#1d214a,#1d234e,#202b5a,#152455,#212e5f,#182557,#202d5e,#1a2859,#222f61,#1a2759,#212e60,#1b2859,#253263,#1c295b,#203060,#18295a,#1f2f60,#1c2c5d,#203061,#1e2f60,#1b2e5f,#192c5d,#1e3162,#1b2e5e,#1d3061,#1d3160,#1b2f5e,#1e3161,#1d3161,#203463,#182d5d,#203565,#182d5c,#213565,#1c3261,#1f3565,#192f60,#1f3566,#192f60,#223869,#182e5f,#21376b,#1a3063,#233a6d,#1c3468,#263e73,#1c3568,#203b6d,#1b386b,#1f3e74,#1c3d72,#23427b,#1d3f79,#204e84,#0e376f,#8093ae,#ffffff,#fcfcfc,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878599,#070324,#1b1738,#191639,#19153b,#171639,#141735,#151837,#121535,#0c0f31,#15183b,#0c0e34,#13153b,#111437,#14173a,#181b3d,#151a3a,#151b3d,#171c42,#171c43,#151a42,#161b41,#14193b,#0c1235,#181d3f,#161c3e,#171d3f,#181d43,#1b2045,#1b2046,#171b41,#171c41,#1d214a,#1e2148,#202246,#21264d,#182755,#1e2f62,#1a265b,#1e2c60,#1c295d,#1f2c60,#182559,#222f63,#1b285c,#202d62,#19265b,#1f2c60,#1a295d,#1e2e62,#1a2a5d,#1c2c5f,#1a2a5d,#1c2d60,#182d61,#1d3165,#1b2f62,#172b5f,#1e3266,#1a2e60,#1f3366,#192d60,#1e3265,#1b2f61,#213668,#172d60,#1e3467,#192f61,#203668,#152b5d,#23396b,#1a3062,#1f3567,#192f61,#203668,#1a3165,#233a6e,#193065,#20376b,#1c3266,#243d70,#1b3769,#203d72,#1a3970,#1f3f75,#193873,#244781,#18457a,#113a73,#7b91ae,#ffffff,#fdfdfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878599,#070324,#1b1738,#191639,#19153a,#171639,#161939,#090c2b,#454865,#626681,#03041a,#52556a,#5c5e75,#4d4f68,#0b0c2e,#0f1036,#101335,#111635,#0a0f2e,#0f1334,#171b41,#15183e,#161a38,#71748f,#8a8ba0,#6d718b,#171b3a,#111536,#0e1234,#0a0e30,#444866,#6f738e,#0c1034,#08092c,#464564,#686b8a,#131f4d,#1b2b5d,#202d61,#182559,#1c295d,#19265a,#202d61,#19265a,#1f2c5f,#19265a,#212e62,#19265a,#1f2e61,#1a2a5d,#1f2f62,#1d2d60,#1d2d60,#1c2e61,#1a2e61,#1b2f62,#172b5e,#1f3366,#1d3063,#1c3062,#1b2f61,#1e3264,#1a2e60,#203365,#162b5d,#1e3466,#182e60,#1e3466,#162b5d,#22386a,#192f61,#213769,#172d5f,#23396b,#162c5e,#22396d,#1a3165,#253c70,#1a3165,#23396e,#1b3567,#233f71,#1a376b,#1c3b71,#193a6f,#24437e,#1b3c77,#1e4a7e,#133a73,#8094b0,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#88869a,#070325,#1a1637,#191639,#19153a,#17163a,#151839,#0e1130,#2e314c,#9b9eb0,#07091e,#9597a6,#3c3d50,#53546a,#22223d,#74738e,#3b3c5a,#2a2d47,#737688,#404359,#121438,#0b0d32,#787b91,#696c82,#0b0d27,#131631,#10132f,#4e5169,#84879c,#363951,#44465d,#797d93,#151832,#77788f,#9896ac,#70728f,#0a1442,#233163,#19265a,#1f2c60,#162357,#233064,#1a275b,#212e62,#182559,#222f63,#1a275b,#1f2c60,#19285b,#1b2c5f,#1b2b5e,#1c2c5f,#1b2b5e,#1d2e61,#1a2e61,#1b2f62,#192c5f,#1b2f62,#1a2e61,#182c5e,#1e3264,#192d5f,#203466,#182c5e,#213769,#182e60,#203668,#162c5e,#203668,#192f61,#203668,#172d5f,#213769,#182e5f,#253b6d,#162d61,#21386c,#1a3165,#22396d,#1c3267,#223b6e,#1a3568,#1e3c70,#18376d,#1e3f74,#1a3873,#22407d,#1b4479,#10356f,#8293af,#ffffff,#fdfdfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#88869a,#070325,#1a1637,#191639,#19153a,#17163a,#141739,#171a39,#080c25,#818696,#575c6c,#7a7a8b,#28273c,#838395,#4f4f5d,#9f9faa,#14142f,#1f1f3a,#727481,#a2a5b1,#1b1a3d,#111034,#9495a8,#14152d,#474960,#848599,#48495f,#8b8c9d,#2f3043,#9092a1,#545568,#67687a,#747687,#58586a,#706e81,#72728e,#161e4b,#1a2658,#1d2a5e,#172458,#222f63,#1a275b,#202d61,#19265a,#1d2a5e,#182559,#1f2c60,#1a275b,#1e2d60,#18295c,#1c2c5f,#1a2a5d,#1f2e61,#1d2e61,#172b5e,#1b2f62,#1c3063,#1b2f62,#1b2f62,#1f3365,#192d5f,#1e3264,#1a2e60,#1f3365,#182e60,#1e3466,#172c5e,#213769,#192f61,#1f3567,#162c5e,#1d3365,#182e60,#22386a,#182e60,#1f366b,#172f63,#21386c,#1a3165,#253c70,#1a3366,#1d3a6c,#19376b,#1d3c73,#193b71,#1f3c78,#203c79,#21497f,#0e316c,#7e8da9,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#86869a,#050425,#191737,#181739,#17163a,#16163b,#14173b,#171a39,#080d26,#505465,#c4c9d4,#414059,#24223b,#8f8ea1,#090918,#74757f,#807f96,#7b7b91,#656771,#a0a1ad,#252442,#050327,#828498,#707282,#12121f,#9496a8,#6d6f85,#7d808d,#060818,#9092a2,#5d5f72,#6b6c7f,#858695,#3b3b49,#5a5a6b,#7d809a,#0b1240,#232e62,#19265a,#202c60,#1a275b,#202d61,#1a265a,#212e62,#19265a,#1f2c60,#1b285c,#202d61,#1d2c5f,#1c2c5f,#1c2c5f,#1c2c5f,#1c2c5f,#17285b,#1c2f62,#1b2e61,#1c2e61,#1a2c5f,#1e3063,#182c5f,#1d3163,#182c5e,#1e3264,#1a2e60,#1c3163,#182d60,#223769,#182e60,#1f3567,#182e60,#213769,#162c5e,#23396b,#192f61,#213769,#192f63,#21386b,#1b3165,#23396d,#1b3165,#1d3669,#1b3568,#213c70,#18346a,#1e3b71,#1f3973,#223b77,#1a3f75,#13336e,#8391b0,#ffffff,#fdfdfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#838699,#010524,#161938,#151839,#14173a,#14173b,#14163d,#141739,#131733,#1e2237,#8b909f,#161636,#262644,#5f5f78,#34354d,#81828f,#4f4f65,#57586c,#82848e,#7b7c8c,#1b1b36,#121337,#1d2040,#7f8492,#82868c,#7d8296,#1a1d40,#6f7381,#8e929c,#4d5269,#323550,#585b7b,#34354a,#9395a0,#848a99,#4e5672,#161e4e,#1d275e,#253164,#1c285c,#222e62,#192559,#212d61,#1a275b,#1f2c60,#1a275b,#1c295d,#1c295d,#1d2c5f,#1b2b5e,#1e2e61,#1a2a5d,#1d2d60,#1d2d60,#1c2c5f,#1d2d60,#1a2a5d,#213063,#1b2b5e,#1e3265,#182c60,#1e3265,#182d60,#1d3164,#182c5f,#23376a,#182c5f,#203467,#172b5e,#223769,#172d5f,#203668,#162c5e,#1f3567,#182e60,#213769,#192f61,#23396b,#192f61,#23396b,#1c3366,#233a6e,#1d3367,#253b6f,#22396d,#263b71,#233971,#1e4173,#11316b,#7f8dab,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#838699,#010524,#161938,#151839,#14173a,#14173b,#14163b,#151839,#111532,#11142e,#070c23,#131533,#161836,#0e102d,#161934,#1e2139,#0d0f2d,#101230,#181a34,#0c0e2c,#16163a,#161741,#12163d,#080c29,#191f38,#0d1131,#12163e,#0f1430,#161a37,#101435,#171a40,#12153f,#131339,#181839,#141839,#161e44,#1b2654,#1f2a5e,#1a265a,#202c60,#1a265a,#202c60,#182458,#1f2c60,#1a275b,#202d61,#1c285c,#1f2b5f,#1b2a5d,#1d2d60,#1d2d60,#19295c,#1b2b5e,#1e2e61,#1c2c5f,#1d2d60,#1f2f62,#1c2c5f,#1f2f62,#172a5d,#1f3366,#162a5d,#213568,#162a5d,#223669,#192d60,#213568,#182c5f,#1e3265,#162b5e,#203768,#172d5f,#22386a,#172d5f,#213769,#182e60,#23396b,#182e60,#1f3567,#1a3163,#22386c,#1a3165,#243b6f,#1f366a,#253c70,#20356c,#223971,#1e4275,#0f2f69,#8492af,#fffffe,#fdfdfc,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#828598,#020625,#141736,#151839,#15183b,#14173a,#131639,#131638,#111434,#131735,#151936,#111535,#131737,#141839,#141738,#121537,#171b3b,#161a3c,#14173c,#181a42,#14163e,#151843,#141843,#181c42,#13183c,#161a42,#191d49,#191e44,#12173d,#1c2048,#181c45,#191e48,#1d1e4d,#1d1e4c,#1a1f47,#182249,#212d5b,#142254,#212d61,#192559,#222e62,#1b275b,#1e2a5e,#1a275b,#212e62,#1b275b,#202d61,#1c295d,#1f2e61,#1b2b5e,#1a2a5d,#1c2c5f,#1d2d60,#1d2d60,#1b2b5e,#1f2f62,#1d2d60,#1f2f62,#1b2b5e,#1d3164,#192d60,#1c2f62,#182b5e,#223669,#1a2e61,#1f3366,#182c5f,#23376a,#182c5f,#213668,#162c5e,#213769,#182e60,#203668,#182e60,#23396b,#172d5f,#1f3567,#1a3062,#203668,#192f63,#233a6e,#1c3367,#22396d,#1c3467,#23386f,#223871,#1d4073,#0f2f69,#7b8aa8,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#828598,#030827,#141736,#101334,#111437,#111437,#141738,#131638,#141739,#131538,#14173a,#121737,#121738,#101539,#13173e,#13163f,#121737,#121738,#151943,#141843,#11153c,#151b40,#121940,#11183f,#131a41,#131a41,#141b43,#141c43,#141b43,#161d44,#131940,#151d43,#151843,#181c46,#131b41,#1b274f,#152453,#1c2b5f,#1a2559,#212d61,#162256,#1f2b5f,#172357,#1d2a5e,#1a275b,#212d61,#192559,#1c285c,#1a295c,#17275a,#1c2c5f,#1c2c5f,#1d2d60,#1d2d60,#1c2c5f,#18285b,#1f2f62,#1a2a5d,#1f2f62,#182c5f,#1d3164,#182c5f,#1e3164,#14275a,#203467,#15295c,#1f3366,#182c5f,#213568,#172c5e,#1d3365,#162c5e,#1f3567,#192f61,#203668,#172d5f,#23396b,#192f61,#213769,#1c3163,#20366a,#1c3367,#22396d,#1f366a,#233b6e,#20366c,#213870,#1a3d70,#0c2c67,#8694b2,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#84879a,#060a29,#141736,#16193b,#14173a,#16193c,#121536,#16193c,#14163b,#17193f,#13153c,#151b3e,#101639,#171d43,#131841,#161a49,#141c39,#141c35,#14193e,#171c44,#151c3d,#151d3b,#121b3f,#151d43,#141d43,#151d42,#141d3f,#161e45,#172046,#141c42,#182145,#151e41,#1a2045,#191f42,#1b2547,#101e45,#223263,#16245a,#243064,#19265a,#243064,#172357,#263266,#1c295d,#243165,#19265a,#223063,#1a275b,#202f62,#19295c,#1e2e61,#1c2c5f,#1d2e61,#1e2e61,#1f2f62,#203163,#1a2a5d,#223265,#1d2d60,#1e3265,#192d60,#1f3467,#192d60,#203467,#172b5e,#203467,#15295c,#213568,#182c5f,#23386a,#172d5f,#203668,#182e60,#203567,#162c5e,#203668,#172d5f,#23396b,#192f61,#22386a,#1a3164,#1f376b,#1b3266,#20376a,#1f376a,#23386f,#1f356e,#1b3d70,#10306a,#7e8caa,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#8e8da2,#060628,#1f2142,#171b3f,#181d42,#14193e,#1b1e43,#171b3f,#1a1e43,#181c41,#1a1e44,#141a49,#131d43,#162441,#13203e,#1b2349,#121e48,#182345,#1a1b40,#1f1e54,#141d4f,#16264c,#111d47,#19264f,#121d47,#1b2751,#111e47,#1e2a53,#111e48,#1c2852,#15214b,#1f2c55,#101d49,#212e5a,#15224e,#23305d,#182652,#253363,#1a275b,#283569,#1e2a5e,#283569,#1e2b5f,#253568,#1e2e61,#213164,#1f2f62,#233266,#213366,#203264,#203365,#1e3264,#25386a,#1b2f61,#213769,#1b3163,#23396b,#192e60,#273c6e,#193062,#233a6c,#182e60,#283c6e,#193062,#2a3f72,#172b5e,#213568,#15295c,#23376a,#172c5e,#1f3567,#182e60,#22386a,#162b5d,#1f3567,#192f61,#203668,#182e60,#1f3567,#1a3062,#1f3567,#1c3365,#1e3567,#1d3466,#22396b,#1c3267,#22396e,#203e70,#112a63,#8591ae,#fffffe,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#85859a,#0e0e30,#1c1e3f,#181c3f,#14193e,#161b41,#1a1e43,#191d42,#191d42,#161a3f,#191d42,#161b42,#1a1e49,#141847,#1c204e,#171c46,#1b204a,#171d48,#1d2554,#101649,#21234a,#171c3d,#172550,#101d47,#1d2a54,#111e48,#1c2853,#111e48,#1d2a54,#13204a,#1b2852,#111e48,#1e2c58,#13204d,#1c2a57,#131f4d,#273562,#182655,#273468,#1c295d,#263367,#1d2a5e,#253266,#1c2c5f,#203063,#213164,#1e2e61,#213063,#1c2f61,#233466,#1c2e60,#223668,#1b2f61,#223769,#1c3264,#283d6f,#192f61,#253b6d,#1a3062,#243b6d,#152c5e,#253b6d,#1a3062,#293f71,#15295b,#223568,#172b5e,#1f3366,#192d61,#1e3365,#182e60,#22396b,#152b5d,#203668,#1a2f61,#203668,#192f61,#213769,#1b3163,#1f3567,#1a3163,#1f3668,#1c3365,#21386a,#1b3263,#20366b,#233a6e,#1f3d6e,#132b65,#7d88a4,#fffffd,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#8b8a9f,#09092b,#1d1f40,#16193d,#161b40,#181d43,#181c41,#181c41,#181c41,#1b1e44,#171c40,#1a2843,#10193d,#181c4b,#151a48,#18254a,#12193f,#192059,#0b1b56,#152952,#131a3f,#20234e,#0e1c45,#1c2852,#101c46,#1c2953,#101c46,#1c2953,#121f49,#1b2751,#111e48,#1e2a54,#13204c,#1d2b58,#12204c,#23305d,#192653,#263363,#1a275b,#253266,#1e2b5f,#263367,#1e2b5f,#213063,#1d2e61,#233366,#223063,#1f2f62,#213264,#1d3062,#243769,#1a2e60,#233769,#192d5f,#22386a,#182d5f,#293f71,#172d5f,#263b6d,#172c5e,#263b6d,#172e60,#253c6e,#142b5d,#293e70,#15295c,#22376a,#192d60,#213568,#182d60,#1e3466,#182d5f,#1d3365,#1a3062,#203567,#172d5f,#213769,#192f61,#1f3567,#192f61,#1c3365,#1b3264,#203769,#193062,#1e3566,#21376c,#1f366a,#1f3c6e,#112a63,#8590ad,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#88879d,#0e0e30,#1a1c3d,#1a1e41,#161b41,#191e44,#171b40,#171b40,#191d42,#15193e,#1c2146,#13153b,#292342,#251834,#29203d,#1b1c3d,#292640,#20163a,#282549,#1b222e,#1a2040,#101754,#1a2750,#111e48,#1c2852,#132049,#192650,#121f48,#1b2751,#131e48,#1f2b55,#15214b,#1d2b57,#111f4c,#1c2a57,#13214f,#253360,#192655,#263367,#1c295d,#222f63,#1a275b,#253266,#1e2d60,#1f2e61,#212f62,#223265,#202f63,#1d2f61,#223668,#182d5f,#223668,#192d5f,#263b6d,#162c5e,#253b6d,#192f61,#243a6c,#162c5e,#273a6c,#192e60,#263c6e,#182f61,#283f70,#1a2e61,#203568,#172b5e,#1f3366,#182b5f,#203467,#182e60,#213769,#172c5e,#1e3466,#162d5f,#1f3567,#192f61,#1e3466,#1b3163,#1e3466,#1b3163,#1e3567,#1a3163,#1d3466,#203768,#1e3468,#1e356a,#1d3b6c,#132c65,#7a84a3,#fffffc,#fcfbfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#8a8a9f,#0a0a2c,#1d1f40,#161a3d,#171d42,#161b40,#171b40,#161a3f,#181c40,#1d2247,#0b0d2f,#85683f,#cda84f,#cda429,#cda731,#b89d49,#b89c43,#d4a553,#ca9335,#c3a127,#898046,#1f223b,#111f4b,#1a2750,#0f1c45,#1b2852,#13204b,#172450,#111e49,#13204b,#14214c,#1b2751,#14214d,#1b2956,#121f4c,#1f2d5a,#1a2854,#233160,#1a275c,#212e62,#1c295d,#212e62,#1d2a5e,#1f2e61,#1f2f62,#202f62,#213063,#1d2c60,#223467,#1a2e60,#26386a,#1a2d5f,#25386a,#1a2e60,#243b6d,#172d5f,#273d6f,#172c5e,#263c6e,#172d5f,#273e70,#132a5c,#273e70,#162d5f,#273c6f,#192d60,#203467,#162a5d,#223669,#172b5e,#1f3567,#182e60,#1f3567,#182e60,#203668,#192f61,#1e3466,#192f61,#1f3567,#1b3062,#1e3466,#193062,#1d3466,#1e3567,#1b3364,#1e3468,#1e356a,#1d3b6d,#0e2860,#808baa,#fffffe,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#848499,#0d0d2f,#1d1f40,#181c3f,#171c41,#151a3f,#1b1f43,#161942,#1b1e49,#171b42,#16163b,#ae804d,#eaae47,#e5ab39,#eabb47,#dfb147,#ddaa39,#edb740,#edac3c,#e1a831,#c49145,#181d34,#192651,#101b47,#1d2a57,#0f1d46,#0f1d43,#1a223f,#4f536d,#8488a0,#0f183a,#15234f,#192755,#14214d,#1c2956,#182451,#263360,#1a2756,#232f61,#1d295b,#232f60,#212c5e,#222d5f,#233063,#222f63,#212f63,#202e62,#263468,#1b2d61,#23376a,#1b2f61,#24386b,#162a5c,#25396c,#1a2e61,#24396b,#16295c,#273b6e,#182d5f,#263d6f,#132a5c,#273e70,#182f61,#283f71,#152a5c,#1e3265,#182c5f,#1f3366,#172b5e,#1d3264,#172c5f,#213568,#182c5f,#203567,#192e60,#1e3466,#1a3062,#1d3264,#192f61,#203668,#182e60,#1c3365,#1f3668,#1e3466,#1d3466,#1e3366,#1f3667,#1f3c6b,#152c64,#7c86a3,#ffffff,#fcfbfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#8a8a9f,#070729,#1d1f40,#181c3f,#12173d,#191d42,#171b3f,#1a1e49,#141644,#1a1e47,#0f1035,#9d773c,#d19b30,#c79434,#d5b346,#d9b334,#d7a734,#d9ab3a,#c38e30,#c68f2f,#b07125,#1c273d,#151c4a,#1f2552,#0a123c,#283252,#39455b,#8e93a1,#6e707d,#b6b7c3,#2c324e,#152351,#12204f,#1b2754,#15224f,#1f2c59,#1c2956,#1f2b59,#1c2858,#212d5d,#1f2b5a,#212c5c,#222c5c,#212c60,#212c60,#222e62,#233065,#1e2a5e,#213366,#162a5d,#23386b,#172c5f,#263a6d,#15295c,#24376a,#192c5f,#26386b,#1c2e61,#283b6e,#162d5f,#294072,#172d5f,#273e70,#162d5f,#2a3f72,#14275a,#1f3366,#172b5e,#203467,#172b5e,#1e3265,#182c5f,#203467,#1a2d60,#1f3366,#1c3264,#1f3567,#1b3163,#1c3264,#192f61,#1f3567,#1c3264,#1d3365,#1f3567,#1b3163,#203567,#1c3261,#223e6c,#10265d,#848ca9,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#858599,#0e0d30,#1a1c3e,#181c40,#161b40,#13183d,#1a1e42,#151843,#1d204c,#161943,#161739,#ad9036,#f3c33e,#efbf52,#c6a545,#be953c,#c59034,#be8d2b,#d49c36,#dba435,#c98e3a,#141c34,#202354,#0e103a,#5b5d7c,#6a6d7c,#aaafb3,#6c7183,#90939f,#878a98,#696f8a,#05103d,#1c2a59,#15224f,#192653,#13204d,#25325f,#1d2957,#243061,#1d2959,#1e2959,#212d5d,#1f2a5b,#212d61,#202d61,#233064,#1e2b5f,#2b366a,#1c2d61,#24386b,#182c5f,#23376a,#182c5f,#25396c,#182c5f,#273b6e,#182b5e,#283b6e,#162a5d,#263d6f,#152c5e,#263d6f,#162d5f,#263d6f,#182d60,#1f3366,#172a5d,#1f3366,#182c5f,#223669,#172b5e,#203467,#1a2e61,#1f3366,#1a2e61,#1c3264,#1c3264,#1e3466,#182e60,#1c3264,#1c3264,#1d3365,#1c3264,#1d3365,#1d3365,#1d3264,#233969,#1a3665,#142a61,#7a83a1,#ffffff,#fdfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#8b8aa0,#09092b,#1b1d3f,#181c40,#151a3f,#181c42,#171a3f,#1c1f4a,#141744,#1e224a,#0f1035,#a37f3d,#d8a536,#d3a23f,#b69431,#c9a32e,#dca448,#b27f26,#c48d2b,#c48d28,#b37827,#202940,#171a4b,#181a41,#4d4d69,#a5a5ad,#8a8b8c,#7c8192,#9294a2,#8c8f99,#666c81,#091540,#172553,#1b2754,#14214e,#1b2855,#1c2956,#222e5c,#1e2959,#212d5d,#232f5e,#202b5b,#212c5c,#1e2a5d,#253165,#1d2a5e,#253366,#1d295d,#26386c,#182c5f,#223669,#172b5d,#253a6c,#14275a,#25386b,#182b5e,#283c6f,#172b5e,#273b6e,#172d5f,#273e70,#142a5d,#263d6f,#183062,#283d6f,#162a5c,#203366,#162a5d,#1e3265,#162a5c,#1e3265,#182c5f,#1e3265,#1b2f62,#1d3265,#1b3062,#1f3567,#172c5e,#1d3365,#1e3465,#1b3163,#1d3365,#1d3365,#1f3567,#1c3364,#1e3365,#192f5f,#213d6c,#0b2058,#848caa,#fffffe,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#848499,#0d0d2f,#1c1e3f,#13173a,#191f44,#12183c,#1b1f43,#131742,#1b1c4a,#171b43,#1a193f,#b18254,#e7aa4a,#dca341,#bd9330,#c3951b,#d29744,#b68034,#d19833,#d49f30,#c98939,#141f34,#19274d,#060d30,#676a87,#9695a2,#96959b,#6c717f,#969aa3,#8b8d95,#71788b,#041039,#1c2b57,#162250,#1d2958,#162350,#23305c,#1c2857,#1e2a5b,#222d5e,#222d5d,#222d5d,#1f2b5b,#253165,#1f2a5f,#253166,#1b285c,#283468,#182a5c,#273b6e,#162b5e,#25396d,#15285d,#28396e,#18295c,#273a6d,#142759,#2b3e71,#182b5f,#273e6f,#132b5c,#283f70,#152c5e,#273d70,#1a2e62,#1d3066,#162a5f,#1e3466,#172c5f,#1f3468,#192e61,#1f3468,#172b60,#1f3366,#1c3163,#1d3367,#192f62,#1d3466,#1d3366,#1a2f64,#1e3367,#1c3265,#1c3264,#1c3264,#1e3567,#1c3265,#213867,#1c3968,#142a63,#7d86a3,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#898a9e,#0a0a2d,#1a1c40,#191c42,#14183e,#1b1e45,#171942,#1c1e48,#141840,#1b224a,#0c0f33,#b59327,#e9b522,#d79a2e,#c08e30,#b88533,#b57b33,#b68c2c,#c89c2c,#e2ac38,#c49f29,#16273c,#13194e,#191f49,#2d3254,#4f5267,#9395a3,#828794,#7e828c,#9498a1,#4f556c,#0f1940,#131f51,#192752,#132147,#1b2857,#1d2959,#1c2852,#212c55,#1c2653,#212c5a,#1b2755,#23305c,#182558,#253364,#182758,#273568,#1b2860,#24336a,#14255a,#27396b,#132755,#263b65,#162a57,#243a6e,#10275d,#243d72,#132a5d,#243b6b,#152961,#243870,#162c61,#243b6d,#142e5e,#223867,#1a2e55,#1e3059,#1b295f,#1d2d5f,#1d2d5a,#1e2a60,#1b2d5b,#182b58,#1e2e61,#1c2a62,#19315a,#162c58,#1f3363,#142c57,#183659,#162d58,#1f3364,#182c5c,#203464,#172b5b,#203364,#192c5a,#213b66,#0a1f53,#848ba6,#fffffe,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#848699,#090c30,#1b1c46,#161644,#191b42,#171842,#1c1a48,#161a3d,#171d3c,#121d44,#131945,#a17437,#cd932d,#c57b31,#d6932b,#ca942f,#cc8d2a,#d1a730,#c29637,#db8b54,#a59120,#111840,#222058,#1a1d46,#181e42,#161e3f,#151b3b,#6c7289,#666c80,#b4bacb,#222648,#1c1f49,#1c2156,#19224a,#1c2744,#192149,#1b2251,#18204d,#1a2255,#1a225c,#17215e,#19265f,#152457,#19295c,#142652,#1c2d57,#152556,#1d2c69,#152260,#23316c,#15245f,#1c2d68,#12265f,#1b2e6a,#142762,#1a325e,#0e294d,#19315c,#15295e,#1c2f61,#152b5c,#1b3163,#10285b,#183365,#132768,#152453,#1b234d,#1f2267,#1b265b,#1d2849,#242355,#1b284c,#182c4b,#1a2751,#1f245a,#182853,#1d265a,#1d235c,#19285a,#0f2d4f,#162d53,#1a2956,#1b2b57,#172853,#182955,#192755,#1d2a57,#193053,#0a1d47,#80869b,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878a9d,#080b2f,#191b44,#1b1c48,#11133b,#1a1b41,#18193c,#1b1e3f,#15193c,#1d234e,#0b0b3c,#ab734b,#e8a947,#e49d38,#eaaa27,#d79e29,#dd9d2e,#edba27,#f3bf29,#ffb351,#cea04b,#2a2349,#0c1e33,#1a2642,#131d42,#1e2450,#181c4b,#0b153d,#30395c,#4b5575,#0a133e,#1e2659,#1a2053,#1c1f5f,#1b1e5e,#1c224d,#1e2157,#1d2262,#172454,#162359,#19295d,#142754,#172c52,#142354,#1b2c5a,#162752,#1b2c5c,#15245c,#1c335c,#102b4e,#1a305e,#14265f,#1d2c6c,#15206c,#212a78,#182456,#25345a,#19255c,#212c74,#0f2f51,#19385b,#112c58,#1b3265,#162b62,#1d2d6f,#19255b,#1c2851,#1c2857,#152d4f,#172d45,#1e274f,#192955,#172a56,#182b4d,#192b46,#1e2654,#202651,#21274d,#1e2652,#1b275c,#1a2a5a,#1a2b57,#1a2b57,#182955,#182955,#1a2857,#1d2a57,#1a3155,#0a1d48,#80869c,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fbfcfc,#ffffff,#818396,#080b2e,#20214b,#151642,#1c1d45,#15183a,#1a1f3b,#15173a,#1b1c43,#161742,#1b1a47,#48383a,#746436,#745d36,#7b6632,#755f48,#7b6153,#84713c,#87722a,#8d7140,#625a3b,#0e1643,#1a2658,#11184e,#1c2258,#161b4b,#1c224b,#111c49,#16224d,#09143d,#1d2954,#151e54,#182b49,#0d2343,#14264f,#14293d,#122840,#17274d,#1b284e,#192852,#152650,#172c4d,#132945,#192a56,#162755,#1c2d5b,#132452,#1d2d5a,#152959,#1b3162,#132853,#203359,#192a4d,#1f3754,#0d2d4a,#1a305c,#162959,#21395a,#0f2f45,#1a3475,#10286a,#1b316b,#12285a,#1b305f,#1c2e50,#182642,#1c2744,#1e2a4a,#142751,#192b5a,#1c2555,#1e2761,#1a2560,#192a59,#182c50,#1a2e53,#152c48,#152e43,#192f4b,#162954,#182957,#1a2b57,#192a56,#182955,#192b57,#1b2958,#1d2a57,#1b3156,#091c47,#7e859b,#ffffff,#fcfbf9,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#888b9e,#090c30,#191a44,#191a46,#161840,#1d2043,#121739,#1a1c43,#191841,#201d41,#100d30,#0e1542,#030d23,#0f1344,#03072a,#101040,#030b38,#0f133a,#0b033f,#0e0e4b,#001133,#142438,#171337,#1b1a4c,#16184f,#1c2350,#141d40,#1d244e,#171f43,#1a2443,#0d153a,#1a2149,#141b54,#18244c,#121f45,#141b62,#141e57,#162140,#141949,#151c54,#161f5c,#121c57,#152259,#142551,#19295a,#132356,#1f305d,#0f2245,#1a205d,#1a1a62,#202666,#131e59,#1b2a5c,#112757,#17326a,#152064,#20266d,#0c1e59,#13305e,#141d55,#1d275c,#132154,#1c2f61,#152b58,#1c2e5d,#1c2461,#1e1f59,#202144,#242458,#1e2063,#192249,#1c2146,#191e42,#1b2452,#1a295e,#0c1c51,#192c64,#152a63,#102157,#1e2752,#12204c,#182a57,#192a55,#1b2b57,#1a2b57,#1c2a59,#1d2a57,#1b3156,#091c47,#7d849a,#ffffff,#fcfbf9,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#85889b,#06082c,#1c1e47,#171844,#1c1e45,#12153b,#1a1d46,#171745,#191742,#241f3a,#635e6d,#4a455a,#43424a,#1d1a37,#82807a,#8a8668,#363952,#343143,#8e8570,#7d8273,#242853,#4d4956,#8c8563,#777175,#201e3f,#151b4b,#182350,#171a3f,#191b3c,#363a52,#6f7282,#121733,#3b3653,#878471,#87866b,#3a2f5a,#4a4054,#878d6a,#7e8780,#2b3234,#5a6170,#4b506a,#4c576d,#102149,#152555,#1c2c5f,#0d1c4b,#2e4060,#8b8e8f,#a4a3a3,#4c525a,#54616e,#435471,#14275a,#182252,#676964,#92917a,#8f9197,#1f2753,#707566,#a7aaaa,#5d6779,#122549,#1c326c,#152962,#141f55,#35354c,#858567,#726e4f,#343532,#414751,#868a7b,#7f7f73,#262c3f,#232e57,#78777f,#282a47,#212451,#6d6d81,#918978,#52596a,#102253,#182955,#1a2b58,#1a2b57,#1c2a58,#1d2a57,#1b3156,#091c47,#7d849a,#ffffff,#fcfbf9,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#86889d,#060a2b,#191c3e,#191b40,#13163c,#1a1a40,#151539,#162047,#0c1441,#302d3c,#837b60,#827a68,#4b444c,#3b4233,#635c4f,#4a4844,#5d5557,#5b5b4f,#564d50,#645c5b,#484a36,#6e6c61,#42354b,#737062,#3b3d38,#18155b,#181e46,#192544,#121554,#3c2e57,#9a946b,#17224a,#1f2e37,#27243c,#686a43,#807f6b,#211b4f,#16242d,#727956,#675e52,#757e56,#7a6469,#6e7068,#0b1738,#1b2d4f,#11284a,#161b68,#474552,#7d7b56,#17254c,#182f61,#5f6656,#5d6360,#001148,#122f5b,#24323e,#2d3e4c,#94885a,#3d4462,#738678,#59564d,#9aa098,#263f4e,#122a4d,#18346e,#0c1655,#6d6951,#726f5b,#413541,#505930,#756466,#43464d,#7d686c,#454e63,#122348,#9f8d5c,#252a4a,#2a3b4a,#797b66,#423342,#80775c,#212452,#142e5f,#182a59,#1a2a5d,#182e4e,#1a2b57,#1d3055,#0d1a47,#7f859c,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#838599,#05082a,#1d2041,#14173b,#181a41,#16163d,#1b1d3f,#101a3e,#161e4f,#1c1937,#726b62,#817648,#7e746f,#343039,#5e4c59,#322641,#5a4f4b,#4f4f42,#4d3e5b,#4d3e57,#4f4f34,#595849,#3c305d,#555858,#3a4647,#0a1652,#152c46,#0c263a,#0f244c,#292a3c,#82805d,#0e1658,#343655,#958a8d,#7f8242,#47463b,#15134b,#687374,#8f8763,#484249,#4a5f43,#857a36,#938d65,#222c53,#13264c,#1a3152,#151c64,#3f4054,#88825f,#7e8673,#2b3359,#48404a,#8e8e62,#828885,#242f52,#1b2468,#08245f,#807657,#2d2d58,#4f4e66,#b6ac77,#8d8f71,#0d195d,#1d2f66,#14314b,#121c67,#363b4e,#87947a,#918383,#47412f,#5e555a,#393b6d,#605745,#3c4a4d,#0d1b5e,#857664,#22286c,#1f3a2b,#5e6263,#352960,#6e6b47,#202648,#132c58,#1a2a56,#1c295f,#182d51,#1a2b57,#1d3055,#0d1a47,#7f859c,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#888a9e,#0b0e30,#181c3d,#181b3f,#14163d,#1c1d45,#131638,#182042,#111648,#1f1e4c,#121124,#75653e,#56473f,#3d334b,#5d4a49,#51463f,#6b5e5c,#54534b,#4b4337,#6d6553,#525142,#57514c,#423232,#7b7769,#3c3f47,#111850,#102046,#13244b,#0d1f39,#3d3f32,#9f9466,#191237,#57604c,#797a86,#1a1e44,#101d42,#142e4b,#222e46,#816c5e,#5a5f59,#061550,#584947,#766a54,#0c1642,#1c2b5c,#122544,#1f2865,#1a233f,#2e1f43,#605744,#787476,#483d51,#63594c,#6d5c5d,#827f7a,#0b1060,#0f3572,#78745b,#3e3f54,#6d686d,#78673c,#84825a,#1f2f55,#192967,#1c2f5b,#17245d,#112443,#142933,#584d4a,#634f4b,#5f5157,#443e4e,#817653,#4d4c56,#231f51,#a19070,#2c2c53,#2a3042,#685d6b,#483b44,#868861,#1a2543,#142c50,#1d2951,#1c275f,#172d53,#1a2b57,#1d3056,#0d1a47,#7f859c,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#84869a,#070a2b,#1a1d3e,#13163a,#181a40,#12133d,#1b1e45,#131936,#191d49,#161847,#111639,#6f6263,#4b4241,#1d1b35,#857e66,#8a8c6a,#4e474f,#2f3138,#898d60,#8c8f60,#373a3e,#494450,#908360,#7f7763,#322b3f,#1b144f,#211e52,#1d1a56,#202448,#847f77,#8a7758,#756b67,#3e2d2b,#917c6a,#a39c87,#423d4b,#484351,#77796a,#88815f,#3c4049,#041849,#585456,#5f5e6f,#101d50,#14205a,#1d2e4d,#0e1b4b,#303d6b,#696f72,#858654,#524f4d,#39404d,#6e764a,#8d8561,#4b5050,#1b2557,#092b56,#746f6f,#283440,#505967,#928f60,#8c9272,#11215c,#1b3258,#1a2c63,#18244c,#1f2e42,#081954,#4a4b66,#706365,#453734,#8b8855,#8d8366,#392b3f,#7c736a,#837745,#7d8167,#261e4e,#716163,#908c51,#63684d,#13214b,#172b53,#1f264d,#1c265d,#162c53,#1b2b57,#1d2f56,#0d1a47,#7f859c,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#86889d,#090c2d,#181b3c,#1a1d41,#12143a,#1b1d4b,#141744,#1d233b,#111537,#1d2449,#0b183e,#171339,#10151d,#0e1947,#171b1a,#1f2448,#13142f,#19213e,#1a1b32,#1e1f38,#111535,#1a2244,#151e30,#192339,#131849,#1b2252,#192140,#1c214f,#13224b,#1d2444,#231d3f,#1e2844,#232154,#232338,#1e2a34,#1d264d,#25244b,#1f293a,#202241,#1a1743,#1b315b,#1c1c3f,#173043,#112254,#1d266d,#13233e,#1c2c55,#11235a,#1f394b,#24274d,#23215f,#0a2a4f,#25394c,#262745,#142b61,#18273f,#18355f,#2b1c5a,#1a3354,#0e2f4c,#2e3553,#18244a,#142d72,#122c58,#152b65,#202659,#281f52,#1a2457,#12264d,#1e274d,#171f56,#1b2736,#161f51,#1f2452,#24283f,#1f2052,#192e4a,#162946,#232451,#1b2841,#14222e,#17245d,#18295c,#23254f,#1d255d,#162c52,#1b2b57,#1d2f56,#0d1a47,#7f859c,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#89899b,#050424,#1f1e41,#16143a,#1a183b,#16153b,#16183f,#141534,#181a39,#101433,#242949,#33354a,#303640,#2d3451,#2e3149,#0f103f,#1c1e41,#13183d,#171846,#181a49,#14183e,#151c41,#0e1741,#151e46,#131b46,#161e42,#151e3a,#19203f,#111b3f,#161c48,#14164a,#181e52,#071441,#122243,#0e1756,#1a2a52,#031f29,#12265d,#161559,#212251,#12194c,#1b1b58,#121e4b,#1f2756,#131b3f,#20255b,#15203c,#192155,#121e4e,#191f59,#192151,#152c52,#15245e,#1a2162,#19275d,#1c264a,#1c2755,#201e5a,#1b2753,#13294f,#182363,#1b2862,#1a2d58,#142557,#1f3062,#16204f,#1e2155,#1a254c,#142650,#172754,#172859,#172753,#152658,#17284e,#18264d,#1a275e,#162b54,#193043,#1b2a52,#172956,#1b2b4e,#1a2859,#182855,#1d2852,#1b2854,#1a2954,#1c2a57,#1c3056,#0a1b47,#7e859c,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878595,#070322,#1b173c,#1a143c,#191537,#181536,#151538,#151438,#141535,#141431,#9697af,#a4a7b0,#9496a5,#aaacbd,#8c8ea6,#14152e,#141637,#111336,#121536,#111435,#131638,#131538,#161839,#141638,#141738,#0d0f32,#121438,#151738,#16183a,#17193d,#15173d,#14143f,#151a42,#131a2b,#18173f,#141635,#0e2028,#0b1849,#151c3c,#131d38,#151b43,#141e31,#15184e,#131848,#151e34,#141658,#161f3a,#171b4c,#191e4a,#171f45,#161f47,#141d4a,#121e4c,#141f4c,#1b2049,#1b214f,#1b214d,#1a234c,#1b214d,#182352,#17244e,#16224d,#17224f,#182350,#15214b,#19264f,#17264e,#18254f,#19254f,#18254e,#19264e,#1a264f,#1a264e,#192650,#192651,#1b2850,#1c2752,#1b2655,#1b2852,#1c2851,#1a2953,#1a2951,#1a2951,#192952,#1a2950,#1c2855,#1d2a57,#1b3156,#091c47,#7e859c,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#868595,#050221,#1b173c,#19143c,#191538,#171537,#141438,#131336,#121333,#131432,#2f304c,#424458,#393c51,#464860,#3b3c58,#10112f,#141638,#121539,#131639,#111438,#111437,#14173a,#111438,#111538,#14173a,#14173a,#121538,#131638,#121538,#14173c,#14163b,#15173d,#15193c,#12192d,#161a3b,#161845,#121a38,#161c4d,#101a36,#131e33,#171d53,#111e27,#131b47,#16203a,#141f2f,#171f40,#152034,#182338,#192041,#181d48,#171d4a,#16204a,#142247,#152046,#171e4b,#181f4b,#19214d,#1a214d,#1a214d,#182250,#182251,#172150,#1a2452,#192352,#182450,#18254f,#18254f,#18254f,#18254f,#18254f,#192650,#192650,#192650,#192650,#192650,#1b2852,#1b2852,#1b2851,#1b2852,#1b2852,#1a2952,#1a2952,#1a2952,#1a2952,#1a2951,#1c2855,#1d2a57,#1b3156,#091c47,#7e859c,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878595,#070322,#1b173c,#1a153d,#191538,#181537,#16163a,#161639,#131535,#121432,#0e0f2e,#0a0b26,#0b0d28,#0a0b28,#0c0d2b,#141533,#141638,#14173a,#14173a,#141739,#14173a,#14173a,#14173a,#14173a,#14173a,#14173a,#14163a,#14173a,#14173a,#131638,#131637,#0d1130,#101038,#0d0e36,#0c0f31,#110e4d,#19134b,#131234,#171b43,#0c1131,#0d0f3e,#141a36,#161845,#191846,#14124b,#100f40,#191651,#12113d,#121434,#1b2041,#1a1e4a,#181f4a,#172144,#162144,#181e4b,#19204c,#1a214d,#1a214d,#1a214d,#1a2251,#1a2251,#1a2151,#1a2251,#1a2251,#192450,#18254f,#18254f,#19264f,#19264f,#19254f,#18254f,#18254f,#192650,#1a2750,#192650,#1c2952,#1b2852,#1b2852,#1c2953,#1d2a53,#1b2a52,#1a2952,#1a2952,#1a2952,#1b2951,#1b2855,#1b2855,#192f54,#081b46,#7f859d,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878595,#070322,#1b173c,#1a153d,#191538,#181537,#16163a,#16163a,#151535,#131431,#141532,#151538,#151536,#151537,#151536,#131432,#141638,#14173b,#14173b,#14173b,#14173b,#14173a,#14173a,#14173a,#14173a,#141739,#14173a,#14163d,#14173b,#131736,#171938,#353953,#3a3959,#373758,#434b51,#201f4b,#2d224c,#78775f,#141131,#5c5974,#5b5e52,#120e35,#373640,#686656,#3d344a,#77736c,#211930,#6b675c,#595d5c,#0c1227,#1b1e45,#1a1d50,#181f4a,#182045,#181e4b,#19204c,#1a214d,#1a214d,#1a214d,#1b2151,#1b2151,#1b2151,#1b2151,#1b2151,#192450,#182550,#17244f,#12204b,#14224d,#172550,#192650,#18254e,#192751,#162450,#182650,#192752,#192751,#1d2b54,#1a2853,#152350,#182752,#1a2952,#1a2a52,#1a2a54,#182851,#1b2955,#1b2855,#192f53,#081b46,#7f859e,#ffffff,#fcfcfa,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878595,#070322,#1b173c,#19143c,#181437,#181437,#171639,#151736,#121538,#121439,#131434,#121438,#12133b,#121435,#121430,#131432,#131539,#131735,#121833,#121834,#131835,#13163c,#131739,#131738,#14163b,#15153f,#15163a,#141836,#17163a,#121336,#21283d,#7c8297,#767484,#777683,#899288,#413f5a,#221722,#959256,#1f152d,#423d38,#616146,#160b25,#6a684e,#413b44,#2c2142,#605b55,#483c55,#544940,#6d6a60,#252732,#191c45,#171e45,#191f47,#181d4c,#181e49,#1a1f4a,#1b204b,#1b214c,#1b214c,#1c2150,#1c2150,#1c2150,#1c2150,#1c2150,#1a234f,#17234d,#1a274f,#2e395d,#283050,#192245,#13204c,#1a2554,#172148,#212b49,#1d2551,#222b4b,#222b52,#121b47,#162042,#2b3350,#1d2749,#1c2753,#1b2553,#182346,#202b4c,#1c2553,#1d2856,#1a2e58,#091b46,#7f859a,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878595,#070322,#1b173c,#17123a,#161235,#171337,#181637,#131931,#0e1640,#101344,#141636,#101636,#0f1340,#101437,#111728,#121433,#12123e,#101435,#101735,#111834,#111533,#131441,#101538,#131732,#15143d,#171247,#18153a,#131931,#1c103e,#1c1848,#041326,#5b5e75,#888490,#8c8999,#8d8d9b,#41395c,#211420,#9a936e,#231638,#68673c,#403650,#352a3b,#6b6950,#02013f,#485240,#575d3f,#251a42,#645f43,#736d54,#252031,#14174a,#132230,#17203b,#1a1a53,#191c44,#1b1e47,#1c1f48,#1d2049,#1d2049,#1a214d,#1a214d,#1a214d,#1b224e,#1b224e,#1b234d,#172149,#1f2a4f,#636882,#c7c4cd,#d8d7dd,#36406b,#090e44,#9aa2ae,#d9dde2,#545278,#e9e8e9,#5d5d78,#515572,#dbdde0,#fbfafc,#e1e5eb,#2c3259,#1b1d48,#b7bcc3,#ecebed,#505174,#151c4a,#202f62,#0a1a44,#7e8695,#ffffff,#fcfcfc,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878595,#070322,#1b173c,#17123a,#161235,#171336,#171637,#131933,#0f143e,#11123d,#0f0f24,#0e102b,#131240,#11123c,#111530,#111339,#11133c,#111043,#0d0b3d,#0d0b3a,#11113d,#0b0e2d,#111337,#0c0f22,#131236,#16103a,#100e27,#13163d,#170a3d,#0e082d,#0a1234,#24213e,#322e41,#353557,#3e4451,#22253f,#1b1537,#42413d,#191638,#474b3c,#423f61,#302c50,#2f2f37,#0f103b,#384134,#4f553f,#1e1837,#4d4d35,#43403f,#151236,#1a1b52,#16203b,#161f3d,#191c4c,#191c45,#1b1e47,#1c1f48,#1d2049,#1d2049,#1a214d,#1a214d,#1a214d,#1b224e,#1b224e,#1c234d,#1a244d,#1a274e,#071030,#535469,#ffffff,#656c8f,#191c47,#fafefa,#989bb9,#696c82,#ffffff,#545769,#e8f1f7,#cad1d2,#3f3e53,#6c6f83,#151b35,#5d6278,#ffffff,#ffffff,#838793,#0f1742,#21315e,#0a1c44,#7e8695,#ffffff,#fcfcfc,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878595,#070322,#1b173c,#17123a,#161235,#161336,#151737,#131935,#12153f,#0d0b2e,#3d393f,#32303e,#120e37,#181641,#131534,#11143d,#12162e,#18143e,#3a334c,#3a3347,#141230,#363d3f,#111138,#3a3d43,#1d1a3a,#221d39,#43424d,#080c28,#372b47,#63615c,#252940,#4f484f,#53504e,#10113c,#091125,#0e182d,#151546,#0e1028,#131738,#0b1120,#0d0f38,#10123f,#101435,#181950,#0f0d4d,#0c0c38,#1b1a3f,#120f39,#121240,#191c47,#191a4f,#171c41,#151e3f,#161d45,#191c45,#1a1d46,#1c1f48,#1d2049,#1d2049,#1a214d,#1a214d,#1a214d,#1b224e,#1b224e,#1c224e,#1b2350,#16244e,#1a274a,#272c4b,#f7faf7,#84889f,#63667e,#ffffff,#313164,#9ca1aa,#f1f1f2,#2f3246,#dce4ea,#f4f7f5,#767487,#15153c,#121637,#c2c5d2,#c1c3cd,#cfcfd0,#bbbdc5,#0d163b,#20315a,#091a41,#7f8796,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878595,#070322,#1b173c,#17123a,#161235,#161335,#151737,#131836,#14153f,#130c29,#554c46,#4b4643,#110b28,#0f0a33,#111431,#101539,#0f1529,#160f39,#706755,#847d62,#0e0b21,#485045,#110e3a,#4e514c,#1b1633,#262232,#51514d,#040822,#463b49,#7c7b58,#131127,#635455,#999472,#262445,#0f1335,#131c32,#141542,#181937,#15193b,#171a3f,#181b3e,#171a3b,#171941,#141840,#161e2e,#171d38,#16184a,#171c3a,#151f41,#141d47,#191b42,#191b45,#151d43,#141e41,#1a1c45,#191c45,#1c1f48,#1d2049,#1d2049,#1a214d,#1a214d,#1a214d,#1b224e,#1b224e,#1d214e,#1b214f,#172452,#1a2851,#0d173b,#c6ccd3,#c5c5ca,#cdd0d4,#cbcfd3,#08093d,#d9e0e8,#cdcdd2,#08082f,#34395d,#b5b8c3,#ffffff,#9b9bb5,#32354d,#ffffff,#626176,#9794a0,#ebedf0,#192241,#1e2f54,#08193e,#7f8797,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878595,#070322,#1b173c,#17123a,#161235,#161435,#141836,#131837,#15143e,#160e26,#605749,#56503f,#130b1e,#443f5d,#1a1c34,#101631,#111533,#180d43,#6b6245,#7e764e,#10092a,#434846,#140f33,#4d5043,#312d41,#262227,#595849,#161737,#413546,#73714e,#130f2d,#79666c,#8f8a4e,#171228,#191744,#131834,#161639,#171731,#17173a,#171544,#181934,#181a2f,#181937,#151c2f,#141843,#141943,#131e33,#131a44,#101d49,#12203e,#191d3a,#1a1a46,#151c46,#141e40,#1a1c45,#191c45,#1c1f48,#1d2049,#1d2049,#1a214d,#1a214d,#1a214d,#1b224e,#1b224e,#1d214e,#1c2250,#162352,#192752,#0a173e,#8489a1,#fefefb,#fffffd,#656682,#1e2047,#fcffff,#92919b,#363366,#32326e,#24283f,#f2f3ee,#c4c5c8,#8f9391,#ffffff,#efecf4,#fcfaf9,#f9fbf0,#343e58,#16274c,#0b1d41,#7f8697,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878595,#070322,#1b173c,#1a153d,#191539,#181434,#161234,#16113b,#151137,#171527,#505149,#414038,#130e21,#5f5d58,#251f3d,#171035,#161426,#1a182b,#37373c,#363639,#141223,#3b394c,#130f20,#3c3940,#5d5c5b,#232219,#575747,#464445,#242124,#565453,#312f32,#353234,#393d3b,#191f2b,#121534,#15163e,#14163e,#14163a,#14173a,#14173b,#15183a,#15183a,#15183a,#15193d,#151843,#151941,#161b3c,#161a41,#161a41,#161b3e,#161a3e,#181c41,#181c41,#181c42,#191c45,#191c45,#191c45,#1a1d46,#1b1e47,#1a1d4a,#1b1e4b,#1c1f4c,#1d204d,#1d204d,#1c214e,#1b224e,#1b224e,#1d2450,#101846,#494e6a,#ffffff,#dddbe8,#1a1834,#575866,#ffffff,#4d4b65,#9797a5,#ffffff,#f6f7f4,#e2e2e5,#656471,#ebeaed,#c2c1cb,#4e4e57,#777681,#feffff,#606986,#0f1f4e,#0b1b46,#7d8495,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878595,#070322,#1b173c,#1a153d,#191539,#181434,#161233,#16103b,#19133e,#181533,#0c0c1a,#0d0c29,#171344,#090922,#110e3e,#151144,#151236,#151237,#12102f,#0d0c2c,#171538,#0f0b39,#141044,#0f0b3c,#0b0833,#15123a,#0c0a31,#0e0c36,#14113d,#0a0733,#0f0c37,#0e0b39,#0d102b,#11172c,#121636,#14163b,#141739,#141738,#14173a,#14173a,#15183b,#15183b,#15183b,#15193e,#15193d,#15193d,#161a40,#161a3f,#161a3e,#161a3f,#161a3f,#181c41,#181c41,#181c42,#191c45,#191c45,#191c45,#1a1d46,#1b1e47,#1a1d4a,#1b1e4b,#1c1f4c,#1d204d,#1d204d,#1c214e,#1b224e,#1b224e,#1b224e,#1a214f,#1c2249,#444666,#363765,#18194d,#32355e,#464868,#22235a,#282b53,#535670,#565974,#26284c,#162147,#3e4a6d,#233155,#08173b,#112045,#404b6a,#2c3554,#1c2c5b,#071844,#7d8495,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#878595,#070322,#1b173c,#1a153d,#191539,#181434,#161232,#16113a,#16103f,#18123d,#19153b,#141643,#0f1242,#13173f,#151942,#10153c,#14153a,#141339,#131237,#141338,#131239,#141636,#12192d,#13192f,#131a31,#111732,#141a36,#161c34,#131931,#141b32,#151b33,#141a31,#131736,#17193d,#16193b,#141736,#141834,#141835,#14173a,#14173a,#15183b,#15183b,#15183b,#15193e,#15193e,#15193e,#161a3f,#161a3f,#161a3f,#161a3f,#161a3f,#181c41,#181c41,#181c42,#191c45,#191c45,#191c45,#1a1d46,#1a1d46,#1a1d4a,#1b1e4b,#1c1f4c,#1d204d,#1d204d,#1c214e,#1b224e,#1b224e,#1b224e,#1b224e,#1c234e,#131b48,#131a4f,#1b2158,#192152,#131b48,#1c245c,#162052,#101b44,#121e47,#162150,#2a3561,#38456e,#101c47,#1e2b54,#2e3b67,#1a2549,#303959,#182857,#071844,#7d8495,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#888696,#070322,#1b173c,#1a153d,#191539,#181435,#161234,#161238,#16113a,#16103a,#16113c,#131738,#131a2e,#13173b,#121a2d,#131b2d,#121730,#12152d,#121532,#121432,#12152d,#11162d,#0f1532,#0f1533,#121638,#13173c,#13173c,#131739,#131839,#131839,#131839,#131739,#14173d,#14153c,#141737,#141835,#141736,#141739,#14173a,#14173a,#15183b,#15183b,#15183b,#14183d,#14183d,#14183d,#15193e,#15193e,#161a3f,#161a3f,#161a3f,#171b40,#181c41,#181c42,#181b44,#181b44,#191c45,#191c45,#191c45,#191c49,#1a1d4a,#1b1e4b,#1c1f4c,#1d204d,#1b214d,#1a214d,#1a214d,#1b224e,#1b224e,#1b234c,#1c2549,#1c254a,#1b254a,#1c254a,#1d274a,#18264c,#18274b,#1a294c,#1c2b4e,#1a294e,#656988,#4e4c6a,#61607c,#6a6a89,#747292,#6f6f8a,#636c8a,#0d1d4c,#0c1c48,#7d8495,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfcfc,#ffffff,#858393,#080423,#1b173c,#1a153d,#191538,#181437,#161138,#161234,#161333,#161232,#161237,#161735,#161b22,#161444,#16182e,#161830,#12143a,#101533,#10133d,#10133d,#101534,#111434,#13123c,#13123a,#15143c,#16163b,#16163a,#16153d,#16153c,#16153c,#16153c,#16153c,#15163e,#14173a,#141834,#141835,#14163e,#141641,#141739,#14173a,#15183b,#15183b,#15183b,#14183d,#14183d,#14183d,#15193e,#15193e,#161a3f,#161a3f,#161a3f,#171b40,#181c41,#181c42,#181b44,#181b44,#191c45,#191c45,#191c45,#191c49,#1a1d4a,#1b1e4b,#1c1f4c,#1d204d,#1b214d,#1a214d,#1a214d,#1b224e,#1b224e,#1c224e,#1e214d,#1d214b,#1e234a,#1f234d,#1f224f,#1a244c,#1a244f,#192351,#1b2453,#17214f,#53587a,#6d718d,#656983,#6b708c,#606581,#6b7089,#4b5472,#122351,#091b47,#7b8293,#ffffff,#fcfcfb,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fcfbfc,#ffffff,#9593a1,#03001b,#1c183d,#16133d,#15133b,#151339,#161236,#161234,#161233,#161233,#161235,#171336,#17142f,#17123c,#171434,#171336,#151239,#141337,#14123a,#14123a,#141338,#141335,#141332,#141332,#141432,#151531,#151530,#131532,#131532,#141632,#151733,#151733,#141637,#131638,#131736,#141737,#14163b,#14163c,#15183a,#15183b,#14173a,#14173a,#14173a,#15183c,#15183c,#15183c,#15183c,#15183c,#16193e,#161a3f,#161a3f,#171b40,#171b40,#181c41,#191c43,#191c43,#191d43,#1a1d44,#1a1e44,#1a1d47,#1a1d47,#1a1d48,#1b1e48,#1c1f49,#1b214c,#1b224e,#1b224e,#1a214d,#1a214d,#1b224f,#1d2251,#1d224f,#1d234f,#1d2250,#1d2251,#1a2551,#1a2552,#1b2654,#192453,#182352,#19254e,#1d2950,#17244c,#1a274e,#132047,#1e2a50,#1d274f,#242e5b,#0a1038,#8d8e9e,#ffffff,#fcfcfc,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#fefefe,#ffffff,#e6e4ea,#2e2b3f,#0d0a29,#151339,#131338,#141336,#161235,#161235,#161235,#161235,#161235,#161235,#161236,#161234,#161235,#161235,#161234,#161235,#161234,#161234,#161235,#151235,#131335,#131336,#131336,#131336,#131336,#111436,#111436,#111436,#121637,#121637,#131637,#131637,#131637,#141738,#141737,#141738,#14173a,#14173a,#14173a,#14173a,#14173a,#15183b,#15183b,#15183b,#15183b,#15183b,#15193d,#15193e,#15193e,#171b40,#171b40,#171b40,#181c41,#181c41,#181c41,#191d42,#1a1e43,#191c45,#191c45,#191c45,#1a1d45,#1b1e46,#1a204b,#1a214d,#1a214d,#1a214d,#1a214d,#1a214d,#1b224e,#1b224e,#1b224e,#1b224e,#1b224e,#18254f,#18264f,#18254e,#18254e,#18254e,#192650,#17254f,#192651,#192651,#1b2853,#17254e,#1d2a52,#131a41,#2e304c,#e4e2e8,#fdfdfc,#fefefd,#ffffff,#ffffff,#ffffff );'></td></tr>
<tr><td height='1px' style='width:100px; background: linear-gradient(to right, #ffffff,#ffffff,#ffffff,#ffffff,#fefefe,#ffffff,#cfced5,#403f52,#12122e,#141530,#141431,#161235,#161235,#161235,#161235,#161235,#161235,#161235,#161235,#161235,#161235,#161235,#161235,#161235,#161235,#161235,#151235,#131335,#131335,#131335,#131335,#131335,#111435,#111435,#111435,#111435,#111435,#111435,#111435,#111435,#141738,#141738,#131638,#121538,#121538,#131639,#14173a,#14173a,#15183b,#15183b,#15183b,#15183b,#15183b,#14183c,#14183d,#14183d,#15193e,#15193e,#15193e,#161a3f,#161a3f,#171b40,#181c41,#191d42,#181b44,#181b44,#181b44,#181b44,#1a1d45,#191e49,#181f4b,#181f4b,#1a214d,#1a214d,#1a214d,#1a214d,#1a214d,#1a214d,#1a214d,#1a214d,#17244e,#17244e,#17244e,#18254f,#18254f,#192650,#192650,#192650,#18254f,#182550,#1a274e,#182645,#404861,#cbcdd6,#ffffff,#fafaf4,#fffffe,#ffffff,#ffffff,#ffffff );'></td></tr>
</table>        
  <div style="font-size:30px; color:red;letter-spacing:5px;font-family: Georgia, serif;"> <b><u><b style="font-size:35px;color:#044588;font-family:Algerian;"> <span>Y<span>O<span>U<span> <span>A<span>R<span>E<span> <span>O<span>U<span>R<span> <span>W<span>I<span>N<span>N<span>E<span>R<span>..!</u></b></b></div><br>
  <div style="font-size:25px;color:#9b9255;font-family:Arial;">  <b><span>D<span>e<span>l<span>i<span>v<span>e<span>r<span>y<span> f<span>o<span>o<span> <span>m<span>a<span>y<span> <span>a<span>p<span>p<span>l<span>y<span>.</b></div>
  <div style="color:#817d7b;font-size:23px;"> <b><span>C<span>u<span>s<span>t<span>o<span>m<span>e<span>r<span> <span>n<span>u<span>m<span>b<span>e<span>r<span>:</b></div>
  <div style="font-size:20px;"> <b>#537933813</b></div><br>
  <div style="background:#0072cf;font-size:18px;width:250px;color:white;padding:5px;font-family:Arial;border-radius:19px;">
<h3> <span>C<span>h<span>e<span>c<span>k<span> <span>w<span>h<span>a<span>t<span> <span>y<span>o<span>u<span> <span>w<span>o<span>n<span></h3></div>
<br>  
</div></div></a>



<br><br><p style="font-size: 14px; line-height: normal; text-align: center; margin: 0; padding: 20px 0 0">
    <span style="font-size: 15px;"> 
  <a href='http://storage.googleapis.com/teampass/Ha231120/hrf2zsdf/newb2.html#2537313Mj6763378Gg520434352Qg14664pj24HIunsub171571XE' STYLE="color:#fff"> Unsubscribe here
 </a><br>848 N. Rainbow Blvd., Suite 3974 Las Vegas, NV 89107

    </span>
  </p>
 
<br>
 </p>

</body>
</html>
















































































































<address R21rMjAyM2R6 520434352>
`}},en=["html_smuggling_attachment","html_smuggling_link","qr_code_phishing","vba_macro","paypal_invoice_abuse","google_comment_phishing","callback_phishing","spam"];var eo=t(44456),ed=t(64929);let er=A=>{let{ruleType:e}=A;return(0,a.jsxs)("div",{className:"flex items-center justify-between",children:[(0,a.jsxs)("div",{className:"flex flex-col gap-2",children:[(0,a.jsx)("h2",{className:"text-fn-h2 text-fn-text-strong",children:`Write and test ${(0,g.e)(e)?"Automations":"Rules"}`}),(0,N.Nn)()&&(0,a.jsx)(x.EY,{children:"Uploaded EMLs are not stored unless you generate a sharing link."})]}),(0,N.Nn)()&&(0,a.jsx)(G.N,{target:"_blank",href:"https://docs.sublime.security/docs/message-query-language",className:"no-underline",children:"Learn MQL"})]})},ef=r.memo(A=>{let{isEMLAnalyzer:e,readOnly:t=!1,showPendingChangesAlert:s=!1,refetchGroup:n,ruleType:o,baseUrl:d}=A,f=(0,l.wA)(),c=(0,l.d4)(AM.aI),g=(0,l.d4)(AM.tp),b=(0,l.d4)(AM._r),u=(0,l.d4)(eo.lQ),h=(0,l.d4)(eo.lm),B=!(0,N.Nn)(),{isOpen:x,onOpen:C,onClose:I}=(0,z.j1)(),Q=(0,l.d4)(AM.Ht),y=(0,l.d4)(AM.Wf),w=(0,l.d4)(AM.Zj),v=y?._meta.id,{data:F,isLoading:S}=(0,j.v$)({messageId:v},{skip:!v}),M=F?.needed,R=F?.justifications_require_explanation??!0;(0,N.Nn)()&&(M=!1);let T=(0,r.useRef)(!1),P=w?.result===void 0,U=M&&!P;(0,r.useEffect)(()=>{M&&(T.current=!0),!M&&T.current&&(n(),T.current=!1)},[f,M,y]);let V=(0,r.useRef)(null),X=(0,A0.C)({onSuccess:()=>{A1.o.success("Copied to the clipboard")},onError:()=>{A1.o.warning("Unable to copy cURL command to the clipboard")}}),H=async()=>{let A=(0,i.nk)(Q),e=`curl -X POST ${(0,A$.$_)()}/v0/messages/analyze -H 'content-type: application/json' -d '{"raw_message": "${A}", "run_all_detection_rules": true}'`;await X?.(e)},G=(0,r.useCallback)(A=>e=>{f((0,Av.hn)()),f((0,Av.sT)(A));let t=e?.target?.result;f((0,Av.pF)(t,{onError:A=>{let e=A instanceof Error?A.message:"Unknown error";A1.o.warning(e)}}))},[f]),{feedRule:J}=et(),L="Backtest Rule";if(J?.backtest&&!u&&!h){let A=D()(J.backtest.from),e=D()(J.backtest.to);L=`Cached backtest results from ${A.format("lll")} to ${e.format("lll")}`}switch(g){case ed.xm.IDLE:return(0,a.jsx)("div",{});case ed.xm.EDITING_EML:{if(e){let A=en.some(A=>b===`${A}.eml`);return(0,a.jsx)(A8,{baseUrl:d,isExampleEml:A})}let A=[c.EML,c.MDM,c.Screenshot,c.Insights].some(m.identity)&&(0,a.jsxs)(k.fh,{className:"flex flex-col bg-fn-layout-containerBg",children:[(0,a.jsx)("div",{className:"mb-0 flex flex-col gap-2",children:(0,a.jsx)("h2",{className:"text-fn-h2 text-fn-text-strong",children:"Identify suspicious indicators"})}),(0,a.jsx)("hr",{className:"my-2"}),(0,a.jsxs)("div",{className:"mb-4 mt-2 flex flex-1 flex-wrap items-center justify-between",children:[(0,a.jsx)(E,{canCopyToClipboard:!!X,isBuildModalOpen:x,onCloseBuildModal:I,onCopyAsCurl:()=>{H()},onOpenBuildModal:C,onUploadNewEml:()=>{V.current?.click()},selectedFileName:b}),(0,a.jsx)("input",{type:"file",accept:".eml",ref:V,hidden:!0,onChange:A=>{let e=A.target.files?.[0];if(!e)return;let t=new FileReader;t.onabort=()=>console.warn("file reading was aborted"),t.onerror=()=>console.error("file reading has failed"),t.onload=G(e?.name),t.readAsText(e)}})]}),(0,a.jsx)("div",{className:"flex size-full min-h-48 min-w-24 grow basis-auto items-stretch gap-3",id:"editor-content",children:(0,a.jsx)(AP,{requireExplanation:R,justificationId:v,loadingJustification:S,eml:Q,mdm:y,justifyNeeded:M})})]});return(0,a.jsxs)("div",{className:"my-4 grid size-full grid-cols-[repeat(auto-fit,minmax(0,1fr))] gap-2",children:[A,!!c.MQL&&(0,a.jsxs)(k.fh,{className:"flex flex-col bg-fn-layout-containerBg",children:[(0,a.jsx)(er,{ruleType:o}),(0,a.jsx)("hr",{className:"my-2"}),(0,a.jsxs)("div",{className:"my-4 flex flex-col gap-2",children:[(0,a.jsx)(eA,{}),!!U&&(0,a.jsx)(ei.l,{variant:"warning",title:"Heads up!",text:"You may need to click “View Contents” to accurately test this rule"})]}),(0,a.jsx)(p.Eg,{showPendingChangesAlert:!0,readOnly:t,autofocus:!0})]}),!!B&&!!c.Backtest&&(0,a.jsx)(k.fh,{className:"flex flex-col bg-fn-layout-containerBg",children:(0,a.jsxs)("div",{className:"flex grow flex-col",children:[(0,a.jsx)("h2",{className:"mb-3 text-fn-h2 text-fn-text-strong",children:L}),(0,a.jsxs)("div",{className:"flex grow flex-col",children:[(0,a.jsx)("hr",{className:"mb-2"}),(0,a.jsx)(ea.V,{})]})]})})]})}case ed.xm.EDITING_NO_EML:return(0,a.jsxs)("div",{className:"my-6 grid size-full grid-cols-[repeat(auto-fit,minmax(0,1fr))] gap-2",children:[!!c.MQL&&(0,a.jsxs)(k.fh,{className:"flex flex-col bg-fn-layout-containerBg",children:[(0,a.jsx)(er,{ruleType:o}),!!c.MDM&&(0,a.jsx)("hr",{className:"my-2"}),(0,a.jsx)("div",{className:"my-4",children:(0,a.jsx)(eA,{})}),(0,a.jsx)(p.Eg,{showPendingChangesAlert:s,readOnly:t,autofocus:!0})]}),!!c.Backtest&&(0,a.jsx)(k.fh,{className:"flex flex-col bg-fn-layout-containerBg",children:(0,a.jsxs)("div",{className:"flex grow flex-col",children:[(0,a.jsx)("h2",{className:"mb-3 text-fn-h2 text-fn-text-strong",children:L}),(0,a.jsxs)("div",{className:"flex grow flex-col",children:[(0,a.jsx)("hr",{className:"mb-2 mt-3"}),(0,a.jsx)(ea.V,{})]})]})})]})}});var el=t(36854),ec=t(35028);function eg(A){let{isDisabled:e=!1}=A,{isOpen:t,onClose:s,onOpen:n}=(0,z.j1)(),[o,{isLoading:d}]=(0,j.lV)(),[f,g]=(0,r.useState)(""),p=(0,l.d4)(AM.Ht),b=(0,A0.C)({onSuccess:()=>{A1.o.success("A sharable link has been copied in your clipboard!")}}),m=(0,A0.C)({onSuccess:()=>{A1.o.success("A sharable link has been copied in your clipboard!")}}),u=(0,r.useCallback)(async()=>{let A=await o({rawMessage:(0,i.lF)(p),ruleSource:""});if("error"in A)return void A1.o.warning("Something went wrong, please try again.");if(A?.data?.id){let e=`${document.location.origin}/?id=${A?.data?.id}`;(0,N.RM)()||(e+="&eml_analyzer=true"),await b?.(e),g(e)}},[o,p,b]),D=!!f;return(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(C.m,{content:"Generate a shareable link",disabled:!e,children:(0,a.jsx)(B.$n,{rightIcon:(0,a.jsx)(h.wji,{}),onClick:n,disabled:e,children:"Share"})}),!!t&&(0,a.jsx)(c.a,{isOpen:t,onClose:s,header:"Share",actions:D?(0,a.jsx)(B.$n,{isLoading:d,onClick:()=>m?.(f),disabled:null===m,children:"Copy Link"}):(0,a.jsx)(B.$n,{isLoading:d,onClick:u,children:"Create Link"}),children:D?(0,a.jsxs)("div",{className:"flex flex-col gap-2",children:[(0,a.jsx)(x.EY,{variant:"bodySmall",children:"Shareable Link"}),(0,a.jsx)(ec.p,{value:f,readOnly:!0,contentEditable:!1})]}):(0,a.jsx)(x.EY,{children:"Share your EML and analysis with a link."})})]})}var ep=t(75409),eb=t(86740),em=t(65700),eu=t(22981);function eD(A){let{mdm:e}=A,t=(0,N.YF)(),i=(0,l.d4)(AM.Ht),{onOpenPlaygroundLink:s,loading:n,error:o}=(0,Q.qm)({rawMessage:i}),d=(0,eu.a)(),f=!!e?._meta.id,c=(0,r.useMemo)(()=>el.bC.isFeatureEnabled("eml_analyzer_survey")&&!d&&i,[d,i]),g=(0,r.useCallback)(()=>{(A=>{let{devID:e,prodID:t,triggerEvent:a}=A,i=eb.HL?e:t;document.getElementsByClassName(`PostHogSurvey-${i}`).length>0||el.bC.capture(a,{})})({devID:"0197a453-5581-0000-57e5-0deb5bc8cb82",prodID:"01978ad9-37be-0000-dc5f-07805ed79339",triggerEvent:"opened_survey_eml_analyzer"})},[]);return(0,a.jsx)("div",{className:"border-b border-solid border-fn-layout-borderStrong",children:(0,a.jsx)(em.Ze.Wrapper,{suffix:(0,a.jsx)("div",{className:"flex flex-row gap-3",children:t?(0,a.jsxs)(a.Fragment,{children:[!!c&&(0,a.jsx)(B.$n,{variant:"ghost",rightIcon:(0,a.jsx)(h.stQ,{fontSize:"20px",color:"functional.alerts.highlight"}),onClick:g,children:"Help us make the EML Analyzer better"}),(0,a.jsx)(C.m,{content:o?"Unable to create playground link":"Create detection rules for EMLs",open:o||void 0,disabled:!!i,children:(0,a.jsx)(B.$n,{variant:"secondary",isLoading:n,onClick:s,disabled:!i,children:"Send to MQL Playground"})}),(0,a.jsx)(eg,{isDisabled:!i})]}):(0,a.jsx)(B.z9,{variant:"secondary",target:"_blank",isDisabled:!f,href:(0,AW.n8)({canonical_id:e?._meta.canonical_id,message_id:e?._meta.id,organization_id:(0,ep.t4)()??void 0}),children:"Send EML to Rule Editor"})}),children:(0,a.jsx)(z.BI,{children:(0,a.jsx)(z.BI.Item,{icon:(0,a.jsx)(h.Sv2,{}),children:"EML Analyzer"})})})})}function eh(A){let{disabled:e,onShare:t}=A;return(0,a.jsxs)("div",{className:"flex items-center gap-2",children:[(0,a.jsx)(G.N,{target:"_blank",href:"https://github.com/sublime-security/sublime-rules",suffix:null,className:"no-underline hover:underline",children:(0,a.jsxs)("div",{className:"flex items-center gap-1",children:[(0,a.jsx)(h.Nbh,{}),"Browse Sublime Rules repo"]})}),(0,a.jsx)(B.$n,{disabled:e,onClick:t,children:"Share"})]})}var eB=t(41946),ex=t.n(eB),eC=t(77770),eI=t(27688),eQ=t(37545),eE=t(18799),ey=t(91940);function ew(A){let{defaultValue:e}=A,{control:t,watch:i,setError:s,clearErrors:n}=(0,f.xW)(),o=i("triage_rule_triggers"),{standaloneUserReportsEnabled:d,loading:l}=(0,eQ.Bc)(),c=(0,ey.Y)(),g="Select Automation triggers",p=(0,z.ZC)(o),b=(0,z.A5)(A=>{A&&(A?.length===0?s("triage_rule_triggers",{message:"Please select at least one trigger"}):n("triage_rule_triggers"))});return((0,r.useEffect)(()=>{ex()(p,o)||b(o)},[p,o,b]),l)?(0,a.jsx)(eI.E,{className:"h-8 w-full"}):(0,a.jsx)(f.xI,{name:"triage_rule_triggers",control:t,defaultValue:e,render:A=>{let{onChange:t}=A;return(0,a.jsx)("div",{className:"w-full rounded bg-white",children:(0,a.jsx)(eC.l,{label:g,multiple:!0,defaultValue:e,getDisplayText:()=>o?.map(A=>eE.wc[A].displayName).join(", ")??g,onValueChange:t,value:o,children:c.map(A=>{let e=eE.wc[A].displayName,t=d&&"triage_flagged_messages"===A;return(0,a.jsx)(C.m,{disabled:!t,content:eQ.ZD,children:(0,a.jsx)("div",{children:(0,a.jsx)(eC.l.Option,{value:A,disabled:t,children:e})})},A)})})})}})}let ev=(0,r.memo)(A=>{let e,{isLoading:t,isDisabled:i,onClick:s,editing:n,isAutomation:d,tooltip:f}=A,c=(0,o.useRouter)(),g=(0,r.useCallback)(()=>{window.history.length>1&&c.back()},[c]),p=(0,l.d4)(AM.Ht);return(0,l.d4)(AM.he)&&!p?null:(e=d?n?"Save Automation":"Create Automation":n?"Save Rule":"Create Rule",(0,a.jsxs)("div",{className:"flex items-center gap-2",children:[window.history.length>1&&(0,a.jsx)(B.$n,{variant:"secondary",onClick:g,children:"Cancel"}),(0,a.jsx)(C.m,{content:f,disabled:!f,children:(0,a.jsx)(B.$n,{isLoading:t,disabled:i,onClick:s,"data-testid":n?"edit-rule-button":"save-rule-button",children:e})})]}))});var ek=t(84081),ej=t(47191),eF=t(89692),eS=t(36895),eM=t(57302);let eR=[{label:"EML"},{label:"Screenshot"},{label:"MDM"},{label:"Insights"},{label:"MQL"},{label:"Backtest"}],eT=(0,r.memo)(A=>{let{canonicalId:e,showUploadEmlButton:t=!0}=A,i=(0,l.d4)(AM.aI),s=(0,eF.j)(),n=(0,l.d4)(AM.tp),o=(0,eS.G)(AM.he),d=(0,r.useRef)(null),f=!(0,N.Nn)()&&!(0,N.YF)(),c=(0,l.d4)(AM.Ht),{isOpen:g,onClose:p,onOpen:b}=(0,z.j1)(),m=(0,r.useCallback)(A=>async e=>{s((0,Av.hn)()),s((0,Av.sT)(A));let t=e?.target?.result;await s((0,Av.pF)(t,{onError:A=>{let e=A instanceof Error?A.message:"Unknown error";A1.o.warning(e),s((0,Av.hn)())}}))},[s]),u=(0,r.useCallback)(A=>{let e=A.target.files;if(!e)return;let t=e[0],a=new FileReader;s((0,Av.sT)(t?.name)),a.onabort=()=>console.warn("file reading was aborted"),a.onerror=()=>console.error("file reading has failed"),a.onload=m(t?.name),a.readAsText(t)},[s,m]),D=eR.filter(A=>{let t=A.label,a=n===ed.xm.EDITING_EML;switch(t){case"MDM":return a&&(c||e);case"EML":return a&&!e;case"Preview":default:return!1;case"MQL":return!o||!!c;case"Backtest":return f;case"Screenshot":case"Insights":return c||e}});switch(n){case ed.xm.EDITING_EML:return(0,a.jsx)("div",{className:"relative max-w-full overflow-x-scroll pb-2 md:max-w-[auto] md:pb-0 md:[overflow-x:unset]",children:(0,a.jsx)(eN,{options:D,viewState:i})});case ed.xm.EDITING_NO_EML:return(0,a.jsxs)("div",{className:"relative flex",children:[(0,a.jsxs)("div",{className:"flex items-center gap-2",children:[(0,a.jsx)("input",{type:"file",accept:".eml",ref:d,hidden:!0,onChange:u}),(0,a.jsxs)(ej.e,{type:"none",children:[!!t&&(0,a.jsx)(ej.e.Item,{value:"upload",onClick:()=>{d.current?.click()},leftIcon:(0,a.jsx)(ek.HVe,{}),children:"Upload .EML file"}),(0,a.jsx)(ej.e.Item,{value:"buildEml",onClick:b,leftIcon:(0,a.jsx)(ek.xdT,{}),children:"Build EML"})]}),D.length>1&&(0,a.jsx)(eN,{options:D,viewState:i})]}),(0,a.jsx)(Q.Yx,{isOpen:g,onClose:p})]});default:return(0,a.jsx)("div",{className:"flex"})}});function eN(A){let{options:e,viewState:t}=A,{canBacktest:i}=(0,K.V)(),s=(0,eF.j)(),n=(0,r.useCallback)(A=>"Backtest"!==A||i,[i]),o=(0,r.useCallback)(A=>{let{value:e,label:a}=A,i=Object.values(t).filter(A=>A).length;(1!==i||e)&&(i+ +!!e>1&&s((0,eM.OI)({filtersShown:!1})),s((0,Av.YS)({...t,[a]:e},a)))},[s,t]);return(0,a.jsx)(ej.e,{type:"none",children:e.filter(A=>n(A.label)).map(A=>{let e=t[A.label];return(0,a.jsx)(ej.e.Item,{value:A.label,active:e,onClick:()=>{o({label:A.label,value:!e})},children:A.label},A.label)})})}var eP=t(30236);function eU(A){let{onClick:e,label:t}=A;return(0,a.jsx)("button",{className:(0,z.cn)("h-[72px] w-[170px] rounded border border-fn-layout-borderStrong bg-gray-100 p-4","disabled:opacity-100 disabled:bg-gray-200 disabled:cursor-not-allowed disabled:border-gray-200"),onClick:e,children:(0,a.jsx)(x.EY,{className:"text-fn-bodyMedium text-fn-text-strong",children:t})})}function eV(A){let{onLoaded:e,baseUrl:t}=A,{isOpen:i,onClose:s,onOpen:n}=(0,z.j1)(),o=(0,r.useCallback)(A=>{console.error(A);let e=A instanceof Error?A.message:"There was a problem trying to read the .eml file, please check it is valid and try again.";A1.o.warning(e)},[]),d=(0,r.useCallback)(A=>{e(A)},[e]),f=(0,r.useCallback)(A=>{if(!A||0===A.length)return;let e=A[0],t=new FileReader;t.onabort=()=>null,t.onerror=A=>o(A),t.onload=()=>d({data:t.result,filename:e.name}),t.readAsText(e)},[o,d]),{getRootProps:l,getInputProps:c,isDragActive:g,open:p}=(0,eP.VB)({onDropAccepted:f,onDropRejected:o,multiple:!1,maxFiles:1,noClick:!0,accept:{"message/rfc822":[".eml"]},onError:o});return(0,a.jsxs)("div",{className:"flex size-full flex-col items-center overflow-auto bg-white px-24 py-12",children:[(0,N.YF)()&&(0,a.jsx)(AG,{baseUrl:t}),(0,a.jsxs)("div",{className:"flex w-[716px] flex-col items-center",children:[(0,a.jsxs)("div",{className:(0,z.cn)("flex w-full flex-col items-center justify-center gap-6 rounded-md border border-dashed border-fn-layout-borderStrong pb-16 pt-28",g?"bg-white":"bg-gray-100"),...l(),"data-testid":"dropzone",children:[(0,a.jsx)(x.EY,{className:"text-fn-bodyLarge font-semibold text-fn-text-strong",children:"Drag and drop an .eml file here"}),(0,a.jsx)(h.qR6,{className:"my-14 text-[50px]"}),(0,a.jsx)(B.$n,{onClick:p,variant:"primary",size:"large",children:"Upload File"}),(0,a.jsx)(B.$n,{onClick:n,variant:"secondary",children:"Build an EML"})]}),(0,a.jsx)("input",{...c(),type:"file",accept:".eml","data-testid":"file-input"}),(0,a.jsx)(x.EY,{className:"my-8 text-fn-bodyLarge font-semibold text-fn-text-strong",children:"Or use an EML example below"}),(0,a.jsx)("div",{className:"flex flex-row flex-wrap gap-x-3 gap-y-4",children:en.map(A=>{let e=es[A];return e?(0,a.jsx)(eU,{label:e.label,onClick:()=>{f([new File([e.fileContents],e.fileName)])}},e.label):null})})]}),(0,a.jsx)(Q.Yx,{isOpen:i,onClose:s})]})}var eX=t(80315),eH=t(5637),eG=t(84436),eJ=t(89983),ez=t(24592),eL=t(49053),eO=t(83227),eZ=t(81432),eW=t(82695),eY=t(12099),eq=t(32398),eK=t(93915),e_=t(22946),e$=t(82058),e1=t(42720);let e0=A=>{let{isEMLAnalyzer:e,rule:t,messageId:s,canonicalId:p,initialType:m,baseUrl:u}=A,D=(0,o.useRouter)(),C=(0,f.mN)({shouldUnregister:!1}),I=(0,eF.j)(),{loadEML:E}=function(){let[A,e]=(0,r.useState)(!1),t=(0,eF.j)();return{isLoading:A,loadEML:(0,r.useCallback)(A=>{let{filename:a,eml:i}=A;t((0,Av.sT)(a));try{e(!0),t((0,Av.pF)(i,{onError:A=>{e(!1);let t=A instanceof Error?A.message:"Unknown error";A1.o.warning(t)}}))}finally{e(!1)}},[t])}}(),{loadingMessageFromAttachment:y}=function(A){let e=(0,o.useRouter)(),t=(0,eF.j)(),{message_id:a,attachment_sha_256:i}=e.query,{data:s,isLoading:n,error:d}=(0,j.Lt)({messageId:a,attachmentSha256:i},{skip:!A||!a||!i||"string"!=typeof a||"string"!=typeof i});return(0,r.useEffect)(()=>{s?.raw_eml&&s?.data_model&&"string"==typeof s?.file_name&&(t((0,Av.sT)(s?.file_name)),t((0,Av.nI)(s?.raw_eml,s?.data_model)))},[t,s?.raw_eml,s?.data_model,s?.file_name]),(0,r.useEffect)(()=>{d&&A1.o.warning("Could not load message from attachment")},[d]),{loadingMessageFromAttachment:n}}(!!e),{isOpen:w,onClose:v,onOpen:k}=(0,z.j1)(),{isOpen:F,onClose:S,onOpen:M}=(0,z.j1)(),[R,T]=(0,r.useState)(null),P=(0,l.d4)(AM.tp),U=(0,l.d4)(AM.Ht),V=(0,l.d4)(AM.Wf),X=(0,l.d4)(AM.aI),[H,G]=(0,r.useState)(!1),[J,L]=(0,r.useState)(),[O,Z]=(0,r.useState)(null),[W,{isLoading:Y}]=(0,j.lV)(),{data:q,isLoading:$}=(0,j.qw)(O),AA=(0,r.useRef)(!1),{refetch:Ae}=(0,j.iT)(t,{skip:!t}),{lookbackDays:At}=(0,eG.U0)(),[Aa,Ai]=(0,r.useState)(!1),[As,An]=(0,r.useState)(!1),Ao=(0,l.d4)(AM.r$),Ad=(0,l.d4)(AM.zq),{getConnection:Ar}=(0,A7.jZ)(),{canCreateRule:Af,canUpdateRule:Al,canBacktest:Ac}=(0,K.V)(),{data:Ag,isLoading:Ap,refetch:Ab}=(0,_.KQ)({messageGroupId:p},{skip:!p}),Am=(0,r.useMemo)(()=>s||(Ag?Ag.previews?.[0]?.id??null:null),[s,Ag]),Au=(0,Q.Zc)({id:Am},{skip:!Am}),AD=(0,r.useMemo)(()=>(function(A){if(A)return{actions_taken:[],message_action_events:[],attachment_names:null,attachment_sha256s:null,created_at:A.created_at,delivered_at:A.created_at,external_created_at:null,first_forwarded_at:A.forwarded_at,first_quarantined_at:null,first_read_at:A.read_at,first_replied_at:A.replied_at,first_trashed_at:null,flagged_rules:null,forward_recipients:A.forward_recipients,historically_matched_rules:null,id:A.id,is_warning_banner_applied:!1,mailbox_email_address:A.mailbox?.email??"",mailbox_external_id:A.mailbox?.external_id??"",mailbox_display_name:"",mailbox_id:A.mailbox?.id??"",matched_exclusion_rules:null,recipients:A.recipients?.map(A=>A.email)??[],sender_display_name:A.sender.display_name,sender_email_address:A.sender.email,spam:A.landed_in_spam,state:"no-action",subject:A.subject}})(Au.data),[Au.data]),Ah=(0,Q.Cc)({id:Am},{skip:!Am}),AB=Ah.data,Ax=$||Ad||Ap||Ah.isLoading||y,AC=!!t,AI=(0,z.A5)(()=>{if(!p&&!AB)return void I((0,Av.$j)(ed.xm.EDITING_NO_EML));AB&&(I((0,Av.YS)({MDM:!0,EML:!1,Preview:!1,Screenshot:!1,Insights:!1,MQL:!0,Backtest:!1,ANALYZER:!1})),I((0,Av.w3)(AB)),I((0,Av.$j)(ed.xm.EDITING_EML)))}),AQ=(0,j.iT)(t,{skip:!t});(0,r.useEffect)(()=>{AB&&AI()},[AB,AI]);let AE=(0,z.A5)(A=>{T(A),I((0,Av.J3)(A.actions)),I((0,Av.s8)(A.references??[])),I((0,Av.Zg)(A.tags??[])),I((0,Av.H4)(A.severity)),I((0,Av.$j)(ed.xm.EDITING_NO_EML)),C.reset({source:A.source,name:A.name,description:A.description,severity:A.severity,tags:A.tags??[],actions:A.actions,references:A.references??[],auto_review_classification:A.auto_review_classification??void 0}),I((0,Av.hc)(!1))}),Ay=(0,z.A5)(()=>{I((0,Av.J3)([])),I((0,Av.s8)([])),I((0,Av.Zg)([]));let A=C.getValues("source");C.reset({source:A||ed.Vz}),AI(),I((0,Av.hc)(!1))}),Aw=(0,z.A5)(()=>{A1.o.warning("The rule you're trying to edit doesn't exist."),D.replace((0,AW.n8)({message_id:s||void 0}))}),Ak=(0,eY.S)(AQ);(0,r.useEffect)(()=>{if(I((0,Av.H0)()),I({type:"backTesting/hasBacktested",hasBacktested:!1}),AQ.isUninitialized&&!t&&Ay(),"loading"!==Ak)return"error"===Ak&&Aw(),AQ.data&&AE(AQ.data),()=>{I((0,Av.H0)())}},[I,AQ.data,AQ.isUninitialized,Ak,Ay,Aw,AE,t]);let{feedRule:Aj,loading:AF}=et();(0,r.useEffect)(()=>{Aj&&C.reset({source:Aj.rule.source})},[Aj]);let AR=async()=>{C.clearErrors(["source","triage_rule_triggers"]);let A=C.getValues("triage_rule_triggers"),e=C.getValues("type"),t=await (0,eO.J6)({source:C.getValues("source"),type:e,triage_abuse_reports:A?A.includes("triage_abuse_reports"):R?.triage_abuse_reports??!1,triage_flagged_messages:A?A.includes("triage_flagged_messages"):R?.triage_flagged_messages??!1,triage_email_bomb:A?A.includes("triage_email_bomb"):R?.triage_email_bomb??!1});if(!0!==t&&t?.error){let A="invalid_rule"===t.error.type,a=t.error.message?.match(/triage rule must have a trigger/);A?C.setError("source",{message:t.error.message}):a?C.setError("triage_rule_triggers",{message:`${e===ed.QT.Automation?"An automation":"A triage rule"} must have a trigger.`}):C.setError("source",{message:"There was an error validating the rule"})}return t},AT=async()=>{I((0,Av.XS)(!0)),!0===await AR()&&k(),I((0,Av.XS)(!1))},AN=async(A,e)=>{try{let a;I((0,Av.XS)(!0)),A?a=await I((0,e_.E9)({...e,type:e.type===ed.QT.Automation?ed.QT.Triage:e.type})):(a=await I((0,e_.Fn)(t,{...e,type:e.type===ed.QT.Automation?ed.QT.Triage:e.type})),A1.o.success("Your changes were saved.")),Ae(),(0,eZ.c4)();let i=(0,g.e)(e.type)?(0,AW.Te)(a.id):(0,AW.c5)(a.id);D.push(i)}catch(e){let A=n()(e,"message");if("invalid_rule"===n()(e,"type"))return A;A1.o.warning(A),v()}finally{I((0,Av.XS)(!1))}},AP=async A=>{let e={...A};delete e.newReference;let a={...e,type:e.type,action_ids:e.actions?.map?.(A=>A.id),severity:e.severity?.length?e.severity:void 0};if(!a.source.length)return void C.setError("source",{type:"required",message:"A rule cannot have empty source."});if((0,g.e)(a.type)&&!a.triage_rule_triggers?.length)return void C.setError("triage_rule_triggers",{type:"required",message:`${a.type===ed.QT.Triage?"A triage rule":"An automation"} must have at least one trigger.`});let i=await AN(!t,a);i&&C.setError("source",{type:"required",message:i})},AU=(0,r.useCallback)(A=>{A?C.setError("source",{message:A}):A1.o.warning("There was an error performing the backtest")},[C]),{onPerformBackTest:AV}=(0,eL.L)(AU),AX=(0,A0.C)({onSuccess:()=>{A1.o.success("A sharable linked has been copied in your clipboard!")}}),AH=C.errors.triage_rule_triggers,AG=C.formState.touched.triage_rule_triggers,AJ=n()(AH,"message")??null;(0,eq.KW)([{trigger:"Ctrl+Enter",name:U?"Run Rule Test":"Check Rule Syntax",action:()=>{I((0,Av.N$)(C,Ar()))},disabled:Aa||![ed.xm.EDITING_EML,ed.xm.EDITING_NO_EML].includes(P)},{trigger:ed.j3.trigger,name:"Run Backtest",action:()=>{X.Backtest||I((0,Av.YS)({...X,Backtest:!0},"Backtest")),AV({action:"backtest",source:C.getValues("source"),lookbackDays:At,triageRuleTriggers:C.getValues("triage_rule_triggers"),ruleType:C.getValues("type")})},disabled:!Ac||!!AJ||![ed.xm.EDITING_EML,ed.xm.EDITING_NO_EML].includes(P)}]);let Az=(0,r.useCallback)(async()=>{let A=await W({rawMessage:H?(0,i.lF)(U):null,ruleSource:C.getValues("source")});if("data"in A&&A?.data?.id){let t=`${document.location.origin}/?id=${A.data.id}`;(0,N.RM)()||(t+=e?"&eml_analyzer=true":"&playground=true"),await AX?.(t),L(t)}},[e,W,H,U,C,S,A1.o]);(0,r.useEffect)(()=>{if((0,N.Nn)()||e){let{id:A}=d.A.parse(document.location.search.toLowerCase());A&&(AA.current=!1,Z(A))}},[e]),(0,r.useEffect)(()=>{y&&I((0,Av.IQ)())},[e,I,y]),(0,r.useEffect)(()=>{if(q&&!AA.current){AA.current=!0;let{rule_source:A,raw_message:t,data_model:a}=q;A&&C.setValue("source",A),t&&I((0,Av.JT)((0,i.D4)(t))),q.raw_message&&(I((0,Av.w3)(a)),I((0,Av.$j)(ed.xm.EDITING_EML))),e&&I((0,Av.$N)())}},[q,C,I,e]);let AL=C.formState.isDirty&&!C.formState.isSubmitting&&!C.formState.isSubmitted;(0,r.useEffect)(()=>(AL?(0,eZ.WO)("true"):(0,eZ.c4)(),()=>(0,eZ.c4)()),[AL]);let AO=!!(Aj??AF),AZ=(0,eZ.ob)({isEditing:AC,cachedBacktestProvided:AO,isEMLAnalyzer:e,isSandbox:(0,N.Nn)(),ruleType:R?.type??m}),AY=e&&!U,Aq=e&&!U,AK=(0,a.jsx)(eh,{disabled:Aq,onShare:()=>{M(),L("")}});(0,r.useEffect)(()=>{let A=R?.type??m;A&&C.setValue("type",A===ed.QT.Automation?ed.QT.Triage:A)},[m,R?.type]);let A_=(0,r.useMemo)(()=>Ag?(0,e1.a)(Ag):null,[Ag]),A$=AB??V,A3=(0,r.useMemo)(()=>({setIsModalOpen:Ai}),[]),A2=(0,r.useMemo)(()=>({mdm:A$,isFocusTrapped:As,preview:AD,setIsFocusTrapped:An,messageId:Ag?.id||"uploaded-eml",justificationId:"",messageGroup:A_??void 0}),[A$,A_,As,AD,Ag?.id]);return(0,a.jsx)(eX.R.Provider,{value:A3,children:(0,a.jsxs)(f.Op,{...C,children:[(0,a.jsx)(eW.h,{title:AZ}),(0,a.jsx)("div",{className:(0,z.cn)("flex flex-col max-h-full flex-1 bg-util-layout-secondaryBg",e?"max-w-full":"max-w-[95vw] my-0 mx-auto lg:px-5"),children:(0,a.jsxs)("div",{className:(0,z.cn)("flex flex-col flex-1 min-h-[400px]",e?"pt-0":"pt-6"),children:[e?(0,a.jsx)(eD,{mdm:A$}):(0,a.jsxs)("div",{id:"top-header-container",className:(0,z.cn)("w-full px-3 flex flex-col md:flex-row items-center flex-0 basis-auto",AO?"justify-center":"justify-between"),children:[!AO&&(0,a.jsxs)("div",{children:[(0,a.jsx)("div",{className:(0,z.cn)("flex items-center"),children:(0,a.jsx)("h1",{className:"mr-1 text-fn-h1",children:AZ})}),((0,g.e)(m)||R?.type===ed.QT.Triage)&&(0,a.jsxs)("div",{className:"flex flex-col gap-2",children:[(0,a.jsxs)("div",{className:"mt-2 flex items-center gap-2",children:[(0,a.jsx)(x.EY,{children:"Triggers"}),(0,a.jsx)("div",{className:"inline-block w-16",children:(0,a.jsx)(ew,{defaultValue:(0,ez.C)(R)})})]}),!!AH&&!!AG&&(0,a.jsx)("div",{children:(0,a.jsx)(x.EY,{id:"triggerError",variant:"bodyMedium",color:"functional.alerts.warning",children:AJ})})]})]}),(0,N.Nn)()&&"narrow_view"===(0,eZ.fL)()&&AK,(0,a.jsx)(eT,{canonicalId:p??null,showUploadEmlButton:!AO&&!e}),(0,a.jsxs)("div",{className:"flex items-center",children:[!AO&&!(0,N.Nn)()&&!(0,N.YF)()&&(0,a.jsx)(ev,{isLoading:Ao,tooltip:AH?AJ:void 0,isDisabled:!!AH||!AC&&!Af||AC&&!Al,onClick:AT,editing:!!t,isAutomation:(0,g.e)(R?.type??m)}),((0,N.Nn)()||(0,N.YF)())&&"wide_view"===(0,eZ.fL)()&&AK]})]}),Ax?(0,a.jsx)(AS.Vw,{}):(0,a.jsx)(Q.lY.Provider,{value:A2,children:AY?(0,a.jsx)(eV,{onLoaded:A=>{let{filename:e,data:t}=A;E({filename:e,eml:t}),I((0,Av.IQ)())},baseUrl:u}):(0,a.jsx)(eK.q.Provider,{value:AJ,children:(0,a.jsx)(ef,{isEMLAnalyzer:e,refetchGroup:Ab,showPendingChangesAlert:!0,readOnly:AO,ruleType:R?.type??m,baseUrl:u})})}),(0,a.jsx)(b,{selectedRule:R,initialType:m,ruleId:t,isOpen:w,onClose:v,isLoading:Ao,onSubmit:C.handleSubmit(AP)}),!!F&&(0,a.jsx)(c.a,{isOpen:F,onClose:S,header:"Share",size:"4xl",actions:(0,a.jsxs)(a.Fragment,{children:[!J&&(0,a.jsx)(B.$n,{className:"min-w-24",isLoading:Y,onClick:()=>void Az(),rightIcon:(0,a.jsx)(h.qYV,{}),children:"Get Link"}),!!J&&(0,a.jsxs)("div",{className:"flex",children:[(0,a.jsx)(ec.p,{className:"narrow_view"===(0,eZ.fL)()?"min-w-[inherit]":"min-w-[400px]",inputClassName:"rounded-r-none",value:J}),(0,a.jsxs)(B.$n,{className:"min-w-24 rounded-l-none",isLoading:Y,onClick:()=>{J&&(navigator.clipboard?.writeText(J),A1.o.success("A sharable linked has been copied in your clipboard!"))},children:["Copy Link",(0,a.jsx)(h.qYV,{ml:2})]})]})]}),children:(0,a.jsxs)("label",{className:"flex cursor-pointer items-center gap-3 p-1",children:[(0,a.jsx)(eJ.S,{disabled:!U,checked:H,onCheckedChange:A=>{U&&"indeterminate"!==A&&G(A)}}),(0,a.jsx)("span",{className:"text-fn-bodyMedium",children:"Include my EML and MDM when someone opens my link"})]})})]})})]})})},e3=A=>(0,a.jsx)(eG.RB,{children:(0,a.jsx)(e0,{...A})}),e2=A=>{let{standaloneUserReportsEnabled:e,loading:t}=(0,eQ.Bc)();if(t)return null;let i=e?ed.QT.Triage:ed.QT.Detection;return A.rule||A.initialType||A.isEMLAnalyzer||A.messageId||A.canonicalId||A.id?(0,a.jsx)(e3,{...A}):(0,a.jsx)(eH.r,{href:(0,AW.n8)({type:i})})};e2.getLayout=A=>(0,a.jsx)(e$.N,{children:A});var e4=!0;let e5=e2},13336:(A,e,t)=>{t.d(e,{dX:()=>n,oI:()=>s});var a=t(91283),i=t(11449);let s=()=>({type:a.Tq}),n=async A=>{let e=`/v0/messages/${A}/image_link`,t=await (0,i.nr)(e);if(!t.ok)throw t;return await t.json()}},22946:(A,e,t)=>{t.d(e,{$o:()=>d,E9:()=>l,Fn:()=>f});var a=t(8710),i=t(14653),s=t(11449);let n=A=>({type:i.U6,payload:A}),o=A=>({type:i.yq,payload:A}),d=(A,e)=>async t=>{let n="/v1/rules";t({type:i.pq}),t(o(!0));let d=Object.assign({limit:200},A||{});n=`${n}?${a.A.stringify(d)}`;let r=await (0,s.nr)(n,{signal:e});if(!r?.ok)throw t(o(!1)),r;if(r){let A=await r.json();return A.rules&&t({type:i.DJ,payload:A.rules}),t(o(!1)),A.rules}};function r(A){let e={...A,triage_abuse_reports:A.triage_rule_triggers?.includes("triage_abuse_reports")??!1,triage_flagged_messages:A.triage_rule_triggers?.includes("triage_flagged_messages")??!1};return delete e.triage_rule_triggers,e}let f=(A,e)=>async t=>{let a=r(e),i=await (0,s.Lo)(`/v1/rules/${A}`,{method:"PUT",body:a}),o=await i.json();if(!i.ok)throw Error(o.error.message);return t(n(o)),o},l=A=>async e=>{let t=r(A),a=await (0,s.Lo)("/v1/rules",{method:"POST",body:t}),i=await a.json();if(200!==a.status)throw Error(i.error.message);return e(n(i)),i}},35756:(A,e,t)=>{t.d(e,{A:()=>l,F:()=>f});var a=t(37876),i=t(14232),s=t(85673),n=t(66726),o=t(4430),d=t(96742);let r=()=>(0,a.jsxs)("div",{className:"flex flex-1 items-center justify-center gap-2",children:[(0,a.jsx)(s.y,{}),(0,a.jsx)(n.EY,{children:"Loading preview..."})]}),f="Unable to display this message screenshot.",l=A=>{let{screenshotUrl:e,loading:t,addLink:s,testId:l,noImageMessage:c,queryErrorMessage:g}=A,[p,b]=(0,i.useState)(!0),[m,u]=(0,i.useState)(void 0),D=(0,a.jsx)("img",{className:"ph-no-capture w-full",onLoad:()=>{b(!1)},onError:()=>{b(!1),u(f)},loading:"eager",src:e,alt:"Message Preview"}),h=g??m;return h?(0,a.jsx)("div",{className:"w-full",children:(0,a.jsx)(d.G,{children:(0,a.jsx)("div",{className:"flex h-full items-center justify-center",children:(0,a.jsx)(n.EY,{children:h})})})}):t?(0,a.jsx)(r,{}):e?(0,a.jsxs)(a.Fragment,{children:[!!p&&(0,a.jsx)(r,{}),(0,a.jsx)("div",{className:(0,o.cn)("flex w-full p-4",p&&"hidden"),"data-testid":l,children:s?(0,a.jsx)("a",{href:e,target:"_blank",rel:"noopener noreferrer",title:"Screenshot URL",children:D}):D})]}):c??(0,a.jsx)("div",{className:"flex flex-1 items-center justify-center","data-testid":"message-no-screenshot",children:(0,a.jsx)(n.EY,{className:"text-fn-bodyMedium",children:"No message screenshot available."})})}},62728:(A,e,t)=>{t.d(e,{M:()=>D});var a=t(37876),i=t(22097),s=t(11381),n=t(15258);function o(A){let{messageGroup:e,__classNameOverrides:t}=A,{lastAction:i}=(0,n.p)(e?.messageActionEvents??[],e?.messageActionsTaken??[]);return i?(0,a.jsx)(d,{actionEvent:i,__classNameOverrides:t},i.action_id):null}function d(A){let{__classNameOverrides:e,actionEvent:t}=A,n=t.action_type,o=s.Xl[n]?.icon??s.O4.Solid,d=s.Xl[n]?.manualActionName??t.action_name;return(0,a.jsx)(i.v,{__classNameOverrides:e,fill:"outline",prefix:(0,a.jsx)(o,{}),children:t.user_id?d:t.action_name})}var r=t(10971),f=t(53556),l=t(65744),c=t(98869);function g(A){let{userReportCount:e,firstReportedAt:t,__classNameOverrides:s}=A;return e||t?(0,a.jsx)(i.v,{fill:"outline",prefix:(0,a.jsx)(f.G4r,{}),__classNameOverrides:s,children:function(A){let{userReportCount:e,firstReportedAt:t}=A,a="";if(!e&&!t)return a;if(e&&(a+=`${e} ${(0,c.t)(e,"user reported","users reported")}`),e&&t&&(a+=", "),t){let A=(0,l.n0)(t);a+=`First reported ${A}`}return a}({userReportCount:e,firstReportedAt:t})}):null}var p=t(27688),b=t(81726),m=t(4430),u=t(42747);function D(A){let{status:e,report:t,isLoading:s,isError:n,messageGroup:d}=A,l=d?.reviewStatus,m=d?.numberOfMessagesLowerBound,D=d?.firstReportedAsPhishAt??void 0,B=d?.reportedBy?.length;if(s||"in_progress"===e||"pending"===e)return(0,a.jsx)(h,{criticalSeverity:!1,oneLiner:(0,a.jsx)(p.E,{className:"h-7 w-[750px]"}),chips:(0,a.jsxs)("div",{className:"flex gap-2",children:[(0,a.jsx)(p.E,{className:"h-7 w-28"}),(0,a.jsx)(p.E,{className:"h-7 w-28"}),(0,a.jsx)(p.E,{className:"h-7 w-28"})]})});if("error"===e||n||"not_started"===e||void 0===e||void 0===t)return null;let x=t?.finalVerdict==="Malicious",C=l&&"reviewed"===l,I=d?.classification,Q=x&&!C,E=Q?{icon:"text-white",text:"text-white"}:void 0;return(0,a.jsx)(h,{criticalSeverity:Q,oneLiner:(0,a.jsx)("h3",{className:"text-fn-h3",children:t.oneLiner}),chips:(0,a.jsxs)("div",{className:"flex flex-wrap gap-2",children:[I&&C?(0,a.jsx)(u.q,{classification:I}):(0,a.jsx)(r.$,{verdict:t.finalVerdict}),(0,a.jsx)(o,{__classNameOverrides:Q?{base:"bg-white",icon:"text-fn-severity-critical",text:"text-fn-severity-critical"}:void 0,messageGroup:d}),!!m&&(0,a.jsx)(i.v,{fill:"outline",prefix:(0,a.jsx)(f.W9x,{stroke:Q?"white":void 0,fill:Q?"transparent":void 0,foregroundStroke:Q?(0,b.o)("functional.severity.critical"):void 0}),__classNameOverrides:E,children:`${m} ${(0,c.t)(m,"message","messages")}`}),(0,a.jsx)(g,{userReportCount:B,firstReportedAt:D,__classNameOverrides:E})]})})}function h(A){let{oneLiner:e,chips:t,criticalSeverity:i}=A;return(0,a.jsxs)("div",{className:(0,m.cn)("flex w-full flex-col gap-4 border-b border-fn-layout-borderStrong px-12 py-8",i&&"bg-fn-severity-critical text-white"),children:[e,t]})}},84244:(A,e,t)=>{t.d(e,{E1:()=>n,Sz:()=>f,aI:()=>o});var a=t(14232),i=t(57219),s=t(98869);function n(A){if(A<1){let e=24*A;return`${e} ${(0,s.t)(e,"hour","hours")}`}return`${A} ${(0,s.t)(A,"day","days")}`}function o(A){if(!A)return"Select range";let e=n(A);return`Last ${e}`}let d=[1/24,1/6,1/3,1,3,7,14,30],r=[60,90,180,365];function f(){let{data:A}=(0,i.Aq)(),e=A?.mdm_retention_days;return(0,a.useMemo)(()=>{let A=[...d];return e&&e>=365&&(A=A.concat(r)),A.map(A=>({isDisabled:!e||A>e,label:o(A),value:A}))},[e])}},84436:(A,e,t)=>{t.d(e,{RB:()=>n,U0:()=>o});var a=t(37876),i=t(14232);let s=i.createContext({lookbackDays:1,setLookbackDays:()=>{}}),n=A=>{let{children:e}=A,[t,n]=(0,i.useState)(1),o=(0,i.useMemo)(()=>({lookbackDays:t,setLookbackDays:n}),[t,n]);return(0,a.jsx)(s.Provider,{value:o,children:e})},o=()=>i.useContext(s)},93915:(A,e,t)=>{t.d(e,{q:()=>a});let a=(0,t(14232).createContext)(null)},97029:(A,e,t)=>{t.d(e,{V:()=>Y});var a=t(37876),i=t(82851),s=t.n(i),n=t(14232),o=t(75625),d=t(90746),r=t(84436),f=t(94768),l=t(79098),c=t(14864),g=t(7344),p=t.n(g),b=t(20224),m=t(57219),u=t(65700),D=t(76923),h=t(29819);let B=A=>{let{data:e,onSelectedRowsChange:t,isLoading:i,errorMessage:s,onActionFinish:o,totalCount:d}=A,r=(0,n.useRef)(null),[f,l]=(0,n.useState)(0),c=(0,n.useMemo)(()=>e.slice(100*f,(f+1)*100),[e,f]),g=(0,m.Jl)({listIdentifier:D.I,values:[...e?.reduce((A,e)=>(e.sender.email&&A.push(e.sender.email),A),[])||[],...p()(e?.map(A=>A.recipients??[]))]},{skip:!e||0===e.length}),B=g.data?.value_contains??{},x=(0,m.DC)({include_deleted:!0}),C=(0,n.useMemo)(()=>{if(x.data)return x.data.reduce((A,e)=>(A[e.id]=e,A),{})},[x.data]);return(0,a.jsxs)(h.h.Provider,{data:c,loading:i,children:[(0,a.jsx)(h.h.SummaryMessage,{totalCount:d,onSelectAll:()=>{e&&t?.(e)},onClearAll:()=>{t?.([])}}),(0,a.jsx)("div",{className:"relative mt-2 min-h-[500px] w-full flex-1 overflow-scroll rounded-t border border-b-0 border-fn-layout-borderStrong",children:(0,a.jsx)("div",{className:"absolute inset-0 h-full",children:(0,a.jsx)("div",{ref:r,children:(0,a.jsx)(h.h.Root,{orgListVipData:B,rulesData:C,totalCount:d,scrollRef:r,onRowSelectionChanged:t,renderMessageActionsPopover:A=>{let{row:e,onOpenSubmenu:t,onCloseSubmenu:i}=A;return(0,a.jsx)(h.h.ActionsCellPopover,{message:e,onActionFinish:o,onOpenSubmenu:t,onCloseSubmenu:i})},emptyMessage:"No messages matched.",errorMessage:s?"We encountered an issue running your hunt.":null,pageIndex:f,pageSize:100,onPageIndexChange:A=>{let{pageIndex:e}=A;l(e)},rowLinkTarget:"_blank",headerTop:"0",hideFooter:!0})})})}),(0,a.jsx)("div",{className:"rounded-b border border-t-0 border-fn-layout-borderStrong",children:(0,a.jsx)(b.b.Footer,{pageIndex:f,pageSize:100,onPageIndexChange:A=>{let{pageIndex:e}=A;l(e)},totalCount:d,gutterLeft:u.$u,gutterRight:u.$u})})]})};var x=t(84030),C=t(36895),I=t(85954),Q=t(57302),E=t(44456),y=t(4430),w=t(84244),v=t(58480),k=t(31004);let j=A=>{let{data:e,backTested:t,isLoading:i,errorMessage:s,flaggedCount:o,deletedCount:d,totalCount:g,classificationCounts:p,retentionDays:b,refetchResults:m}=A,{lookbackDays:u}=(0,r.U0)(),[D,h]=(0,n.useState)([]);if((0,n.useEffect)(()=>{h([])},[i]),void 0===b)return(0,a.jsx)("div",{className:"flex h-full flex-col items-center justify-center rounded border border-solid border-fn-layout-borderStrong bg-gray-100",children:(0,a.jsx)(c.A,{})});if(b<1)return(0,a.jsx)("div",{className:"flex h-full flex-col items-center justify-center rounded border border-solid border-fn-layout-borderStrong bg-gray-100",children:(0,a.jsx)(l.A,{context:"backtest"})});if(i)return(0,a.jsx)(F,{days:u});if(!t)return(0,a.jsx)("div",{className:"flex h-full flex-col items-center justify-center rounded border border-solid border-fn-layout-borderStrong bg-gray-100",children:(0,a.jsx)("span",{className:"mx-6 mb-6 text-center text-fn-bodyMedium text-fn-text-weak",children:"Press ⌘+B to backtest your rule"})});let x=(0,I.o)(p),C=`${(0,f.rR)(o)} Already Flagged`;x&&(C+=` (${x})`);let Q=`${(0,f.rR)(d)} Trashed`;return(0,a.jsxs)("div",{className:"flex h-full flex-col",children:[(0,a.jsxs)("div",{className:"flex justify-between gap-2 pb-4",children:[(0,a.jsx)("div",{className:"flex items-center overflow-hidden whitespace-nowrap text-fn-bodyMedium",children:[C,Q].join(", ")}),(0,a.jsx)(k.A,{selectedMessages:D,onFinish:m},`${D?.length}-${i}`)]}),(0,a.jsx)(B,{data:e,isLoading:i,errorMessage:s,onSelectedRowsChange:h,onActionFinish:m,totalCount:g})]})},F=A=>{let{days:e}=A,t=(0,C.G)(E.wI),{cancelHunt:i}=(0,v.P)(),s=(0,d.wA)();async function n(){t&&(await i(t),s((0,Q.AJ)()))}return(0,a.jsxs)("div",{className:"mx-6 flex h-full flex-col items-center justify-center gap-6 rounded border border-solid border-fn-layout-borderStrong bg-gray-100",children:[(0,a.jsxs)("div",{className:"text-center text-fn-bodyMedium",children:["Analyzing messages from the past ",(0,w.E1)(e)]}),(0,a.jsx)(y.Ip,{}),(0,a.jsx)(x.$n,{variant:"dangerSecondary",onClick:n,children:"Cancel"})]})};var S=t(77770);let M=A=>{let{disabled:e}=A,{setLookbackDays:t,lookbackDays:i}=(0,r.U0)(),{data:s}=(0,m.Aq)(),n=s?.mdm_retention_days,o=(0,w.Sz)();return(0,a.jsx)("div",{children:(0,a.jsx)(S.l,{label:"Lookback",value:i,getDisplayText:A=>(0,w.aI)(A),onValueChange:A=>t(A),disabled:!(!e&&n&&n>0),children:o.map(A=>(0,a.jsx)(S.l.Option,{value:A.value,disabled:A.isDisabled,children:A.label},A.value))})})};var R=t(62222),T=t(53556),N=t(76327),P=t(64929),U=t(8413),V=t(93915);let X=A=>{let{isPending:e,backTested:t,resultCount:i,onPerformBackTest:s,errorMessage:o,retentionDays:d,onFilterResults:r,filtersShown:l,disableFilters:c,hasFilters:g}=A,p=(0,f.rR)(i),{canBacktest:b}=(0,U.V)(),m=1===i?"message":"messages",u=(0,n.useContext)(V.q);return(0,a.jsx)("div",{className:"flex flex-col gap-2 pb-0 pt-2",children:(0,a.jsxs)("div",{className:"flex flex-wrap-reverse items-start justify-between",children:[(0,a.jsxs)("div",{className:"mb-2 shrink pr-1",children:[(0,a.jsx)("h3",{className:"text-fn-bodySmall text-fn-text-weak",children:g?"Backtest result, with additional filters":"Backtest result"}),o?(0,a.jsxs)("div",{className:"flex items-center gap-1 text-fn-bodyMedium text-fn-alerts-warning",children:[(0,a.jsx)(T.c8l,{}),o]}):!e&&t?(0,a.jsx)("div",{children:(0,a.jsx)("div",{className:(0,y.cn)("text-fn-bodyMedium font-semibold",i>0?"text-fn-alerts-success":"text-fn-text-strong"),children:g?`${p} ${m} found`:`Flagged ${p} ${m}`})}):(0,a.jsx)("div",{className:"flex items-center",children:(0,a.jsx)("div",{className:"mr-1 text-fn-bodyMedium font-semibold text-fn-text-strong",children:"Untested"})})]}),(0,a.jsxs)("div",{className:"mb-2 ml-0 flex shrink-0 grow justify-end gap-1 pr-1",children:[(0,a.jsx)(M,{disabled:e}),(0,a.jsx)(N.m,{content:u,disabled:!u,children:(0,a.jsx)("div",{children:(0,a.jsx)(x.$n,{onClick:()=>{s()},disabled:!!u||e||!d||!b,keyboardShortcut:(0,a.jsx)(x.Sj,{label:P.j3.label}),children:t?"Backtest Again":"Backtest"})})}),(0,a.jsx)(R.Q,{hasFilters:g,isDisabled:!b||c,onClick:r,filtersShown:l})]})]})})};var H=t(49053),G=t(89692),J=t(12931),z=t(73638),L=t(92345),O=t(52717),Z=t(44495);let W=A=>{let{backTested:e,isLoading:t,data:i,error:s,totalCount:n,flaggedCount:o,deletedCount:d,dismissedCount:r,classificationCounts:f,onPerformBackTest:l,refetchResults:c,retentionDays:g,onFilterResults:p,filtersShown:b,hasFilters:m,disableFilters:u}=A;return(0,a.jsxs)(a.Fragment,{children:[(0,a.jsx)(X,{disableFilters:u,filtersShown:b,onFilterResults:p,hasFilters:m,isPending:t,backTested:e,resultCount:n,errorMessage:s,onPerformBackTest:l,retentionDays:g}),(0,a.jsx)(j,{isLoading:t,errorMessage:s,backTested:e,data:i,totalCount:n,flaggedCount:o,deletedCount:d,dismissedCount:r,classificationCounts:f,refetchResults:c,retentionDays:g})]})},Y=n.memo(()=>{let A=(0,o.xW)(),{data:e}=(0,m.Aq)(),t=(0,C.G)(E._F),[i,d]=(0,n.useState)({}),l=e?.mdm_retention_days,c=(0,G.j)(),g=(0,n.useRef)({onPageChange:s().noop}),p=(0,C.G)(E.wI),b=!(0,f.Zr)(i),u=(0,n.useCallback)(e=>{e&&A.setError("source",{message:e})},[A]),{hasBackTested:D,isPending:h,results:B,response:x,totalCount:I,huntId:y,flaggedCount:w,deletedCount:v,dismissedCount:k,classificationCounts:j,onPerformBackTest:F,error:S}=(0,H.L)(u),M=(0,n.useCallback)(A=>{d(e=>({...e,...s().omit(A,"page")}))},[]),R=(0,n.useCallback)(()=>{d({})},[d]),{lookbackDays:T}=(0,r.U0)();(0,n.useEffect)(()=>{p||R()},[p,R]);let N=(0,n.useCallback)(()=>{t?(c((0,Q.OI)({filtersShown:!1})),c((0,z.YS)({Backtest:!0,MQL:!0,EML:!1,MDM:!1,Preview:!1,Insights:!1,Screenshot:!1}))):(c((0,z.YS)({Backtest:!0,MQL:!1,EML:!1,MDM:!1,Preview:!1,Insights:!1,Screenshot:!1})),c((0,Q.OI)({filtersShown:!0})))},[c,t]),P=(0,n.useCallback)(()=>(0,a.jsx)(O.e,{ignoreDefaults:!0,callbacksRef:g,messageGroups:x,onFiltersUpdated:s().noop}),[x]),U=()=>F({action:"backtest",source:A.getValues("source"),ruleType:A.getValues("type"),triageRuleTriggers:A.getValues("triage_rule_triggers"),lookbackDays:T});return(0,n.useEffect)(()=>{let A=(0,Z.h)((0,f.Ui)(i));y&&!h&&(async()=>{let e=await (0,J.C)(y,A);c((0,Q.zX)(e))})()},[c,i,y,h]),(0,a.jsxs)(L.g,{value:{setFilters:M,filters:i},children:[!!t&&(0,a.jsx)(P,{}),(0,a.jsx)(W,{hasFilters:b,disableFilters:!D||h,filtersShown:t,onFilterResults:N,backTested:D,isLoading:h,data:B,error:S,totalCount:I,flaggedCount:w,deletedCount:v,dismissedCount:k,classificationCounts:j,onPerformBackTest:U,retentionDays:l,refetchResults:U})]})})},99312:(A,e,t)=>{t.d(e,{W:()=>n});var a=t(37876),i=t(76327),s=t(4430);function n(A){let{active:e=!1,tooltip:t,testId:n,className:o}=A;return(0,a.jsx)(i.m,{content:t,children:(0,a.jsx)("div",{className:(0,s.cn)("size-3 shrink-0 rounded-full",e?"bg-fn-alerts-success":"bg-fn-alerts-caution",o),"data-testid":n})})}}}]);