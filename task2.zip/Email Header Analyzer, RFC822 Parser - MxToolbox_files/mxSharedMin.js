/* Minification failed. Returning unminified contents.
(96,33-34): run-time error JS1014: Invalid character: `
(96,35-36): run-time error JS1004: Expected ';': {
(96,50-51): run-time error JS1195: Expected expression: /
(96,55-56): run-time error JS1014: Invalid character: `
(97,9-10): run-time error JS1002: Syntax error: }
(98,33-34): run-time error JS1014: Invalid character: `
(98,44-45): run-time error JS1004: Expected ';': {
(98,59-60): run-time error JS1014: Invalid character: `
(99,9-10): run-time error JS1002: Syntax error: }
(107,29-30): run-time error JS1004: Expected ';': {
(108,16-17): run-time error JS1014: Invalid character: `
(108,22-23): run-time error JS1004: Expected ';': :
(112,16-17): run-time error JS1014: Invalid character: `
(112,22-23): run-time error JS1004: Expected ';': :
(162,19-20): run-time error JS1014: Invalid character: `
(162,25-26): run-time error JS1004: Expected ';': :
(571,1-2): run-time error JS1002: Syntax error: }
(572,12-13): run-time error JS1195: Expected expression: )
(572,14-15): run-time error JS1004: Expected ';': {
(619,2-3): run-time error JS1195: Expected expression: )
(620,12-13): run-time error JS1195: Expected expression: )
(620,14-15): run-time error JS1004: Expected ';': {
(766,2-3): run-time error JS1195: Expected expression: )
(767,12-13): run-time error JS1195: Expected expression: )
(767,14-15): run-time error JS1004: Expected ';': {
(798,2-3): run-time error JS1195: Expected expression: )
(820,16-17): run-time error JS1004: Expected ';': {
(1078,2-3): run-time error JS1195: Expected expression: )
(1080,1-2): run-time error JS1197: Too many errors. The file might not be a JavaScript file: (
(108,9-22): run-time error JS1018: 'return' statement outside of function: return `https
 */
(function () {
    // Do not copy this this script is intended to be unique
    // and shared among all the master pages
    // all the functions here must be declared here and only here

    window.MXT = window.MXT || {};
    var _postRun = {
        functions: [],
        hasRun: false
    };
    let _adminConsoleMsgs = [];
    // =============== Temp Shared Code
    // This may be replaced with MXT.WriteLog
    // In the meantime we need it for AB variation calls
    window.MxErrorHandler = function (input, details, e) {
        /* Remove this restriction for now - we can put it back in the future
        if (input.indexOf("VWO") === -1 && details.indexOf("VWO") === -1) {
            // Only engage for Errors that contain "VWO"
            return false;
        }
        */

        if (typeof e === "undefined") {
            e = "undefined";
        }

        var userAgent = "";

        if (navigator) {
            if (navigator.userAgent) {
                userAgent = navigator.userAgent;
            }
        }

        var params = {
            "input": input,
            "details": details,
            "stackTrace": e,
            "userAgent": userAgent
        };
        $.ajax({
            type: "POST",
            url: GetMxWebsite() + "Public/Lookup.aspx/ReportException3",
            data: JSON.stringify(params),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function (msg) {
                //console.log(msg);
            },
            error: function (err) {
                //console.log(err);
            }
        });

    };

    // =============== MXT Interface
    MXT.GetMxWebsite = GetMxWebsite;
    MXT.GetMxDeliveryWebsite = GetMxDeliveryWebsite;
    MXT.API = MakeApiCall;
    MXT.getCookie = MXT.GetCookie = GetCookie;
    MXT.setCookie = MXT.SetCookie = SetCookie;
    MXT.deleteCookie = DeleteCookie;
    MXT.AddPostRun = AddPostRun;
    MXT.ListPostRun = ListPostRun;
    MXT.RunPosts = RunPosts;
    MXT.MxUrl = MxUrl;
    MXT.EscapeRegex = EscapeRegex;
    MXT.StringFormat = StringFormat;
    MXT.Deprecated = Deprecated;
    MXT.AdminConsole = AdminConsole;
    MXT.Watcher = Watcher;
    MXT.OnPasswordChange = OnPasswordChange;
    MXT.HTMLEncode = HTMLEncode;
    MXT.HTMLDecode = HTMLDecode;
    MXT.GetDeliveryTemplateUrl = GetDeliveryTemplateUrl;

    // =============== Placeholders
    // In case the application does not load the other resource
    MXT.AddABTestTrigger = MXT.AddABTestTrigger || function () { };

    window.init = AB265init;

    // =============== Initialize
    InitMxToolboxHostDomain();
    function InitMxToolboxHostDomain() {
        let hostName = window.location.hostname.toLowerCase();
        let hostSplit = hostName.split(".");

        MXT.HOST_NAME = hostName;
        MXT.ISLOCAL = hostName.includes('local');
        MXT.DOMAIN_NAME = hostSplit.slice(-2).join('.');
        MXT.DOMAIN_ENDING = hostSplit.slice(-1)[0];

        if (MXT.ISLOCAL) {
            MXT.DELIVERY_HOST = `${MXT.HOST_NAME}/site`;
        } else {
            MXT.DELIVERY_HOST = `delivery.${MXT.HOST_NAME}`;
        }
    }

    // =============== Events
    // To let early callers know that the mx shared library is ready
    document.dispatchEvent(new CustomEvent('mx-shared-ready'));

    // =============== MXT Methods
    function GetMxWebsite() {
        return `https://${MXT.HOST_NAME}/`;
    }

    function GetMxDeliveryWebsite() {
        return `https://${MXT.DELIVERY_HOST}${(MXT.DELIVERY_HOST[MXT.DELIVERY_HOST.length - 1] == "/" ? "" : "/") }`;
    }

    /**
     * Used to indicate that an old function should not be used anymore
     * NOTE
     * The reason for this is urge the moving of global functions into the MXT namespace.
     * When a file is converted to use the MXT namespace, this utility will help
     * identify when we are still calling the old global.
     *
     * @param {*} newFunctionName This string will have an 'eval' applied. Make sure it's correct.
     * @param {*} oldFunctionName Optional - The old function name
     * @param {*} oldFnOverride Optional
     * @returns {fn} conversion function
     */
    function Deprecated(newFunctionName, oldFunctionName, oldFnOverride) {
        return function () {
            let msg = '';
            let fn;

            if (oldFunctionName) {
                msg += '"' + oldFunctionName + '" is deprecated. ';
            }
            msg += 'Use "' + newFunctionName + '" instead. ';

            if (oldFnOverride) {
                fn = oldFnOverride;
                msg += 'NOTE: The new function uses a different signature. ';
            } else {
                fn = eval(newFunctionName);
            }

            MXT.AdminConsole(msg);
            // 'arguments' is a hidden property available to all functions. This returned function is what the
            //       CALLEE is calling, so it has the params.
            // Using apply to pass through all old 'arguments' into new function.
            // Using Array.prototype.slice.call to turn arguments into real array
            fn.apply(this, Array.prototype.slice.call(arguments));
        };
    }


    /**
     * This is for AngularJs templates that need to live in classic and DC2
     */
    function GetDeliveryTemplateUrl(templateUrl) {
        let url = templateUrl;

        // Only Classic MXT will have MXT.currentLocation
        if (MXT.currentLocation) {
            url = `https://${MXT.DELIVERY_HOST}/${templateUrl}`;
        }

        return url;
    }

    /**
     * Helper to angular $watch and $on that reports when watches are fired.
     *
     * @param {*} fn
     * @returns
     */
    function Watcher(fn) {
        let controllerName = '';
        try {
            controllerName = arguments.callee.caller.name;
        } catch (error) {
            // This is most likely because the caller of this Watcher function has
            // 'use strict'; at the top of the file.. therefore it will block our attempts
            // to look behind the scenes.
        }
        return function WatchInterceptor() {
            AdminConsole('WATCH "' + fn.name + '" fired in ' + controllerName);
            fn.apply(this, Array.prototype.slice.call(arguments));
        };
    }

    /**
     * Admin Console outputs a console.log(), but only if the USER is considered an ADMIN.
     *
     * @param {*} [arguments] native arguments
     */
    function AdminConsole() {
        // 'arguments' is a hidden property available to all functions.
        let fnArguments = Array.prototype.slice.call(arguments);

        if (MXT.isUserLoaded) {
            // The MXT.User is not properly loaded by this time, but the mxUser.js has set the is_admin bit in the window variable.
            // I'm pretty sure this is why the deprecated message that calls this exists
            // This is a shim until we figure out a better way.

            if (window._is_admin && window._admin_console) {  // TODO - Add condition of inpersonated
                // 'arguments' is a hidden property available to all functions.
                // Using apply to pass through all 'arguments' to console.
                // Using Array.prototype.slice.call to turn arguments into real array
                // Colorizing tag with '%c' which console.log in chrome, safari and edge support
                console.log.apply(this, ['%cMXT ADMIN LOG:', 'color:#FF9900;'].concat(fnArguments));
            }
        } else {
            _adminConsoleMsgs.push(fnArguments);
            MXT.OnUserLoaded(function (event, user) {
                let i, len;
                for (i = 0, len = _adminConsoleMsgs.length; i < len; i++) {
                    AdminConsole.apply(this, _adminConsoleMsgs[i]);
                }
                _adminConsoleMsgs.length = 0;
            });
        }
    }

    function OnPasswordChange(element) {
        var decode = decodeURIComponent($(element).val());
        $(element).val(encodeURIComponent(decode));
    }

    function MakeApiCall(type, href, success, params) {
        var apiUrl = MXT.GetMxWebsite() + "api/";

        params = params || {};
        params = $.extend({
            type: {
                GET: 'GET',
                POST: 'POST',
                DELETE: 'DELETE',
                PUT: 'PUT'
            }[type.toUpperCase()] || 'GET',
            async: undefined,
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            data: null
        }, params);

        // v1 or v2
        apiUrl += 'v' + (params.isV2 ? '2' : '1');

        //Are we passing in a path or a full href?
        href = href[0] === '/' ? apiUrl + href : href;

        $.ajax({
            type: params.type,
            async: params.async,
            data: params.data,
            url: href,
            contentType: params.contentType,
            dataType: params.dataType,
            success: function (data) {
                success(data);
            },
            error: function (xhr, status, error) {
                console.log(xhr, status, error);
            }
        });
    }

    function SetCookie(name, value, days, domain) {
        let expires = '';
        let date = new Date();

        if (days) {
            date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
            expires = "; expires=" + date.toGMTString();
        }

        // Anything over 4k can not be stored in a cookie. We are going to store it in local storage instead
        if (value.length > 3900) {
            localStorage.setItem(name, value);
        } else {
            document.cookie = name + "=" + encodeURIComponent(value) + expires + "; " + (domain ? "domain=" + domain : "") + "; path=/";
        }

        return document.cookie;
    }

    function DeleteCookie(name) {
        let isCookie = !!FindCookie(name);
        if (isCookie) {
            MXT.setCookie(name, '', -1);
        } else {
            localStorage.removeItem(name);
        }
    }

    function GetCookie(name) {
        let cookieValue = FindCookie(name);
        let localStorageItem;

        if (cookieValue) {
            return decodeURIComponent(cookieValue);
        } else {
            // We did not find it in cookies.. try localStorage

            localStorageItem = localStorage.getItem(name);
            if (localStorageItem) {
                return localStorageItem;
            }
        }

        return null;
    }

    function FindCookie(name) {
        let nameEQ = name + "=";
        let ca = document.cookie.split(';');

        for (var i = 0, len = ca.length; i < len; i++) {
            var c = ca[i];
            while (c.charAt(0) === ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
        }

        return null;
    }

    /**
         * These are tools for VWO and Optimize to trigger code execution
         * AFTER VWO and Optimize have run it's test code on the page.
         * To add a function to run after VWO/Optimize, use either:
         * window.MXT.AddPostRun(fn)
         *      if there are no parameters that need to be passed into the executed code
         * window.MXT.AddPostRun(function(){ your code that uses parameters outside this })
         *      if you have parameters. Look at ShowSwitchResponsiveLink in this file
         *      for an example.
         *
         * VWO/Optimize then can call window.MXT.RunPosts() when it's done.
         *
         * In VWO, go into any of the javascript edit (Control or Variation),
         * Click on the Edit Campaign Code item. This is where we can set code that
         * runs after the variation code runs. All variations use the same campaign code.
         * This is what you put in there:
         * (function(){
              var MXT = window.MXT || {
                RunPosts: function(){
                  console.log('VWO On Done error. No MXT found');
                }
              };
              if (MXT.RunPosts){
                MXT.RunPosts();
              }
            })();
         *
         * In Optimize: I could not figure out a solution to this one.. No optimize post execution
         * until we figure this out.
         */

    function AddPostRun(fn) {
        _postRun.functions.push(fn);
    }

    function ListPostRun() {
        console.log(_postRun);
    }

    function RunPosts() {
        if (!_postRun.hasRun) {
            let i, len;
            for (i = 0, len = _postRun.functions.length; i < len; i++) {
                _postRun.functions[i]();
            }
            // reset
            _postRun.functions = [];
        }
    }

    function AB265init(i) { //Put in place to fix a timing issue with AB-265 without restarting the test.
        i = i || 0;
        if (i < 10) {
            i++;
            setTimeout(function () {
                window.init(i);
            }, 300);
        }
    }

    // MxUrl accepts a param that can be:
    //      [object] 'document.location'
    //      [string] a css selector
    //      [string] url (distinguished by '/' characters present)
    function MxUrl(obj) {
        let _$elem;
        let _href;
        let _location;
        let _params;
        let _this;

        // if string is passed in, it's either a class name or url string
        if (typeof obj === 'string') {
            if (obj.indexOf('/') > -1) {
                // The obj contains a '/' so it is most likely a url string
                _href = obj;
                _location = ParseURL(_href);
            } else {
                // The obj does not contain a '/' so it is most likely a css selector
                _$elem = $(obj);
                _href = _$elem.attr('href');
                _location = ParseURL(_href);
            }
        } else {
            // The obj is an object, so it's expected that it is a 'document.location'
            _href = obj.href;
            _location = obj;
        }
        _params = ParseParams(_location.search);

        _this = {
            $elem: _$elem,
            href: _href,
            location: _location,
            params: _params,
            UpdateQS: UpdateQS,
            IsPage: IsPage,
            HasParam: HasParam,
            GetUrl: GetUrl,
            MergeParams: MergeParams
        };
        return _this;

        function ParseURL(url) {
            let parser = document.createElement('a');
            // Let the browser do the work
            parser.href = url;

            // IE11 compatibiliy.. silly, I know. https://gist.github.com/koron/c66b67c6bcdd286f6209
            parser.href = parser.href;

            return {
                protocol: parser.protocol,
                host: parser.host,
                hostname: parser.hostname,
                port: parser.port,
                pathname: parser.pathname.indexOf('/') !== 0 ? '/' + parser.pathname : parser.pathname,
                search: parser.search,
                hash: parser.hash
            };
        }

        function ParseParams(search) {
            let searchObject = {},
                queries, split, i;
            if (search === "") {
                return {};
            }
            queries = search.replace(/^\?/, '').split('&');
            for (i = 0; i < queries.length; i++) {
                split = queries[i].split('=');
                searchObject[split[0]] = split[1];
            }
            return searchObject;
        }

        function IsPage(page) {
            return _location.pathname.toLowerCase().indexOf(page) > -1;
        }

        function HasParam(key, value) {
            for (let param in _params) {
                if (_params.hasOwnProperty(param)) {
                    if (param.toLowerCase() === key.toLowerCase()) {
                        return value ? _params[param] === value : true;
                    }
                }
            }
            return false;
        }

        function UpdateQS(paramToChange, value, deleteUndefined) {
            let foundParam = false;
            for (let param in _params) {
                if (_params.hasOwnProperty(param)) {
                    if (param.toLowerCase() === paramToChange.toLowerCase()) {
                        _params[param] = value;
                        foundParam = true;
                        break;
                    }
                }
            }
            if (!foundParam) {
                _params[paramToChange] = value;
            }

            // If nessassary, delete the param if it has no value
            if (deleteUndefined && !value) {
                delete _params[paramToChange];
            }

            if (_$elem) {
                _$elem.attr('href', GetUrl());
            }

            return _this;
        }

        function GetUrl() {
            let returnUrl;
            returnUrl = _location.protocol + '//' + _location.host + _location.pathname;
            if (_params) {
                returnUrl += '?' + ParamsToQs();
            }
            return returnUrl;
        }

        function ParamsToQs() {
            let returnQs = [];
            for (let param in _params) {
                if (_params.hasOwnProperty(param)) {
                    returnQs.push(param + '=' + _params[param]);
                }
            }
            return returnQs.join('&');
        }

        function MergeParams(params) {
            for (param in params) {
                if (params.hasOwnProperty(param)) {
                    UpdateQS(param, params[param]);
                }
            }
        }
    }

    function StringFormat(str) {
        let argCount = arguments.length;
        let i, len, replace, re;

        for (i = 1, len = argCount; i < len; i++) {
            replace = EscapeRegex('{' + (i - 1) + '}');
            re = new RegExp(replace, "g");
            str = str.replace(re, arguments[i]);

        }

        return str;
    }

    function EscapeRegex(value) {
        return value.replace(/[\-\[\]{}()*+?.,\\\^$|#\s]/g, "\\$&");
    }

    /**
     * Converts a string to html characters
     * @param {string} str String with unescaped HTML characters
     */
    function HTMLEncode(str) {
        var buf = [];

        for (var i = str.length - 1; i >= 0; i--) {
            buf.unshift(['&#', str[i].charCodeAt(), ';'].join(''));
        }

        return buf.join('');
    }
    /**
     * Converts HTML Entities to regular characters
     * @param {any} str String of HTML Entities
     */
    function HTMLDecode(str) {
        return str.replace(/&#(\d+);/g, function (match, dec) {
            return String.fromCharCode(dec);
        });
    }
})();;
(function () {
    //
    // !! THIS FILE REQUIRES MXSHARED !!
    //
    // Do not copy this this script is intended to be unique
    // and shared among all the master pages
    // all the functions here must be declared here and only here

    window.MXT = window.MXT || {};

    let MXT = window.MXT;

    MXT.AppLog = {};
    MXT.AppLog.WriteTypedEntry = WriteTypedEntry;
    MXT.AppLog.TraceEventType = {
        Critical: 1,
        Error: 2,
        Warning: 4,
        Information: 8,
        Verbose: 16
    };

    function WriteTypedEntry(type, errMsg, traceEventType, detail) {
        if (detail) {
            if (typeof detail == 'object') {
                detail = JSON.stringify(detail);
            } 
        }

        var clientMessage = {
            Location: type,
            Message: errMsg,
            TraceEventType: traceEventType,
            Detail: detail
        };

        $.post('/api/v1/Loggly', clientMessage, WriteTypedEntrySuccess, WriteTypedEntryFail);

        function WriteTypedEntrySuccess(data) {
            console.log('data', data);
        }

        function WriteTypedEntryFail(response) {
            console.log('response', response);
        }
    }

})();;
(function () {
    //
    // !! THIS FILE REQUIRES MXSHARED !!
    //
    // Do not copy this this script is intended to be unique
    // and shared among all the master pages
    // all the functions here must be declared here and only here

    window.MXT = window.MXT || {};
    window.MXT.OnUserLoaded = onUserLoaded;
    window.MXT.RegistrationValidation = registrationValidation;
    window.MXT.GetPasswordMinMax = getPasswordMinMax;

    // Global variables
    window._is_paid = 0;
    window._is_logged_in = 0;
    window._is_admin = 0;
    window._numDomainHealthMonitors = 0;
    window._domainName = window.location.host.split('.').slice(-2).join('.');

    // Private variables
    _passwordMinLength = 8;
    _passwordMaxLength = 128;

    (function GetUser() {
        $.getJSON('/api/v1/user', getUserSuccess)
            .fail(getUserFail);

    })();

    function getUserSuccess(user) {
        // Store the cookies
        /*
         * Features:
         * If the cookie is present the backend won't return it, so just read from the cookie for now
         * We need to stop storing Features with the user, once that is done clean here
         */
        if (user.Features && Object.getOwnPropertyNames(user.Features).length > 0) {
            localStorage.setItem('_mxt_f', JSON.stringify(user.Features));
        } else {
            user.Features = JSON.parse(localStorage.getItem('_mxt_f')) || {};
        }
        // Store user without the Features
        var _mxt_u = Object.assign({}, user); // Copy so it does not kill the prop Features on the real object
        delete _mxt_u.Features;        
        MXT.setCookie('_mxt_u', JSON.stringify(_mxt_u), null, '.' + window._domainName);
        // Cookie Segment for ABtesting
        var _mxt_segment = "anon"; // for cookie _mxt_s
        // Set global variables
        if (user.IsLoggedIn) {
            window._is_logged_in = 1;
            _mxt_segment = "free";
            if (user.IsPaidUser) {
                window._is_paid = 1;
                _mxt_segment = "paid";
            }
            if (user.IsAdmin) {
                window._is_admin = 1;
            }
            // SetCustomerIo
            var _cio = window._cio || [];
            if (_cio['identify']) {
                _cio.identify({
                    id: user.MxVisitorUid,
                    email: user.UserName
                });
            }
            window._numDomainHealthMonitors = user.NumDomainHealthMonitors;
        } else {
            // Set the Temp Auth Key if is not logged in
            if (user.TempAuthKey) {
                window.TempAuthKey = user.TempAuthKey;
            }
        }

        // Set Segment Cookie
        MXT.setCookie('_mxt_s', _mxt_segment, null, '.' + window._domainName);
        MXT.isUserLoaded = true;        

        // Raised each time User object comes back (for external integrations)
        $(document).trigger('userLoaded', user);
        document.dispatchEvent(new CustomEvent('mx-user-loaded', { 'user': user })); // For those who don't use jQuery
    }

    function getUserFail() {
        // Delete the cookie/storage
        MXT.deleteCookie('_mxt_u');
        MXT.deleteCookie('_mxt_f'); // If you see this line after 9/25/2021, please remove 
        localStorage.removeItem('_mxt_f');

        MXT.isUserLoaded = true;

        // Raised each time User object comes back (for external integrations)
        $(document).trigger('userLoaded', null);
        document.dispatchEvent(new CustomEvent('mx-user-loaded', { 'user': null })); // For those who don't use jQuery
    }

    // Wrap up function to execute something as soon as the User is loaded
    // Async user integrations: Used by Ab Test and by MxMaster (to load the header)
    function onUserLoaded(callback) {
        if (MXT.isUserLoaded) {
            // Already loaded, send from cookie
            // We are mocking the trigger and the first argument must be the event (null to let the called know that it was immediate)
            var event = null;
            var user = JSON.parse(MXT.getCookie('_mxt_u'));
            user.Features = JSON.parse(localStorage.getItem('_mxt_f')) || {};
            callback(event, user);
        } else {
            // The trigger will handle this
            $(document).on('userLoaded', callback);
        }
    }

    // This is a form validator for our Registration forms
    // Starting with password validation, it can be extended to any and everything.
    function registrationValidation(registration) {
        let returnMessage = '';
        if (typeof registration.name !== 'undefined' && (registration.name === '' || registration.name.length === 0)) {
            returnMessage += 'Name can not be empty.<br />';
        }
        if (typeof registration.email !== 'undefined' && (registration.email === '' || registration.email.length === 0)) {
            returnMessage += 'Email address can not be empty.<br />';
        }
        if (typeof registration.password !== 'undefined' && registration.password.length < 8) {
            returnMessage += 'Password too short. Password must be at least 8 characters.<br />';
        }
        if (typeof registration.password !== 'undefined' && registration.password.length > 128) {
            returnMessage += 'Password too long. Password can not exceed 128 characters. <br />';
        }
        if (typeof registration.name !== 'undefined' && registration.company.length > 50) {
            returnMessage += 'Company Name too long. Company Name can not exceed 50 characters. <br />';
        }
        if (typeof registration.domain !== 'undefined' && (registration.domain === '' || registration.domain.length === 0)) {
            returnMessage += 'Domain can not be empty.<br />';
        }
        return returnMessage;
    }

    function getPasswordMinMax() {
        let passwordLengths = {
            min: _passwordMinLength,
            max: _passwordMaxLength
        };
        return passwordLengths;
    }

})();;
(function () {
    // Do not copy this this script is intended to be unique
    // and shared among all the master pages
    // all the functions here must be declared here and only here

    // =============== Windows Interface
    // These are here for backwards compatibility. We should remove calls to these
    // and replace them with MXT calls.
    // Be aware that any functionality that needs to work on any browers that 
    // do not support a root object called 'window' will fail. Some stateless 
    // browsers are like this
    window.setIpAddress = SetIpAddress;

    window.MXT = window.MXT || {};

    // =============== MXT Interface
    MXT.SetIpAddress = SetIpAddress;

    // =============== MXT Methods
    //Called on Init from MxMaster
    function SetIpAddress() {
        var whatsmyipUrl = 'https://api.mxtoolbox.com/api/v1/utils/whatsmyip';
        if (whatsmyipUrl.indexOf('//mxtoolbox') != -1) {
            whatsmyipUrl = whatsmyipUrl.replace('//mxtoolbox', '//api.mxtoolbox');
        }

        $.get(whatsmyipUrl, function (data) {
            // ******* TODO ******** Move this out of here. This should only return data
            $('#lnkIp').html(data);
        });
    }
})();;
/*
 * JavaScript MD5
 * https://github.com/blueimp/JavaScript-MD5
 *
 * Copyright 2011, Sebastian Tschan
 * https://blueimp.net
 *
 * Licensed under the MIT license:
 * https://opensource.org/licenses/MIT
 *
 * Based on
 * A JavaScript implementation of the RSA Data Security, Inc. MD5 Message
 * Digest Algorithm, as defined in RFC 1321.
 * Version 2.2 Copyright (C) Paul Johnston 1999 - 2009
 * Other contributors: Greg Holt, Andrew Kepert, Ydnar, Lostinet
 * Distributed under the BSD License
 * See http://pajhome.org.uk/crypt/md5 for more info.
 */

/* global define */

;(function ($) {
  'use strict'

  /*
  * Add integers, wrapping at 2^32. This uses 16-bit operations internally
  * to work around bugs in some JS interpreters.
  */
  function safeAdd (x, y) {
    var lsw = (x & 0xffff) + (y & 0xffff)
    var msw = (x >> 16) + (y >> 16) + (lsw >> 16)
    return (msw << 16) | (lsw & 0xffff)
  }

  /*
  * Bitwise rotate a 32-bit number to the left.
  */
  function bitRotateLeft (num, cnt) {
    return (num << cnt) | (num >>> (32 - cnt))
  }

  /*
  * These functions implement the four basic operations the algorithm uses.
  */
  function md5cmn (q, a, b, x, s, t) {
    return safeAdd(bitRotateLeft(safeAdd(safeAdd(a, q), safeAdd(x, t)), s), b)
  }
  function md5ff (a, b, c, d, x, s, t) {
    return md5cmn((b & c) | (~b & d), a, b, x, s, t)
  }
  function md5gg (a, b, c, d, x, s, t) {
    return md5cmn((b & d) | (c & ~d), a, b, x, s, t)
  }
  function md5hh (a, b, c, d, x, s, t) {
    return md5cmn(b ^ c ^ d, a, b, x, s, t)
  }
  function md5ii (a, b, c, d, x, s, t) {
    return md5cmn(c ^ (b | ~d), a, b, x, s, t)
  }

  /*
  * Calculate the MD5 of an array of little-endian words, and a bit length.
  */
  function binlMD5 (x, len) {
    /* append padding */
    x[len >> 5] |= 0x80 << (len % 32)
    x[((len + 64) >>> 9 << 4) + 14] = len

    var i
    var olda
    var oldb
    var oldc
    var oldd
    var a = 1732584193
    var b = -271733879
    var c = -1732584194
    var d = 271733878

    for (i = 0; i < x.length; i += 16) {
      olda = a
      oldb = b
      oldc = c
      oldd = d

      a = md5ff(a, b, c, d, x[i], 7, -680876936)
      d = md5ff(d, a, b, c, x[i + 1], 12, -389564586)
      c = md5ff(c, d, a, b, x[i + 2], 17, 606105819)
      b = md5ff(b, c, d, a, x[i + 3], 22, -1044525330)
      a = md5ff(a, b, c, d, x[i + 4], 7, -176418897)
      d = md5ff(d, a, b, c, x[i + 5], 12, 1200080426)
      c = md5ff(c, d, a, b, x[i + 6], 17, -1473231341)
      b = md5ff(b, c, d, a, x[i + 7], 22, -45705983)
      a = md5ff(a, b, c, d, x[i + 8], 7, 1770035416)
      d = md5ff(d, a, b, c, x[i + 9], 12, -1958414417)
      c = md5ff(c, d, a, b, x[i + 10], 17, -42063)
      b = md5ff(b, c, d, a, x[i + 11], 22, -1990404162)
      a = md5ff(a, b, c, d, x[i + 12], 7, 1804603682)
      d = md5ff(d, a, b, c, x[i + 13], 12, -40341101)
      c = md5ff(c, d, a, b, x[i + 14], 17, -1502002290)
      b = md5ff(b, c, d, a, x[i + 15], 22, 1236535329)

      a = md5gg(a, b, c, d, x[i + 1], 5, -165796510)
      d = md5gg(d, a, b, c, x[i + 6], 9, -1069501632)
      c = md5gg(c, d, a, b, x[i + 11], 14, 643717713)
      b = md5gg(b, c, d, a, x[i], 20, -373897302)
      a = md5gg(a, b, c, d, x[i + 5], 5, -701558691)
      d = md5gg(d, a, b, c, x[i + 10], 9, 38016083)
      c = md5gg(c, d, a, b, x[i + 15], 14, -660478335)
      b = md5gg(b, c, d, a, x[i + 4], 20, -405537848)
      a = md5gg(a, b, c, d, x[i + 9], 5, 568446438)
      d = md5gg(d, a, b, c, x[i + 14], 9, -1019803690)
      c = md5gg(c, d, a, b, x[i + 3], 14, -187363961)
      b = md5gg(b, c, d, a, x[i + 8], 20, 1163531501)
      a = md5gg(a, b, c, d, x[i + 13], 5, -1444681467)
      d = md5gg(d, a, b, c, x[i + 2], 9, -51403784)
      c = md5gg(c, d, a, b, x[i + 7], 14, 1735328473)
      b = md5gg(b, c, d, a, x[i + 12], 20, -1926607734)

      a = md5hh(a, b, c, d, x[i + 5], 4, -378558)
      d = md5hh(d, a, b, c, x[i + 8], 11, -2022574463)
      c = md5hh(c, d, a, b, x[i + 11], 16, 1839030562)
      b = md5hh(b, c, d, a, x[i + 14], 23, -35309556)
      a = md5hh(a, b, c, d, x[i + 1], 4, -1530992060)
      d = md5hh(d, a, b, c, x[i + 4], 11, 1272893353)
      c = md5hh(c, d, a, b, x[i + 7], 16, -155497632)
      b = md5hh(b, c, d, a, x[i + 10], 23, -1094730640)
      a = md5hh(a, b, c, d, x[i + 13], 4, 681279174)
      d = md5hh(d, a, b, c, x[i], 11, -358537222)
      c = md5hh(c, d, a, b, x[i + 3], 16, -722521979)
      b = md5hh(b, c, d, a, x[i + 6], 23, 76029189)
      a = md5hh(a, b, c, d, x[i + 9], 4, -640364487)
      d = md5hh(d, a, b, c, x[i + 12], 11, -421815835)
      c = md5hh(c, d, a, b, x[i + 15], 16, 530742520)
      b = md5hh(b, c, d, a, x[i + 2], 23, -995338651)

      a = md5ii(a, b, c, d, x[i], 6, -198630844)
      d = md5ii(d, a, b, c, x[i + 7], 10, 1126891415)
      c = md5ii(c, d, a, b, x[i + 14], 15, -1416354905)
      b = md5ii(b, c, d, a, x[i + 5], 21, -57434055)
      a = md5ii(a, b, c, d, x[i + 12], 6, 1700485571)
      d = md5ii(d, a, b, c, x[i + 3], 10, -1894986606)
      c = md5ii(c, d, a, b, x[i + 10], 15, -1051523)
      b = md5ii(b, c, d, a, x[i + 1], 21, -2054922799)
      a = md5ii(a, b, c, d, x[i + 8], 6, 1873313359)
      d = md5ii(d, a, b, c, x[i + 15], 10, -30611744)
      c = md5ii(c, d, a, b, x[i + 6], 15, -1560198380)
      b = md5ii(b, c, d, a, x[i + 13], 21, 1309151649)
      a = md5ii(a, b, c, d, x[i + 4], 6, -145523070)
      d = md5ii(d, a, b, c, x[i + 11], 10, -1120210379)
      c = md5ii(c, d, a, b, x[i + 2], 15, 718787259)
      b = md5ii(b, c, d, a, x[i + 9], 21, -343485551)

      a = safeAdd(a, olda)
      b = safeAdd(b, oldb)
      c = safeAdd(c, oldc)
      d = safeAdd(d, oldd)
    }
    return [a, b, c, d]
  }

  /*
  * Convert an array of little-endian words to a string
  */
  function binl2rstr (input) {
    var i
    var output = ''
    var length32 = input.length * 32
    for (i = 0; i < length32; i += 8) {
      output += String.fromCharCode((input[i >> 5] >>> (i % 32)) & 0xff)
    }
    return output
  }

  /*
  * Convert a raw string to an array of little-endian words
  * Characters >255 have their high-byte silently ignored.
  */
  function rstr2binl (input) {
    var i
    var output = []
    output[(input.length >> 2) - 1] = undefined
    for (i = 0; i < output.length; i += 1) {
      output[i] = 0
    }
    var length8 = input.length * 8
    for (i = 0; i < length8; i += 8) {
      output[i >> 5] |= (input.charCodeAt(i / 8) & 0xff) << (i % 32)
    }
    return output
  }

  /*
  * Calculate the MD5 of a raw string
  */
  function rstrMD5 (s) {
    return binl2rstr(binlMD5(rstr2binl(s), s.length * 8))
  }

  /*
  * Calculate the HMAC-MD5, of a key and some data (raw strings)
  */
  function rstrHMACMD5 (key, data) {
    var i
    var bkey = rstr2binl(key)
    var ipad = []
    var opad = []
    var hash
    ipad[15] = opad[15] = undefined
    if (bkey.length > 16) {
      bkey = binlMD5(bkey, key.length * 8)
    }
    for (i = 0; i < 16; i += 1) {
      ipad[i] = bkey[i] ^ 0x36363636
      opad[i] = bkey[i] ^ 0x5c5c5c5c
    }
    hash = binlMD5(ipad.concat(rstr2binl(data)), 512 + data.length * 8)
    return binl2rstr(binlMD5(opad.concat(hash), 512 + 128))
  }

  /*
  * Convert a raw string to a hex string
  */
  function rstr2hex (input) {
    var hexTab = '0123456789abcdef'
    var output = ''
    var x
    var i
    for (i = 0; i < input.length; i += 1) {
      x = input.charCodeAt(i)
      output += hexTab.charAt((x >>> 4) & 0x0f) + hexTab.charAt(x & 0x0f)
    }
    return output
  }

  /*
  * Encode a string as utf-8
  */
  function str2rstrUTF8 (input) {
    return unescape(encodeURIComponent(input))
  }

  /*
  * Take string arguments and return either raw or hex encoded strings
  */
  function rawMD5 (s) {
    return rstrMD5(str2rstrUTF8(s))
  }
  function hexMD5 (s) {
    return rstr2hex(rawMD5(s))
  }
  function rawHMACMD5 (k, d) {
    return rstrHMACMD5(str2rstrUTF8(k), str2rstrUTF8(d))
  }
  function hexHMACMD5 (k, d) {
    return rstr2hex(rawHMACMD5(k, d))
  }

  function md5 (string, key, raw) {
    if (!key) {
      if (!raw) {
        return hexMD5(string)
      }
      return rawMD5(string)
    }
    if (!raw) {
      return hexHMACMD5(key, string)
    }
    return rawHMACMD5(key, string)
  }

  if (typeof define === 'function' && define.amd) {
    define(function () {
      return md5
    })
  } else if (typeof module === 'object' && module.exports) {
    module.exports = md5
  } else {
    $.md5 = md5
  }
})(this)
;
(function () {
    //
    // !! THIS FILE REQUIRES MXSHARED !!
    //
    // Do not copy this this script is intended to be unique
    // and shared among all the master pages
    // all the functions here must be declared here and only here

    window.MXT = window.MXT || {};

    MXT.IsMobile = IsMobile;
    MXT.IsTablet = IsTablet;

    //Mobile handler
    function IsMobile(ignoreCookie) {
        if (!MXT.getCookie('ismobile') || ignoreCookie) {
            if (!MXT.IsTablet() && (MXT.CheckUserAgent(['ipod', 'iphone', 'android', 'blackberry', 'palm', 'smartphone', 'windows ce']))) {
                if (ignoreCookie == false) {
                    MXT.setCookie('ismobile', true);
                }
                return true;
            }
            else {
                if (ignoreCookie == false) {
                    MXT.setCookie('ismobile', false);
                }
                return false;
            }
        }
        else {
            if (MXT.getCookie('ismobile')) {
                return MXT.getCookie('ismobile').toLowerCase() === 'true' ? true : false;
            }
            return false;
        }
    }

    function IsTablet() {
        if (MXT.CheckUserAgent(["ipad", "android!mobile", "tablet", "kindle", "playbook", "xoom", "sch-i800"])) {
            return true;
        }
        return false;
    }
})();;
(function () {
    window.MXT = window.MXT || {};

    // =============== MXT Interface
    MXT.ProductUrlCarry = ProductUrlCarry;

    // =============== MXT Methods

    /**
     * Finds Sign Up or Upgrade buttons and attaches any page url querystrings to it's href
     * Button querystrings have a higher priority than the page querystrings. So if both have
     * the same parameter, the button rules.
     * */
    function ProductUrlCarry() {
        let pagequerystring, productBuyButtons, buttonUrl, $button, url;

        // Get pages url
        pagequerystring = MXT.MxUrl(document.location.href);

        // Grab all upgrade buttons on page
        productBuyButtons = $('.--upgrade');

        productBuyButtons.each(function (index, button) {
            // Get button iteration back into jquery
            $button = $(button);
            // Get this button's url
            buttonUrl = MXT.MxUrl($button.attr('href'));

            // Copy the all of the button params into the page url
            // This sets the priority of buttons over page
            pagequerystring.MergeParams(buttonUrl.params);

            // Copy the params back into the button
            buttonUrl.MergeParams(pagequerystring.params);

            // Assign the full url to the button
            url = buttonUrl.GetUrl();
            $button.attr('href', url);
        });
    }
})();
/**
 * Object.assign()

 * The Object.assign() method is used to copy the values of all enumerable own properties 
 * from one or more source objects to a target object. It will return the target object.
 */
if (typeof Object.assign !== 'function') {
    // Must be writable: true, enumerable: false, configurable: true
    Object.defineProperty(Object, "assign", {
        value: function assign(target, varArgs) { // .length of function is 2
            'use strict';
            if (target === null || target === undefined) {
                throw new TypeError('Cannot convert undefined or null to object');
            }

            var to = Object(target);

            for (var index = 1; index < arguments.length; index++) {
                var nextSource = arguments[index];

                if (nextSource !== null && nextSource !== undefined) {
                    for (var nextKey in nextSource) {
                        // Avoid bugs when hasOwnProperty is shadowed
                        if (Object.prototype.hasOwnProperty.call(nextSource, nextKey)) {
                            to[nextKey] = nextSource[nextKey];
                        }
                    }
                }
            }
            return to;
        },
        writable: true,
        configurable: true
    });
}



/**
 * window.Promise Polyfill

 * Lightweight ES6 Promise polyfill for the browser and node. Adheres closely to the spec. 
 * It is a perfect polyfill IE or any other browser that does not support native promises.
 */
(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory() :
        typeof define === 'function' && define.amd ? define(factory) :
            (factory());
}(this, (function () {
    'use strict';

    /**
     * @this {Promise}
     */
    function finallyConstructor(callback) {
        var constructor = this.constructor;
        return this.then(
            function (value) {
                // @ts-ignore
                return constructor.resolve(callback()).then(function () {
                    return value;
                });
            },
            function (reason) {
                // @ts-ignore
                return constructor.resolve(callback()).then(function () {
                    // @ts-ignore
                    return constructor.reject(reason);
                });
            }
        );
    }

    // Store setTimeout reference so promise-polyfill will be unaffected by
    // other code modifying setTimeout (like sinon.useFakeTimers())
    var setTimeoutFunc = setTimeout;

    function isArray(x) {
        return Boolean(x && typeof x.length !== 'undefined');
    }

    function noop() { }

    // Polyfill for Function.prototype.bind
    function bind(fn, thisArg) {
        return function () {
            fn.apply(thisArg, arguments);
        };
    }

    /**
     * @constructor
     * @param {Function} fn
     */
    function Promise(fn) {
        if (!(this instanceof Promise))
            throw new TypeError('Promises must be constructed via new');
        if (typeof fn !== 'function') throw new TypeError('not a function');
        /** @type {!number} */
        this._state = 0;
        /** @type {!boolean} */
        this._handled = false;
        /** @type {Promise|undefined} */
        this._value = undefined;
        /** @type {!Array<!Function>} */
        this._deferreds = [];

        doResolve(fn, this);
    }

    function handle(self, deferred) {
        while (self._state === 3) {
            self = self._value;
        }
        if (self._state === 0) {
            self._deferreds.push(deferred);
            return;
        }
        self._handled = true;
        Promise._immediateFn(function () {
            var cb = self._state === 1 ? deferred.onFulfilled : deferred.onRejected;
            if (cb === null) {
                (self._state === 1 ? resolve : reject)(deferred.promise, self._value);
                return;
            }
            var ret;
            try {
                ret = cb(self._value);
            } catch (e) {
                reject(deferred.promise, e);
                return;
            }
            resolve(deferred.promise, ret);
        });
    }

    function resolve(self, newValue) {
        try {
            // Promise Resolution Procedure: https://github.com/promises-aplus/promises-spec#the-promise-resolution-procedure
            if (newValue === self)
                throw new TypeError('A promise cannot be resolved with itself.');
            if (
                newValue &&
                (typeof newValue === 'object' || typeof newValue === 'function')
            ) {
                var then = newValue.then;
                if (newValue instanceof Promise) {
                    self._state = 3;
                    self._value = newValue;
                    finale(self);
                    return;
                } else if (typeof then === 'function') {
                    doResolve(bind(then, newValue), self);
                    return;
                }
            }
            self._state = 1;
            self._value = newValue;
            finale(self);
        } catch (e) {
            reject(self, e);
        }
    }

    function reject(self, newValue) {
        self._state = 2;
        self._value = newValue;
        finale(self);
    }

    function finale(self) {
        if (self._state === 2 && self._deferreds.length === 0) {
            Promise._immediateFn(function () {
                if (!self._handled) {
                    Promise._unhandledRejectionFn(self._value);
                }
            });
        }

        for (var i = 0, len = self._deferreds.length; i < len; i++) {
            handle(self, self._deferreds[i]);
        }
        self._deferreds = null;
    }

    /**
     * @constructor
     */
    function Handler(onFulfilled, onRejected, promise) {
        this.onFulfilled = typeof onFulfilled === 'function' ? onFulfilled : null;
        this.onRejected = typeof onRejected === 'function' ? onRejected : null;
        this.promise = promise;
    }

    /**
     * Take a potentially misbehaving resolver function and make sure
     * onFulfilled and onRejected are only called once.
     *
     * Makes no guarantees about asynchrony.
     */
    function doResolve(fn, self) {
        var done = false;
        try {
            fn(
                function (value) {
                    if (done) return;
                    done = true;
                    resolve(self, value);
                },
                function (reason) {
                    if (done) return;
                    done = true;
                    reject(self, reason);
                }
            );
        } catch (ex) {
            if (done) return;
            done = true;
            reject(self, ex);
        }
    }

    Promise.prototype['catch'] = function (onRejected) {
        return this.then(null, onRejected);
    };

    Promise.prototype.then = function (onFulfilled, onRejected) {
        // @ts-ignore
        var prom = new this.constructor(noop);

        handle(this, new Handler(onFulfilled, onRejected, prom));
        return prom;
    };

    Promise.prototype['finally'] = finallyConstructor;

    Promise.all = function (arr) {
        return new Promise(function (resolve, reject) {
            if (!isArray(arr)) {
                return reject(new TypeError('Promise.all accepts an array'));
            }

            var args = Array.prototype.slice.call(arr);
            if (args.length === 0) return resolve([]);
            var remaining = args.length;

            function res(i, val) {
                try {
                    if (val && (typeof val === 'object' || typeof val === 'function')) {
                        var then = val.then;
                        if (typeof then === 'function') {
                            then.call(
                                val,
                                function (val) {
                                    res(i, val);
                                },
                                reject
                            );
                            return;
                        }
                    }
                    args[i] = val;
                    if (--remaining === 0) {
                        resolve(args);
                    }
                } catch (ex) {
                    reject(ex);
                }
            }

            for (var i = 0; i < args.length; i++) {
                res(i, args[i]);
            }
        });
    };

    Promise.resolve = function (value) {
        if (value && typeof value === 'object' && value.constructor === Promise) {
            return value;
        }

        return new Promise(function (resolve) {
            resolve(value);
        });
    };

    Promise.reject = function (value) {
        return new Promise(function (resolve, reject) {
            reject(value);
        });
    };

    Promise.race = function (arr) {
        return new Promise(function (resolve, reject) {
            if (!isArray(arr)) {
                return reject(new TypeError('Promise.race accepts an array'));
            }

            for (var i = 0, len = arr.length; i < len; i++) {
                Promise.resolve(arr[i]).then(resolve, reject);
            }
        });
    };

    // Use polyfill for setImmediate for performance gains
    Promise._immediateFn =
        // @ts-ignore
        (typeof setImmediate === 'function' &&
            function (fn) {
                // @ts-ignore
                setImmediate(fn);
            }) ||
        function (fn) {
            setTimeoutFunc(fn, 0);
        };

    Promise._unhandledRejectionFn = function _unhandledRejectionFn(err) {
        if (typeof console !== 'undefined' && console) {
            console.warn('Possible Unhandled Promise Rejection:', err); // eslint-disable-line no-console
        }
    };

    /** @suppress {undefinedVars} */
    var globalNS = (function () {
        // the only reliable means to get the global object is
        // `Function('return this')()`
        // However, this causes CSP violations in Chrome apps.
        if (typeof self !== 'undefined') {
            return self;
        }
        if (typeof window !== 'undefined') {
            return window;
        }
        if (typeof global !== 'undefined') {
            return global;
        }
        throw new Error('unable to locate global object');
    })();

    if (!('Promise' in globalNS)) {
        globalNS['Promise'] = Promise;
    } else if (!globalNS.Promise.prototype['finally']) {
        globalNS.Promise.prototype['finally'] = finallyConstructor;
    }

})));;
