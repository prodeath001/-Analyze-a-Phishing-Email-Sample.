﻿(function () {
    // Do not copy this this script is intended to be unique
    // and shared among all the master pages
    // all the functions here must be declared here and only here

    // =============== Windows Interface
    // These are here for backwards compatibility. We should remove calls to these
    // and replace them with MXT calls.
    // Be aware that any functionality that needs to work on any browers that 
    // do not support a root object called 'window' will fail. Some stateless 
    // browsers are like this

    window.MXT = window.MXT || {};
    MXT.ToggleSlide = ToggleSlide;

    // Meant to be called from LookupResultHtmlView
    function ToggleSlide(slideSelector, buttonSelector) {
        let button = $(buttonSelector);
        let slides = $(slideSelector);

        if (button.length > 0 && slides.length > 0) {
            if ($(slides[0]).css('display') == 'block') {
                button.text('Show');
            } else {
                button.text('Hide');
            }
            slides.slideToggle('slow');
        }

        return false;
    }
})();