/* Minification failed. Returning unminified contents.
(141,51-52): run-time error JS1014: Invalid character: `
(142,21-22): run-time error JS1100: Expected ',': :
 */
(function () {
    const TEMPLATE_TOP_MENU = "/public/templates/mx-top-menu/mx-top-menu.html";
    const TEMPLATE_USER = "/public/templates/mx-top-menu/mx-top-menu-user.html";
    const TEMPLATE_ANONYMOUS = "#mx-tm-template-anonymous";
    const LOCATION_KEY = MXT.currentLocation || 'supertool';

    let _menu_element = "#mx-top-menu";
    let _user_element = "#mx-tm-user";

    let _active_menus = {};
    let _active_primary = undefined;

    // When jquery is ready
    window.addEventListener('load', function () {
        // If we are in the top window, initialize the menu
        // otherwise, this is being loaded in an iframe and we don't want to initialize the menu
        if (window.self === window.top) {
            Init();
            $('.mx-tm-cloak').removeClass('mx-tm-cloak');
        } else {
            $('#mx-top-menu').hide();
            $('footer').hide();
        }
    });

    function Init() {
        SetActiveMenus();
        LoadTemplate({
            destination_selector: _menu_element,
            template_url: TEMPLATE_TOP_MENU,
            data: {
                menus: _active_menus,
                config: {
                    isWorking: false,
                    logo_destination: '/SuperTool.aspx',
                    loading: false,
                    logged_in: true,
                    show_second_bar: true,
                    active_nav: undefined
                }
            }
        }, function () {
            LoadUser();
        });
    }

    function LoadTemplate(item, callback) {
        if (item.template_url) {
            if (item.template_url[0] === '#') {
                RenderContent(item.destination_selector, $(item.template_url).html(), item.data);
                if (callback) { callback() };
            } else {
                $.ajax(item.template_url, {
                    async: false,
                    cache: true,
                    dataType: 'html',
                    type: 'GET',
                    success: function (content) {
                        RenderContent(item.destination_selector, content, item.data);
                        if (callback) { callback() };
                    },
                    error: function (xhr, status, error) {
                        console.log('Error loading template: ' + item.template_url);
                    }
                });
            }
        }
    }

    function RenderContent(selector, template_html, data) {
        // Uses jquery's 'template' system to set the HTML in it's cacheing system, if it's not already there.
        $.templates({ tmpl: template_html });

        // Use jsRender to combine the HTML template and data, then insert the rendered template into the selector element.
        $(selector).html($.render.tmpl(data));
    }

    function LoadUser() {
        // Render current cookie while we wait
        LoadUserTemplate(JSON.parse(MXT.getCookie('_mxt_u')));
        MXT.OnUserLoaded(function (event, content) {
            LoadUserTemplate(content);
        });
    }

    function LoadUserTemplate(content) {
        LoadTemplate({
            destination_selector: _user_element,
            template_url: (content && content.IsLoggedIn) ? TEMPLATE_USER : TEMPLATE_ANONYMOUS,
            data: {
                user: content,
                user_menu: _active_menus.user
            }
        });
    }

    function SetActiveMenus() {
        let path = window.location.pathname.toLowerCase();

        _active_menus.user = GetUserMenu();
        _active_menus.primary = GetPrimaryMenu(LOCATION_KEY);
        _active_menus.site = GetSiteMenu(_active_primary.site);
        _active_menus.secondary = GetSecondaryMenu(path, _active_primary.id);
    }

    function GetUserMenu() {
        let user_menu_config = [
            {
                id: 'settings',
                text: 'Settings',
                url: '/user'
            },
            {
                id: 'billing',
                text: 'Billing',
                url: '/user/billing.aspx'
            }
        ];
        return user_menu_config;
    }

    function GetPrimaryMenu(location_key) {
        let primary_menu_config = [
            {
                id: 'pricing',
                text: 'Pricing',
                url: '/c/products/matrixdos?feature=no-feature-selected&source=pricing',
                grep: '/c/products',
                site: 'supertool'
            },
            {
                id: 'supertool',
                text: 'Tools',
                url: '/SuperTool.aspx',
                grep: ['','/SuperTool.aspx'],
                site: 'supertool'
            },
            {
                id: 'delivery',
                text: 'Delivery Center',
                url: (MXT && MXT.DELIVERY_HOST) ? `https://${MXT.DELIVERY_HOST}` : 'https://delivery.mxtoolbox.com',
                site: 'dc2'
            },
            {
                id: 'monitoring',
                text: 'Monitoring',
                url: '/monitoring',
                site: 'monitoring'
            },
            {
                id: 'products',
                text: 'Products',
                url: '/c/mxtoolboxproducts',
                site: 'supertool'
            },
            {
                id: 'blog',
                text: 'Blog',
                url: 'https://blog.mxtoolbox.com?source=greynav',
                site: 'supertool'
            },
            {
                id: 'support',
                text: 'Support',
                url: '/support',
                site: 'supertool'
            }
        ];

        // Set active property on primary menu items
        primary_menu_config.forEach(function(item) {
            item.active = item.id === location_key;
            if (item.active) {
                _active_primary = item;
            }
        });

        if (location_key === 'user') {
            _active_primary = {
                id: 'user',
                site: 'supertool'
            };
        }

        return primary_menu_config;
    } 

    function GetSiteMenu(site_key) {
        let site_menu_config = {
            'supertool' : {
                class: 'fa-duotone fa-toolbox',
                name: 'SuperTool',
            },
            'monitoring' : {
                class: 'fa-duotone fa-display-chart-up',
                name: 'Monitoring',
            },
            'dc2' : {
                class: 'fa-duotone fa-envelope',
                name: 'Delivery Center',
            }
        };

        return site_menu_config[site_key];
    }

    function GetSecondaryMenu(path, primary_key) {
        let secondary_menu_config;

        switch (primary_key) {
            case 'pricing':
                secondary_menu_config = GetSecondaryMenu_Products();
                break;
            case 'tools':
                secondary_menu_config = GetSecondaryMenu_Supertool();
                break;
            case 'delivery':
                secondary_menu_config = GetSecondaryMenu_Delivery();
                break;
            case 'monitoring':
                secondary_menu_config = GetSecondaryMenu_Monitoring();
                break;
            case 'products':
                secondary_menu_config = GetSecondaryMenu_Products();
                break;
            case 'blog':
                secondary_menu_config = GetSecondaryMenu_Blog();
                break;
            case 'support':
                secondary_menu_config = GetSecondaryMenu_Support();
                break;
            case 'user':
                secondary_menu_config = GetSecondaryMenu_User();
                break;
            default:
                secondary_menu_config = GetSecondaryMenu_Supertool();
        }

        secondary_menu_config.left.forEach(fn_set_active(path));
        secondary_menu_config.right.forEach(fn_set_active(path));

        return secondary_menu_config;
    }

    function GetSecondaryMenu_Supertool() {
        let secondary_menu_config = {
            'site': 'supertool',
            'left': [
                {
                    id: 'supertool',
                    text: 'SuperTool',
                    url: '/SuperTool.aspx',
                    grep: ['','/SuperTool.aspx']
                },
                {
                    id: 'mxlookup',
                    text: 'MX Lookup',
                    url: '/MXLookup.aspx'
                },
                {
                    id: 'blacklists',
                    text: 'Blacklists',
                    url: '/blacklists.aspx'
                },
                {
                    id: 'dmarc',
                    text: 'DMARC',
                    url: '/dmarc.aspx'
                },
                {
                    id: 'diagnostics',
                    text: 'Diagnostics',
                    url: '/diagnostic.aspx'
                },
                {
                    id: 'domain',
                    text: 'Email Health',
                    url: '/emailhealth'
                },
                {
                    id: 'dnslookup',
                    text: 'DNS Lookup',
                    url: '/DnsLookup.aspx'
                },
                {
                    id: 'headers',
                    text: 'Analyze Headers',
                    url: '/EmailHeaders.aspx'
                }
            ],
            'right': [
                {
                    id: 'alltools',
                    text: 'All Tools',
                    url: '/NetworkTools.aspx'
                }
            ]
        };
        return secondary_menu_config;
    }

    function GetSecondaryMenu_User() {
        let secondary_menu_config = {
            'site': 'monitoring',
            'left': [
                {
                    text: 'Account Settings',
                    url: '/user/account'
                },
                {
                    text: 'Summary Emails',
                    url: '/user/email'
                },
                {
                    text: '2 Step Verification',
                    url: '/user/twostepverification',
                    class: 'mfa'
                },
                {
                    text: 'Ignored Problems',
                    url: '/user/problems'
                },
                {
                    text: 'Billing',
                    url: '/user/billing.aspx'
                }, {
                    text: 'API',
                    url: '/user/api'
                }
            ],
            'right': [
                {
                    text: 'General Settings',
                    url: '/user/general',
                    class: 'general'
                }
            ]
        };
        return secondary_menu_config;
    }

    function GetSecondaryMenu_Monitoring() {
        let secondary_menu_config = {
            'site': 'monitoring',
            'left': [
                {
                    id: 'notifications',
                    text: 'Notifications',
                    url: '/monitoring/notifications'
                },
                {
                    id: 'tag',
                    text: 'Tags',
                    url: '/monitoring/tag/'
                },
                {
                    id: 'history',
                    text: 'History',
                    url: '/monitoring/history'
                },
                {
                    id: 'availability',
                    text: 'Availability',
                    url: '/monitoring/availability'
                },
                {
                    id: 'outages',
                    text: 'Outages',
                    url: '/monitoring/outages'
                },
                {
                    id: 'addmonitor',
                    text: 'Add Monitor',
                    url: '/monitoring/add'
                }
            ],
            'right': [
                {
                    id: 'alldomains',
                    text: 'All Monitors',
                    url: '/monitoring'
                }
            ]
        };
        return secondary_menu_config;
    }

    function GetSecondaryMenu_Products() {
        let secondary_menu_config = {
            'site': 'supertool',
            'left': [
                {
                    id: 'blsolutions',
                    text: 'Blacklist Solutions',
                    url: '/c/products/matrixdos?source=blackbar',
                    grep: '/c/products/matrixdos'
                },
                {
                    id: 'deliverycenter',
                    text: 'Delivery Center',
                    url: '/c/products/deliverycenter?source=blackbar',
                    grep: '/c/products/deliverycenter'
                },
                {
                    id: 'deliverycenterplus',
                    text: 'Delivery Center Plus',
                    url: '/c/products/deliverycenterplus?source=blackbar',
                    grep: '/c/products/deliverycenterplus'
                },
                {
                    id: 'managedservices',
                    text: 'Managed Services',
                    url: '/c/products/deliverymanaged?source=blackbar',
                    grep: '/c/products/deliverymanaged'
                },
                {
                    id: 'mailflow',
                    text: 'Mailflow Monitoring',
                    url: '/c/products/mailflowmonitoring?source=blackbar',
                    grep: '/c/products/mailflowmonitoring'
                },
                {
                    id: 'bulk',
                    text: 'Bulk Lookups',
                    url: '/c/products/bulk?source=blackbar',
                    grep: '/c/products/bulk'
                }
            ],
            'right': [
                {
                    id: 'allproducts',
                    text: 'All Products',
                    url: '/c/mxtoolboxproducts'
                }
            ]
        };
        return secondary_menu_config;
    }

    function GetSecondaryMenu_Blog() {
        let secondary_menu_config = {
            'site': 'monitoring',
            'left': [
                {
                    id: 'blog',
                    text: 'Blog',
                    url: 'https://blog.mxtoolbox.com?source=greynav'
                }
            ]
        };
        return secondary_menu_config;
    }

    function GetSecondaryMenu_Support() {
        let secondary_menu_config = {
            'site': 'monitoring',
            'left': [
                {
                    id: 'knowledgebase',
                    text: 'Knowledgebase',
                    url: '/DMARC/knowledgebase',
                    grep: ['/knowledgebase']
                },
                {
                    id: 'status',
                    text: 'Status',
                    url: 'https://mxtoolbox.statuspage.io/'
                }
            ],
            'right': [
                {
                    id: 'request',
                    text: 'Support Request',
                    url: '/support'
                }
            ]
        };
        return secondary_menu_config;
    }

    function fn_set_active(path) {
        // Returns a FUNCTION that sets the active property of an item based on the path
        return function(item) {
            // See if there is a .grep or .url to match against
            let find = [];

            // If there is a .grep property, add it to the find array
            if (typeof item.grep != 'undefined') {
                // If the grep property is an array, add each item to the find array
                if (typeof item.grep == 'object') {
                    find = find.concat(item.grep);
                } else {
                    find.push(item.grep);
                }
            }

            // Add the url to the find array
            find.push(item.url);

            // If any of the find items are in the path, set the active property to true
            item.active = find.some(function (x) {
                if (x === '') {
                    return path === '/' || path === '';
                } else {
                    return path.indexOf(x.toLowerCase()) > -1;
                }
            });
        }
    }
})();;
function GetMxWebsite() {
    if (window) {
        if (window.location) {
            if (!window.location.origin) {
                window.location.origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ':' + window.location.port : '');
            }

            return window.location.origin + "/";
        }
    }
    return "http://mxtoolbox.com/";
}

function sendMailTo(name, company, domain) {
    locationstring = 'mai' + 'lto:' + name + '@' + company + '.' + domain;
    window.location.replace(locationstring);
}

// load src files after the page is loaded
function AddDeferredJS(fileLocation) {
    var mycode = document.createElement("script");
    mycode.type = "text/javascript";
    mycode.src = fileLocation;
    var firstScript = $('script')[0];
    firstScript.parentNode.insertBefore(mycode, firstScript);
}

function getParameterByName(name) {
    name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
    var regexS = "[\\?&]" + name + "=([^&#]*)";
    var regex = new RegExp(regexS);
    var results = regex.exec(window.location.href);
    if (results == null)
        return "";
    else
        return decodeURIComponent(results[1].replace(/\+/g, " "));
}

function escapeHtml(str) {
    var div = document.createElement('div');
    div.appendChild(document.createTextNode(str));
    return div.innerHTML;
}

;
//Set up user obj -- I would like this iffy to be generated server side
(function (MXT) {
    MXT.User = MXT.User || {
        isLoggedIn: window._is_logged_in ? true : false,
        isPaid: window._is_paid ? true : false,
        isAdmin: window._is_admin ? true : false
    };
})(window.MXT || (window.MXT = {}));

(function (MXT) {
    var qs = window.location.toString().toLowerCase();

    MXT.Lookup = function (command, success, params) {
        params = params || {};
        params = $.extend({
            type: 'POST',
            async: undefined,
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            data: null
        }, params);
        $.ajax({
            type: params.type,
            async: params.async,
            data: params.data,
            url: MXT.GetMxWebsite() + "public/Lookup.aspx/" + command,
            contentType: params.contentType,
            dataType: params.dataType,
            success: function (msg) {
                success(msg.d);
            },
            error: function (xhr, status, error) {
                console.log(xhr, status, error);
            }
        });
    };

    /**
    *  This acts as normal $.inArray but with the additional capability
    *  to use a callback as the comparison, which is handy for searching
    *  for a value in an array of objects
    *  
    *  @function inArray
    *  @param {any} value - a value to search for
    *  @param {array} ar - the array to search
    *  @param {function} fn - (optional) a function that uses two arguments, the first is this value, the second is the array item. Should return truthy statement
    *  @return {boolean} index of item found or -1 if not found
    */
    MXT.inArray = function (value, ar, fn) {
        fn = fn || function (a, b) {
            return a === b;
        };
        for (var i = 0, len = ar.length; i < len; i++) {
            if (fn(value, ar[i])) {
                return i;
            }
        }
        return -1;
    };

    MXT.IsInArray = function (value, ar, fn) {
        var index = MXT.inArray(value, ar, fn);
        return index !== -1;
    };

    MXT.getParameterByName = function (name) {
        var regexS,
            regex,
            results;
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        regexS = "[\\?&]" + name + "=([^&#]*)";
        regex = new RegExp(regexS);
        results = regex.exec(window.location.href);
        if (results === null)
            return "";
        else
            return decodeURIComponent(results[1].replace(/\+/g, " "));
    };

    /**	
    *  MXT.safe is a great way to get a value from a longer than 1 tier object
    *  Take for example:
    *  		var obj = {objSub1 {objSub2:{objSub3:'value'}}};
    *  		var myValue = obj.objSub1.objSubNonExistant.objSub3; //BIG FAT JS ERROR!
    *  		var myValue = MXT.safe(obj,'objSub1.objSubNonExistant.objSub3','No error here');
    *  		assert(myValue==='No error here',true);
    *  
    *  @function MXT.safe
    *  @param {object} the base object
    *  @param {string} string representation of object path to value
    *  [@param] {any type} [defaultValue=undefined] if the path fails to find a value, this is returned
    *  @return whatever value is at the end of the object path or the default value, if set.. otherwise undefined
    */

    MXT.safe = function (parentObj, pathValue, defaultValue) {
        var parentCopy = parentObj;
        pathValue = pathValue.split('.');
        for (var i = 0, len = pathValue.length; i < len; i++) {
            if (parentCopy[pathValue[i]] !== undefined) {
                parentCopy = parentCopy[pathValue[i]];
            } else {
                return defaultValue;
            }
        }
        return parentCopy;
    };

    Array.prototype.stringPrepend = function(value, startIndex, endIndex){
        var i, len;
        var returnArray = [];
        startIndex = startIndex || 0;
        endIndex = endIndex || this.length - 1;

        for ( i = 0, len = this.length; i < len; i++ ){
            if (typeof this[i] === 'string' && i >= startIndex && i <= endIndex){
                returnArray.push(value + this[i]);
            } else {
                returnArray.push(this[i]);
            }
        }

        return returnArray;
    };

    window.MXT = MXT;
})(window.MXT || (window.MXT = {}));;
(function () {
    window.addEventListener('load', function () {
        var _qs = GetQuerystring();
        var _opttestCalled = 0;

        Init();

        function Init() {
            // Look at MXT.masterMin if we want to behave different for that master
            // Both are the same at the moment

            // ST Ads: Static content
            SetTemplate('#template_ad_static', '.supertool_ad_static', {});
            MXT.AddABTestTrigger('Supertool_Ads_Loaded_Static', {});

            // Load user data
            LoadUser();

            // Set IpAddress
            setIpAddress();
        }

        function GetQuerystring() {
            var queries = {};
            $.each(document.location.search.substr(1).split('&'), function (c, q) {
                var i = q.split('=');
                if (i[0] && i[1]) {
                    queries[i[0]] = i[1];
                }
            });
            return queries;
        }

        // Templates
        function LoadTemplates(data) {
            _opttestCalled++;
            if (data) {
                // Main Menu
                if (data.IsLoggedIn) {
                    // ST Ads: Dynamic content
                    if (data.IsPaidUser) {
                        SetTemplate('#template_ad_paid', '.supertool_ad_dynamic', data, true);
                    } else {
                        SetTemplate('#template_ad_free', '.supertool_ad_dynamic', data, true);
                    }
                } else {
                    // ST Ads: Dynamic content (animation OFF due to AB-654)
                    SetTemplate('#template_ad_anon', '.supertool_ad_dynamic', data, false);
                }

                // Enable Batch Tool for certain paying customers
                checkDisabledAccount(data);
            }
            else {
                // ST Ads: Dynamic content (animation OFF due to AB-654)
                SetTemplate('#template_ad_anon', '.supertool_ad_dynamic', {}, false);

            }

            MXT.AddABTestTrigger('Supertool_Ads_Loaded_Dynamic', {});
        }

        function SetTemplate(templateName, target, data, animate) {
            // Skip if it has content and has already been replaced by an HTML AB Test
            if ($(target).children().length > 0 && ($(target).hasClass('mx-ab') || $(target).find('.mx-ab').length !== 0)) {
                return;
            }

            //ST ads: tracking URL
            data.st_tracking_url = 'utm_campaign=1280&utm_medium=banner&utm_source=';

            if ($.templates) {
                var template = $.templates(templateName);
                var html = template.render(data);
                if (animate) {
                    $(target).html(html);
                    // Wait, then animate
                    setTimeout(function () { $(target).slideDown(1000); }, 100);
                } else {
                    // Render, wait, then show
                    $(target).html(html);
                    setTimeout(function () { $(target).show(); }, 100);
                }
            }
        }

        function checkDisabledAccount(data) {
            /*
            * We use this AndAlso so that we can rely on the cached sv.IsPastDue 99.9% of the time,
            * but we get the live version to make sure you still are past due and you didn't just pay us
            */
            if (data.IsPastDue) {
                // You owe us money is more important than us telling you that email has been bounced
                $('[id$="lblDisabledUser"]').text('Your account is over 30 days past due');
                $('[id$="lbDisabledUser"]').text('Update Your Credit Card');
                $('[id$="lbDisabledUser"]').attr('href', GetMxWebsite() + 'public/checkout/UpdateCardInfo.aspx?uid=' + data.XID);
                $('[id$="trDisabledUser"]').show();
                $('[id$="divDisabledUser"]').show();
            } else if (data.BouncedEmailOn || _qs['ShowDisabled']) {
                // Your email bounced
                var defSettingURL = '/user';
                if (data.IsPaidUser) {
                    defSettingURL = '/user/password';
                }
                $('[id$="lblDisabledUser"]').text('Your account is disabled because your email address bounced');
                $('[id$="lbDisabledUser"]').text('Update Your Email');
                $('[id$="lbDisabledUser"]').attr('href', GetMxWebsite() + defSettingURL);
                $('[id$="trDisabledUser"]').show();
                $('[id$="divDisabledUser"]').show();
            }
        }

        // Load user data (Templates and NavBar)
        function LoadUser() {
            // Render current cookie while we wait
            LoadTemplates(JSON.parse(MXT.getCookie('_mxt_u')));

            MXT.OnUserLoaded(function (event, user) {
                // Load Templates
                LoadTemplates(user);
            });
        }

    });
})();

//Save in the site the cardClick 
function ClickCardAd(cardSlotID, CardVariationID, VisitorState, navigateUrl) {
    // call the web method on-success/fail redirect
    var params = {
        "CardSlotId": cardSlotID.toString(),
        "CardVariationId": CardVariationID,
        "VisitorState": VisitorState
    };
    $.ajax({
        type: "POST",
        url: GetMxWebsite() + "Public/Lookup.aspx/AdCardClick",
        data: JSON.stringify(params),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function () {
            window.location.href = navigateUrl;
        },
        error: function () {
            MxErrorHandler("", "ClickCardAd: ");
            console.log(arguments);
            window.location.href = navigateUrl;
        }
    });
}

//Hides Menu from Master Page Previously ShowMenu on Master Page
function HideMasterMenu() {
    $('[id$="pnlMenu"]').hide();
}


/* Sends Click from Iframe to Signup URL on top page
* @param redirectType
 */
function MasterSignUpRedirect(redirectType, srcPage) {
    let redirectString = "";
    let mxDomain = MXT.DomainName || 'mxtoolbox.com';

    if (redirectType.indexOf('PB_FREE') == -1) {
        redirectString = 'https://' + mxDomain + '/public/checkout/delivery2/v1.aspx?so=' + redirectType + '&page=' + srcPage + '&upgrade=' + srcPage;
    } else {
        redirectString = 'https://' + mxDomain + '/public/registration.aspx?so=' + redirectType + '&feature=no-feature-selected&source=pricing&upgrade=' + srcPage + '&page=' + srcPage + '&buffer=true';
    }

    let queryStrings = getQueryStringPassOver();

    if (queryStrings.length > 0) {
        redirectString += '&' + queryStrings;
    }
    window.location.href = redirectString;
}

function getQueryStringPassOver() {
    // Find queryString to pass
    let qStringPass = window.location.search;
    //Make sure there is a query to pass
    if (qStringPass.length > 0) {
        //Remove the first ? on QS
        qStringPass = qStringPass.replaceAll("?", "");
        //Remove the first Amperson if there is one
        if (qStringPass.indexOf("&") == 0) {
            qStringPass = qStringPass.substring(1);
        }
        return qStringPass;
    }
    return "";
}

/**
 * Handles Click To Learn More from Iframe on top page
 * @param learnmoreType
 */
function MasterLearnMoreRedirect(learnmoreType, srcPage) {
    let mxDomain = MXT.DomainName || 'mxtoolbox.com';
    let redirectString = 'https://' + mxDomain + '/c/products/' + learnmoreType + '?source=' + srcPage;
    let queryStrings = getQueryStringPassOver();

    if (queryStrings.length > 0) {
        redirectString += '&' + queryStrings;
    }
    window.location.href = redirectString;
};
